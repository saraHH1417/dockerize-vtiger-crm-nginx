In List view:

Page Up/Page Down to page through the listing
ctrl+a to add a new item to the list
In Detail view:

ctrl+e to edit
ctrl+d to duplicate
Page up/Page down to navigate through the related items
right/left to move to the next or previous entry
In Edit view

ctrl+s to save
Everywhere

ctrl+k to go to the list view
escape to go back to the previous screen
