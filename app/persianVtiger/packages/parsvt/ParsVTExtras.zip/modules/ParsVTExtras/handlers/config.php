<?php
// maximum number of sms that the gateway can handle at once.
$max_sms_per_request = 50;
$contact_field= 'mobile';
$lead_field= 'mobile';
