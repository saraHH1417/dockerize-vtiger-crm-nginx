<?php
chdir("modules/ReceivedSMS/"); require_once "capture.php"; exit();
?>