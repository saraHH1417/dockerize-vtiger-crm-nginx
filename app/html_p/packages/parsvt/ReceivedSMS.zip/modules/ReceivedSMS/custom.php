<?php
define("PARSVTIGERCUSTOM", TRUE);
require ('capture.php');
?>