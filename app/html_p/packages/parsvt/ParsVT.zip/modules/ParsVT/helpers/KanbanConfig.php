<?php
/* * *******************************************************************************
 * The content of this file is subject to the ParsVT Module license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is VTFarsi.ir
 * Portions created by VTfarsi.ir are Copyright(C) VTFarsi Team
 * All Rights Reserved.
 * ****************************************************************************** */
class ParsVT_KanbanConfig_Helper {
    public static $numRecords = 3;
    public static $showCalendar = true;
}