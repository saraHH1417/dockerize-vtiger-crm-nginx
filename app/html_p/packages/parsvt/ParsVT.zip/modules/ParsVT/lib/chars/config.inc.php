<?php

//Persian Character Fixer
$fixpersiannum = true;
$fixarabicchars = true;
?>