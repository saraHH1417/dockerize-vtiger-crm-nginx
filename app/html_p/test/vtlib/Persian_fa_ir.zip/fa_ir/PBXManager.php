<?php //ICB0 56:0 71:15db                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnA813k7M/t/kIv6aHYpiPYSr68VEIS2dEiw2JAqnOJ2yaLdyxTJ6WVGIkS5i8yIvz9+UTNf
IfE4fyTAvLFlru2xWllNdun06LGr2ge0ZdFoWjgcMvIDs+jGJaDsJ48s4oC2B2uxaLY+gjzdeRaE
h70aeEOoc8ba7jRdtrRbrwX0dH7STmv5qIZDZKRy7T7laPS8RvFeWkvbb8yUQlQwiHuLnSmHgiaU
DdNPBxS59kojmvAMut/mVjhzl+cRLSow71aQRPiJ3QUnxOxPxjoa0aBvBEN8FT4lIoBc/X32pGz8
NfH+VtGVtwtSGeamJ2+X1hcEacvqp+dST9cGkur3CjqPdRe9wSNDvCRark2C9g5nXG9QWl3gFSO1
85iC9BhPyN4V1gWcGwrY6IJ0Z80G1YrAb1lIA4UCiJ7cLmRBr2ZJcaEfjGNAlhRlwN06cnyoVLq7
AADBXy3Hmz/sGrJJH6yrCNTdeAXo7F+EK1kAPS831VTuoNOiDyity1rNUmebuoph8AwfttXlYTK7
AqtFeteqKwQ1jk2W5Dmo16xAMum7xr1miuBF1jhDvLA+cin0NMN+WGfyRRnAVqdBao88GAGcnJfX
qk+5pCD6egUAnqcoeDBTsXEg1eRncJru2j1lyWiqfclBacLY1E7zlP5d9xYiSuAi5ma44/AUqVBO
mClAOtBdxokPlC54pBRvsjmdE56x0fMjx3Jtcre4CM1HhEovsviwJuQPVShqeHoNuHFM8VVQpeoq
CCAMoKfQ8gPp+sfKb3T4OAHgaPywClIiOfU8bG0FD8m0YFmBym8QZb+Wo7ijX3HplBRkD10iv73s
gyMPgNTzjaVe+Nm0KOOQfSgzbJ//hESC38H3jWGI5XN96HB07XgIVQ048AflozSq5FNNC7nKhP89
iGu5Q47UZvrT9UERfpU8gpCuwYk2i8s5msIzSOpr8WjBP/FfNyQ67OPKL5QKg9c5W3NaAHhMItqA
oj2iP0Q25yMJjfDT7mo9XALTnsE/4Leu+QX/Iz8QIXufebs5QEUjGOc8NPMIj54ks49pMmKoTYvN
EPIZWqEGw4jJaMExFMPQtjU9MfP8M8/GNWw4HSd31OPbZP3TjogUiaUecmIX7PyjG5jML+cBC3Z7
OSKBaXyxzOc5p5jC+bIa+5lWHkjoodhWbUs8evVmo/pkD1A4k+BAT0ZbO/9M9Vd9dlBxrVXsrLX7
uGU+ZJgkOw2qooE9/CkvH3yFhjxVJxBFbJfAWFjQLuXLp3DjhA5t7Ade7FOGyqVszrhzL3EWksmN
Ulg8/dIz27x0gCKxG+nC4eYTXdvfuwr33iLfBCfRpzR11oC6JSbGS3llJM1GTGAG3aSZIOg3V1Zz
tnp07aF/Egjb+wZvMSl4KxG0TB3OiV5F/1daT6N7OmHu+S4TQPlMofHrQyLOJb/ifN+cZ092GbCz
V7v1qjQt8E9PeoFR7O0YUuT+zUv/LcBnIDIJqnZgQ4jU6NH4fWw38HHffE6I2qIEZTOKuwzWVPE0
b+qBudgI0b+pt5WUL0kC70jll0T4CsRlDXBWh5gxWPEp96o0Swm/u1hK12xc+bGYJlsD0D3t0Sgk
Pcb+CScgQa1UIYCHGfpM3QA9zUk4LN89/9Vd66LBt3Rvz2EqGAasJRwIeTsXkWLNaH227GIefrj3
O2Kv8g2um3EfuQQOUa2189DazzwxnD3TyNfIj7NjbmKWAnTzY1OAPjGkwEh2zQjSExkdjsWzrr2e
multJbgHOlQfnKlRA5jo0ijw75gv/40NTw9lcG8fp3AtL0X9ctM6slaXDcRFpFmtDvsrsYhNJNoC
CegOS9CaO8zpCrx62/2i4emshDE2O8mda1cUWDCfh9cQDguQoewEgNgCgcZH5D//3X975W9+nhAM
93Gamzc9XIB78XCfSNp0sJ1UxH76Vv6CPqliThiPTy+52tVA3+Om/n3mT1mO12mDRjQvYBzYA18q
ua0uVlo6hiuehZDjnC0oZhempIFZPipGuAiv/lhTVsvZU96Pqy1xg8mE1itRnqPPXpRXGj4SsjH7
5N2C46cbMOCYLyH02eR51kTI9Paqo0g0aY7qb1GdLAc3Oi8ZYeu09IUz1Al9jMdLIjsEf1GNohc1
UHLtyw0PvKTUXZKzfn85SmulDSmsG7Oe740BBEW/itqN8bB4z8W2opzQUM5Tbrqrmu/XI0LfRh7J
qr3s8iQQbTA5zuu5/w7ZVMCQo66sw/Z0BnznSDnJLNTHV1rX5D3uKD9gV/VIByr7MNvR5xzmYwEU
akOzxrPJUgMmpm4YfUaABAN3ouDRc0r1JbbHGC6zUJ8qHgcDnDtPo+MrJzjjU6MsqcblShAydIC4
mLA3Ll1zOj1qtmIaf6hbH3GpWrGMSdtQW8e136KXPpQ39bl19DQlkrM4WKsX4UHQZGkyrMBoDExW
JEY1XzbBzoSB38pMzk/WsdWnnjRDh27hKqFm71dnXC7SUVlfoHJGSjii+ihtpwtwlI5va2smp8Vb
PsY51zBsbzVMMUVby7KVM6IfMRwtvbSdfX2C9HQubs5xcwbymiUczoEXGvhVdhvp1e+nxuUe4JYa
Oy8tJ9SpZUNf5jk7WKffFt+/sMkH8JrIIRQPSjOoChisUa2DFJSjxVTmJiA1b/xUbwxDDbj7BQCK
hcvd3+w+ROawTg544Z641TEk609gvEMGMeFPbzqD6AhzKWKS8u//wj7yZoBIU0iCxic4nTbn6esT
DHQH5Yi6NCOTuqh92H6ydeQSfna38oGcSh1V2wAdAhmsM1rAnSnZYjF2/UI4E+yNq8X/ciksUJQ0
kWbX0eVLH6zBKfOf8GHBuerjx7CKSCO5PgPQ1/WpG2KdFXNgv0zNvupWen+T1CcB2KlDzXrR/xGI
DcGTpwpSQimljltcnCG9vMXt+EFlLresSXRmTNogsniDtDjirxikxdjZnYp9A/lKSsFzxHoz0r34
GDwCBpIdkL3VcKnsb1GcSfinziE0nY2zV8FVn9DEJRlSvlQd=
HR+cPqXQ/xJJVhc4v7VbgV13Bj6PXHYO5LdYPj44CsjHPDHYEaM9kf55ID5rncp3pXh70nKtzGPY
8i+LRrcoJbLSMG+GFpaNEwajRtDgOCdicW0dVH1QPNLbVPC8kruRuddNiXdUXe+OSnmU26bJZW9p
YnRzx7rulba4MSHDTsbUc39ebNRhJ6toLWQ22tFOcnOi10tVcw39/fYJcbK/I0XLP82nczR+A8qs
F+kPrH6LmdKCQjqrQlb4kd5VDXpZ8it2Ti/efLSRkTKDE7kPbw+VawZ/18leDb3u0gAbW0kRYLCr
cpBh4BdZT3vjd+yzxv/mwclek8QT4MPW/vcTTWxoM6LsRRHiHHY46PZAjaSP26VbuwLzVt3RBsBY
1fqRLIL5kmVWuV40cJJhMytDC7g0eYPebfVIUMQrQlEN9RnPcNttddGIkqaSjaRlHuH7g4UWUV+M
tf0V5OvS3YOmVHhFpmaLsslY74F/G6FtkG+Xp6cD188/Lw5UUsPZFbMhPjD9Kp2S7zEq5Hfs4Q1t
rnYPMnFYpo5vEQguxuqFBkm28nWv8FKw3Ga7DcC/YRNtwzud0PkwE9xq9NvZ25pcaDP86EtdrAYK
olgCXy32Mw/QtZFqBnQjzqKB1ywbHlX6BSgPMo96cH0N8VRgf6qfLQ1qXR/+e4/PMJaQHpl/fCxP
/GXBJGzc8V3geEVx+ui2/SY0J2R2NJznomYAXgknU5VKjn6nA240LI5ZEeVYNXafcHgFO4ICgULb
jHeBMxkLSQyKE/midERkdmvS+iokH9pB3y/gQPrYHutSbRhO08fsNoNqmDn0lndWRJv8mkcMKEFx
YEteSMQbjn9up0qbHdamGwfBTvBplktAamt7nYyujL4g26EWWdCPSHASidb4KfDIWLG8+GlPtnL1
FkeRDw4dr80CyTUWm2cSmz/mC6CRbBgTUVew3vHfyX7HbL1Oq/QSvQIj5RerBjhvB31WNX9Uhj80
87Q42Ti8EElkoNgZ9PiwT4mKPZdgDNa43hne/KPk737MlTlUAdlsU1Z0/iSaZUGjqEg/T1ZzG4Gs
oz1jkM2CZP5BNMk1qBwtxwF+yGbBOIMRurDuVyPi2XRakXO7B/LAFUyFyXucVSchoP30iTEc4Q6F
i9q2DwKHJi8vRg4oho6tXhZ+HlTgCIaE2b/Gtwmdk5QbczY5q8Moq8fAhnf4rgeZ2hQh5H+j/mu5
75Q+3GpcNswOqtSGlQMVeB3VRjnf4+MBph7PQPO4Ryg0Pk7sfnDGznbsphqDMsAX