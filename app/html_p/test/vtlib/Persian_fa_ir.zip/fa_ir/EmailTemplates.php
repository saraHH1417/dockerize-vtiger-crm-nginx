<?php //ICB0 56:0 71:16fb                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrfGvG6xyjqsCfzm8YJS8PUkzYmRZlMFKB/8rJJksO0u7gfmsAl1ZEojyo79MAj/yost3Hps
xVtgmA+LrQUqgYD9X9wJlF9k5hvfGn3Z5Quty3t8Q/El2gXt+iShf5KAd8Z4Nnf/kOwwlaCpxpTZ
jL/vvT33k6nWSgMbcLoAvPyR06SlObTaPyA/64AVC2S1gVyh7X8pmJ3tDGo3O35o43S8zaPoxa1M
6Sfu2sK0pK5x6HgI4J4o9SwAaBZvmTJvYRKmNK1mDNHWc2wWFpqn8qg0qSWzqIzB8kR+4CBD3qXU
b7u1R+ikD3eUSzqQJVS6kOwIPZuobBVKA1kFYWZAFqXY6xhmB4tg89tT8tLcNCZLFbwxS8fTnCaP
8RGJdxM1k9vExLDKzPfRAmVWpLJndbq46uO0cG2C09C0aW2J0880cm2E0880aW2Q09u0cG1CiyCU
6THmQnwBJwOcnFC9HNf7zIpIOKiHS31FZvt46M+PPapGsMoaeEhItbOL3YRBawYItqaBXzPeL5oS
XBRwzesaxKJ5h1QtYqV2PNSvEZ2oVOZjfp0DHL0KkVHaCSae6VDKjQnpx68ajjf7I+V5DcOpjh4o
AJZ4xRNDT/+VprcKJeoEdSGcfs9AiN+GtbBGfQelIUqeClvxL8Wk862uy6pWLnKoqHpqKGGle299
EDbGeryIQFya8jNuouo+6i6x7mLG6jKZ2ACnGrrTDThD9acOZcbYjLTLJhfNeZKENHUrJ6Ra7QeR
/5/KenUmf/oWm14LzOkzY3KYrtaKPO1aN8Jpc7P0SN0A8oF64lTwxANF4a0xR+hE4CWTTVQxx1dU
bG/Xix5UO1HbEuXGPwMyJ7beUF/0STEcvxe6EvdmK5DV00SlTHx4Fja/ZrVWPMrWxX83Nq2DaNkt
37HYoNfmIb8jiuwMTFWriVEV+G95veHaND2q4H30fugZofaN9gweo+FAhU5AMSlEWt8g3q8JJFtc
Xwcv8yQ0obZ7+d62Q1S/Vm4iPgCEVHvhvdwRsYXiDQq45ZO7/oG3UohEiyhh2Dbl3Pt9L5ssiyjE
gelMqZFMYt0T4hHuaStrKsny9byYMUUn4q5v/J+beHu0GfS1u8jDcKPPpiI1DIzIHIinMN6RODOa
NFXICrZGYkh26AIP22Rb0GXgz8h0NV1TZuAnTxy/jrvEez46TGDSvfjR1iUOxyQg5CukVxMIHb9m
4hUd+a+P8ykLlxiFJZ5/rOPfEmsm6ebHer9EVW46nlWxlH2x6w7ujHpe8IDp+iIqjBUVgvGA+NZR
h34A7/uROMYE/+8/DBYJtYMYu55w78MTAjMbO308nwS9jLI4d1FX4Z5M+j9fEHLOC1aAUckzrzy2
UauZXQHfOLd/UfgX33w3k/3VCevF/iYl4FXD2bIZJnH0ZLwcOBI0GJ7Ua2GwW67dRgC3GIy8MwmX
KdG24bf4ubJMxlJWUNpteCD2qY3W9b8AhJw7UjEa45ze4uxgdHuGazBYBN6DjmW2qoOCekcz+ege
zte3Mv9DwLW54c8bspwqQDoALUt4PCmraOYP8chN9IrU+/M+k/XRCGKFlOIIQkGgSqgvkMRXk5b2
tVs0wBEARr87E3id/lN7ZSS1vxj60FTuK/g1EK1ELveBJBO9vdv57lNO0EGOZ4w3Aupv/C4hb0Of
KBIJV4+LMYSU68El0C7I8UQxryfVCt0asGo6CrNoJFeUhOTX6FzPzrPki6IVtRVeJH1N7+6eBCmg
AAG4ZpZP0ZIBJrRBCQPDK/K2nkCiMU9IwDKWTmdBefSaHWYyIMRVGfHL5vYKkFK//l9EZgiuWKQ/
oTdCV9IVcKNeT+c2fkKz3FMRpaYpb07Dq+jmTkYla5JVzyHy81097Ppt1Dtuluw5zKSia/7sJZ27
gdW1xeZ/Z6vitzL/37axlP5ijx9nSFv2RMvBwK11XQk/QoDVFTu3uNbg8aMw/4q3mfGYVcepilcw
79LMn90aQwFe8ggpgb7N6YJG3f4GlmCY4QfSISxbO9ArBNtJVFjs1W6vsupOyn6qP3Aol1xJ+tvI
U8ApXy81cq5q/nE/7/PWn4t1FXWwwDkfzZ0utf4/iWajWPSqDOL48RzpbKBqSIAXeQzthN5mavRF
aYiKxqkBkeobmwY8mxl1o7OJHyvLLr0pTMbytNFIkI7lCEiem9o/QuUVfERqlm/DFwf8R0jX3VK/
iHS/aHwc7vjrSgRbiXxh6l+YN/5oF+waGJFC1Wz37hKS1TXIa27cVHLG+u0f0VemgG0aKTifJqXE
ZcCaVhrDQ3HHBRL+mL9JVyEmXgueUz2H4tImwr6j7mOTgVf0e4J+kQ5U9bIe1I57NM8x75ghlgRU
hWBzP3ZtKYYywvU/VWrWExRb8m7gSW6D38ZDAYeNvHoevLAAxcoL/FkQb1Fky8PDpDVZt/XP85KH
n/Tg8HThA8lfluB/hZezV6BwKwrSqDGa40I81t2PEBTVlgi1NqY1bJjoVXpPTlrnfAEa5fpVJBTM
0EFgf6Ojsm6Ixh2J3H1IIwwss2Au3mdieSdoBzB7z4gh2YaILASWfpt7TBF5K94KapiYK3BA+RBd
Zham8xEWG5Chrc/oQHfWFjwClaPfu5y6hoXeLATEPqkmgAu6+/T34NT6ccmJXvUrOolFrye+oXUL
wSFiYUras/sKINHPvEDXso7u2mglqNJqBrChc4W7JCN6SLcV5MCaiDVDNgNdTWW0W+lhPnqlyL49
11ZVCLJxeOBADuMPP58HarJ7jFAjqVEFr8RTXowI7CCOvUwfbtSwlF5gTdjOv76jxO9ZiMttkwTU
LGlvWwqgbuqQgFt+01vBsINDFhfvRO9gqvMS7X5gqQcVDyDgv9vXX6u8h0ZXXREYNzBlzSFcY+Gq
noN/5k+Kv25PPxQ2hjsrJc+W24aotc+Ls4winEWfHDKvUsQZTZLoFPI6OBkGfyMzWj7Hl8f7CE78
PfSHXl1l/zOC2RdGwXzK915rj3VuPMdeXHVSwTLUon6UYO0GDohcmyAccO9L25yjBD1sXbr+qRJx
x46xntPXJDjz8KPgDtZ2WBE/+AOCqlQQvH3weE8J1GnaLuQV9ZuuLEVSbaLfZ7EGFqjjTSaXllLm
WjkilkgStfDYEnr6NaCbXD7u9qIyrZTQ1XEZ2tgHCLG34OlDQe2Sm0rPOVV/SY8Z617ht5vcjIgd
6qJH5K7YGzSACi+62yqdXZSgmGZwyg7TV037iGNwBjZB7vC608elU8GaZzCeRt67tXr6jk3yLmhr
3WUE/mVi1/v9tXBeDylSkdi/rw0==
HR+cP/duFX0jKeCdM42hCoUBUP5a5o9d1V3mEikvUgfwwO7rMvH9W4FJd6c6hhO+lxvVlgO7yOEq
oPe56jvWEEjxQTkWGTdPxH//YSI2rgAOjWL6+myBzVLg3rxY9mlnaG90IBCSjpgfpJiBX6kdQYYf
kt0vZU8XVvVM0GqacTjujnirmvJo6+kXGZPdJs6HjcmkeKMXB3C0wtazCmrpdSPiCXgYEohNArNJ
skZzIRxw4jkxLdjtWZZOro9mqKkzycIBbl6OlfbXojg77RnEFyOnOOt4ir3Z0gAbfGkRYLCrcpBh
4BdZTE1nsfTFQG4niPE4ceQTkrv7/wVMb6kwqvxmAgnTe3dMn51/kcguNmusY28MwsMuAvGuQ/l7
wNSK4s7u6mA8BHkmf8vqrWmw8xaF/M8cQuJ2ub3VNqj5zsa89DUE5EWQ2VGofJ9kZ90LckhwEiOE
k2oJfZGaj51mUR59colJb/VugnAxYrx0/AYMt66S8nyPzGCpx0P3tWfISjJGag/HoL5xOMzz+Ak9
fbXzshC+2cmLbYai66OLMJuCN/GgEbVaZv2gayZEyOdxdkI3OvPwr6A8SU/m7TuWet6SO8orC9/M
Qm62zqta+et7n+3AK1jr02tGmEDp2BgC5qpDM49xy0oPXv6QAy1pNARBW0+P1sLPRWatcuMpvMTr
5aQTZSCcFIrbf9jQ4BrzVU7V5rUDa1LCcaeetL9uqesF8DsSJXPKvY15GJacW1/EZudkVqpCwso7
nAEiCLYhnPx0ic2kDQU+P/F5qbNXMKzhPfmJmVrt/SUNSayzVa6suZBS7YOoVDPpIXBLcRnHPR2i
Li89n2EGHYcvkeEOqWBrdz8pAZtqSEyEiROaCONK+AJZRhKdEs/IapMMrmpnn/iGYTVXSTPlnqI8
mlgQJvFcBayixLJkCR97+MS70uYfjYhC9QhEXBcGvFJSQmMyRNB54k5BFZ6P4foELucRtoB2LQC+
cPuiTeXGWdT7B204ZE8TgQ/CKK1bjDtsDAZf7BnGB3XpX0NrWdKI1jiAnQin7za+iu5I3EVmh1Z2
LlWGPceGNfXkRltXB8I47GJSLeoRachULctWgTG5N8mDMiOPsw45/cLOvWhI8X3uY/u+j9xGHBRZ
50jtU2KuP/D6wTty5NEQD8ugwd2K5jfrCNnQOAdLmR0/Pd1Qv9kS8VHFauF3WW8/r91/nE5AjKJh
uVxif6ffYgqsdVqWd9oSzpw/v6bIIScpqh+FhjoAGs3Ldvsq35g8LI3qbeW7YXpuwjofGVo88IEv
YMrz8NaRHzcG1fq13nn21MhtmbPRglUnrzOtNjTDs0WCTGKYXzPhe1mwgPwMkr6gNCTfllfBcMXl
d6MDdPOo5xWDIUEpFJqg0IS48OfyahMbsg53YT9naeKODUnN/u6mjbYxFn/wUavXZuBtkdZgd7Zj
D9TaAluMnVaOvV0F2NOMDbhC9+C2ZU4mtclNWd/dfzwoO1a=