<?php //ICB0 56:0 71:14d4                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzA7miARH3Vr4abNuUNvaP+1YiSdJoMh9ft8h01lvORv5z1Fyt9UPTwjSv38kU+FndWXxsUt
KnqsTwMHlOExUiXLg3+tS0RlittoWaEBwQdu8N50oTenz+It3+sraH8GN4bLJNFtLtdcLjdhw08g
yQpKEolzzUXMefg2CTyW4crXfRdB5jYNYh7EMvv8MvOhjafIE2ORXwuuEXD3vj7yd2Bk0cV5pDUk
FZtp9NLZa5gg3a4oS+VjJzltG51y6Gh9AOhhOGaLXS8pzK+IMqQYhc1xHSWzqIzB8kR+4CBD3qXU
b7xHT4pT14eUIHZeQUu6QVUJD//WrFplp/Y4Bg1ooypEcjLq1152HWArMoOAGFZuJFmPACWfUtNK
m5xnlGCHZ0wtwkqdllmArn5ZJsPAnQR4yA5wOwNNBADwNQHbH3/Z+B7QcFw5oqGICuLu+SAWgjzk
846QFGBquPbYWlH+NyHC66+YA1EcRQgzFYoAnLa3Y7Ffjs1aefloDE1ybc1URj0HDv2zBQBPUWK7
kpPrUIPfVrH2puRPVnqmZQEM7qgNRbdgpAVgiSXdqtoOHSIwvzd96lmMQU15YTMk5g7PMfSJT7qo
LCiOaVFGZ7yN81pfL+NeFUg+z/gQXQwv/czDc+8nzQlXBzAvTDEclLt0C6kIWpimGCIM0+rBTl2N
LDbep0x6apH1FI0hYAqF2cgA+6YPpjjAv7h3zaNw+IRvby5HqIHBclQOdhQQ1pW16YSDQPvsm3AG
MZ6+CjW9HLVy3IqJ4R/zdVP7nXMqrFT516NTAoMDaELQliWlJIkeQ53lv5/VK3f7PbwoiZ85vlX2
3uUYoZjf75aookqXZZ52MDlVsk1w2Sc4E23mz7Uv4zaeMRWKq/Dvq2fDK4D8rwfA6GU6ZEIFT7J7
bAHc1KwHNhPWMUPfP1AMPq8mWy7V31YLIg7EWJ8BMLmu64xj9V2wgjtK9Da4DK3q1pa1IRHF4qnI
DMDxQAsM2Nv5VwuA95zEARG87k3l/0Gql2e5lS94IBhlKYWbmDEzy+IanZGDoXpIqFmr+kZADLPy
dMMELq1JAq8kd9qzztGtKKa7z8GEEmmGk1AbZ5FYGn6/lHARLngz1La+iM5JVK7OPhUObFahGcPQ
AlZ30h+7i0PkwMLJr4pLFR6GUitepFHKNyScv9yX5Q+h8kohCXJaZZNcZBuL7zyfd+QjOP9tMpTy
tN4izSvfllM0Xr5cqpybmysL0HghnFVj2Cf8Xs1sCIK41Ty8EO/5N4boUD6SK2/pMMwrmzyGLZx4
VnglWOqinQf21Le7qlk3PSLiXZcW+mqZKAhedxlw6Owt/DYcjxCI2jXwtCwgYNdVud/b/5Y6w1TC
PsajpzuN5JJ2kOEMeneqRxSKRTxPhvP20pcLH8dGqo0QwN1HjtokkSKd6ROzXGj1MBvwEwzB9OVx
+a+kKbnNDwbBHf1z79YlLIbd40pmQIoYE0cdX4S0I+IY1SsJ6lxxil+Sxhvud0AY9p6773ALbL5F
UeqevvnTqfhZx5KkAI8NqTG37ej1PerMWmGwquf23Eb220I4lY291VNPSWChrWkLGsetLpLtsIyC
GQYtBINf97LLaN/PzvEJ+RkXYcLf7nuloYKQykVPN3kKlP/YYZ2nK4a1k/zMZsvz9besdFWzZeiq
8lqkbo/TK96an/QHh32TIBPAYufTLmpBgw3239swwtLYLZtJSGHjblWOrLsdG9JiBum9Aj7M21Ku
Qw9O30fU+/QhAO4L/nSmCZ5+KirmjWytXItlt/tSx3z5ypdCPgWawsjgowUebE9XUTe60XbkEkkX
QJ9gvzkUWXe3g0WuLP4hBb8k08vLs2r/OqvFPixWnwq2dSF0iOnBnWqOJCWbXkfv828BRenJmJDc
031BG0sQOzRNII90ehTof2Cj+GYRFS8c0QHvKNx6zud/qRhXxXn88lLpZDhU71aQ+sUIY9fY1bNW
bNIT8JCFqa+aG1HyxbVw7hzGcikvL4DqpNS4wGpqxEkZlljY4+w9oN8acq9DMfsCosNO5T6aMUUy
fk+uY1gaNGgwCHEpZp7BzT8YLAqxXyuUgxM+mkBOqxWj6BtslFDRWsRhsEs+HGqHr2TzvxyE/0V5
vcCToN6qcBgCuQtb3OwdWXwZkbAwPzdsvGgmIZe1UNogxJH8H4tY40y/+L+5Uy+0v8SamntqUQJt
64lszu7cGNB43GeEG0VQ7INKxlX8SNF9jrFFrMu4+KWT/O9uD8OS0+eRALNl74gAGMUQhGsGOX61
wCwWXCdbAtiWcj5shFhlov+rn0PT2aYQYkixHBmKmIJGjhoTuRX07zcgYU7xb0ZSBGJGNhUXRLUt
+utEIwJJaQE/69tf9BUwcFHgQkzZa2pFE4wqxgI0ERseZV0+4m919uEI/rgwT7/jLMgA3L8ibyTp
2hYPISbwjLu1YVZnIgk/v4Z/qpz/Gn8QPqR68KqLIB0Uj2rUnNs33FcGY0dbuCT6PYZizmu7v2Wk
nN//f+4DD20SnRheyw/njqNnujPtJUX4yNdjzU2VeIsyyxnJur7KMqdpxxVbko6OWgLyqh0eW5YW
MeSoI5OYaZ3s3uVClqxcoXBjD1m8zabiZ1H/PqG60bFxDFa6s2bfjkbZGOGFoi4jD0sR0NNw3lHi
8FekmHTVoq25rmdS2qYZnXj8rCG9vGN665AGr7k9TwjGNuWh4GCvUzYHe3eI8Trod0mk9OS/FxvD
SG2J8bYVetf/gby==
HR+cP+3mWzWQGtWVaqyM+nOQwBWsIqbkmE2tsSovy8Q84n0ambp3zjKsXzaZ3kt6m0QY+DTfc6nC
mjM/PhPYzV2ft5LW7lAKhS5SfrkJqczxzJiS9QWNOCX8LOvkX6+ljuOUov8xO6agPVQUoz8jQBvf
Iy98y4B3YSEJVUhJSoRiwq+Gj04OQiL4w0SlkIMdKYejLRWPDCZKMhptQlAHAFLeboPCPwgXfiCH
NvB9zCXbLZs26+JSudWJSGAxIo2X5ocKeEOsNpwog41m5Ndhx+NUMMVDU53o0gAbamkRYLCrcpBh
4BdZT2PsdDmvfl6dDkEIheQT4MPv/q8JDKVb/YWxxPgP4eBXmSEsbVPyPTZqxtbL7y3AgVG+9+xv
6m1EgpAIM4oFNlyEjk/U456eafZxH7itfXZTcllleNV3Yg7IwR2p5kX0qgIb18xnaQjfDDmwWacf
6BvgQ+TKeSFS06PPqm3iiTFL555rfvhOH/uJwm7/oWcqaKRDmVGhu5LpR4AHXYDHcmts/ClR+k/H
/u2biU/wWiaDw8+8PIPzTwua0w4E63e4jhBPO4WSdjm2quvkhjHXy4PRSMcckYnxzRdGjLuf93vh
MBazWx/yBPbFD/qmJxQXkXpMmk8bOdDDDw24qOvWnn6eEbXlLq34w6yNWpHbU+tm2HGh2WqUTe29
HrdyTSjt05ZnFRmvXpu5+2gesZFromMAmbWIi/L6TPESvW8ZnPGfQTD4mS40bHRsGyR3y8oZEKPd
iKy1R1GRyhEL3uWcK52hLYGnjyzuDQUTSWuarDhWsAVabYLuc9xsZKPLu8Tad3eGmx54/X7Cdrg6
gvkPW81/BjYPkFkCc+HkEgZP9U1DWXFKTOi52ywdM6Z4vDxl491BQV4oItFmP/mEiTWLhO5/sNR/
mnxbEtcbQigSuTTmohvYh5+68sPcDb85xANf1SU2mXN6o8/RH2temqsen1vwo9o80lA3MPZ+lYEA
GQN7Kq8rC4tnjx+RcT/BEQA3iZbH35ZBH8WWyKmW2TE1j0cx4RFhYRQ9VFecBdj8ZIQY6q6kA1E/
WT1jvqy6aijAdvG+wJYKIO9Q5arTPYI2+Dei1T+FhXHsFvbLlrJkNgwuy+tufyW7qmtE4jtYUrKo
x+I4nKIxsVroaRk+ZxvME3MwopB9CnSsqcCF29r3isV0s4sjEEAmGjSAkf/wwXwQikLJvyS=