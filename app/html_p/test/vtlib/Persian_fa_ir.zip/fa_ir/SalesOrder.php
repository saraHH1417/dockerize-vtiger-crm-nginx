<?php //ICB0 56:0 71:1ed9                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxHrlbBAuW9bux0hSPzAvn4jlW4XfiIByyIWlhc5ZispWXqfEd5sy21oPCg5gnVOieC3ua7u
VZcWwtY2S+OND1JzM1M+eakSu3vSog54wzzxyoaDA38r59qfviifbaFLSQxaR6kv1XsCz9pdwPWT
PWeV6Dn6udD8KxGkuqXk6NTF/USDanT2VdNEFsRcrB4HdNF9YY43h/2WxsZ0BpwzLR4AAzPdN9Cd
y8DSacjYosLsAFX4WvHWM17f3QWd3IcYZKnNWhZ17SPDkkLxuauu1drTLp38FT4lIoBc/X32pGz8
NfH+UsvvXwpVqc/BJB5r1cdtapN/cZ+L3Ydd3tgZmV+QxDrT418ke56qsr7v5DLs2nhdPLPaBlLt
2yCF1L240AEZ9Epivu/RxLQtok2SyRjm8EneqD3EyYZqrZyYorOEUv2994LJcO/kO6ZiJezoiSbY
AkVSLhemPv/deK/trZT4AYrZ9jUWtRLzaYBh47tbMq5BXie/sHrVy/fXDaFvjD4avGeczea+BqBu
yA8BZy9M9lQ4jgBznPintyjeNhuie1BJqspRolsG6+PXGVMwPWixhuoMs0vkjnhzNrHhXJe/5qFX
0TSF8kV8uugM8Kr+PQ3iU/Kk2RPMdA81hm4V2RrHJrVRlvAZ41Gk68tJW8c2W/rJHgMZyCzS0e6Y
yVkb6Pcx2F+8s1xACg3NmlvgqOXUv7X/HD7F7nEhKkQ9qIpKG+FpyIV2Qxhlnu7MMpc2H6PNxU8I
AmXowwvJB70A8dYEZq8/5NiSR7epvwQvu/OgYRwyFt9NKGFwEd6kRzRI/VyM39EiYNA1GTmtuzk0
hWQ4adW4mGLSjt/2jZcZh4dPw2MboRKAsAWQ9bwqYA0R+//0dTwN5pL5BcE6wtnPOytDoaecdvol
QzdhFU8MQtk2IrnpdUPeM9x8F/GY54tYHcC9PS5Jzzv0yFA+nPhVDP2VeMWQZ9RC+hDQT3ukRF9e
kM44L+VtFKw8LCZ5CkqbFWEAH2Ct6yeDUtGa4eD+7NEDnGs16JK6FujOkmRrHG/Id7sSdl59SfzB
FnB5/zn4a/2BNN2haZ7AnKbaIQHdPHd5qaKQVTZW9V+U9rEhuL4FtCE/OuzZqIXvzlq9dz0FPEJO
VS+gJjFdC5u1aUzUQCYfa8WoN/r0RItRlCIwQvv9cuGIZetp7OD3UjtvZXknjiSJGy4fokLq2wmH
vf+rh0ppybugQhjdh5vkbQQojK7HQ3hZjVF+s6pDfpu91vzT4I7ge6Pfg1rZ9UyQkvibx/S4x6I4
UBzJ2ItVAKRzPGu8wZAQbZdjkQG9rsgk/ofLbuLt2bgnAeNOFGYl3dIoNdMYCOQ6uSW8bCihhmfV
bwvN8ssPeeOXZ6p9sy4qVTOkCrTXnQTp5cBY/eKrsumc2OL/riOm2BcPEzZ8752Oo8m0/j1SdD8U
DwCJfmh0XdKTFzElBaviD7fUfROedxpLtHQzGoBWfsia5jxwA06AlakVJvjeChz6OfPWExM6ftnO
C2xfQmkcDizRFaVAAU2THtgKidslcMOZf9a+f0z08iVxlLYAa2r3s5e0oIDxhBUSnYnraEYevYEH
P2kXGgqcvlIFUnDvsuanEAAlpjIts8AeqAkuLl3b0+B7WVLdQOYVMNl6ekE5jn1D/FeY7hb0NI4p
Q9DZCXwMoRMncTNdDSI2H54tAY7PM/nT2EDyskvYA4H6DyUj1GA5oonIXcc2UL9QPIlgyycuXHmJ
VUXeVGJE7feE2wcYdfAvt09TnLi/L/oRNQvKfWKLjpDZ2hsvLxAPFaBBVuZjKRhOQktN8MBsgdNY
QoGzRu07M+CTeUaLGb5FolTKFwA++4rO3OOkhBCcw+oer8jt4lF2cLvm6QWJ3LyTZUrrU+Kzt9q0
4FaVeVzEsDQq9gmT1UqnKb4BD+hzDxVHckUrmWH8vkdId9shRwuTQyx4U484aZ18Do6h+Vy1NNWN
It9EzpO7I5fLM58V1/iCNtgwiwznz1mXfLlmgfoKPP7jEJWMhPY7OB0l7JTTLRQV51wsnn+ftC5f
IWckPYTu/mGvFhGtRaJNt/N1JvExfIWpzlNmfdnLt3En96r0EgVguifayvgdKkWtulNa1BxP0LP5
+eZeD2T0cqd76j89jeHyDXHUE2wBbvXUu7daviqYp46RJnasCq3Qih3rFIiW6HwXpYD0x2zkcGY+
aJz+wV/kdPASZ5RVthoKSGhsIfM+V9eNRIwc2mWJlU35cxMYQq/D4WHs+hhjXDrdDYRU/kpNI7lY
BWWm1amY5D/Hptq5PLxRwuS/zNcGbAlBBf6gdueGdSlZ8omZblg6i+rYXg4ZaPvk10fu91WUl4VG
qtCfdr0vq8x5i06d75mvJqaN5Sg+LnQwd7vEYWpVKacF65i4OJ9eZPkgR+AtD4BzD3Cah5+24n4I
tZbfYFOzJOPyroedTW8ZaZAKNhJtQXrVTjsGrPGxuXdecZaiQUlaJ+HBRJl0i5kzJ+TFjOrbQggp
tbgNlh8KOUTRRoHaPIFiOxpyXjFVaogg6Dj1j5BdvOErmP78XGlXwwGlyocnAGvTu4ukDiXerOvV
bZ+Q8xCnvnCmbbYZ3fI9NpVVCbaYs3BZy56uKZ1awLvJVcASGevsRLUFGJbAVbu8UsAHmtiZFjwz
qNqFqs1WpeEZBOhBmHzDZn8OZ0IMrhC1fT4+gzAByWlm9NUR8no895aiZwf85sOb6W4N+d2kBIlC
Mk4KWiIp7w7IWyYOKtaoO/pQus5esobnaiGYacgZtF54jacf2Yk5fUzU1zdZbWsJnhC5pekwohCU
rcUsT07eJnmC7R9KCP14b6+m2fS5V/gFRE6O4ePLSy5xcCfyHjbfAFcSZQR4RUjJ/zmHxXHEsYFw
4jTrTTrcP51e/Bm83zdLHg8HJwUAa+WpXIsM3equ6Y0j5+6SAhqd6TvwdNaSi7VL7HvtXy/NwunI
Kg7S6gHEEfn4O2xp/cZ4kXzf6asG8HKvWR5d2WWYewEzv74VqLAs4zz91zY/3zSnqg0Bo7S+6qnO
bNGEQaXDg4weQhSmBacthxw2QUnAHGAfg86ORR99cfsPFH1bHzt5c9P4wyfisvgTu/MiLExfq1tp
XurpkxMw+wctOCwv7FAw0H1u71jgToiRV12pptY64cIB/IdbNuRYKfBjNG0wyO6n0Wvr+c9cqAhe
4/ME40rD47D3/PiEebU/SeJmWClG2NeZXH10eJVYH52S6g5sUZ8ogctQg0obzUOdsDV1w5ITMgcq
yBQliKIUsgV/Pc0C2lTSll+SaslYhla4+05HYSD03HY1WYCxYK3goBMeL7iDoKiiVHPwiWmlmpHo
KuR/kYY61HQQvJzzBixxcXw9n6xaCBb5Q9cQwLQIE5Zv1rjKG8pdEYEzXlvEyKV6lAqa9eOYNF8s
H9vAnV3eYdQU8YBiif5b71nwUnB/J9MhyNyE73ObKMNuKg5FuUSBsHh7IwPP2Zv2pPR8LUUQTXip
USeEKRrSEZA0sSWV6r9nefdM4gKjerNMfY9iYETiuzR5G1py3YQruTvK8koBnfsKgAlMBFmXAhvu
XchAsxxhx4cwv7W3/HTkmy0WK0kh6cqJ4cQwptm8wTcZ7xaJfQqL1ZupMODjLUAV3amQDf7bacgD
KdKVFlfHQ4WkLfK6me5jUCZYPW3jsEhvYxwnbBH5rOWXfIQ6QhoUveocOYJLMeGEFoUAWhvN9s82
JC9pRCOxRD3U7cwFTMhoqhyGw189ol7nZd7/SRyDen1wWYC7yZjfK+Oe4fdu6j6EIZ/l+Yfrzidu
vQh3uN3aufqNsLtgbxx/n8lefiJ4e3tNoyX4LuF7PF/pumsF3WVskWaGeIJHdRRI9PoBe4QHbWAA
xbw1dSmFvlp8HFJ2pbI0k4lIsxD1WechRd792eBUak/1wuaseeA1vLGev226IoIb3ub/4KySs602
VXQy83aFHB5CLfTACgLIbyIn1IYwfcQZO4dUw7Ut9sY5XOo3D3GExOwhw+XYMPEeTO6i2j9f4xJT
IDnStignjv51/WTxPJCIz4KeddLpFSsP7N9jI2xZYpCI2m+4juNwXYwP/EDoWURik8jJnbvTt0xI
Py9SiD00dTekhdwWCyAVzfqSkm8wbtPhic83/zG6LkL4yXMNoaice62Ya6dvJmItO+RBMVIFbOex
AT9Umh3WOc1HYYSlogduXSChNJNOwutoDIdmVEaGlaYjz8cco71cvadMbvzE3iJfyP7DARHYaGKK
rWk24MwRAXN5SGUzC9Do2jTKjK+DwV4SOA4WGe0FHwlsUjvMwpbKioHRQN/Zpf06jQZlPBhiPe5E
6NrfzELtunE0xzczE6ihSco38xyZpD3P4q5rna34A0H818ubEm43ePAiKYU3cCnWkFj1kjG2uiOv
r+TvxQwjp6MZtKVECl5wWIxC1UNzCUxCvMsHIXFu4q4REHoKwNkqzn4gf0PCDBYQ1NKeTbgxW7D3
ks8w+N3bLUY9ej8tWn7qeXwUsa54gSS+jypJsT/g4YLMvR/Rc2V56Kq/opsmJMUOKUhbI91ayrCb
3U5thx12GbGNxPD7HvDHc6VM/fSDfyZ8tcJ/LGVBWPdRilECT6XOs3HvRGEHvPyO+c6RlrEYom/B
mMJtZfFgjHJS+58zIM6lPJb1Dp54Pvhx0U6DQBNoQJlQxuPjHD+kHp2kQZx0G4rqM5PxgLU60b/p
6FhzWrd5zGt88IEEWROEtXLbNW67J8xNyvEAlXnSMVB08ezT3Y51Xc89Z34fHr+7GcKdQQZS2GeS
9j+Y7E3iun2kU/10W5avLx88Bcb07ks6SRZgwxgCDpclT5Sd3fZhByGNuYe5MlqVEHzdLuLdzSGA
7aZ660Fml34PpUhdbW2bSSLrmW0orioFBHaYqHR1SfGugv5q0Qeb50GHlFrRH16gYIjDr4rEbM3l
wxVnL3U4pT6KRmQdqIRuTQjnJ0o6bWJm8vvrDy3Aer7YV9+uJE43kve/3nuLJpkh6ylcnEW+8VD0
konfqQeR2D8N0WHm972ioV7ksC6DAga6zDoKwdPOSkToi7FCykQrlkIQk9rFruggpBNhrO2/0Jl+
MeCmYb7F4zT1EX8B2qgEnZuAX5wxXX818UxtSSPL0jFTPF8KkTUfQkyRIVat6pNgJM6A8A9RvQaS
nwGD/ef6cou9Hu30Ehcb1Lc+6/bvn4r7DsE6OQwULWlbPOpmJx1o94g1Vlo8C+92ZCpLbpegJV/I
MeeAbRNdgX8oMFS16S/AjTEnMhyrUVnoeAuvdvK==
HR+cPnJ6JHYt4hPVFd/OEpg2Im21ctVJAZcujl6vuC7vIx5BtJz/XbvOHimxG+i6RZ4BIoFM/U5d
1H7KONs8G5JqHW3AiIJL7TgoAElPf0RLodFQOP8RkrMsnOweD1JA+B/mKVTHtPrkCcjNmwZcl7uU
6Yz0L1uajNLPcWeWtrzyMoo9/Fxn6EA6NTAUL1SAT7gCnpwZR8au+QyxnUS/B7cB4lG+6ai3n3qh
DViHSER2X8dHXkTuMrn0+bSOIRYDakKQGnTOX2pD8mf9GVh/SL1i8BTxIL3j0gAbhWkRYLCrcpBh
4BdZTBnje8K2VY0eq9S/c8QT4cOmORVT4l6uLdoxXMiQn0DNBJicZYnoowpItpCjKekdP9AO5C/C
jgPZsdqBNQbzJXrAw+pSlWShUneXfR5gX+Eukws1yBqnA8vwHT1LhfZrfEooiEhGLpOoYyme1isX
rN9QTIAGOG21flUottC+/wjWxq1FId9eU7JwUtZhZi255YP+KIGdvJxr1JXfU4y0thL8QeHtYB/3
Xjd/JPyqmkJb4cHr9Ay/rgcHSOIsE1E4RvxY+zEIR7ooi8rYKHI9PZkJAcudUgUYsn1NFhws9BSu
+P7BUSs8rzvpD5i8Y+Id+zWKh0Ik3i5DW5066spCj28ibAZp7AJtdItJ5suG26hgVl+SiTAh4JF/
4xoQ4vZzQHaoi6i7/QzRCanMi+aCWyQnT0V4h0gzuy07qktvTvWSJyY6YF4P5/41eIp2tGAyv/VD
PwyIcCZnw6L66S1nrdqeQuGP9ENlV1M9qsufdtn47piBqF5jLR97GuobYovioHvQmqjShhZGLy1Y
TPa83gny5W9O2B91m0pHYmGeMfcD1TxPn1wj/Z2vZDgVC2tH7Sf5fzwLhRRr0HSYb3YNSldT+e5b
7EB92XEyJjVwQJx/4caCyMcdXiUes+WtTmxFJhtSHKDEyKlHZAJl857BoUobkrEcP0yX7GpQGxX5
opa8XmhN2c64W/r09C2+V3RLKp/XxIPfxM1Y92PSVcc3qyDu3giSRnZKBqxuHGP4xavAU24K0GNU
hFkbAiqOvvtskuJa2B7d7nQTIVeWHNHxq4yD6kKeDTaa1dpUfLm7iWxULvMDvDwJtGdy6xow83Pr
qlMZs4yWmMlgN1CLbCZ7wIi4rn1KOfatglbGzrSHig+YMDKQH+4Uqf1xjP4g51UhGzFwkedWwv10
1oXY3NkbWRkakfJ3/KBDKg9mq2/ahwjmygKL1NU5O6iJwNSEQM3/oh/Mq5VkRpCeKJBwUm7/5+CO
ObgdECmANNi0c9PSd/w8//VJSP+83GScHPIOy2LQfNKpIr30LdK4HbIPpAMFYT55AVOGrGVs0UhD
8zTQWjuuLoH0RR+IbjHxqECWhSrOWyZATHtEmE75eDFSTPyIbQRKcTSKOIBrusYD1/D9axaCgeCP
IPp4TrC1oRPApEouZHVdbFDbdvELcNCSmgV6A8KSGoCIwqlQFPYt3beZ+vsn0PSo34vdqyn0nHTk
OIgMb/9Hs13Fpp0VG+81PFr++Jb3wmuMX4AYy+8lryMJ38QKJoxtNoT+l5Y8NZa0UD/w+PHAbrcb
9UAsv9S4Xrp7puO4WhMsCYoEpJW9oiTGOpLtwegJcA5OGZy1pksSoVs4YAQrtREW3nWTWQvK4PHJ
sTo8j1y4MisvnOJYJ0qoUKX9cJBrRs8XjZgHpKMW/NAghXy9tCdQao6iu7jyKgIF6sCWsPPquAUp
pjdgDW0mjKUi70LcuOWRaVB+xJ/c2kNmKO9FfbhdRsXPhkEWglu0H/TtOKe9G6y27Js4IHogGmQU
W9N7e6kj6lnzj2ku7T0ez2HxGK1U+RGt1wtyp6W2+rElY2D9coPtVemYd2GLBWXh3kopJW1wb9kO
SpjGdTCXxif1dd1OYcjVe5HQ1Axgtb2ZqX468wiTYsaWohhpsfbTOpeOgwkf0K8TLYlqv/iOdf8L
o9nsPRSCPpcj