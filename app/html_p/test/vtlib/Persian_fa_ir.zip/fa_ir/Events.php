<?php //ICB0 56:0 71:2999                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyVjjljFOWlyPZ0Zs46SdrwYS6L/OYhioAx8ApFoi4HLWUutlBkoJcqdiom9Zsmz7Ngunlcg
ell96QhZPqRibjqZ8Sd8riJXzhIdfDIp/TRJkqr3j8ca4owOi+D+HGP6dcd18ru43hVRU7sVdSpr
4dFvxyo/GdOnpAR7V3NGQ1Tf2lE58ExosKSgFInnaznNpLVOGy4CQlRP8Q60kmthVOLgtKlUp3Ve
0oaK52+VzdPvL6Wr1tscbH7GR/cIC17dOwLGQ2iIY7ORlElWQ1i4ynBX0yWzqIzB8kR+4CBD3qXU
b7w3T06ltFDKipRb7wm6kOwIAFytLMWNRSahsx5y3h9uESs8iZlDBH4hGOtsm5bIhrwkmKtVU4me
5hxiTFiJY59S+GgcRlZeUI7TtqyM6K8W4v7pX+5q2Xk6/fw1FYdBFg4MrncZj/R4guE4yGrC6ilP
eGzbqn4DRFqWTgPMIUSYV9Fo0m7BETgDOWXxrGnapXOoMyOMgb9xn/19Ir7TEEAgqaFU0kjxUFiU
Z5pXB/6SXVO0FLXkD9j1gX+wK8Xn5EmwhFSBgkhW5vuRaKBm5DyNClISqxQFE4R9oGCZEuMBcx/P
x34xd7NgQP4KD4bCH6kOUNw7OE/p9H6RYzaYjxfNNL9KTTqUqd04hbI0ZE3wwU4RBcIyDpgxGXoX
6qsLZNPOZGR1HaXM6YMswdQCecqpul/D2qZcHTZIUIi6Jc1ngikRHH3Gzove1KZzbejdlo8VnrnD
AcFppu+39D/XLXDcW1iVpKLHtgB/EfptvKc8WeIBxcXYSiZxWu7mTB/40GxvOIc8PRy6h4o5b8lb
kaTqeNBV38CHzlXeHztRQNcvATtrc4+f+idiAOkNGU4Vlyx/1GkqbHRRaxfC/yV4EFJ6thneOS+W
Wmjn8OpiexaD9+qY0ghXCLcrQJTFiJ7dcyXjwuO+bVtqh3va/WAJwgx36CvfJPF8ECrDFhNg5fk/
VJ6bkge7AlOdP/ni7jZrKpK1Rhuzm2a8kEz0b6dhDDk9QIqpnxWQxauTPLMQW55jTWHrocbf6o16
OiKB27e1xFm65VxGMHLkpLzVv1RYETkWTJGQ1tuWZMzFmf9KryJRK6wK0Sg1vx6mpA+Xp+5jO74t
uHpyQqgsvSKS33AxLnMlqHOhs9SnHNvxltZtL4rad20I5UL1B06fpayMdnKzGl3dzMU6f6ZqRdVh
3+Zg6PmQO13TvWSCStrEFGb3R84bYreLyOuMssKnGYcTB6QQSWs97vBuY8QQVZrkD73b69KZobdo
CY2Lx5uVt0D7q6vtDGjMQoksg4FVcuIzToitjEshtej/iOM0santQgNIe6r1RPiCXtn+4B+udzSR
OuHFTxO8Yh2BcT0QwIgrRn9s1sldq+gLFK8b6gEe/fu8V53P9peRsAXx0ADkmuNXpe60K55ltkmm
OER2iiKwy16ilP6dlnnvoapEPdFo9Wgm9fy0ZovttOvMFpBfHtFABJarenjMsLwKt1q2nTVm6hID
gc4fxMHALyJiFraXwSCSo43KFI63v0PwJsbnO+tnQSR5jOL97pgHpuYtLn8TtKjeJMBL0CDwGqAO
QWXA2ZVhSAGlZYTnfwvobbLbTn/xkDZDrxHff+GEeP/kkJVqVNHYelUJQ+lgDCUCfH2ihytDaAhq
TOS9r8dDMbvZV+1nP+yeDwlZnHXwZIaWsrvz8fEoQeeQL4nPKwFmIW9+OLY7VyK446vLwNS1A9ym
SorXTtajs5+mP/MmMyPQhEJcUkCRJgtSO8abN1NcQV+BH9uGcu/+Da/wzYraqJEZbcQ9vTI9cH03
xd+30vfTUwfYX4EYrsmWmCAVqcPaROUby0Hx9VLItQkHTTS1+d0QwDFEdlLiW1uvt2NNEVCFqUdk
wgHkn6JoQfbSZ3ua8kwwTjzjPS3B5s7h2VXwxekDEI9izci7UQ0PDz5cTemk7MbobQ1LadpGJoZl
MVdDFVYf75PLvtolRZwLk4eIZeNh26cHMA3jgGYEaqsAr0Kfai3N+Alvmcfjj6gD9jXK6ApoKyzf
lNSBuVSSO1/45tl7LtKJEje3PoF9RNoRojrmdtVtQYcFhqGha2oI4kTmpANVXpEQPv5o3jkCAQsy
xQzXNwxMFG/nLEJO+C/4p13z2wdUQMjk84YVN6y7+DqQB3Ks3EkloxHTpgpr7IT3DhEtyGs37Xsf
5jATI3S71uCLCU/NQ1IDTj+rCvtVLCoVy23lLG3OqIlDPok3+IBoEOFBwEKhIt1CdzWDK6gc/bsw
0wZMl0H0pUqSW5auKasydDEE0+4gKSHJzE6wBeSzd/OVXfz6FJhFz/WnhoriTpCg0mkXT+KbpYLt
zbbptGffNSBwgWq6WDPdWXMh9b84TLf9LO7p0TZ1Iqzb3JE65PaqTZKj68nkX1MIauj9RMpXuCwe
a8LVBLdHyUqaknVfiEPBDyzKkv3YwSJ5HLmow3J3P3TNZsjof9OwS0Zwg7gmtXBZLv03PC3u+v3H
T7ESkc0Hp1VP+IvbrsG3gtzu7Fb+Z21OLOQgctcFOm3mnY+uzNLGNZcNo4HBmglUN7VrkJwm1Ecu
19y1acL6JWaDLDBS7Y/AYwEoE15IoL597hduDAvxcQi9C/jaKP65Os9n1liBD+ww9BSIJjKSlRxf
vP8jRySnsIGZZwOO8yc2vF2z1uNN+iCv1GrPmjaXDV9Ug5PWAJyVmtuwdJAgUD0ScnRSDjKVp2Hi
jAWFeNMCbO8p0bf5FeUmeR9S/6S0PHqTNlBPH54w//k/4c3oN9uhfTCoMvryhqeX9kD8g8THCIS4
hhCAl+YBVjFIxOpr1WwLH6UpXlP9DxHkKX4R9mICpzWwkYBhRv2Rl/X6dqBC+lTumkXaERwi1UCV
jnEQvgLiDW6iVrKZCcwgaZhvpCzX6wDaAWBIhHuvII4p+Yjw9R6oIwehoV3IvsEAaYTkajhSvTeO
XwV1j4PtcQfID3QvrrgquJtkx2F/GA1mMfMdzwATw1nsHFkSGJ0NLFi/MiJF3YakyXxWkyi/aMmu
HYJvoTi4RdgVGJRJb8WlofalAj1oepNX5moCnopj6MxsW0CTE42Js1K7sfo/NmAKY1p/AP2uQevX
A+jYjTDmVHbu8PGSoi//LVa+AQcdKqZUP+cBraf5kMOzyKQsKXvStu1njvi2JvzNkwSmuOBMUBjZ
pVYENEzkZ7aA752+d6w64piG6FkYH9SPbeUBoFDbsFc+BJqxSXrOaMUFwaio5G/HDGctad9oFXAU
TAwSEyXZhDhQeuNICFkthDkxCe9g3TsQwScNJ35K5ID1ZdWcx8MKKAGlzoeGqnI4P1HrOsikNjFC
7LgAkZMueu97ENpMVr7COtMHDgYxY8vSpWzSJ3OSwgfqqKidY5O54TnR4ab5SIa8nkHyelbeFyJ8
HkUVSQJREkacB99Gmr7oka5dHaKO3V/vPnI3P6JvzBphoWLQJaue9tnBJ0lAwrWfdZ/cDWAG/4cA
HYTRx0ZXQCuHePeDIeAuw2DrWg8KYGLJcadsCAtXH8ylD9RwYlbX6kk/J77GxBtIftz+6zEal/r8
90aD5kIzthKUmZjwu21MW7R+pj7cH2enAE2Z0MR1/6dPqXv3200NzIv1uLe4wSuik5IAnEDyTFrs
OaeAGJBTSGFxLlWoG9DANLyAP4YQ4vKID0vZL7WQcKA8frt7q2acjj6hHuO/CDidp3wJWo7Q94SM
dSQ/uAdeaTrskFi6qEysy8feKj6r3FsIldcyMOKZsd2rjoWv2z3Lf6NmfdZv4KGVZAHNmi63OL7I
357IG7QCll5IxVyUHggrUFVTM5BN6MLFzwSZduyfSHC0D+Ge3ScOpAZPzohb/7rRV1S+I0KntsPm
VSNuHnR3oDVpmjmX4Qmm1ezE3N1gqoPa76mFui+DusXevPrYvnDCu5mkR/RK+XkJPAvVpgw5LsQA
9BxseSWOEioMps8oBjn72KK4VNPfKqF6BKSEedPeLKmqiuAFY/1PlE6q3x1ssli4klQh0siXTTy2
fi5ilUFPhO/kWuHqY9WAL7ytbtLnEr60Ds7kwEGDPzvBfM9BDRrYg9M+WoSAnjDvlsRTb9UhzXz2
G8NpoPQtr/8Y108bduXokdWl75+NizeKJG6VPVy4XxZpEtawdFt5H1+BIyLU0jrRHlfDCLjODaYX
sJqCsaWfRef5osJlae+Pkr4fVord7+NXOcp8kcUP6Y4D0xZaw72vNDywK5bjGONu355FyjswhKVp
NiRr6w/teA2yIdxK0zxuShSKE5YpoSLi5d8GiFGYVME8EYbhSByfvNaV0TLTH9Iv928VH4dZ0rYZ
u02gD3Ow8tsdVLVKG0bkgem7rYIsB5dncaUmkMJBKjN4TtqMSf2xN8neHR1HKZULURj7B54VU6WU
YEbVpAQ2mZjIsyQfcaVCoZ3RpDLCZIicLIVIhsvcPCLox3G9Y5YTTvx9ImcrzcaYQONGs655nOOI
GEk2E4xAo44/Y0AksP5gAIoKdrwrxabF4TwSGUC9Q60nm6SRsxVJ30RpfO1WOo3sz40FQNNWmUwG
MD0HJs9dpUYIMcs+FwWhG7FlryghmvIaWXiXDrQEZiToAcNIxQ0HuXtow1M+DFlghMNVlk3AmHpB
eMRZ7TcXymLA5RcuhDskOhyw08oEWJBIWJPhBAut4hBTgMLjoWbZJFuTsx5Hcswh2Bzbt8A4bbX5
COu4izGUsop3+GpELb+waXwg+qgrvdnK6PrtDZaNGbZ/BAYvEP2qZroIM0hTETh0PJrtmhSiowB/
2WqLEizQJj51sarPLGXSGIa1/rLdvbZPEYH9qy1PTZTzxiJHBi3bpgh/4Df0owTeFP84RCk9f6K/
M8Sz3uMotV8B+Tl7owCT+JWo09KNCB1sKrFXG0FfNeHVjsFwlp6f1yIntwsiOq3Frzwge372BGt9
64UwlYe6glU0+xvsN80op2q32CWeqAjUyktyozQlrlNbsa2Qqkwr8xYzSL6N0H21vvIONE3hzITB
14Jc7WwjnDfAU98XHt7JiBv7J4Tq0R361a0Mn9Z4sYVWbHTpJasC0A5ktxW51Tj7BPYmSLUOTGYc
mWjKLPOwcnRdLKRJD4fcB2xoA8XgHknBINl5SF8mnrRq1Sq+3gjHoF5Fip2NDYZgMbW+BtLCFXY8
XEP/QRQAKVyPUwYZoT9vOSyPG0uO/lJBt6iTnMexyzbEh9/suEvQVQS3zPxQyjy0+3guJA+nJdWg
hVIi1RvzaShizioItEvWLup2M2B940vdonSsjfsq6vtxqrSBAWR/+iPXJVHewrwUBJvKX/oyd/8+
O5EvnpJaRJS3Jtq1vzLOhjKYEL5k4ON8XjCATqsc9TggS54mWXC1NO2s7ysapvF69gK1/T5bhu1k
T2JY1PmgOdFnZWpXcMoKoX9DKiZzAkR2XdSU2OHs6iMDQrTQiGAi2ea7nSLjZSF6qsCRvTTWSR1d
HIweaVYDI+tqQ+z/TgHyA4MaLpCg7Zt//fXn8IP2h5+mnBTk/m3Rt0zYDlep8t5FBpROQJKksGTC
L8pW/Zs/PvMSjTXOM7ZJC2szBXLNDahuT9iXqMd7yjXQZaiNLD2cxhMOYdLWgONLyG/7EI9TuVFy
Bakgf55T6TAxVl+/Tvj/X/p978khKBEon+Di4+Of/qUfYLOUQKHHwy2FOeFlU67oVzZrBRvpuVy1
DB9+T9c1aCi+bAkUi8c/b0cdQ6zgE7IWFwMmsQN20yr2y/icn4jShHKorgPHiIK+UYBzjDSS/Qbv
isTqDqm5rPFrB6DA3T20es/k2tozpQOr7shGmVMdA8NlvxhJy8NzgviG3csX5/yYmruH7VzKetpY
gYOb3478b8VEVlu8zKRobHt/yKMHajB/Pq9JErel2o7RIDFuCTXhJmaV09/D4YNaDBP9H7qoNN45
uPDR3Rvv0Q7BD5jvOPp7wtHmWceFz+lr6yeOCfCs0goxXh7S4m189d7U+5FXe9Zq0TziavIbbjDT
eefog5ONtqH7BcW5tJqCAIvvx1xF4Jxat/V8ukKbya6+AYo3YP19Rnmp6jWluBQD3f6G5e7hYMM0
lzOInAzalBOpGKnyAY4wJRUo/tm8ynpbO63HQaSm6yGCdH/UeDmnOHsg6j4TKzxO8y/8yCzgCOAP
vvWvgor/aNvsLE89nx5E83QWb4ISIrDX39vL6LE2XOeoOUb2KaZ/it7iQP4a/neh6eU78zo8QDHq
tLnlgoe52l+rBLXyN8ksMplm/KkSIKpQKOrSoOGOcfswjv8CqwHBPv0PIjf+x6k+ZDsmBsFtL4kv
0dqGYJ1NvD7CyyB0ZCrg3c4lazfZaNk6F+qFjo7yGYxj9pkoj4MKxU5as+g2+jzNGyzRexO48uCT
45L43eQu/GcT4zOgVukJvcKuXO9lEHTjWXjqSTdJBCcTXKRDcgfiBHqgPHxP8YwFU75pZpX5BsEy
AMfsPLK3qs7ZFvW/qxZIQH1vcDUywOHKpuYZf9Pt/izH7MtB4xR99/TTtCpSbrxnn7XU4hoN2zBA
ZTItEwdyLB4CFl+zWsPS3KEZ4p8bOu0gJojsqaJ90pajlgHd8lkChYFZNjR4Rr3zQmYIPfTIWt/8
4dbThx4EEjpKqz4QQhugoUhSzHgT34pkJC/83vTEWKel6xnhv4KM/B9IcLZPTXhHd+rcYyPQCz6G
HLuzIP9QdjKoCNBqJSWbksM7/OjEruPTWa+BXB9KXAguUavqsNYuHAvHwmsa0UwfHwf8rxxeIa/W
Nd3zZ9OlqDX41MDfrPtjSmy8bbDvI6YVg8QPqz+FxoFhlBWXPTidfnVmUzXxlfD8eH7D357mR38k
PNarWHwcw+ps3C5Ma1zd0/WuwjxKEaVoDbCSTJysBdUyozX39PT6/nQ1mDcoFyh08VE8bKKdPPru
AbQ+LKqen3iMs6VehIAJRAsgIdM1OnUjTOhK7NZALPQ1Wwx3iqxgz89szswi59x0aH1544zQECe2
u5Hm3Yogtn2xpmBLSpv9/1Sv9EJ3yowF7YT9o3W/Bo6/lnLX038kAK8xBmqJ/XICFXE20uw7Q2Dy
YY8FzCeordKKKQ3JzNtqEeae86+Oxzy83apxLwVh9IS/argSCxM/2EuV/sWqW5ZZCKEHmBRLPgN+
0GFegGiabLNZha2PWrFhHw1SatNcO/ZvydqJa4/8dWWnCvhyN1h/D/voT1KB+cg3EBBkW3bGRSl2
OuV0Xvm+cJBtQaV/t3blsTOP5+QGKUdZZXWSHAv57HwFOsH/5oTpGD00u8dEz83G7d3wEMFOzOQD
3/Kfg3GSpAWTXGp7O6BkeQRpaCDHukGopt9rs+Ahx8vFa4pGtg8KgPxBXYP6PqLveHAMGfYXEDKB
4QZwc3PFZ2dNLXLzuuw3E2QvI6Ge+zmYXmYVWJd+Hc4lUS7IdfiBsfmfXK0pv8V+zQEVqCKL87Qd
3ApqRX036tvOX8Ngzqra9t39nkCj11W7AmG2ax9FOZwIfhoe3NKFyWE9Uk5Ia3JyqqdYgIhXAsfE
7KCL+sFPlZYDJi8xn0TP0Yokj96fEcRgzTMWmvGcBirYm0+7uo9jQLOJbsUR8nwZU19+eB3Qcg7r
BlmtGrjpxdr3yQcNMMydoAo88Ou8nR28MSf9M8vFyeX5nrGxgFpawPOJdU80JI5+ixlZO3bn33/0
NWmt7IKu7+6veVPAY8dv9WO3krPt6y66g5sXH6sEsiedrmq9LhKWRlPFUNtw9GOHsLW+M25EvOG2
7skfc4xriZvyhiydulxkYIbkRgIWBBgZ9vvurTWJZBgnubWoetyOuHInnha6hHgLAgNKQwvaeS2X
7LjcpXngJvKgj76QH2nR0wgKYot1kxEx+QiasMjTjOIxUTK6aBcYeQWHlK5GQUzbnlniCtashaOp
uIlTjpHLXe+V+53nYUVaW/uKC2WBbZHTWvyN3Qg4V8Mtdh8rY08peAM7gK43wtuAWmmOXKzwhxR7
3RFTq5ZCipUqqwH76vIa=
HR+cPum+oTyV7Z8GbeHS/8ZW6JI7K8/l8UpOYi6vfjc5H3DkUj20SZjaawEe3Szp5eBJS22tOzW3
zDf+elURGKc5+alfgWIzjCYd9LZPPJv4iwx6zA4I46xfIsDPANhRy5iSxbEcNkehPuKi8Zf/6uuu
k12lNj+mSQvMImrfGAOl7jYbnq/Sc8w54nMly4VI2PnISvVGLT6UTWhTCQ2cd3IqFOtlplVuvB/x
DbWY7OGT42jHc6ZDDOSEt/srq1GMOcr8W5/+XJFf6GChJ6iDjLsc1W3BuL3Q0gAbgGkRYLCrcpBh
4BdZTBXlIXQB3ZIJ/0bBw8QTkbuQ/o+Jus/dHwEstxc4+ts1nrhN2XQ4KjAQQkjlnpy7eR/8q0lM
Tr+u0LNtp9glqMCuVng6+lxstMSISszszufjGJT+NcgJVSvK/XOdcx2inXvp7uIYzn/ocWvaP1B0
YWtd1V3mk8STT8LZbRJyebE4XwZp0GmGOuQKIgkJR0jZkM7AeM+AKwYJ+iISlpl3dD3QVl2uRsvp
7LVFttaafVAmmHBu9DiSGO2kUUS3/wDVBXye4Pom3qrQZmzTnYE7XXtICwCd3VyBK9e100qC4w8w
CEjrHLY2fEz+FcRtsL7Hhve7h+Vgs7xoWbjQ67Lb29dcjR7X/7Vh4KuBmH4+3ws+bXV/hWjjtVSB
R+3kPjlEpyqA5soxJlywU2gE7pskvv4bSbVSGPS9KmS3rgEcB2c5EY2+mSzJ0EZ50dV8wbRuVy27
Gc1ow2033DtnGl0WAdcafemjDAEiUJ0T6vCXbtBYkrnDc4nvQViXhQwAwBB8y5761X/i5AYUyBH0
xe9OjWAXXZCtHSA7PZB33L4qBcXY4+ByX9NTklVEPn6e/MMD42Ae20CCBAoCa1Lg116dKxxCfjOe
mkO8IkjmgyDkbp9u1qKnGkqu1fMuRRaaU8NHu0i6CB2pFthGhWde43t54IzH1U8KN+uBQje32MN8
FpJmktngjyy1NPOLsuiBVPkt9jXy6buvUWkLcLuUqdfzDhifacuJOYnK4zra++GvLrLHhdNJXQRU
mDWBers9pCeNIs4IPLB7WyCOKjbvjV58zLqcPhvYtH/fIpY4/IVGyzYJMtTlTd09h1dmWulJk6UK
MWB6cd4h4tkbq3zBONX3B4vJaz8kFaj7xScBjYECc/sZJi4b9NK8Va+B/9t1cHLZGkMsaV8KP+Sj
qYXaomEZTYJEzNrsNcoaf5KwcZTJ4ZImE5XyuO9OVoEW/8qbWdAl2kIzqX1ggE4bO4QKAQtN8Lck
unClavMR7PvMkdpdlWGUmqYdgIeGeMDjTh+HiUpfo/AhRUN98gbOw/6RYsOLEIjTvkfqDfbCMDnp
/zo2RjrAyMTID8y2jvsFTJu7FI7PKjGqudYutiYv/4ysmC5t2tOKbAfX7gPwcjqIU8Ba1jL8ycT3
zC5r1mt1AqiIaR0saar7I3i+S+ubQy0+OzXpkOcfis9zKKn/rpGaao67jMipBl7/Z5v9dFd7w598
Vy7ot+wRhtjA4hQR+tVj8grIA8dFzDLo1OfTS/ZfsosXR2PyzoE+a+UcSxidWOmiRxGwiMAa1c3Y
OmbaMVYwneDHl75W/4biZcY3nWx8QEGVcCKGdvfKoX1PBEpbCerrL5mNfryEMBE7YziNX1y1TKjD
XtpK5MgYr51j3AA5RVd0bKEWRvcsyHICHbrdo3CZdI2E42l2BFEMGZSEsBuufQ12vDfRICOvnrAc
orQc/oPtU/+JVY4qY5ro39m697RRdcAB6BgI5SwdVtAKUIf6hCmXH+EF0pU5h3xFBdGcpfJykZsK
IW4QRkLnau64KQQMyFdZLHkx3lys1dWQBjcxV87LgMPQ1TLueKvziDDroh9l11jAUzd5n/9iKDPZ
8D88NONpMhwR2oL6QE6WQURA6xAizffO4sZ1W5ASaVz0Kr+j5t+1TjaBDuMSWwAJy3hlx4TODG4B
vAYXnMzOpMdj/Z71seder3g4NfkLti15ErOx78tX+43T4Eq9ohfVawXvfL1J3OnOVVU6VRmVD1La
xtP0bq2FLpRovq2gCWmUBuF8fa3sy9TiaWxwplCLqZTnV6ncJLJsUH+RRGG73Kdtx24bPgoK3JY5
HFLcVakNdW1PiFj63wkiLwd6+lduK+3S3MbHWUMKW2TifG5ebGids228UBn2K33GdjnoNQVjzzLV
A0m39gzEkLSr8OixSYdKbpO3yNJC1na5myWrIBbZ21MdYQwEc4YH8Y2mNCJw5m==