<?php //ICB0 56:0 71:255f                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwRPrGgFTYuj9Xj0ALE6EQbiL8AqOHsxWE4T05SfrxrFS1nqCg0fJT65ry1Jx56lsPMXQJPW
rk6bggBp+O7jAYMWCf0ancWCTQ8+yHAVw7234S+LJJ1CXmPf+5vHWYfSBOlgUEEXaVmeGZXzK47w
C/JccivHa18O8ZSXD0ccRvu3BA3BWyUHyMURqP92aHdIFzQEHftu/XDmsg7FIlMWtUtInV7tVF4x
rMCVK+lY6RmUqmIWeX2pZJUS7CcOW2FY0n5HDLfCQwlzPACcYc8jQChQbUx8FT4lIoBc/X32pGz8
NfH+UN3AxtqIbt3JsOIP1cdtanMAhsH/sMphU7DD5OFzrGSJSm++h720LVLkTPRjWMhSRGTT/kCC
KHjMnfYmI7UTu3vzr5LZpl8mhDL//2qknXxWfmChl7mjw2RIm1R2SeuF3GBuVxDuD4ceLlNh0z1E
oE4cpDcc7uRSqL1Aq3g/uuwvMc8RB3lXfigRwQckGV/uh1V/7MlIOeCgX83mbMf6T6BrMW+2aUb8
GK3U9Rfi6CSbCx+cl4gvL0QXuy82R26o/kWltRPyY0qeFefNQ+0iDyez1KqJFkFO/46bHMkwJ/dJ
CrqvBN8wMI1emP0D87q/w4JZrB8wJ0EGcYsHKE3+oZBmP3N9lol4wyOETO79y5tAYpcL9I//60HH
s3/mv2icdKtGXB85A+sPMqglYI7C8EQxZImIdvYBxEMq2VkjWJrG6MmqiOMi0pl+f+rY1QSD4i1u
UCh0eyP9Ry8EAu+aY46lrDjIcuFJGcN+3KR4HmsIXdWdQNzijoJ8cr0l6SDWdT5DKOEaC9CjzK/8
0ZhrogaFhwTbuiHxobYSOzEziFB9OJNJZjxtlFthre/zLAysscrx2YUXp3Wvb0QSmW0pVDHB2LFA
b2j7nO+RI1uct85lhcvVmvaho2g0QNdjko8p+N48Mxr2D8BPuW/BUW198Sy0+EUPWsgxiWzTurQb
ZRIHiT+Dki8JDyBJB/yICjHY2yuAaSGCaknoq0vqjjKviJfhsJg/mpLJ6LvrKxd+gN4L301nVkYn
xZ4D+VMic6dXo8rUhJBfbO7q1atHntYKHL84pwt+8fXGYLXYtIn9coOilsJbLAvexlrDCDq7KGKW
P3M6dqD+M7Mstqz2WIyTvw6ZAvogg8Gnj5sXnb8/yCoReXs8pnD/SFOrpeOrzj3HslXwMOd84uGa
P1HRFkRq3EUvLWV1yOmxZ/t5e9PScY5bAJSJUNYuaRplKijEm67MEvxPb6vVH4OntafSIzKzm1uH
qTX1QrPoOmvpzXTMvSIuPJHmtKilIj//a6+Wf7fsx8JPeFFR8pRN8/Lal6R9GQBvpNOQyAIwoyG1
dtPm0pwCHtp/8LHAiXb0/VV3TXJVVmwDhAu+LjvI6NIgMqorT8b8YOSOjI7eIMdTj4Y8w2H8UnH4
NkIKTzW2rmAtD8SzZSoHMq7ihd/pnPNq/ng9PeAP7dQcL6/odXjv+Da6xxK955UFNOODfzdEgZv7
GKQyBZI9x69TtGcAVtxNXKpdZFg04svFW0J39PpmnNOI2Ofs4xiXbOhUPEaLieuMhq0WOiIuP2HT
zIuY/lGWwJDwJA9Gkat6tieSqCnV1t0Rs642jBJ5Isq0JrQAx+3aotvYf8B9BzIUDvkHyH2Yoynh
qh3DGK47cAW83b8Y/YhKZ3bdsBO4SIdaJ04MOX5nhVjdfDVeV/yLMsW0atKRDa/siHMrIFLzIYAn
XXqU2MpbgFezn8LSAPMHAK/jYcvCg11blVlHTCgZvfGYUBc7KuExAx+YmoAQdPNqw5BXT2G/h13t
e9QXXS0UI/1pMrhK7xNycQIqRuuuNfsuxoNds8+iP1+6QkHGxFB4Tjljn3Ey6xRvO7Gf0xJ+SWzB
C4olOre57y+PZvlS2lDS7kgCbGwT5BuGqquN49qt5gpBGHuf6huIaOr/NItSdNIxZ2zMm3j10kdh
bR41wK6kYmjJxpwgnX2NaYkBjQwHAOlinntYU/Cm2F5r62ZW20v/K5XWVrNJqAHfVKqJGfQDCErc
nuL26ZccouWbJiyB52CIwxMfR0F9DVBjnYj1e+TfLNM1Kd2+l7GF0GthFt/tOqBXmmAui+c19vwf
PRZa992/ksEHporCO9vgZxroFG6zx0nOVNZZDSAG+OKtD2wDijlGCQr7GD75Ju5NgWeph58o3XqW
41/dvdOZof7+FXnuXcEteBpwsMTuuhmnbBSlWR2RcmhEX4pw/el6wnnzzT5Wd/E+k7Ciwi/T+KK5
MIkvInbQIRqK+e0e3WMXBJFe8t/NW2XPJ3kqwINEsVJWAwkSKBz2MvG5YIHB9f9zAxC2OjnH/z9I
mV7irWZyOQ20j1nABrCWYxXAjER47e8N3cnvSJkvXFb3qFUw2AN1JYz1w57/k4lbThQE9XrnQK0Q
cIDkQ1P0R30BX30Xy9ABfAjiwMAB07SCYEdoCcAS4tx0MBK6D88rFh85hu0kh/P2wQeifMD3sGtz
YhpsNRxncPHFyr750G6RymLt0O0a4pFBE12Zu3bO0RPyTVNbDC9u7h5xf/OWPAd7rp9TIQC7GiRe
Quf+ydwYg5MxGbmkVoqVRoNWLPU6ktTDz4lkaaRWY0m9muMuCijNBWQuHZTORdO6IfysSAq+PxT6
bASG1cIk4slX+kJ1o8azbaE3UmpxbGyPYZOg0W35zib/8do+9e/9CI5nAuGSVzGtyErDsv1UMPFX
cRcR4QrLib4Ijb3HqDKUT1N3g+LWJEUFBK3awPYmQKYJFqR8sKEKlN3QjfpNE8nZRD8hmu7mEz5Z
0yQY9EZBZEMwgM+c7Rs2Ad/sm5nabepJy3EJ5MlPaU0VGiPZ3jIn8S4xGgnhIVNyZiINvKKtmfrd
iqwoYimofQZdFeDCw9O36mrioCDvizYN1mmAMMCQ0J51xvStQButk6/VxRPMKyCGiBNv2W1QWP64
5o+icTtWE3fPdpLWSxPsWnFGX1NU/f+SD/x4ICBTViQxgkBkhUFOXow9aDQQPi5Tk8IYlffJbxDD
ZiKQ2hOJP7fhXb2ogoZF2MrZ2IgnmkS1y/sBauiz8R+GdNWEIGyAXrA2rPk4Wq4E9krt+GNpY74D
giZ+kKpKGow5iFm2Wu/IqRS3RFhG3ttstzsNJhhmfVkzvGs6T/V9+a/Z31p+lRrgSPDN2Lsm072n
l52FNwe7zCLopJ45fZSYzfXQtVVQNqkkYdfQupHkUOJl2HRr99kI4ApOaYFOTH/obnAz8xxrtMOS
6QklkWb9bZ3VH/CnpImFemH4BKqKIvdXqncPzeVm9VfsnsQXKIVIEfIQ8QDxn0+dXcNCsrZ0kn60
bmmomGoffwhgB5k4KsLb9Cmno106XfhGg1rIipHQSCQTP/CD1npJV21FCwz8Ui4Us2Xg4cqLsNC+
soEWgasbfSH0noPRMgiPB9UxEGKesWFzUpB/ykLKgvLWN+UG9PlzrQUXBtrPGKFVTb9x+dZgB0uQ
n49uvS6AUPcyTPG7aZNKANqU1cTAdUHOczFm5n/lLKhIlb0wJd50NtGQffE1s8FGBEAboX6By3F5
YHYazREgtdjrpuZs16nRG5H1BMH0Rf/WqiGkTeDP+zBY9gd7+mCX/yhzpYXjyjLsVkb5TlCNmc8z
Iy8G/gvM7Xavp3gcK1N1LRjOUz1vio7mM7kj21l+XplLIRaH3fyQxzkcik9vD4u/12NSxPBYijCW
86eZ7JA5ofAzFYYQLOU3/6WFq21JuHpBpYHovZShcytCpcS5HpQjumAfuUjrRaLEdc0KAVwP0Brf
zm1ZNknSTkBGUsMrBXnk0Nl/fj++3dK6TAeUZ2dABh7SZjouEkgTW/X6vylgg4yZTe4g1oX2gK7M
yjGR62QjMptl41L5I2Wx4symA3xPWwEPQp6MxUylj55hZzJ3jVN2iyYR47eQOZTv0kbDvIECpPSP
YUwFZ49ToH4xc4S6/SLWkcgcqB9/GCiGTBKqRA3IEXOBgFhWBc5ajjKLaMxVIBF5wIy067MdzotP
vSyjerGHppeOosgDV7HLoaA00W0qPpEbRlmx1IMqJv9Ua67A+YllDYtDvGywCwggFYgC/7HuBTEd
TPgTvNw3bFdmUXyT+YAHLu07LWnhRaljgS9bYi2vZb9FGqPNTJi/6RrUrdok8Ah7QXT5Q8mrfHSg
a7/1wjNBQpzjeu62LQGb08NuKwRkX1Guh79f39yQya8sAgvJVlnyMQpSQUIFNtkxEENJzI4S/BWV
6LfKq/HPwLyZhK7f/3NmS9CdkMItR8+jORmr/034OFglPAi/zEFk4/euHj3+mwM2ZNmDTb8RBi7a
ld8FmhQ9S8uSC8UB9F9M93bPwxTjviNYcv31mrO/IbjycUELYelkZvTPlnQHvecj3oWdusOXbNyV
NXofSidmVaqxuEQ8FjES4KtIJv03EMKdDH+UEREh5u5TgE/T3gubMJ6RRTDnA45DAvaO8nFF8rAq
ZgSYBZZy60+KgL6f9vmACcij9w/j2zuvHQkyT1dpKiWLuM+SNaWD8bMEwhKpyAosWyF9bjnZe9un
L7hykiBgZYdoABNO8V1Sp9O/bBSz3OtTYgNKgH3IHSEE5HqdVplFj5+6Nb+ngLbL3SII2LclDs8c
TzCE5ZSKtTOp9Bni9kWzQ5sVhiD2jocIuUqwPn3DlSncX/tHe9ESLPJNcOz1BbGfkRRNCGUMciXW
I+HX1ggQrN/kf5YPWadteTJt9cXpfvbKIhajeM2k1FtU4xLpyoByoti1KxS/eZco0oAENUFlZ6os
HMJk9Eh1DJxA12be7I/Cxi+EmZ4LXMjMlNJ1i2+LPOFcd6T/BPrWpCYG7x8ZGv2Pk8gA/+Y2xax2
r6Pd/H76Akla5QscJMJ2JdZCWX/V5LY13SWA8hJmUdgVuzOr8aW4bLv//cdI5ViEJLdttUKQOWiN
k6/EI75U8TscZt2I6FYtFbshUtkt630qwsJvNvozyLZro4B/iFYRcvkSWOjjccYdQ3UnHpF7CdmZ
kwsH5mtXkVxKMFep0cSqjd/j0sP8POgu74LfgSeSWdgvzsH4zWPCxmcQqjc+YkXygOqLdpruHepU
djs11glDbc5RQhTs4wchHN+bMt7nHNp7opgPfo0B+8leYS4QksaK1wy5T0Qfe0TV2OQ83g2otE22
mrOze48zkPAoOB2OhIy537tz6M9C77d7nO8azwlttBLzb8sw56j7l8OUlBEaBEdymrMCAJVYBzzT
/os5Wj7k1atz7op4Abh+7CojzMosOMW3B1SUaa20QqQ2o6rFp+nJukc/6HvvnsorCHXSVmeX8SsO
2Y7OchdnS1m7NCZiVhCujWBDB6IaeGagxSCWBk9ruP5Zis1fElxd+ZqjQsmDBLtbqJQtlZPAB1IH
lqke05eMdPR0smz8Q1jG4uelx2G8lRkYm+pIFYLxJY3D0fX1HnqdeN+RK3RmoZ+aIWgHS8C5coR9
DZclsUdSYB2xuJyiIIiMayn0GwwENgY+UM0c4whhbvn8C6BhM44Em6GgX3wsLVUDT+0wZZUjBIMr
plRTIX1HAO0WzEiAWn10fCV2E79Q7umI6FFFPiYzYd0mmV0n0xA2whkTFmQOn7JzfJsuBHUkX4b4
8WjSZQXjJ8bXZCsWAB6HlrjFFsgM9X07UHzMDfcDNcQ9EFnB96z6DtftS9eISgQW+6kIe1tB96x9
j3M3R19aCjCVfpJAVtLZzsPnrWNGV+Opy0WHPJ83OID7/p+FYrYxxqzhDWUQ8rOlKy0juf4+91oN
CW9HOd134TT6rRQXQpOwfEsOBTF9pex/svR5JW6j+C2TzRUO5L3352992EgH54VihlokGEUINJrs
8xihyoU1VKxfEXeAianNVikqk8xXTOngbeU39FzsKFDcfieqvn6uJb0oD5i7VJb8G/2Qg9H32CkG
Dg8PGNr5dIsr3LD2pyyuxCdyqh9geQh2tNoUCcxzP7YMd68L5pxVcPVAJVwj/g2VKck/DoZJxirg
/PGx2necXratrL3/RFOhKEpWnZuDEbxN1DKLiQZJdN5VBnV7/Hq52di0oWpHGsS334P9NLk/HpXB
RPtKdEApP1O8z4r4qZamk3zEz1x+8tUNBCav+iAIfcsI/loVHUQDD9h78YBGFgY2LDeWmRM2KBFh
BI28vIpZ5xETYkPzNmwADo6y2H8H38uUqxAben5kL1fja2DM9YwnmTTmgKJqrpA+uP9tQbhVtEqA
/o2ekHRhTx0KRWv8SFTXAshh32waAdZZxtr1BKoFbxJLXwNfMQ3El0yTDYyKbPgU7JOwCAUo184d
xo3nFwx61aIjlJA89PDnJqHGwahsf/ylHQ8bB/3Arp0xqLl5gqJoo0OmrbwnKdHjZgcUJXLzD+sY
p8JlQ1OldCSVh0SMaTlo+my+NC59koNqvszeD6M5sYInV4kXxFtWCwVcmHbqTviTvswMYSGksG5I
kx1WxhNHRy+w0LvSq8sdHznUPx7dg5qPQeb9RHjGJdZZEUcq2IP7m6tZLis0xHEKtGw1ko5oB1GR
o4oEcwFGYI55UC4tm+Ce8GXGhNkWayimgiMoXs7/wBk8mLFtgpYC4aGHHkiG86dq3Att/QcdnBgs
PZN8ck132EyMltNOgUa5KPVQt2BHL+X3IYScve3b78t1eBcZJJdJm/vNUIqHawp32yO2ixlPU74/
YthXd8gMQ2nW9UM2ivqDVzCrX1Zwx7MtbpsBNCqRZdv4oj6AdAlnr/nigHvMGJ6fVBz3sN3H38iJ
S43tMdru5w9tDY4Hn+YTWreCrdRka+ov1Vy2nk3dY0HghEr7bzoGXO0m6WOVsTfamyfaC3qWSj4I
v4Xzv98iUZ+CjrlIC9vRTIS47WmNW9hR9awZvjHuM4WvWHaTBWWl8hu0W5A5oPlnSIUpPFXh3OGf
0WNk7V79Nhs1Ywbg=
HR+cPya1OmXBrrSWOhlsAvVa7mCewgATZAjiPT8aqtpP2N2jAP2Fh1eZi4MLQROSmdQ9DSh8z0Lq
CRI4cG3UURHhxfI/Zp5ww4C4dQ7l+Huhk0Tl2jvZ16a7HsOHyanKgiBK0HamnqkryIlLshz5kuqC
V2P9CNnPaFLRI1ZxbG8vLhU7Z2oXfzx53c9h1nTmRsBPBpJBihXo8l2D7fZQSeIsuVFPI4sZw0lw
BJ9FnVEjh87YOXBqgwD3nswNrwgp727fVfOL0SwNrXgCuVFFjBLT8I7rvO5GxWAYfOiBcubJDPio
wn2vutHqSVMCxL0YbocHzz667H5c48xpLkvPrOdvho+05NwZ6zNowL1nxkZOy5OBKx+HKx6AmgQZ
umfj5yo4VOFdOkRjUS/jJ090ebHGBQSA1zg543iV9kCAddiCAbQ2iu11IyxhsHDtmFuUNyb60bNV
hDSr5VJOZaSfCHzgeR8KSTAW5b4+clf5Cd0gt0WWRRDHeyJNQfkehhpCAdbrT0hXMRbsa3yOS8Dm
WzmAqndMQpdnVUanYkKi8BbmxldgHRedILzm/7gbt+If56x+3GM10U8wxoo53/Vs7BAWb595XCbf
q92Gch89FhMQxAcPxwYJr3Nkvt9blVLMudGD54M/3AvGmFlLd4CE8OSCVy5qWzz/pAPozGuObj/G
TDpgK8ZtvuZwsF83/YU+hoWJHi9IiofPBUXLBmp/gKRqgwjftaQ1TKuMXvs9bYCENBMVvUPgrNev
WRMKlYl1R7RcnaSkhS3Jy4GhCBdeFVuooxpjtmGzptt87mTv0Ane/2gWQzubdv/qd7sJo6kaOZs5
tC0zJOTSygFDdxUH/6qrREDttsQ4X037TSGMCw8X8qeaO9XgP0D46Zw4GMuEKHZgyL0TmSq4ukP0
8YMEoKvLbVpc9bjYuZaHRHhQm8SgPjnFKDZWQej51od5V6zeBZXNnBc7o1l7/EvUVxDBsLA1XAxx
bQFwwanPWUIKyEUHIVV4VdFe2EMPNtEmvtcYPuTwv5B7NI41tO5iNC3xh7rzgwHsTUaRJIaOWMKM
YvzwErBocyADtV2S+ZBlxTIUw0Vk+0jX01IvoIWgSQRM9VmA6sAK96wPKdNPEZxk4SqVYQT8mkgi
bvojyC2JWKHLqQC9wWpiouX7sOIq37vZ80qZ1tpr74HQG2kX6Lpp5oI4eaw36wACB5QGXB/urA2j
sp1uhW7ljeE8zz+dwLZDTf5SPRwNAHhX/DYUAMpFG8KFroxFdKqt1hYIVaOh3R/gv2BHBJ6AlLCG
Ok9W3H6S1buxh031jVlJu5tED89cSzbqyCIGIxxdWOViZHvB3oukhovV/iWXktn3TyvKGcmQiIg3
zcsl/oa33WOfxTah0Qa1BP3at5yArkhJ5T+gU/4qPU5q/jYiR6BAYRt+wOg8U6Gu3W8JA8/xXG/y
ZbbHuu7O9T676hSfUWGxIBdlfkG00cGtP4sDM9zEqughfUWeRssv/pJpTl1ZrIU8wMNlK6DP1dne
7jJIDUf9SpHnbgu4AFnm9nejN3e3+SMlR+/4+7YQu2Mss5wgszW7DK7CAXoclBDtLDJPyMo4ecjy
0IGmV53AZOv3ipdQpz2ZxW2/2jFoxF9EKm3PHvTHUb5FKhlaX3jCjGiiuyPO4e7i7d7STBML1iR8
MDxjKyrC+GYCf4AyawZrEfFFsigHEomirpjEGDPGPMa5S958SK6fn25nPgyOhLXZWL/A/NY+reS8
tLBAboI4oLHbHR+qvmiFCqeSjdzL+5YEm2cfC1H5ueXbAO6zbFHdoc5y6gGr0a88t/ATAw1CMenE
ReXkYYbe5zz0/FnvmcbyMr3M5D1NMmxeIcKs1YHuYcnyc6uL1egYHgEGUfKDEvJlqYLjnnVdltcE
2a0YE0Ewp5JCV8+yCqVQb6lTTn8wHTXDzjf/HXC1lg+XpLTyU40UGILuTt8m27n0ZXCdxwgRRyQv
KSmGklIv4Fh4MhegYBz878242IfewYMEkQ+XTesHtcANOUlDjo8ZBdBjSiysDn00pqW+Y/GENW13
+juVko00dCPw1WWIWx/7B2RODhsP4Bh20pBQfuzzX/l2aFEenY3bn9Btnrox5n2DK3MDFnarEuoA
mxKYX28sXtihoC5wSmIRNPWjYBUFgirG