<?php //ICB0 56:0 71:1456                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoaWx1k+eDHSD+rvE2MEyd9w5jurIsGXeDf3qg4M51gw7SYVSfiSRgj7JCBpa6FOpYP+qiJy
VMfWXSfucHTjPthKkZfapIGFIk+F+hEovChNB2V82l1CrmU4sUyNDBw4qKsLH4namC661fDU2D95
jZry2jKQEyM2tABlOBZo72OFhd8njUJFc87FXwplYkL8ZPEY9BMNa9DuU5UBjk4xVuf3Us+hdzJF
6is1tdXatLUCBs4GNRWnlmN6HbTpdRI2t11w2a1ZdgH7+hYRqObc8LLEjeh8FT4lIoBc/X32pGz8
NfH+/szotIRPkCFDfxTb1Z63aWU8Ac4qBOhps9KIZ63u998eCX8XS9b+PYSf4FXUrhLw/OY17Oww
U3vzoM4UUItb+d/xjw9q+SGxMZ4EtGBW1qrlzsWg9EcBIKO5/SK65x/18Yb9WLdJrkyNF/pAHba3
nsoipLv+crxjcuffRet3+g5byUmrY/u0z00Ot0fgXrvhQJXzDJfuWKhoG8V9MtQ/TanyY5RwzMCl
gini4B68n/YhQcjMWCYdXQCX0yCZEF68RDGr9wIXDcLWt+keQT/ZIu06YYTgoWwerOJP9EB5WH/I
g1OmGImtClawdjKecyUO25Iy73s5QFt8hkh8k4uQbQDl4DIWxQ5RH+6FVlKfk/cp0Zx4UgtTeFKh
niL50rAEhXgOcq12Tw1Tonq+5jZL7w1ZpRgwOzKeLH6JOfYPxc5r+bbHfxMJSLgl1b5rDxda7YgB
+esdWJVmXDMmJplMhN6Hg/DLDqw93forJYpUq4Ge4+B8e8MJU6TNrAbTRH0BobbXn0qLkXCZ8KxW
fuMicB4LK2+T2HBEWdSKlGYVD/MUXZKw9OGu2pwAHzMYUdaItifGeJ4tMM3AYdxyZdBX340jZvfS
8L70kn29rG5RCmtjxffyHCwOvXG852/HA1mh3bAL+vfLLz6Aw4r/ErYPJIv8ugAN2hYHAka1yUyK
AmYFjsnR7nfB2q8H3oe1SsEmbsh62v9ziAz1iqO1CHSdj9To/9UEt0t+hDB6R1xrpt8OLqv09mKm
wM8F79C8lfQzZlS/xMwH94h4338J4ArK3uofwATO9xCKvYQC93fG/SZCAFMb70joI5LOStIkseFN
9GzJBL8GxMZ1v6FSWYuscSRV7haBTWSwC1LXI+SlDh4cWVlXm3aM9ZEy9na+JUKg9J94mzXoMlji
b1EfCp0hqdwo5H/rBm7CM9KvI+xQWvL93pMDTbII5jyvVh1HWKn3B8laPRnP2TiLsEHCthWDBFf5
EEacX/CeuGVDhHjBL77DpageHE8XupvkolK9WqXY7ao1ZYqp7zMh+zclJZyQl7a9KKj0BOhoQtig
2IhmZn3/rZsdYJZJYlvlwKaiRq2FqezQUCRZj22ml2Q7wnBuT6cK8HQyUtAg9UcCRTWVHKhqQTsM
Z171K0xEZ5U95EML4JCCd+Qqltl0wrYQyY/gJy/EwkT0ftUmYgjg6dJvQMqJ2BRHfuwiBqXfbpby
g7epFKC8NnF3aX8vuSgFhIopB+5Uq2ClVrHA+GPNpbdcpEjB6JN9HSwI+NAB6Qu3wg2lL3bGZ12n
KFtu8iRGlOWvD3BwOKRTCZk7lGP07rAgSO3KXJWqdoLkwbl+fweuvF+H1Sa+fJR7OtsMOZb4Rrfh
emP5dCf9wlD+Wuouyizup/II4mTfsYKtn6fmVSqBZrbpRZujM2nz2GJWQrg5+SdJEkbNtlKu6FBt
Zo7F6hDvaaA44Re8s0/9VWz01CUZ++TzYFUGCCmF+caD6DdpAF/JluxQFLlajQlqqdlrKODia45d
+m9VG7p82WQOFf48/vzWkKD89GQS+ontCV7aMvrhwP7Q7QcwX2SBkeeA3H1/str1QXSW8wHuqsL9
3BzVbl3+yB1AEQdtnnl5b9PyFMOVdP14P30dHjb0hB+Zksyof3Ts25k/1BvURc4YO6qVBr3Edluk
4uoFEDOK7hrmrKbZiSAofXIZNkCJslKd/rIEEUP3Jyk7CJPDw2cBKHpWib/OUJwemg5gkaPGvboi
18/C+urp4kpialmisWlM1LJoZKF07/jT/V4vQqMILkIW24Vxh5Nj794bnFcZSY7+n2J68+7ticdx
wiBvgm3i9qFW30N/bGmz1fQohha+sj+PgLH2o0xvgVnhYynQ2gQxUjfFrKN/pHoOik1ORh6MEsJ9
ryxWMoLFhGuCfpv/1i4rg0iZH+n2FQpvXBqVst64M6QvOdASsC0OLzXDO0yTDp3tyMsHmCz6o1A9
Zay6W237ao/cGd9AzCqXFfWXfT2FVtIqSmEwKU4tcNAM7Uf+zcgNEkU2YiSZcmluQCYfAVWJifcx
bIJYZ8Pl94v0W90TMziCNWficJ/gdCnGwaOPsep25c40oGXFcRCWBJuCccnyG6f2+99Vsu8nvY9q
OVacrLil3XsQub5HCHScDb15Aliv0RR+SV+OgkbbA3StTluCrt42AORtWxNYbg74MiaNkZI3O5lR
wN9z9LvJQPzo6LLDmNYUCjpX41yTnzUaz+dbCjNasWOIOn5GAVTE5jj4UQauEPpZAnkn9bTGt8oW
4HWSxEaD+NvNsG3ly/uLhFZ00TfLVyWrngcxNJvODW===
HR+cPrMfAKssYv9YFnQyRZt3DjLGYoKlZeJmLVCuu3UN2FRyi1RaYTGhwKWwE4Rrr3hA+yLlb3Xe
S+pgiBkFzOle9RpUNE+7x9Rykxu9yZwi3vCogcp4WCOu/JH6aNiAjA8OwUJRnyzBDAwX9pMdyKTW
Sc4c5ImoBKSPNJRvgiO1kysXAWh2xQmX0U4SV0R9WLfF1YByxnFUhyC7juvAwMufYz+pi+vuTgmM
ZX5eLizwf1eipIaA4IylPKROkyl2BQUrclDyZDWBIsDjpnfCIQxD5md8dLvGzGAYfPCBcubJDPio
wn2vutHyScNZjjWEqRW2GRxsdx1UTl+uTXmV2NP1Z3LHrOjx4kfgCCebI711lOb76GobbwNBCH6O
LE/dD7sUxmUFSxhh5GDVnry94r1ohDxOqF6TxK3+ZWP50ykuhJSR366tzBW0NTg2fFhb+/nBvfjW
QQIYDUhxUFGgSuLpYqPsXGMj8Q5q11AAI9zmwBngjYMfY10tdOlVTrwUCuNK2u+vJ3UMws46x6Pd
kHxQrsaKpcWd7maMZJ45Z3ZDxIRjKzCc+sspkwyQOtsrJiOdEhRplTMGRdDpPs5IFnMdCPmGCMgn
y7m8HrLnwj/W2fPnA+NA9YBmo7j5CHf/Hz+2Q7vZJFHh5s4WNH/aRsb/e0sf2IUrdUm+xlL1ygdL
NhCmd3uNpTZv4RqcOz+BWQbZBC3Koyrk1NpkbIfpGSn+/JRbEBff1Hq4uD6s1cLSFdVWDERZnJ5f
lfvrWJuWlcmFzzlcAzh4AsCvf2t29NbwsQrgiDyL32p6ecF1KCWZHOfGEsWCNE0B8YAfTKda+vj2
/RxmGuEa8g471RcjwCrMO/vRkmAxySTSYaBeicfJinRD80E0QpJKcMIg4MR0ve7J4CIVUXP5Dqzg
S7WjwiRZApdvJh2Cq7lic25VY2j3vZ8U4HKVe6nvyOqMPc5GZpDMZaeV6nPmvus17iSM446rD0w2
GxCGRqwUWcKGo2w+0pihA8tRd8wsIg0t4rYEVnVARkC94xUyd/XlhePrEgcknKpnAWtK4upTORCW
0NO+6AKjpq0ASU/W+U2vs9TNyIgELrrq/2akpLXFi+oEEdZIzYITvhEiEQVOUN0eTp7HpePWO61l
WY56XADm69YDAAt6Zi8IPmxiT26csG9vnq8Dds9FHsn99R4mPd1UKJ41qCM6m0yRyGzWPGnzlBau
Ezio