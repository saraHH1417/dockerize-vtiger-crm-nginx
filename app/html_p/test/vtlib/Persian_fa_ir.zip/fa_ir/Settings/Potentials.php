<?php //ICB0 56:0 71:de5                                                      ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpJx69oKHk7J4KkDlvFKWaGdCsiL2Q1BAyLiki30hwCrhhpWPPpVaHP1q1I2TJiLPIgoAZ/G
XtSJZRJBRjAJ5jEKeeP6k84l/l4U4Rstz2jysDN3J4gQGe14wxSoXgF5Fu46TlSTza1bTq4X5enr
aMwi1uACnl5Qye2iNOIcjWit/sUS9cUAibiIjiesejKHVpKg2PVemss7xWeiRxRT90hD1Em4b8F9
tzTaqIdJyGRb25I/6CJGWQRCEHHfcVZV7EqAbKMEuN8wowz6E4X48mLjIip8FT4lIoBc/X32pGz8
NfH+E6/fmpM8OFCn8dlk1Z63aYp/T//YlezUWj3hRexr+Ns7X4Zf6t4E/AFN205HdY/hUbIu1o0a
3zsGrQ7/TtGRWbCfg60f8pFHv9VYdFWMZke0q0nweCQErRaXljwWtg69bKYy28al6liBcafMgJ20
JP7sljLT/RDLoaek7E8/+0pZ1ypl+fDcW3T4dURTAw29mvRAV9oN+0hQnmaUrQ6DtqgdD+upFTlu
TK4wWDh3LOQCc5BUAaz1l/S85SchG7MsBwqYoJTGy+d0d5EU2kf/WecfVCzcQ6dbivm+LaT9GwYH
ppTkVq4jx0RyHWNx9w/hSBkCNbuwqYoevAcOEeK95G1k7FuzT6y0vjzPwrVHKlhpEbQQbhQ+Fr6W
ArYvLkpOZZvJXWF8r236hsew9qGDu2P8QLGLhSkNpzpIOJNfzUAsN4Uk2KkkHfLcn46+XlIsK2ik
1atWHI+H/HNznUYesBsrXngbgXitQvgyUfEQXreUmmt5H8IXUWmzqSAv2uUryu3VQ0JzINugZxqX
qWM06VJ5J8NS/lzruV47pclisXw2C71VZmrAWOtPJMHWNfSI2pjM4fAoq7oaB0DgImbe6hihW+Kx
hqu0IksK18VhYn7SGdJPj+ukNm3Q655dhnesc+F3kT7k1pcdPl+SAf0O5gK0Ktwbf0DIMLN3b4vF
ZkkZoFbDpW===
HR+cPzIba9X1TsdVR1i5kz/K3gBgSKkbNL7kMCMv5efow06yjcQHCl1Tknf5FUh0qLa8DTrfWgrS
SHz8ocV4xKKIRr6TeVK2Ov3Rjkb9Nbd4sZUI9tYxonlSKojAKAjuRYQxXh1rwca1/8+C3cdUwvXQ
BrQywLNb+ai3s+VkA/BOCHwuRnRCHb6HUG25sZJUkYqwKDK9ITs5rEhevd1LcXNccscBzgfonybo
VZBN3u0KS5DLYcLopiRk8YP/4Dx7Osm9T7+hUxJUL+YQAbvyKpLzVQpa553f0gAblWkRYLCrcpBh
4BdZT35qcL1/C6J7wUV3lVQVi5v0J1MbQnTEdCc8RdX0A9fsyH+ihNMfrCVUogOunVaxs3QsTWir
B+TrbO/3iDmPw25ZiJaCAsLlezej79FnvYhrehhSMEX3JXsh1/JvS6I0PfXcRcJ2byqUIaRG3QsQ
ixipt3tT5CSjaKzTvinpMadSJ3CRXJ98VC+sg91H8Ro6K+3lmqHA/Od6Tf2E/bJRPVkkgAy35B/Z
Gd74qUo7oJFF0GC20LnrLV62UOOutirbyapUYmJGZpurZYuNJECAuqsiZRx017YbgPy31i1y9S4K
y0Bubu4lpIkAJxzbvDlZeZBKu7Kg6gyCx5N62ZEIlM0jbhPkkfS6ORrBQB8BIwKfEiVlrVZXG2jp
FZGrAdLov8vdWI/oJDBIonyt5SMUU7JnwDK80Ymsof6E+I02HHZMQvk6vx8/WikVfKUpcF9kye3r
6Vonfle7ft+cJei=