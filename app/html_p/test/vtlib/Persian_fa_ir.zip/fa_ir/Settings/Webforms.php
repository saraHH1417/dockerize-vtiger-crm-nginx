<?php //ICB0 56:0 71:2ad9                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqFU7Dl/UfBb7FO0YVZWFeqrJpE0T5t4PEgQchDIUpRiN/SxCDs7cUDRUqzrqaUzikEk+GY2
9x4rwtVZWiYDfbMcFOVMRn8h9YgCjvByq8bW/g2edSkWTyvhRsXL9/6Yz1udC14FNlBvcIi32nrs
yD0ZGDTf+wl5GDzLnZAIwz1R/j8sB+SZ9ZqbMECUdG5Gvn8ub/knowmN3HzdEieMtLtUCoxUe5rU
ZaE2ePbBQsjg3Ql/XxGjY7vtY1H/ztQuZyxXdOfnVS+nOisv7zBL+iPCp/x8FT4lIoBc/X32pGz8
NfH+VdRnzujnONvD41Tb1Z63aY7sm3sktFJtyoKd5/u6bpYU5UZr7ukwnxG33/LRlrCiXKr7cZzz
Cr1AfMR1LLUIxPp+qhntbIss/SYGxvYAhcfoDWNkTSDmLrQpPvBU+s2Vy50baHv2cGH4z3g0hM2p
AgvK6D7q43ZE29aXJqzukxVVNdkdkZYWlR2NMDlesL2D/xhbTuOR8cnMIMjptpsOMe7BrMZGnV1f
UZFlGBkgDvTKAfvcgymcqQ0uCFiU1WwCe952QETIv0Www1XuPeH1imQ8J3b0oceEhRvqYg6oXpvm
URTUTfMZaGKfex5s6M6IA+9vHuv7Kr21YwIl12LSREEjCW/SEBfxWQmE2ABs6oxLd+kuSxq+VvN2
hexPAzZBZ+GAS+MkRDAgsW/X4ssO/GA7pSdQi7uQYz+Mqg7oeSAh/Hetxu+ratS/kQ8w02z0wU4w
fL1MhJdHVyXHHZPZDf+3qUFZecWQgBFVZvYet2+bafgaflAzoVz6cSQhWh4ZoqtHoMCcurmYlpcb
3VKNp4IYD9F+RlbxDTGIXnFJwh1uyZxhxN9g7NscyOfESIL4UMaSyOI6Z/qc3Bp6loTaV1yIc7cp
jW4PeOvatMeP78qbGKoJwKH1UjGFKZ/EQlGR7FH6Y1EVyNjcfHG9SiG6dyGYWdsgRVHCA3MGx68M
3TguBCVIOei5GHEfnjCDLgqw5g+wL+KNvm8MCre9bcXziQ+ObX9RjJj21zDzXgBruHrCzkARItyo
AKT1IBYd/CJix46VlrfpEvVyx7PBBPORTCjAdJk+iRYoj+aSv+ax+pFDE9/lwsfiHiAMV6wVPL3Z
ximDlUMwYVzWFVbV3Q/Wi8bU3MdWhAKEBoxJW7amvd02zfB5kT8VFL3W0KDH0S1Ii/xTsyQ9MHCc
Kaf5OIsSiuAO9WV0QrmcTLgiyQ5ZdiR30KHWhWTzafwBKDFBSFl1oP3c91MHghugeqbAjWb/DCof
wP2HjTT03DUzPmomC6GZrylYxbSrDMzCd7faWERPKfHXL/PQL1TjshtYzLNEZxBW1BbB/amfEXnW
G1//i6VbgqRnZfUf3KsA0gfvxUWa3vmTwjSXH9tC0PR9dSrf8venz8lijigW+HxK9qf4B0xflJ+b
erK+TMH95XDbHEscfP8aUEZJIHwQKZrO6aAoUaSduteAPhIj9p9Ow32utY2r4xNWsyAOoTKmxoUa
pXYcXddsAm6Bg8ocB3YkGWmYyo2dSwVwzqkHj4JfQvJ9wxpKvHxT914U2HEsIjlIAGRr04TSHTvS
NTgz7vubPX+XGTwR4CVF8mwYw0Z3D0CvzfP0dc3Op41gwDpRjfsIZpXEM7dVnIja8X9CJ3b1P12l
xfYtxmqAC7x8k1WU0xVFxyy61m0RXtnp/rIFhzb07O3YFm/OaM58hcBG7YCfEK+cWFRInr4StUI2
cIXo4dX8g4JMqrSGvVPskJ1wbO0+EXxbqbO4WdA4i+0HdmSzQc4439d6su6EW5PnTSJlWNJX8lOk
UlZ1qSVfbNBpGdODhNTfiRyd8eS3ystbuSFdB2qWPBVRKqw1DZ4F+ZVwAVJl0vsq57wn1Sl7YHmU
FMgUaUsTTNuiZ/9uyyEWMcp0ZVBgCJFM3GI32BKHXxdoKSikldL8kHmKxq48gTXWR0OSBLVJxEvZ
Y6crHDBIMn+zlRTfYcYadAZQP3/TdAq992QKB+C1ZITqJ2leC9pzU5MSkT1E3qAe9wuE7jqnogLO
meEUcaDr/ja2xvRwsSmtvOhEwRrsz22OwPbyzrYIT1g7n5LjNKDf05KPLDr7nhSuEODgd+j300Op
Ct3QBVwVc5B52Q+OmjVbMvm4orUQ48SXxfE5FGiIlA4aFw1dhafSmIrP2pTK+GCgc/7Gy6QAU6le
2tkw+NEoxW4N9IvR4zxrEL23YifX+pLjM4rsrWUqLeUiAO1foVXGvu19HEEJV1xYH5vbeVUuBNBG
FvYvdRU9PsI17+s6r6VVJbvXd7dOif4tYEypxcWfjak6FRZB0rLe6syP86I0vD0F57OnQul2JPPd
KnC5nCah/uavh/qNjWnzAP3NVdV50Ir0/3XsRzY1ghKNbMO7/vLTZXLRX9iHRVTsKx5bdNHuPFiZ
BOGY1aPM9hpx0PVnZs5elbQmeAa9HVzHS8Ag2mEVCx4+GVEeAxqhI6EL4Y8H0+70U+TgvGgoqIf6
47FsCpYBXeVPzXdSNL8eVpDdfQQuT7LNfUNuJkfsbEvFYBMThYZTGiMmXq3kYHFW0fhvMptgE7y2
ErptwyNGfokiNRM3uFHsofHVv74Lhi3VLSo+dAGANP5ey+CMC+6fRGFy7aO/rW9VYVEzjXD97sFW
wiUbrH0ZfCs5uLGsYrrRD4N0RT6ePfEyaAuI2n0z3J7epFOWBXuL4MA/IXZXD3vum8pplvcm6IBV
hvbfwA3pvo1LhlL9IjvMZp1p9y7iG8+2KOsemyH/miTOxH1xskPBj506W99EZe7OifHpUy7zRdt9
B6f4gtPHdHQGBuoC7KLX1/UYz2uOA3yOe7OP5zUgvQa6ALVKZe2LHwd5QY4+JSi4c4PDzWUFhZFI
xv60nUEDhqk5xS3eEV+m/IC9X07od5jIXUrowMBejNttgPs8Ab2E/HT3olwq5C1WeWToWn5EbxWK
xwUZoN93m5O+DR8NOmR09flGjj88mllbfiGx21BWlZVbURTA3mbZj7KaO/hCKg679VXOWbx9SNSn
vUkhqjrPgAP95Bvxk02N6WnyKP/R0ddW5Nvaic78LTFcDZ/0iSBOUJBGNLUIVgBxOKF9PsQeWpEE
qu1g2h7UutI8VP90XGoDS5DZu6jtTu64fc3m5xM1/oUPvva9AomoNA3caB2kiEpoBDb2QABXpDO2
cWQz3U4X/igPa0h9XaEAsAD9dbNFINYeoeiXO5HZJ+/V1R6ysUZnFZN65wrDYTB8kcOm2d6zukxY
v4dmOdFa0nl58wwymALIQnGadrK+QqtyMGJ9wuZh7kwHs6847AeDZnWpVszrAbgaFlf9yAVmEOA0
YJuFmN/HcTP46fvVikpzux3fdlyvEeYdJ5JOCLdodlws3hlXscVEfmoiT1K8TRztVjR4Q3a2PkRk
r4i/LIGLhqdntx1tSbG7BSaCMo7TIR0c/x48Q758pU9WYT60z96GDmRTN6Q7Ak+y2vdSs6lXogMw
4S5fvJ8QDibLH4FoFIpWQwg8tK1ype1IKJ+IXWo306IoOsn85P3N/8Tokt8N5zGCr2n4DHE8HAT3
1N/zqSp+XMQF5o9JVc5OjDY1a8n4kNDx5NbN4TFTc6qJJQ6ZibJJdgyjtpNy596rNnx0/knYHasG
ONYgM8tnLO1/6qnZRXpUdTUD5JOFUqGYmFhVFNvnDNnfWxi85fzssaPFNc1mlSnH0YbhOnQcAv63
gOV7BlbH2g0LWDJlqYMnhJ8pAj1elgHpDqVccTQGd5HQ6g/zV+/QOpO/oBLg31NluyquA1VSb229
7U0tNjIgajc21M+dWqGKdHEXWNWMTORTW4NnCOYccCGNunTfQ+bGfc68zWFbPNH8SAlkrRb6KZ6D
YKWPJ7jdRxDqIrLBxSWi7ariEG/GT+3N7yp6cjkA2VGIkTDJ9NnUBkeYTsWMj75RJSBGXA4fqAYk
jqiUVIj4M3hie8U1mavC8tnOCBTIkJt2R2nR4UL4GwnsUXlH2CUG2aj4rQLtsEJ5w6KWs2AT3I+h
Xd9GS5r/PakVI95I3tskixngt9SSV6WEXDnlbdzboGSUekKYptW1GTAeqbGQ0fSLK2AuCiXebvu5
K7kR/XRpqUpeZWF66VPIRITTZHvGqjP5ddqvRl+SLwbuIgfEmUwCBtosTJwuYi0H4CRTaY3GuaW3
aI+Hyw6mxJvr9axZQcD2uJu65uhSbgBuCZS9tkmZcExp54C+sbGAKAJqlny8owUqWFWlx/wJb4eZ
pFy7/X4imtZ3d9ATeb67qt+yipU+KWETU0Lh6ol+8mmYPwdO7Q7uWG8SzpSp09KNaYrTNYgz1gUv
kNXqsKmDp7iwOEMo+7bPrMAK9ADMEssrYCDpAl3eRkInCZFyz6PlFwuMgmRrIrZ239xLcXJrHjnq
NLc6QpOL57n6SVP9OcfsPy21sKNyYVvVtyOpxbMZYRwSGtga5MGRpLcqIphpqAmjp2dB0mESAhfQ
Rio/UQOkzh65jdGKBlZie5SxTvv+Do/dy7PXq/3yVtFWg7878VTNmqj6MRk4OT0QkAT/CZ0vPlwK
07juTfd+x/M8rWC8SRoOARTArifV/2xk52XrQpzaYf9sRegH6zln6x8nyTDQr/0GjVhbGR0VcbyG
aC4un7LDkzazk/k4YjrU2Qf4DRCpl4v4c0qiD2swGgw5wJiEpOm4DNY+kAFrzqwAQmIlFxKM9KQa
KUeE3jXd9w72yApSQNIyrFDdjTiJQc1zo+nnNyrGz1HNeu3szvnEK/TH0CM6UO6/YS7wPcgIuM9F
syNMX9ozewCRewX56bWIWP1pGjCUx3AtqWro6DK3UYBKB1J4ZwxVqz+bSEBmHmAzFmOCze8tohSO
kaJYPJuETB1LN4HgoK65vKGcZRXbIZLNYnlT2MgKpHttaNrtdAjuDqME3knMEH1wsf+tB2A60Mmg
xRFSykrMOIkI3n4FybbyzLFuEiEq/MmKw7BnhS1ZbW8u1QD65thQFW5TVNrRlB+yY/RvaN47Df6n
zrA3uN8wQH/pWe8Elirfq9qkQeDuD/n+rs+6/iv1nDaGKMA8oZl3fGGohp96sMfng4Sb043netd3
+IfXB5Uimjo4HVEXZHQIQ2g2Ktqgr04PHKi6S4bWJylrlK4qhwaJ1OU2+zTjVVj9w1VHArvkAv/o
dh1cVmm5DSX2Ey9YmsIKQ2Ew18e3TGFZWAEUQCXncupCwBbGfNCl2xprwLX1/6baN86/TNyBaJA/
hLvb3XMG9uyWFnIwR7DoaualtIQ7S42dWhmCDXMA0iK2KGOeeaXMZaHt6b3eoxdVBvDZ3HSgALoI
pTpNAUZftunUgthCBZGChNKl1R1DvoHGaLTaMTudGn8RVBww7DFrRjaDFs9N8Lf36qMfMU2AFiPl
vrS7FyF6tFh/bTCzivzCjGhlmCA9MrEu+hJ5gWgjIWF2JMivofKvVm4/dqzMD7HyD62F0XU+qJN3
/HI/aYSSYLSJLTXCG0stfgyJJgzgThoV6h94eoDOIlj91VF5kZGgstX+HJwAa04wELqCgaCICOrf
eUvPia5kFsHixd3SidLIed5dyKZ1FtYdNJj6sSLgoc4CpEhBEw+WdVdXXVIqDuXudfGCxmBaLvuo
Uxa0Vu44rcxXmExoJCK2SLrorPVoqz4GZqpa3UOhx7bHuytp9LyfG07MU9bX1+bsfhyv1E/h/f+U
cNg/v3Nnfux+MMSImsMlJRDnLN9HSLQi9M/ARNssgYxqkYcBLAUkZ4HmiiOtZA53ynz8ds+nb4zp
sfjIz6nE/9Umrp2m2SIpiERCxQvwfBhR1D6Q9CadpMvhMmnpmK9tTfrcYaPoPB9fvuiWw/lr4apd
wLovc9QqA1xsNXJx5//rhIenYsar6jiOi9TzEfBZqFnTt82pVsxP54OVOGVSnMQ9R8c8CoJruDhN
na8PxqoGvy+kEegRVyrTDDqeDubmGZ/Cxy2j6MkN0im8oM1Q6Vh8oRSru6heppKdFmRdDqyNWuml
cQpMuL1LW90oCOvfPN193Ye9j10DiBF9qi1D0V2YTShQnf61bAXi1U7BE5AZJVAl6EXIBQ9vr/R5
7hUo9dYTylSOwcQksnXCqRWJ9ARH60nIBUKwIuu/QI11oMejjWTqqaqBu7voFV0rSuCB7y4F++MI
POJ84z0u1qJ4LyqnImvh1o8o3Ys4GiFlYUrSWpJZ5mYcEbQnbLlal2f8DIPG0cPq5FybdgKu+emN
XZl77dhzVcKonViKNsrCC2iXh8tSMrdPT5dmO5P9qBLWDPnRQk0tWKxhU1DDMQ4Qnpk4AE75k95Y
unPU5WYqLjANbA8zbP/fEMf5d5fDQbCU2b3QnaQ0SwD+TUuJYIonjf7BJpJ9J8REfHD1OS7EHT1t
wKLAGXprSLgdOLPYaffRAFYZdZvGc1iRPymduonMh/n4ZTkczGnWdl92zdcXAp3Osss4QDVJ1dP6
C6tJG1Wg4VoFrHy41AKI3AZSJMCwGBbhB216wI3YG0bh67umfktS8BxdpPNrD2UX6cejzRQmi/mg
21EqNEntI9k8csodsLAAd2U9E01/TWDIQqe7ldq26mAIV4UCKoPMxOlmgD47QD5IhRYN0erIHvKi
TAgdOz02qeExW5ThmMhg+sbT5U0eclh9XgJBHYtUZJ9RMqbQTGE0BNoc4Lh2uTMW5YOMnwJG141D
HAUmK7dSFZHRHQIMadeg6yZ9Ku7Fh0rJK1UVj2U83/OQlbCA4Jk0hrECknMbIDvQlteMJ3ekFqJq
oPSHnRGJXfnvkSQqHgil9flLp6925Gejip0pwHYwV86+WfFTjDLZnn/RSfP9zH8LvnzsN6wwSuBk
yzJSNhHdqHRKZEuteU5voHjlUA1hAy/Gyk45m0fTl06nFfElnUnwObEHBA+9CdQvb8KXj0V/MEFT
w0pAgqcPnQvBLhMNC8DtiRcPTUZ6IV6pxG6EEoBexxP6PJ1U89MgeIPh3oaHfxn5iwP/UeYCrz5O
5S9HjlE0X5KV8APVHzEaLxrzY0bkM4ZNxb+naRpR+XXoOrlDY3YZMQRbUkezMe4wLcLKoMDMjQwE
uhy54xKMi9nTtArFhUoa8yYQVFUPjflMve7lEvJMddwH81iQ/ZRhTrMi+f5TZoObEDKif5GfSz1s
hHIkcyOkaFx2hv/nIvGMeChuJJ4s5PvFMT/kPN60HGjO+yCuv0jIiFSN6tgwHIekFZctxU20r6aT
5ZZ8KVCqqnP5bQeXJ2SKlhT379AOQudMP26A8Df5MQBqsLnECFtNGJHR7n8aiTCDo3XxlVOEsJ/q
RSc4KKV3gCp/lFkY64hASNoxBv4jij3yywlJog+rj13M+Rr3KLY19rBlxb+8gvG6AUCsun4Eu7V4
y0O3sE6jDU+i3ljMwITopBSrepG+bCgzws3giMLb3UJ8z3kE6vp0ZsrH6P9Z5m4r7kNf72DkkBxX
EVNRuudCoGOFgk7JdKYk+9nm8lamgn3BUgAEIpYCgyBTZhdvYVWcOYv/JWRvTapXJ/eJqLgv4/So
ZYG/lTwEXNHjc7LdgxxGDOCfGK4H9LgWxtCp97nVXqaQ6GQ9EHySBtY2KB24mI0oJhv86hbWW/xe
HbHS/muM39X0gFIiqdnDxtoO4zS7cjrOJfJnWmw7+IwPfFBIkirrG7A4xk8t1ijS2yCkfs9VRPtk
FNN3U+4KdrDQoSxwbBu2wQHy+kaw5i33fLjPWMJrn39DTXMXDAcaBoIBN+99lSqj4puRenZlVqh9
Qj3KeamCvpV5fESLiZBcGeHLYI2GdPRAVMfcS39DCD8KhAvjfpNdjhiSpUUmP0IDnMz5RA58Mfme
0bUT0WEgE8BuUtZ/XU/idLTROR9WIpE/D6VQWlDkID+842ikAMWrQQtPyj2i8QitooBhZ06PNX++
GjZc5pJFvH0t1pgR2GghccE08gqpNMg4qqf05gvb1YJRGlJ9fRyGAVRO7PsZ8icYR6g1UkxCqhiV
6CUtcNleV7yMQbJqRJPdRhhNRwg80tPoO+znkYWUz8Z9ZHUswmHXYfh2E9AvL9yPCR0daEgehjKu
3TDygSXOaqLqugfVwvSSDHPYTLEyzYDe9ERg80+kwgdKrpeX17eacqxOK/lB00B+49CL47UynNn3
J+zmww5dtz/Qt6L22ew1M9QRhTUnDlozfeEFHoio32aCmXcWhI0rezgx5kKT8JHA3AJhxkbqWRQi
7+0S3uY9gxoG8WJHdY+eEf8230Uqnr+sXCLu8t1lr1MWPmTWfGml7lCZIPJ9rKdqKCwEVqVJoSAJ
tr+TXw6F5mgTYBjEq6o1vhhYe0MLCaC==
HR+cPtrqcHBAqc4buy0CCIWwLZOVjkV+K0d38SwvrD/fLbSWXukst5rPmfzAR+Cr9wcB+lH8ERNu
DQqGZHKsYm0XdQfRIxR+l2m/8G4Fgp4PplZwuaE1Ep7JJP+Ma7YI7mEzKLcZ6ZaulCGwf5QARuHB
ENPA5WCa9SLBTD5plthhQlhe/Ig1AnI+r5oPM/AVGxXkzbP/p7p8/eeFe7vZ4M3/xOWja0oZmlY1
4dp/OnEpAcPbMIdRocuvGVhLXn6USH7NvXw4NqupBQmcuZrJn8h8OIXMR53f0gAbWGkRYLCrcpBh
4BdZT9Xjk1A2fl0xcKoQJlOVjrvR//ONe1Qo8jPGgP8g+1SSSF2xmCn9Fxts/ZwMomwkqSMMsare
ak7qZqRfChYS79YslFbqGru9jR6r6V/3flzIjZaT0yjNQeiCWDB9CYGfrTam+YSCsupEtTsGKhBn
DOedGa1FX7yVLZ85+50pmW6TOE4fHCBqiwmCT1eu7Tt/J0YAH8FysbjCVnncadSF48cm6/fSqRI+
jKibJak23b2r4gVZ36gtLUKa2HOWZCO0InLyBhPVU8oBztKhYkJPO9Xz/wrtj5V9MPfdl7sFk5jP
tGSpUyMzyRbQ4fL2BW/8RrvU+1yowEIQuVH6q66hvO/5ORgk7KVffWhEC912CiBCrXJ/FLzyCeqS
YBR642CS6ZEMZLu3wNWcUG2mSgUHxemDsd3es6D/qLhJGOfoXNliEZsRR5zhvcmi8Svg/4K80+oL
YcGkYyPDpKwQewP6fIJfbq1TjBJEpMWA8xufhKzlw49GMbQ5alEC4DoLaVbUrtlfqDKKI7dbVYZL
V34+3gNzYNsFQgbdvp04tD2qz0esEbmlOjXVaf3RtXtpFaNBGFca3EHD+4mMCyEzjkTVUvVpU8Rb
ro+pmwjjxMQGY3eYSvWTqIRjPT2PB+uV+LUdhVLlfgCwVKzsA+5189RkWrhzVQxXTBPsskh7XK+I
B4NCs2vfRjFfNuMA5zipS3FvwH2FDkvHNRvgtsxStvXODN1wJORIqqoIh1HsGlQ6lWY6CpJZYlWC
geHYOGakRoGlrSm0RKA1JPcS+oak5JyNv4mofJFylaczuMIgXmcLt+72Z+O0aoERJqMcBcU0W49F
VMlbnPc4i8rM1EJcbSZy4Qh5ZUATEjjxo3rR6CdNI3zlRtF8fZYpqknRCvvmnsVskYS9WcFjtUG5
pe+US/EuwRBG/9vpJSaZaSEI5EIP8bADj1QPnpz30VZXWie75AdBQyYYQg6dQaXVsZrZwoGcz3Ft
H5B6bKfa8dvu3BNld/RM7j9AFLOWsC9T44BPHxMBR0C6biaD4AKaANtVf0Zaxk8jfYBp9WmT/wk0
nL7xI1vuTBxkEIA+w16mqr+wG7DhUTLm78lXbWtV0nfLPeow1hszw0TuQMppIqIOjkfjB2q22cfj
DmWRzqM58dwzgIoBhqXXolvkXFuz5oVoJ43NA8FgmrIfaYZMjRsSBaLk7L+W/eFxxBgxkPgp8WIu
MmqRpWD2m1IFgGn+4P+vfnGL0MynJQajxZzsr/xEaINe9B99UqLlX0ODZpG/elh9n9Ji2G9vdSQS
fq20AuCLZOHWMQtyiuAN4/lfzh/9oIH8FND+3v3n+aKQ2+pkzRVPJ3G5GJ975c1DmtF2D5qJop1v
b1L+KaTU+NiovpJkiQKMucghecJbk4XXAWc2mwcYugIDTJB5e7BFSN4YNjDEuRdLrjZcV9gIRhZP
HEDM5JtNJo/ByOI2xmUbQaI1+JSquVXANM8hrXwwCuH+Sp9vITcKHqp+eaH9qCUwf1qP2Xa87w3M
PlASMEgNGovazIupvLPggsMXoCANgfCsTbemZ0JwKLx9pB0rWiCoqXO82uaD4dpSM37v5hJm3VeT
O40SWlXlNQVz7bB5weqVkszz5ogODYWN+sO91sLvVYGRqlmQaisQJ5YA2lK80lqgZZE4tEbKrtgG
gW2Idu5upeGzn3t5etN+3yXX1ELNLqzo1fpIISGKjQoGjoMVpoSBNcQROEbwmg89VWaRpMs7xKHE
3ShC4QL5RfXNTtTZvf8xsbdHn4kvPheFNiUSlVJoXeQVeIYhp6fW2oog1ymD8c2VfozRZeUVqEpw
1vvPMOscsfqRQLyoxcnuqPzLOQjeKYTQwwlJ40Vhv0CNOFFXCnRGFJrCN6hC6R2maBvWTip2l6CV
XoC+iufYfiIBPhqnZ7oEU+8UlwLkM1G+nPi9O5StTFA4g6Cnhnxq5AXh4o0o8963m+pO7RQA+2Ka
nUmC+NJW4odMs3yQtxAkyt4DnzV4Z5lHspY5QMB/I/IUZQjaD79XBV+un42dZUejsXpvDvHWrYAT
GbC+2gesAKo17fr9ADn5W1JdKyk/ToxWleiO7n0si2u2E++bSKWcNAocdQ1G/KG4/lx+2md6Lj7S
Zt9Vpx4Cl8pN4i+10iWSsPp5M+vIhi2x21PKqkF04TtYfeI4WXez7xITTSnNIoqa1nE+GoWOkBYk
3vRAgGLKQxUt9WvJuU2TuowZICQQtK8S+MsTfXBj7+L/FxXFL6d3uizhZEXo9XcOpResN8XVaXtu
ukgCnYinARedS1Qv5q5RM8lcR+V+qnpG0VHPHI7sPC4l0CmmQvJDNgFc+V27PMJ62Zsj7nYSxkHY
4BGbo1wHELgDND53FUyT0D+KX+tw0kwMePlZhhBII6bDHG0p8y1NEO9bx4EH7Ljd497D1oebaxPd
k/+s7CzFCGzDecmArzUa27nsvgaW7R1RYlWi