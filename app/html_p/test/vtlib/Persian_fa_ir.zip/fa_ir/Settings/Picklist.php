<?php //ICB0 56:0 71:2a9c                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzwzq/AsFYZ5FsD6qQ+EMKB3FTwAC8GC9S9wxV9wStegLR8kMyf6p+4jOUQSTgZgPb4Vihm5
ShAquREIT1kMc6Db9iQPjPIT1XyoKPQt8W0Emm0PBwupAm1cnGhFKN4ikUDXLEGbU8O4DRvjtjMl
nyZ/7XMSfFgEUT5EjW0ntOB5NmdpZmbmOMB1u1vZNar8GxvjxAYjJTSEnE40Q8+4ZJWdMYesy1Ix
nNgHewz6tT9o918IdxyLqn1NUHcW15vtbERe0vJc2pU7aj0bcEETiTIdAOB8FT4lIoBc/X32pGz8
NfH+zsrDU0Ahlr6dOnXt1hcEaYHkWafJ9miV0hMPTPWqYKUDFXLsWh/QP18JG7fXv6LtOBTMEb0t
0Tc4sMMHATkCWBgEpDr6ZqbpEOr8kjzjqj8Zz0/monHRrINA34LjDDjBHbQ51Z4gQjj+ZwUkTArT
vdGIJlS5qEzFtBawnUFEMJM4C6SiOTkVZHU2v8qETKM5CO5rOYKRWlQ9S8ho62tTSEuwUOHn29JQ
sKzAdIufz4M7EZXZKivvYKjP8HQ17njUi0kZQuzYnu9T6Cuf0uCTtNWLVVpiXdnq+Szhh7zRxxcy
noLH+b9gq6hEbHCYzlr7E9J3WX7CFaux8GAK8qN4c5D2FP5OniXGyGH0gotgXMLxjGIKAADr1lzM
HS53U/Slv0TI+6/YqZwRMYd7V2K3tIYhRaXCsYAbpwQrYKLuhAzdDuwKJh1W2XSm+8qEQHKRfN0D
g0vzZY03OfIxU5C0JyJ5IIJGoNYyFOXc7owqQ1WCx+9ZRAYGY+tai/S0j4KHTmEmxm+FU6mL0jTi
Ueput0i7/7i7DFoFzUKbP0ZIW8EzN7Of0kviFHQT6lDYiGt3OItMjplze9guISE6uS4SdTAKpUZF
p0LehyrLYywkGADQkOwEFHSByti4fBQjgr3JWpYdYWWsIypbPsQNKFADJoPLxBQSFwSiWujWJ2mp
GcCa0MdNiGofljBONk3pf29BfuskcSSexVL4JeVO2XBJGNqqM/ihrJKo52fLcFnWG29O5l9dJ70+
xQ3lhh0UlLBETS53nNXq/M4IYAz8unQ9TrNCliBeH3rtSTVzOjbHmQge4jVKNPhlPuJiGx2638IR
X/Wa9nLMOVlZ79AidXn+sc1LVO9sPgc0nS8/oWKLhbXe12wxWhCgJ9jd43MWLW09Op/dTuK12/Vr
jAcJ/ZD/+vL5kCDNEpB14bZwpYEw86swTdqbHrS5t377vlBhp0WtArTDMuiHTpdPbQS93j/9E9pH
kWVa42beoRHZ1rYFSNzpUDSU5/quUSjDBxkd8d94B++82o+V5nI0BmaV9xe1lXIDR6jn4w63NMq8
4r4hmwHxZXeWSgAnyMNwsxB4qY88YbbmNiq+6H48uH3Kgt6iNS9UP1aZN5Qsvv4t69goOTzX3ewC
ah7X8Y6Ep5ir0HJ7oLGbypY9BcehRLtkl/0sDre2tkEnd01YdlDK/4zZSBn+E41TcWUnSio0siXT
Tgml9c3WaW2j1I4VdAHyLeylb62+Pxny7C3+OBtTthKd+T30A/prtwh0q5x4icq5hL/atCR+fx/v
HDgK/eXYMAE2Zv9a0yU4PUgB2oKl8Ouj9LDH0a6EHIFncDvEEEe7E7DVwT+Palg5mcPNGwslNjfR
U5qA4gm5vmosAI3/TsJcCgU5qhpV6ritIDYdFiT9xg5SQuSF7YFbVj44uwEVHpLjWIPSQQXyaYPs
HEwtRMFihlhaN10/hi4nVPxo7LRWWHiR31Z6MNtrYWFrw9uSXklGCayLs+iIvmJOexN+wh/k+9Ry
ghLjHDbCmtqHtHdjTHLh/lnJeX7n4C83iWZuaXTvnLupZgkQYEHctCKdS5pF8RTHCfrTL8FSCgkQ
tsInwcIw7crS+vQtedaKDTRnCO7b1Tx6H2qXL3Y9rv8ZMmLDtEBeOCBMZR0zkqbc4eCC0tiG208Y
SPEfUrQi/yUMqI4gGUHh9y1RYVD6+SUIrwQFytu5YgGuRd4HU8GK8P3+fBkuB/v/Q+EfcbU5zCSR
VKX5EfyXp7TBdL8pVPJk2qXAUPV2Q/5MXZQIxRCS7HBWLy4Ed+BngHgW6ZbZZ2W32Clg9g4ENNWi
c9RwMTFzybRdOCJmYxrWHPWweSaB/DYzaDIKgVip8NsBq6Su2Z1l30xpAOrA9Eh7CrBSSpY/ichi
0a6efzSoKBAmkUuUscdnoXZx5KhjquNoGfQ3IANBHD5kEso72p5zG8UpVCR56FoZxtiJoQuffe6l
r750ncFANcnjIsbEv3X4I8KVZSzf3Xs9vWwKAUeJ4bjaUJfkZx1MnnGGzDfNpUDYtWOq0waW2kZ0
oMRlGQJV249p6ApFUxnaaiZcksnYdsc6lHHg/sDkfbn8Zevo35Xc+cxfaczbgXF1YyHT+EkEruuA
ugLVIRlRrJR//xFKy9KJt8M57x0tSbdor+DIkFzc9QqsVDFMKjiLSxb1D/lAzaSNIRQW36JdPJWM
nDGZa9y6H7Hhe06yh+5xgzFH9Mq3NHcGBjgripCzP/K9KLBdIG3PtRxtRUohjtZ/Z25q/b0gDHyY
ysnJ/Fbo+6JjgROA/HY+rCrSaw/YjNRwl/KAjQkWXrNMp/X2AiFHLoD2lScs3OsYFshCmKLkw/+d
tsnfduyrzcEdEwTPkCi1MH5zctzU9vHV9OUxTKuSzIeUf2XfkOx7n0zZUCoHR6b4a3X+FuFuhK6w
EKGKvG82W1Na5HQuKuuMdJ801hPFnAJ47GC4dXSr88CcTIpbuh2AbFNnFQu8XrhjS+w2GbrKbhql
JblIceNr1pjQ/hnXCPJH/LuLD6KpQ9MuRJ9Vr/sWpSE/pMDMsZVlOHyhrZjmkwBnzgY6p+TQD7Wf
o7cM+/fZSqKt+xqSZnyZUmfYSOtIN9gz9pAATeHs1RkwSykoyEM9WBeFsS5rg9RB7yAmBIIHMs1V
Aw/brplEmEDRR/BEqrGoVW+fgyh4OWEpt9MqPpEgPRjh7OOMo1cCDWIfhV8dA+ghn6xsit0twTUk
MHJBqqb3RYm4THKNbg3YLdkE7BoI9w6a12LFps3rw/104cpVItX7FdP00Iw10JsLVELLr8rIBMa6
UTj+5t/n0/zALcbcLavcBmeCRa1BR8khIPWWcif0FYKoRLvBdbCzQzXNPzo7U+jHwt+sZ+ZYDxw9
Sw0hnYMcVQd1Tvmvzawnw8fNulBVaIU7yJYvSSjTBV1E8glySHGituitEX0krEIV9k8Kq/1NkhFI
eZSjEG+zCpaem2SYFy1jw6az/9Q/KKhTOVoa0HbSS6yBL83u/zAuGqqttbHtfK8ZAneASx2ljXE+
AzPgWTpdxZ5h2UYlfXtFO102H3559Bf5w29ARo8nahyOj7xvBeKfP0PDSO2XL/kShShD0atjy1ci
rn4Zv+/gPCwljWNUubU3y5gRxlo+yoT0bxSWINDe8mk6qbWa/xGHCpi7vR1q5QhqoR/our5Cc56u
kHkves8UvtV6g3YK7BcK6ZIOGZQfETGn/me21rvuiAXYMzMhfjzNuoD9RXCj/lpzdZW4WIB8nqse
N3IHIYUo4R6XGNGPsLifhv4W7m/fh+MZqDaUf5nvjQRRk7LRLOXWPpvfmYzJltcwyL1uEN5/OzfM
LpkrTbb0yDOHc6kREuczj4rEMW04bi+4FT1B0b9KHV+bx8gwV8OuuYzmidQYzySKEMoe/DlQH8i+
i39636YZLcVDfu1n+602XCCOICRvVOKWm19i2wXKO2FAlo0jVbQSDYEWZBsqHJ7GQ/u8QBNHZoJ1
BflsEyzO0djDFhQ8AkfWjfWSuzfKJXq17hpTD2njuh+y8FAnEQOXUwQOQqbWL5L+MOwhVvlJ8Dn0
5TW3tVyNb0h0h7fvL8SrqcBd2Qq1NRdE/jsj92kRl6cnSgkfASIy8qMty+I8xckBdW9UKgt+CdCb
zw0+KEon5RQSMdnouUg1PPIqptRefip4wfqOVSQjrLtmlkedbBK3L+Uid2E3TfY6l3t877AwfoAc
BnwNeY6i7kNxuthHP/zRN8KikWpSVFW+p2jIz2OWRUu0pNt6BQAcm5nG19tzfmVrwytj1KRhptOe
gE3C5eAQNyT/BgX1Tkp0S3+No8OTMCsXxryTmU6v9Kqk6vgBPpy78/zT70qnLVcINecbO65kOIRv
L+EQ7p4r9hCBPVUgrmCd0SnqwMf8kZva5UxZggocRJMKdsmffD24+r+plp9wAsaaCLr0vLn6C0HG
Yb0H3RRq1v2ZY7ysaZcoh/HSW4TPGM2DwDx+LbXmFX3tjWz7HP9t5nSQjGQCNmTs0IAcnj2KJJrw
LMIZ8fMhZecrMi0FveZErrY0ifhog9SVxSQ92C2VsTAx5xK01Xe4qlOCYs+qUhhg7wVaTzjlLOa0
6iGfyqMF+vksT8zTGEUjDdULKt9jqZwR3nLb57GCegI20/3sHd+N7yAc3rx2W2tt8k0HraxDH2pR
WR9oh0O/qsPtsMLf4Dsw9RGWVubMgZs0utGl16+9tosFABqnSoVkMDBk6ANDRy1RK0q6rugw+nAB
bPtXb7L5IVomNPoAqlH0HAadNFWYf/SCiGESYgOK3axENhvqXLQpZKwIxXmcW/OLCwFNLKte37+z
zm3WuQBgq9MBCfhwXWl0mTN8kfcqzmC4SRPWwvmwRjwygPIfY1TJaKXcRoredBueuQ2vBgIpa8j6
aGOYyzUDQWHUxcDhbC6DiSyZWAHAesnltz4514gb7GdTUIAKXCTIBzaGPg9oLA3IBowhNN1j2z1D
TuQnGM6wa88ID8oObsHvba2PeQ06FNDYIsYZYvRAB/S/jnhQl6auOt55L7PYdGCa4tcDEJy4590t
h3QDvY+L18DIuqVno+shAyvSnsSxoL28rOGWWxr/sll/m63QniRJs6uL0lpB3f5oRIkHc1Qf3Tw0
q7ENOR2XxU/TNXSZ8Cv1x/hmwciePx0t0jaE/65g3qwmodrhJMv2jjHj6bBA96CjCdoDM+CWuwxu
CnlQxV/aXiS++BaxoYzP3215D4L3yViRoOSPVWgOHRBK1hN9zWFG8cTaRoMH853wCBpILqXcb1uU
960uou7bxVb/z9CJtkJwhcYdAP+OCc8v1xaYTmZTcccx111OuzJguKbzA6eXu3ZIHl5lsRLM2k/u
J9BZpjf46uNztfxibYOPPsLRab8SA/+Y6xlK31RVf+p1IF0tIeXRXfrLUSl5gdplQLrWw2jttmK2
GVJT0hs8QHckdk6SVxqPbxAp556lwf9LmmudJKlfdyaPEuLxlDgycYmuS9DCRQs7CSAKSZg2Ea0Y
fGbkIThaH5txNqlUyfpHedWsTzEi7qfC25NNv0sObZHfKc5CLctqfLmn/P9RwFGRKinAdA3QthlM
PcL1z+QyVLZILE5Vup33c7Oky+5de48x+fVSpA4btsV9b87AqeddI7ww+XQfxY5lfYW0uxLzNhYN
fp67jM+XRUIU301L0lpP8WxMnS58QeMrLf8wOmNANwCkfD95QDXQ9pyjIW9StMF4ekDoCeH3WuUO
UDD1/lF6UmXP/KdiqCcK5ji1UIt5M9pTYdzrq9R0ARfny1E2YIi5GMITrW9QaeiI9Qk77V9c0kbf
+As2fxwsTUVa40j7ecKCM2w6r8aac5nDvKGQJe2ILMQcYwaWKeNIDYbfQvMvBsdmjP+rXtC3vfs2
ZYa18A1Fmf8qb8nI8oW+ExZlAMH5wltPjXBD8p+kAoAdecoQYHI0P9rET8G76TORDoXcg0k94PtR
VtduNKunD2Ds74CITxdUfeWTHOad9V6S6FI6hpaCtAQUmxwHxLt6ufOTVKiN4g5e70daN6QDz+cx
sFhHy/x8GMrojvrrFtC/AgwCuXyES7heT9Chp7UsElZc9kZTlLkOrwziCIuZpITyC883TiGgLgos
WEnxp067C64puWPD1cRI9Ld3k5bZbVMPJ+7iKjSPs/dX98einFlDcO984p00jMp5YBJjz+6P0MSc
K/sroB3s00/ThIg3LgvxBq6zzLBSTa2kWQ9tx7CWTpBI/SmNullUZ8O1FZzsmJaOTrJQ0lG96tg+
rGovW7sMaKQbvHckG/4HsKCUFQhOeEAZnSKNSt/1HNHcR88Dw9nBUdUN2aP8QBFCFszFxVo25CNe
Up7HtNrJ+YTXX52NuORot2YDwQ8tlo8I9gYJPewwbnM65I1txVMUlaMTVff+mj0/WJiN/W1dOjtZ
bxlaVwCLOBySky9oFMI/eMuv3sL3U8h0pn7HzgHnkPTN/FAznvOAKMXbqZ8m3ShXUMb8jEWR/j9W
ydxrsLEcTkjT3SQhL31V96PWv13GRcq/CJ9qXylckGOCEfqzaDzUoHNvxEfWEi9GFTdZ4gJ/5YFK
GjxfC+6um+cG0+ms+7lmQrSsS1vfn76PU+fO9zyurEI+nkBAab7duJiC8X/g52uZuo+RqCuldx9a
MtAN1PE74qMQlTWZdHzIv4FSqRK8pbOrldxw+MzqkhoHZnFTjxUfVwEZpfh3WygimI/dLfdl1dC3
mTvrxqtxMtRYsqkUPVTckGnKMnruNzeU5AtIYQyGTS2gEumr/onXfahnZrNloqmwbFZnLkaunduQ
auAfNv0NGx5bw5G/x6IGtNVHmHAHbpxVH7/lNBjTdxVgMFyK2jxk7xJhRAZbJaV5T6AbQC31uEpJ
2hX8WGUsMUbMlIchY9czqakXkDiTNTYVa5gcMldShKRhlH8EpH7omX2VULyFUKg8BiFysi6lrucj
3/b/vXvsnDuVboly36eM3J5haE2nc2RFUvoOKf/rWJHKBBwtsoxteCRC0jiXinXTjoy6N1T04FXK
bgGOA+xPQ+K7qdKryPXQqKmtoW5gMwuQkBPCzDLeZHie/NltklJYoozGhvqqL3vtcYvmMKPediVI
rQRRmtV6MJP/XEn0zhzGzTxfomU4lb99M2CBcCmwHN3uYerUxWKSe/1ioAu/lHywwHYxib/IQuC3
D+KgGC8nneV6wGVO38d28H8I4JbgMKJ7tb9vtw3ZI62mNMcfSncuHJXNfex0AUjUjCuTX/wv1RXT
mZeLGp3MtJFRZdMTYHX4cSIkheQITfPKRd/TDMQ7mWe3eiggFGeYaS64vquaxVaMy83xjJyAzt/Y
k9GCPRWPGZwuVSwdDac4DaYO0kD1K1OW6F0Ivtsqn32mLhU52EuXIu8Xrifcg6UPGwDxBGbvg5LB
j2Ux8tLNB089vaKPT3f4j4Avo1cDqa0skkdR5ZyZ00tiyZkkW65a0Gf/DcUs+JBNLu20WRy9ftkD
qAvCa2iPHOPplz4BXiu4REnquuXUxsyIkzNPCgREtbXRPzG1L4bYK4KSbkXvMLitagRg9x7nOubN
enMW/OhzSN4/0tswNFsesBnyHiJJ2EPUDCpLj5SiPbXHs2LXfdnsAS3msQ1nVuqExmjdQV//kMMe
vodNGFYgIe+z23zF0lNLchvplL2BgoE/sBBrFNZFgfTM137Zh62/5EgDRPRyzguV5U3kYRGZJ0c+
4ePRkhMNnZWhHXZh3qEGXzttn1uFqmGF7f7x079drDQFVLtb+/3f80rSM8s9f+aJzoRdaKQr9LB6
2ldAqt5alBzPfRnL/ZU9SEy39NmpY20+O8AvWYVtuoTWrpVC/r9xyTz8dGhgL8hnpB1xK7d1KL23
KJqG2CYLcQXAACKA78mCOx9pCPtUK1u2cQUuJEJuVi5vfUD9rfW2RnehRAa+YlZucF6EORcGsqsf
TDCxTIuOQVDMVZ7gDR9WF/z5IsQixLryXYVg+FLFR8RQQDP89hy1cZiSi2YTiUfWp40Ulrmp5ZKL
tmJcjJhBLTd+Fmlktk5VdUbodje7U/1uOBzFZJZdFL+kq0AOU+VIg7B0cct99BbYoQ+U1aafsm5X
WQPAx44NqJDdNcve8HSSCatwtP+/atEC6cnoVp0eyzTdXri+uMoA9Q6p2O775W5zHOYBD1HFx2rU
5QYHLNv/aUdyTTbeoNk1wcZd5MIXM+fRCsSLZYt8SPO9sUhOju501ble0lV0FUBob+H0ftIcny8u
fEBu2EKWEOqPLwz6hwidweJy8D/FbTgXWQ+l9s0dkT7DSg273OqsM6XhkAifX5ZrmRCnyT1cuWqI
4CRWgOfoPuqF1P6GQVi/xmpDhHO+zOVFOF7BW2HndoRc8SaO8o2vAYqwDpxmszPxoISLFLNll6fo
AJ09C/XdRPGabCk/2oXiGM5FqT3+CLzwp7oa+kSMahC1aE8q=
HR+cPzmKMCKtuw3glg/Dva4qrQQjPxlDDY+WQCkQ9ZY6M9DV26UuhsvzCoz0ySKIves/5Rshfp+m
Vfb3HxNn4qaDJTzrA9YZOmoTteP5Mp2UtdARBhDIA4khRDf9Uh6l7mLYKNRG8ZIXfRfUOqIKxC5s
7qVOeKjMaLLCDwAQpdsnMQ6vfqzTy1NoN1ElH1k0VURSuStb3HEx1tl3TvfBKOi+Xq3jhizhi7H7
p2LgbpBU1Kcz4bB6vzmUKNE4qj2mMFGQjKaJhbu31XJyQaw6MyYxsMdblM5G/WAYfR4BcubJDPio
wn2vutHKSImiwGHBoKnEtWBs7x1UMbXLWRvKXw4N/CReebKG3Hmsgs6Izj5G52XJyoh+oHufINV5
usD7mgn0ma6rKQfyuHQg3QDq33t6orj7Ef3F/LDhSTk27frtbSvVG0WDOIiHytzY9sfhTRnTckvO
Q++z832rgloBg02EfsNqA55T01mJW9eVL/GplTWOzGl3zJqMgbpUD0XZRbKkI/4GwKbA/WeQ6WS5
6AIprd3pnQ3PLUxCcd8ralP9T5jBC55qom7VZwRqEq0t+vogwQXY8LvttTdvVsiB8f7vc9zeAVPg
wz3LQcpkOWvNJiVR2VjlA7vnJRjsC30W1A0kPmAfcozGgTE7BXGOY3yO45tSxTGFwIcQwsMCgiZV
h5eUD5cYpkX6Ufd7a1IT1twJQdluSW1dBEnY+g7smAuXRv1YK26GB1vQ6xR4DhI5NGR1NpRTy/YU
wLiYpjvP3YvIaVL68Hlju6LG3heIJweDhp9x8NgZuKMFeBwMt9kHEntUrBK3Bhs9VKQN1DGMjQI1
/pcbmpadUy1sdJuDXvlmUedy0QV0e9fsqtQGuNokApDyJDuVid0DDg3OAeTrGXB1pdSHwJtcGssq
b6RshNc+/ztfpb7VRh3QrKRjyQo9eYpp/fEeG7WzJNyrxjkI8nWjhNBYImq8wHheGx/3BcHpkCL1
8anFcKRfhPgdMfUzwM+37yjbKlEVyIX3o2dtJMR3XVj53zit63d4JLkwB/BQNIn4z8AvKvMX8ZWN
6Q+7CT0OB+6FOwrI3zK8mX5eJ60rL67nYqP86L4/G84HirN8j4YI1vvqTe+TBeE17mwgA9JR2309
rlO3LIntQIz0p8MxUNn6OKPVjqh4xBRRIyOaTGef7P2aNXvvMiCeKsAGFKcCN9RyL0Zocll1nsE3
EBSN+lyNjovOcqFbi2gs3QAiPAOKB5/ywNv4iGrp6olL41dTRXv+UuwyTD51/F1xgiEu4FABcCx2
czb/H6VtSAfpHh8zPqmhLWYVEA1Ii/KFvQxSn3wjyxBg3huMQiUL5pWpcFEPXY0/2TXW52lnRkQL
KnFeRU2VVICu99NYP6Rl6Mru53ymhbHJp98HUhbjEM732HcZP+BXBhac8wxjr0Gd6BRE5UBzunXW
Jt48tD0/xhdP3Tmfe1/VLeFdDW5XZ7NAyMfzmpX+c4DCdeAYa/mATIEnVmwM2WPugO4+DyUABqh/
/VKA8e26/wZHXmS8cNf00WMTWE19ZX88L1W6REmnxOTH1ol/5vMv1hr2saWDq70BZuw1/J4M295K
/CdmT5+Gnvvt7qri8FuXiAggo6MmcUUDPyLCCNO0Xf0juv4k0rCQPfHypugiex214zIaIHe78uKT
877gTXV0ZFtQGE6RN1lQRZBbKX4IFQQpRukbfxLnsWNCNgkpL0/PcttcZ2o4BIdYClHu/qPAT8yw
gmmMZPtSZowsPZh/M6DjCsYZ91bl93wtbdctZd1as0YMhnYxBKePCSG/zv8g/v+85BfZU0C3kgev
TjOon/+/jD2ZBbc+CUeuN86RiXDEBz8itTUIFKFACPxVkILqaWmv8TZPA8yUX1Km9+6j9NQ5YsB6
bwiNPJh18EDDYImZHK+A/CYp8vgtiSq7+SSGo5rylcHxsvPWundLnQHeItz09llQ3NSEYuzzp2zG
80Hjl9iHbvNKljyzPNE0Ajug+bgUPyG+vc7IRB3Pca+xgVJP5c5kXlpqi+UQSG0rzy1uhnE6pRZm
N0jVSjkFzVQjjXQXo0yiPzBNfwInf65mE+D7dErsLlT75dJn0B+RhLwqtZEsK6hePpbSAAcLb+m/
Wzya3kcumemMvxNe+qx9qCqdrKvyj+vuhEBZqYwSUGd9q5srCFrGFZIjlwf9RtGVghcDaPTpSy55
Kk2DzMTJMCPgUufpkYIHTjJdN3szS87MPGZKu1JjFPSYleLD8eLzoU+7MkM1jS3LMDj7HKyWz5SX
ej5sYJrB2iZ7ryuT9KRCo8b+kzKFy1QZWWZhqkDH8VfQvfAsnGE4jpcOCfkjWLSj7mnS2cGPaD5i
xO+ktL6fKN7qHwvqwKLgtU8SQ0qN2aOa00gMrzgBr1ThJqkxkUUwktuJAOQjQnlyUv3vYzQ0Sy3K
PdCZd20mMv9JvIfT+smt1/0RC1ToU6TTAu9oH3FvRQp/CeVgMuGG3KWOBampuHo7lA6rl05/gVDg
2jZgcqTKvbn7KPJVGmtwzxZiqEFqo3i8RhYpJgrUC5mv4a07oaJGQTHP1+osX0MM7rsyjxfA7ZLo
d3fMkf//cml+