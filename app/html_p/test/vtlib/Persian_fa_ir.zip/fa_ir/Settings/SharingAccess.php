<?php //ICB0 56:0 71:1d07                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr6SasCtIcXKlbW6GBLZ9yaJUxz1PnOcwlA7RBdjCgn7Hy6u+BhaNpBMNaKsjVyKfYSXgH7G
lmAOLdVb/0c26wPX7l0AoqkJ0mhxxbzVcX4vm3Q8gRGY9IceHeZqzItUVgOeYptuhM13aAn2xn8L
Niho2p1Y+MLho1b1yOqR4unDrFJz1Lakwr2ikPFAvTLO9RoQEmxs5458HckX7ma8zO/faa0Dh8Sk
Ji80aDxCo3B1qsknWwKrVl8wth78YfirYLZWsh5FT8jOSUc6FOvt/HbyBGx8FT4lIoBc/X32pGz8
NfH+FcvXMphc9SroqtA31gbuadF/8OoobgueZCd8MjMCfdfYXMqOvm09IxDJsWGz5Ls6jvMrha06
Pct9CDEaa0e84RJT9lErLkUCAS+g7DrQDKTkYg7z5SE6mKt0VECzBtFfJCxf/2uXiKpSNbeJPvLp
odBtlCKRBmiJiKtp61WtgOiRDNGA7dqR1BBjqyT2jORoF/tQV86aVcwdL4CFqPE9E5nPGkYjlOZl
j2UufTKGQD0QVcRjOmPp1+WSuP3km6xoAd3tSVjaSAkzma+fQQH0HFWSc0D4fGw+7eDSRO8Lt5wx
UmCZf3leEXgn7oB6RBBQFwH2nGyj4hl+vmHLusICBJ/E0PWITfD9eQ27TQc3cPyn6vVKxrPTz5qu
7YAtAYoCn1J5hMUw9JinjZTSAeBWBv3nnSmuw/aVVtDXDKNQdJzSNS7X/RYMYlOC/7aQ/ny9YJOr
feNn+AaegmWL+t0oomX9JMMksLfBpvTVi1RJCunASTby98J6s7NV64Mu6Wom4PbOH7DejMVTbAes
1rsNTwI8/saRdTCVUotaxvhGYRvuQB3s5FG0H2TIcpaLHeENoYjPtqzJvfWpmb1IDNFcKLojLu0A
lIkF1etp44PUmSgEsxa420Xaz6+j6eoaFi5zxo8ErPJBjuhfh1PeJzhZ1LfnaYALOHeHRXcXi/GS
EEYm0m5hvttVmnwQSoOE+b3jZY4VULSlRdtqROr94ceB1yd8oSWE35LcnMYswmLkGecfR7kNRZ8K
6IHLMq/EKF9R6MhRI7qNlABdcJO49VMCLQEKhk/mTUFRkOjxsgAj7KhGfC2mpGdtWIbfEfKAb5N/
y9evb0xsqoyJljeWK39WeF1G23Js57NdeeXbaLrtW38iVnJtBgcPFx6bFs5CLWl389NhHH4jmboW
nbzoXtYC8muDdIq5Qxl+Y/wPOHGjRuvVAc9qChtSGM9sjrB9e+fwrgRQLTN0Kr6Vxy0U7w62qT20
DEd+zOcn43isIFBN7NmHbf3auJUR3P2VJk3q5R/HrQOHUhDMc1pxt1ge1NLdPW/FEaB5LKxDqAFr
EH+e1J1LAGlYWqp5DDKVKH2e8toPq/8v1OTWv+LhjiU59+vwMHfQ2XGsIn7UsBv+vOAECJ7ZbQR9
2s0YcBZIgDE3ZWQGX6Sq8RjRNAtOzB4uZXQYnAqUt9bfdjCFnfo0HaAxkwXWfSU5Xg4Avf/e5pM0
CwR8CgwEMos9EmGLA6soQ2D771O098b+6bNMedW1lrkpxnTgA6c9umJBWH3mm4C8xa7SggNj/qlL
8ILYfnOt1muluXxnCsuWDnflLwvqcNiXuTLpTAUCbmWAiA1UcFwC17KvfHZizCgHJhKk29WIie66
jYCSI77TVbceTAk4t+SA8DIEia9LU3Bd4eP+aE+0OX2a5gpMB6/AShMhIh50Uzh4L1gRiQKJ99tR
OCNEp80rn/7uTPI+JDa54+tdcOGRNcX+Wp4QjA6xPD8wZXCsSu39l0LFsd8WnT146ISbSh0r0Df/
CsyOQZ8s3XeK0RCByA47ncbLbiHyRYXI10PfaCxC+6F+m0iBN6tJQXN5zyKt5LHy8tZDjehGSoBi
0PyXrq3N3vPEi6W9jVxtmx3M6iMNO21oOEQkFjgXActOuL9G2lb+n0Ki3n49vys5wkoAZ75DuhDr
1joBhv8leOSU9cPaZjQDSimYIjkrWkx4us6Ieoc9efnUA6ix152Yt2iz/GsYfwCg468a0o//SvTk
63XugcbdlPUvd9wJJUAHEqzCEz9qUeTyEN6hBcPjyClFQiCBwb0BAVIES3RssqSG0VXX5wJ4DNqI
oxZHuH3jE2Y7o8y9CB1hUbLZkrkPVG7GdIqvWbWtikOI2sdDnKrNYyMTI78g6x1b7t4g/hopYIal
bJsqZWKf5DxJRczOYWygrrS7LWAl5Xguk/vlKYOXn6HQBtGMnh99clxj7b+kZGI1xYsfdoVumX4J
/RSTWBNk25zFPZznihS49Vt6omKOiYvkuCz/4OV4l1/C9PUVtORj2YO0XfcPG6m/ANPtPVO2Q99A
Ag1wzNwztffgbQLXKMPO0FiXLfpexI9DERqgA7If5wnab9Jfn+4/68skWi7qvZq9NcZ4ByOkM9FY
U41L/+OL+Gkrwmm/BUnIUx+U/lBJRx8PH4bPtzH+lmIQ0vI052eWAoi62r7UpE7OKVDQuIdoLs7v
vifA0RkLPKHjvfxWl+4E/TXYidsyJZziIzSgoJBgLBBcJnUUMcNyzZ8Tgw3UgeE4geHzFqhSO8H0
DFOhPnwNPyEZLO/2gdCFt//5Ucfx1AoYrqv4ae9NXr6Ozn1Xxt6q0kMNL9tnmI51pRbBmNBTriPn
Xd1qOlZntNgqXd1b7Ppg/gTPqSmG4aWkal7EoldpWsDc0dxPEYvbkNO4wqyYyWbvD+wARuwZy49x
b/tFDIpij51FERLhswaMMX8Ev90KNGaE5NfekB6aRmCxKnmR+Pg9EFZdMv3qZFS4mnGoLkxiTJhx
/7gW+LWa2UsZu/hgDG1WD2iz205BhwbuaUUx6onpvrjAVD9WGtuJxEXVBPfmZlVirvbOtQOKwMZw
1uEsc/Ckb7W4HKIoXefD1nBEN8ly4ONoa1uc23yQel6u7PbtkWR6GkyHD4S31U7VemM8CCUE6503
wj5FZUg/dKQeQR2DxR+/GUcRATx2Qcf4pJYbr+2ku81fW7CrUVYpj8lLyvZHxPnE5dCupyRY6lHZ
dSl0Ocvtau4grqZGGt/8IJeYPRTl6Let6CmK5HoKbn+f8ZObsBOG8BQEf6KMPDQPXUs3do9HKn+I
pxGR/q9BzD+FVfKKAlx8JcUgrZwP1dJOy7I+u+mpKVkB8pGWvfQhrAhQPtTox2yxPZJYpE5oRBny
gZhmvLnyKxRt/OzN1W+kfFcL5m2NyKXSHtEmxMLxac6/3wLXTB7uEp/SQhOlZv4AMaVVGEYDQLs4
uul0UsvxDVTX0TU/wyeBPieioirlsJIJ45AfnsE1ihkBV/EeNP5NkEsFcH6Ws1LshYL0jmO6H7jL
27J4wUSNYdc7Oy0zE7cVyV+NeCQVZXGuEJWo9I9F1QYC6oH4OlQVktA92KLB9d5Wk8YFlJZI0Sy9
dy9Wvnv28RLbHBHQMlOOfGxXJAjAaXTFZKj3Zm76etU+EuXp2hwb91l//Y4jnVZa5SlLS3L4O6cE
RNpYPh6RvvtdUKnj3KjkrKksR8Tf85jTeiMdPyCue6wvpp3gRtU+odiE3Nvq2yJSMNxftb+JMGjX
GQ0CQQp7vnWJKrfI0aluWy/cHESRUq4f/6OIQZXJF/QC/Sexkol7jnZjydGlIh7XYyJJxOfEf2NR
jw4NyD3ctVGP9OxyiHtH2QTYzx7OOcnVlPt38rk6LHJxu3Pt2+yPiKPiQG6eEHOYGAq6OGgYQ9xr
0XVpb8GtVuMTnX8K7BCIcloIGrsljd8mj+L/UWsxCIf6SQO46O3Z4gj/vNNYoPsi7sGuFsctm0D4
zbMvWqXMfHiC7Ow2NVztlLSu05axURubmeIDVw2ZR2Mr2DvBIOmOoGMyYXaWyR7bifzw5rWmjPUh
aPlirUck2e1gKhImHXITzwIeZSft5B4GjhQdv4jfXybXYliFAgFjBuh57gM5bNvsBlb06S7Yma0X
PlwQGnAq/zRxU9CsOGFAAP3GFKpRTO/NtXYpNNlSBzvlNZxdE74glo4l5U6RZBJkoDCQtq56Ke1/
VHJmQkPmsqt5Q058J+YZb6CFjAQlbVQ1/w1N8sHci/DTnHAKrFsbidWusRS4GvBpr6o7lYgVprhx
r5KJtswS0bQXYZ2Qx4WzZT+9muxdxzXza+NiQWG6QlfDdcyZ+21K0Fqqnxjo3tkoh1lU6bc7Ungi
eHrUhaKY3a8ZNS+ETJbxkq2mCFfpnDd9P6YhQjiJkzQ7b5961hoCFxaqwC/iviCERC9Fga6F0F1/
fZ1ZxBHk37Ho5Pa6gvVFwsTs6xXnPxeMNA5Pk6l35SV3xN1JQFQZyfsU/xJkKF+rFu9xtXTJOiD8
9weNr6j/2GPRRs8IRQ6PhObiS1tsXXxZwPABdtHhzxIcNX8vfqQ/R9FuGiHcigIp0PEQUz1qlzTl
2/x/4Q544G/mBnfulEoKFmqtVVx4R9KLov+V7RziFWbO8tWABmI8lTZ8kiLxA4+6qsCEjOUJYb9s
xmdVQG74wVYbzxNq8KMKUqQFhmHcSDEiKLEYwi/zqYGN0k7srkmr+jP84/eSpyHZuWdsSYsOHk3a
HT28xf5nplOZOQPUDAUn9z0c3wMEU9xysrFnvUOoWW/R2SblnDUbMy09aj53dqOEHevVVMqWOivR
hKwElakzbM/VrELJV+Ss3oO6UzXeK90WNDD1esbQ0/p66vhPZ/t5OF3Ctg+FNpg6TW9LLR57319v
u8js96UCcmmQo/ZCG/TVj04UoG/NUt0cq9j041k9oDg2KTmsvfXX1Url18Kp4kJvpqHw1jQ2ypf2
CmlQnYYwZyvRx+yMcnvvvfZ1Yk70ghmEVDIc=
HR+cPzK0U7hWrK1+ZRdjMPiNVHKfpd1cfE2AHEAvl4A76ez0SJAI0+7+G2dwrq3ZQExylwcSVHlt
2ID554ZHtHi+Bdh3I3zjrOsII6WpzmQPA9Bn0jFXkN/SIqnC0iMt97rBJogv7mwBsk5CqqQmIKSG
WDrjPE846szfeYUW+7Dy9aUTxW1elYhW+0L0ebQeZ1PjeH6+hbYWFwjByuRZ1brmNLB7tSUMjuAd
hFEhcvCK4nCAOP36g+FsmTfkZ1Glmm7H1vxRuvVC6JDKTqa92yUvws7aor3Y0gAbfmkRYLCrcpBh
4BdZT9TmK3anhSSlROOIflOVi5viPNoaJoY+pZI4Wzn4hPGborzpM9W1g5IUoH3ME4hBexG01TwK
w7bGQQXG17tk3iKPysuAHp8laWmCqqoRtf7hn8bUZjG6XjGUKlucyq73qVfkTsUuREWtSndtlXHn
f6rzvIJnvAHkZFjcNLNVOVvT1hgca0uqYyp9abBebFJ4gx3OKJBR6394Yxg4+J1NEc2PXM3qTK3M
fxFl1j3B/Peb2CtVMZS5vs7Wk4gVSI35LomnxJHLqQCd2wsCL8Fk8jetY3AM/TsgWePZDn4XsBos
aBWctarOkuveccAwVPVcG0gr3rp763Imh6AfWFLN7ew6FKC3RwA9jqd4lV6c1dd74BK2gJ9u7OKl
QN9E9Ht/miI+/Rqejpe8UOlIautX14S6xmuxLLsE+SDTaJLeq3MBmlPJinJyfn3XkN7jJ8ioBqro
XLZ7DtqXRmNl8vZsXvyQCch51FZdgty2eXiG5f72MDviy4PeBgFEuQe0qXR82b9p5TYKEWq8zkll
TaiUrRXDGNzH8YHO4aWcAra+IAZtL+xgUEnhdLzMlpHbkPNNZSZ8qTe38O+cmbdI2Vrr5jderMrg
zbDZeexUjEdTLaOYLRziwshfq+k5t+/Th4AZVLFIkQB+BE6vxUMdmfKGpPI5kYVijKPT2XFG1vdv
cU47Q69d/YhEZtdXg+Eg+RzDVohjhCxFEf+MGZVJAvm9BVzs5V6+/LzfU/b82gA+o752Yy+8MWd9
oAVy67x2jYA44WCPz9tRRy5JllePXd6Iy2ZfOWd/s/S/Rmorb14vu8A1kx/9qLeV0Qpx3HX0H2jf
lvYJ1a2j7Sj5b7dKz0XqkNOjd0efoBfa6g3DQcLoL75c+0QGP5mAVRTT41dBLlrRrFiz+JUI4Rmx
Tp7Fz+5ZPIIvVlfJrXsTGXmVjcl2863w7x9BbIPLZsaxihC9Q54uA3Q6tIbRMP6pOHE8CvxlJZR+
ZmQKufmQ1XNsCNtE/4RG0pdqlEzpLbHgTGMgsth1siYfdolbxtbYZpGc2atRMR4TshZDbM8NJTxo
GXc//MbW/sYoBn+Z/28z2FioTS1b/lNXjiQtJqqgq2yUL6nxUm2tlBvI4tkr8SL+IynOWAvkpBVT
UdgSkBRs331bekWSmhlHQpqBViygUdf72ED7uYEsw7LAHqww5H1hnEbdGqlPp66KZZdUaYE63w7K
lg5KsvBLcojqOHJSTwN3yK4dHggA1UYJniwwIzITVlAXfI7YCQZdZfCBRSw0xnfyGigPsCsPtidO
ViBcYUB+7Ki+R+LNAPvYPmB0h3gQZS1MYPKePi8b/jzAnsnpR1fy6wQ4mVhvzmnZMOxH5YTvioDx
daLaBGvkMG8l/QRti+X12Dcuax1ysEraK8qEYCaFWtEmYXbLnxV7FiSSwb1oAN3W9hr7A4VsL8tY
weesF++Ym3g++8RQYVsN8T8MPhV+jXaiMibBq22hMscg6jLBMH71QSDkZX7c9C8s/JeIPTv2VcnM
4TiiWpMRgArA/y7svW==