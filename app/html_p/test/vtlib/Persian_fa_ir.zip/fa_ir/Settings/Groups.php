<?php //ICB0 56:0 71:148b                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuUVRCetJ5NklbBvwJ7RbAehTC62Ph+1KieVxKpeCc39fANGSTR4Gmw/OHD1sHn0jwjm12ov
RVShRCyBzigFo52pl0KQzyArd6qe4mzrMKY0FsL3AUw/SZFb8uhsghgZvIK0zayG1Ll2UVbE6pd0
FrCFXHb2OIwzKJDp0VycTYv1HMf2UUYHeZRXOJ5bYw0ncjhsNTNA5Ytv5lEV73gbWjZHQ0LRPlgu
OQhkB8QymeKaI4WjKpe9vfghMr0K+9FPBz+AQJlGt1if5xJGDNXX2kqBn3Cno3tHBqiYvluGmiqF
I5wKVYfjfmDdSWbDwzSHLGOnWv80/rSWfsxc6T5+yWsJ2nm66tbGIo1flzgukV9t4NXdCTn7jHWt
fpFug2KgbyJsvAsgDkEnkcMtU739BAoWZ9DoIYzQfOxIb178IG5AYeMH6S2EfKiT7zEK2fqUr52b
PrYV9bQIKHMEbWL8HeZYQz6H+z20MyQJowi4nXkbnDSTK7qSp2sCDCoaTS8YVhL0VvoSjY8pTP6g
YAqekfi3fY+Umh72ExyKOJGYkF3t1skHBuh50/eh4z8GK9zbLj4winIhpCN5OmX9Z133/PPtbwt+
lfGcr5BJq9jL3k6GG0cnRyH85GfRozLLU6ySp/IYrN0heGRdIvM5DAI69lOuC/vyz0LCaFqs8E+b
eInZYxJcxSPZk7/AUREmG4oJtQBAboQrvCctBKjcLIaeouP2O268AunMRy0X8OE7hG1blFrt+0dx
8u53kCiAC7xpqJRqH8MP7x9Aj3arIvsHymIGr0lsWSU/Wta7+LQyqKCLVURU0/FO1E7MRfmqox/2
HsD7nLfMDR8hVK7pmMTgwd5UeQwb638R/C9HKNy0KNfVJFUX1Z5eQYNUKHG8ozYfCHJ+rkC94rTE
zOy0JD/O4s1OWBpnyxrsoNHsjht7fe0UfaB+erOJbUqA/tVMk1vBPpCeBfnc8DOGxp8tV+iGrqeC
5juInRsGYbgZ3ldgA8KWKF1AKTBwq3EtKGfCn2fm0GEl6k8uaMydzDm+PxNCNBxO4OoDaitbYgZM
jGQ1lIdabr5nH5VCVGoN+ja69OCs7YX+NjTt50wOV7ITj+om87SBAExwmQrkkb2FpnFuuJZMY7ya
2f4QqnBiK46tZeCjA0PCsmbCyYLI9/VmFTWULQ90OLcTwwdhDrwuPCET0aYIkCP0jJrn3cAOA1Nl
JIehE2znypRz5qXOQBSAViHnoSwAcUKQSJRu9KR2cKO+dzV1yiD/tCjAoI88t1jQMBR17kk4nuNP
D/g4ZZG/B32pGspxFQ64j6z6rRZyP23CLbYypYWafM869O1h15PVqwqWAAvxyxMhaMd/zweRZMCj
/yEJVAfIdtBUZ8Yf9V55V4hwNaHSkFR0NHLMJPpwS6LRHdIPtP0qFoaDTazYN61NgqRH79DNI2FM
5+oiLp/9gMIuacrou7so68NDC3/NE8EGeq9XdpubBtH4K0woLejp8uBTIsP28y7cPywd8EEh9izQ
0S1yCIoV3fl2kbLs8PdHwJZOKomsSe9fAdleEF7/sgVs1xaLb6d17PwHdHvysTxWBMtcYx5iZqb6
AG6YD8rIX6YSiOakT/8qR36u9FD1vohQotgd11DoAELYXWDRqicw4pOYyHM/mpa1v8XzFxCb0ddN
1QARNzsdry3TPoYPdiN1sqw/GqdK2wTWhs49vKW9zedtO/SViifcY0CYzIWftbxIqL0frVZoSEAK
lka/98erwTFWB5zkbsTKlLNhrOQJ9FzCmsvyqBR8mHtbxZHhUNpLXK9lX0Y4lXXFIPrJ6krF2Llf
Z54W32lx2eDXWN/ZIavd2kP93iynCHK9UsmN0fsl9NPzIbljaunjTH0uQlEh3SxrfAJRJPs6X3Yh
MRnp8YZSJmG37YUVWAxQdp5e7T4aiAph2q5JVdARC8acRrowiuSU0WxXeO3Yr9HhdbTCxpg7PuMT
IajXsZGuczCQvIITaEv+94Eaz8UqekRRqA5IDCabcHsKp1zb+eMnBqjfdWX0a253/ia5eWswFN1q
wXHrKshwq+6GeoNu4OJ1VXrLmDQYVuoEzTp2Zihh18qDrmePaVgucZLwqDQU4XhxEfB/iQ1M2xcP
0/1EcyLMwZhqSY79pvqMDEFVz2LOdzhIexDmg48oXQ2Jw2ji7cVcJRt0hv6EiGIlq8lK1rN/aoHF
bE68HzdhIyYB0OUnh5vBo4CMIdyJ+LY/AK3C67r+mZlh/HJKVdAQgyHS0bNoCwtPQY3mxr+A96La
rtzaBEuZx4LyuhLLi3OvhnLLYrA/LuNfd+kPm4iLvV+p71vDw+jvWy0sGayRKIA9Xsw+GBz3C5LR
4SyTxQiGgpbMnqCMc61auRTtz0jytjAgu/pfacQlfedaQbap9t24IldOKdVdlJD8zQ0zB70uvCAZ
jO/iKrSnZKAV9Kz9Z2hKZsBeuvFN79pBLbUm50ZOghYKYa4Op5JCsGV8TT8dyTZw8UdKBNoIHgNH
NO+0f21ZQn3iHA8OW941aPdQEKgCCU3AOcvNScNojBUdp9R7RaWv79nbqIvX+IYwSUgtL2k/Rt9W
BEDiLjyJVdKcrgXsDjviB2b6dMO2Uv0fLsBdv/LvWr698AFymzZ7S7xMlChDcuF+7s3Mw00cyUyk
fZJlQsET9JgcLcUdKG===
HR+cPogcmSx3S3hXwXvKxKMUb2BXA9/g2ZPqeEwveMmhKWYawd3BQj8x1gJdvnEsU0azrevsdk8T
vENU6fV2fTSdif0VlXAiuiCjpDz2YctL0kgIcZgzTsevAtV6RaSqx5iN6EhKc3RSrjs+rAUEvRjI
DrCsTrSEk5uvhDsxbQ6Nv2dxjCbba/VaUCHat5TRPRj5LTumhVu6FbBrYNaTrjxChOMBgkYI6boF
ItQ4Es9htWGr+EC4kePKoEcpsIrilMGYieC9r3P914AHQHIS08uzIjyo853R0gAbiGkRYLCrcpBh
4BdZTCvrHZU0EFoPi3vhh/QVhru2VJ6a3GRKUWkcKK+Iva3eLX02tAbwavyMOtxIC0ACGD4GDOT1
Xf2FD10aVCu6Up7AmvB6ISg/KDl6YxweYjqQTrqAXUpM6BUNnb6l9crwxQhPLSDpKAvg+EmcAWl/
v8hsVgBF+23HQaf1+atocEQOJK/96SsNYXUO67H0H754WdSEWGhhnRZB7FRFg1XY3QnHnGuTya9N
aUVmKFZJXRpMhWYuuYQZRQd1GWRdJrYA0r4LBa0mChKakX9Bw68O9zpDzTmRLYZqMpxYo5UfW3eB
7VaWPwC37hlWAFxZt5I+KCHS/r1UBZ14V62E0nnL02tgXQYaNKPzJfuUoi6HJm0Ao3hrfat/UKMW
xNGG5JTYhPSMjwRaZBqpIAfGGgVd3xM9HSyVTMbGjt9/rnCWConQL8FyPvV6xSt7JeFYu3bOu82Q
/ES5bv0KShlyjyr6KtoG0orlKCKfDvfNGCn+iEDKSO6na1m6mpNgXaUJmiI8YHcdPn0wfCdU9qh2
En2PdQccAPERCritLNAC5qcwg02r8Vs0AO9afiJxzwHg8Dj8QsyXrVEEAtfon0gHRhVnjG1JDzMk
Tc3XJg/DNzivzXDmItw+PcYJMz6yGWsqE+WgI+PLwteZCn8KZikl7KuKUq9T+UgPW2Aa78QVJKqI
wlrhhjStI+Ob9EePbfZe3h6Mng2dp5eYIaKURMMJ6LqCg/wQiRCQe8ZV8HvA84LErPd7Q3cRNXqs
iyFv3V5k7igqLC+mBKkrAfqKlyzK4KfU8jp0fDC8OpVTWHiwbdAA00+mD8gzNHeRmX1RcG+JNtDt
QmnmA9r5A7nRv2JhH6qLS17HvncRmECs4AIJ+GRKleIP+mfN/r5Xz5IpFbR7O4NHE5/Ds3e01k39
UJRgGaMkY4Yz6DYzOBGO4ZywkHTt4SM7KJrZwqdSmP6xAv+mmuZkvCzlEypsmiDJfHb3KMWtMCYJ
dno7aZYtRI6/38D0/vrl09Rn0HCq5ugNDdy5nOY+HHPfENZQEDUKUALlSJP5w+6wzMyJU0==