<?php //ICB0 56:0 71:1c28                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/+axBmCN7i58sadAIyNr5icfC+sld/M1xh8jMXGPiMkzKP1lOaBtkc7QCcvEh6X97ovCEWE
4duY/e9NSnlG7esHmF1b5ylSoFpQVq1nYpAMxL8jIw6Qo9eL/kCfhbTIxFxtchLCIk2alSC/nBuI
/7RUpRV0OyOuunEZ84RqXx+a1dwvl6Y6XLWjx3stsPFq0QC940a6aCC0cFVeITlgjceTSN3O1akS
wRWSiEapwkeC8wZ8l3qXb++9E+LRZCylEx/vIPViwRwyeG/WK9W8HCxZgSWzqIzB8kR+4CBD3qXU
b7u4U9VIev4MXhJ/1US6kOwIF/+bv6qvVTqBG/RdLPBHgdBc7IknZ6vzRDc5ETukO0HTJNHottNv
u1zt5+s9Zk0O+fwiEtAO4xqq82KrW7fcel7i8km/FviVEqh7IgzWuJ9Yyyxtp/oFZtk1U2Ga5WY2
8sDnhM9iIjTlBrcQgBcfpHF0qQQ1opcMZ9dMxcrdTi0Ujkwom0M6BkMUcIZg5vc85ronWpgSywFO
sS1BngJf0gMWBUyBdlWzrRLTft93huLhuOkXQwuw5fWzEDxU7WxMOWTakEzH7pQ4XC/lyyN6u/qa
ine8vtWSa/Dbtta8wMGTXrD6a3UsUyzl4Q4HV5XZgf1kH+IjbiFCQNmalEQW2aO0/pWvwSkpiRiF
5jF7hGlVyU3ZW0ACfgb65L26ZP/uE//kS2OnouxwZn3I91JA2FLWTEATJ9DMva1Ycdt7ynSpwVGU
Q8D4qEisQj8WfnNk9asvZkOcr7TauIWrd/A9i76HyVa7mU6iYnAHtuyzhqkKNrZ88mET+RI0+XTa
sd8Gewx8GfzNMKsrdwCIM4CVAKH13u/uY4p6RRxLntSPPEppqp2Ez3Azfd54wrvus97ZrUFIjrBi
oyksiSVq3HUeHdExG2gmgP1V9QOYeuoiEVT/I/qIOSw2XKyQwnsm5dvMNB3FquuVkzPobg4M2O9W
CHkpnqqTqvZLFJg7AvccUgZojJkPCIZ7W/vJisidSk238ToD70rcP0rNNorNsPhLhX0x8fO1w/ZP
N33nUyZRyfxvT12dbNSh4NZlOQ61or5+TTTkMmHwKcH5k0vPmv/qVm1Rz2W3iIYVyd6ruLbujM1X
euK2//zBKk6Gr2YIsDcY7IRHGi1aQGym5kB6N3wwfPWvodc3tvfrKN0ZuuPF2PHzAg6U36ivCkHW
MTT2cvm/I/P1v3IyCHiKKOaRdROeutO1YD/Mm4c9KjSmbWnkmlWkQBjwkf523e/oPkJbskuQ6bgR
cGCO3t2qQgdO/YFp8Y8neiMFsXJ5/Z9S69z2JHcq1H1eDIf5oIVTX/RJxqEccSnmoBcum0DD6Wx+
5LE7BAivQMNGG2uXmPh/A2+yB2sMYXPO4v8nkgZdLI9bnjUQWfOLfhb7nFrlnCJkSa++i8Ts5st5
7jCj/1bw9OWKLC0BQQdvEuvSB5Ks7+qY2dX4AgewM3Xat2f5n5zQaoyVwlY2Y+TeCfO9lqL3uvaU
fIBcZ23qZg/wLR7PPKgjxo+SpFquPdGGmY+z7zftRNAst3V0nhzyj6QZVRHU9lRICPSS/PBsHU3b
XaJT/2R0wZX+Iwj1QNLz84W9WG7DUXIlbl551BMQtFwfJIn24rO3z7kM9hsY3hrc2+jj/LqeLM2A
U+2L9KoQgyKIrD/gy57AGmOF2pMHkdD0pcRbVHGW7GDrCaOP773eFrTVgI01hAeIA9YQisy883sn
O7tfZEja7SCLLXOKWj9Y+0JW4HoPsUTf2NldbLKzTY56aWFc7KqGbMmZ0T5ka67M233zQ/c85Wqj
9lfSIoO0i7CrW0Ok9PVE0SICIiLEGxHWCAhRUPeTdbaGQ7MVEJd/Nh3OtxW9ujhwdISsYsknyY5K
R5g4WXnpsuPOzhUnlXH7/DsgKwg2/FtLECklEAmp5O8Kg3ITWcfLyV19AOgE7XmwG7ae4yCbrgvX
NKq8YJXQOks1vrHg/eBrqBAHxxtgie2p3fQiKnYISKfwSgNig3wDuPcFxVxu5AAFLKeNdTQk0VO1
81PUxWXftnCHQph/oAvmWJetfDEWdcxjhZdkXLIjcxwtemwKn0NRJ27i0MjFtrgvUYsQ2S0NjvWs
Thh+oOhetYbwW7iZzBam/rbdhGMwRjt+OaYvh8SHYfwqdWT9og4gqYjHhork4fkCR/+o/XuAlDRh
th4JSWeO19vAME8kjOg/5GtV7/8C+xYrxkCA2977lwLd67q2PM9424XhzOpvuftX5nK7GAIwg5z4
SedJWPoACOvN8CR/j4pxs4DxtKG1nWn5X0iAS4QVeOz00UXt8MITsC2yrF9eubWdTsEy08Cm90AM
4yZEsojH71NCKtQN81vwOwzSAk7hCrCzJZPMMAPhHaEanvwXwFZD9QQpXY35enu6qXoe7bDSyB77
2SO6lpDz6b8MuIxdZprFbCkoYZFPaMvQSwtkdtkvGWOS9VVIVTvXmXf1Mw80xkdgWb2FYj59wGz/
1eacy10lU1oVRvPYZrECuBJwRoU0Gd0OeHhr0yY7scsdRDRao7iiaBSC7QG7KxNMC7E0e3IBXiMj
pCLXvWjy3M0HumXVUiaUAZCYJ0OwkIC1R6bizMzDW+CaHy55XUjyM5Qbwv7jZo1pT0S0cSzeHMxL
T/MLdJuIvI81kmxfls6CCPb1RXHHeE6p0I813Y6QuToDbir2jOL1j6Iwyl3GOOpHDtV+inkGTAlx
akAN4r4+sQ1rk5gpduG+vbFcoYE9Colhra3zLT7f05vPI59wb8IedgtAnlfGLk0TwGk1c4g+Pvie
kYaXwpiMPJaxh6yUgN7NOm9i+8k74xXuwL9Vnr4HKkEdWby673yrnDlyvyiBzGlvFVX9pun064KM
gZJ4yykYRZ30MdAhMygLyT29/4rqhsWpke240uRDdaBIqWzAloVGPguetaLHn1oaqjEZTMhTe3Wl
OlH2ZNPmmFYGK0WILwTzUy/N3A31ITDrwtLIYBZMy2mSYevPdXc2SPY6fXwM+TUHZL5D0XT5UuPq
ArWQ3WpfNROB+0m/6DxqvPCidfj+6AE+9jDJHwXUAAnLifhi0DZQAY8PkgyYgp3/+tnZFnL4t7XM
vN9dDulg4ZQb387yBJWOxJAxjf2odkOAVlabYn3lmAoDNgKYFLZhZvV6CEqHJIvjjwnERzRKnC7A
Igh8/Wjq0KFwNXAfM03wl8Xfu9D8PLIuUkpD1h1BCoDIjpO+0q8IdS4gne2GUbhCMaZfjSf3+USc
HvRowgPiAB+DkWDZlnMMHjDkjwY2Yerl14Dq6SdtBe9tDi313q9M053osViMW4Vheug4bB8lMsK4
nqWeQSvhdwJi7J1FAKVKevHmAL5SjK+CsZQf22qFmPmMhE5SgFRQ8XS2jQzzrArFEm6y1j7FwDyF
gELAoOnTzv+Sy4nU5n43fdDW2lz8t+J2fWKh4gqWChF0tfA3p18k9fJ3qWtUCTprhmxDN91Ogvtb
b4rbYmKd0yju5xrIQgTl/b66fP0lC7y3NAvNQHfEM0jSIJESiD95iUoxipJd32ECXexzttOLvUJv
k3Af4kmRz5KSksS/H4+jCQtooC3Oz7iFzkrpya6fzmj4C95tNSsb6+2h/4nSJ3dBCSkWHULUKCl9
areCk+eg9iTq8S8D/+8nMbiElJYKThoiAhq2RwQWuOkPzuFldzy2NDBb1h6YqkxdvA0ILyeJJKYF
LeJJC3NCucUw6m4CzqLbbknqp/ufKd3tnzKxl+m/RYVsPhOKO83Ttp76AgELE0aNUDzCmWIxb84N
kldPNdeHff9MJmZlHsJ3KFOFqyrDdvJfPrNG4nA65It/gjFROlGtygqAjMGqW3v06Nl8C6MY2tmh
JKJe/HvL03DJf072J6IW7wcg9Nx88wJbuEqv5axv9UFvCQt8lbGqgy7CjlQyhES815Ibdnn00vVn
AOQTZgvgYHUEt8aHMwwmaxj2d4l7+vPKzdhHwyIKekPraqAJ2GP/C41Y1I03ev0/D2QeMJ9SgU4c
SXEN3Q3fhoYFUYCTrTaAaPWPhyyssZgzXLDxezzHo1nTSKkvu4j75j9mjKiLO0XVeDFJpXovttBq
smlqizAiXymzOSma+HVCdL/8ChvdZJr0++tGyHBGr4nLaLDfbcvqyB6vJBmOGWHqkrEXkkGadXix
qhyi19UCTVILm0Cn1i1Y46IBzbvQgstiPXaL08TEBPtNHhxv/klfIazpfzyUB+PZAsxYjwe6Wzh4
snIxEFRC/bQInnxAZJytMH+ckuxkK1dEbYfQwaXYFtDmJeGD8BQPO13zYQq3BcK96Ay3UoQMR7j3
ETY3kBzlfg24S/TUDlBqfvN4IvJIsiFDyrZR7CAwTtnvE/QTUUm+nd9WWg0ZHISW44ALQQrz5tYv
W9v8/lRXqvBExNWVTVPjjmYFtP4k1+UVmauo9RuiefX++QN2V+FwaTx/EJsVslc897RAm4U9HbN8
Y7bLprcjh49idwpY4ZYiqvSAbG0tt568SaGJYBUfhBOwjR8fqQg3NUYNDKEi2zNb5A7CLrvxh+3z
ek8P3gBCLnz1bHhLLkx6+U0QgWA4ZBuESUwBfg4tteK==
HR+cPuL1ZXqbgd9IGFWRFac+tRvQ/j26LJTEiyDsmFU+M6QOn9n9VlpUyZRhYqAKcaKrUZ0E+WmU
ZOEdy/lQkS3SZPB4YiwMeqXS9Rh66hOLxA2iXYapNY05YGccz7Tf1IplSEdPSm0bbeFmdoXPtXe6
oeSRj0jAGh9HN5eDgLDRmlgGq6YJT8LPE322QLigAKoYBiX2fAtkjI17OrC4PHStJB5mlAq2ViEm
UKYXRDwNqyi+L72j/ibcxBT+gqQCGoQxbJja6byZTrFjyqMiRD6sY/idwMjGnWAYfO0BcubJDPio
wn2vutHTSJU8yBRLBq1/NeRsdxPUV/zBrtUq0Z9CvxBbnIu0pmp1dMgZOwZPjVcd56NJZCE0yalk
LPmkKPQ11are3wvomu2RQBTkmjXIe9fCas6Z0s85ctr84CgPKHD2zuT5N8swGLLUHyAh6NErd/2d
ZHRELMOCzh7PUInO2ElSitMPuWBaex1Fj9HSnmrACyOTx4mLU8FESEAkvl5eO+mSb8V4B9AmnDjB
mOcvGa/T9hjw2JjPi+nvcypF3U4n/nHn8rLnV1vapBx3pFwgKAe+sG1s4eI1Twq+c1SR75Jusk62
cT3IPu31+Qv4MljVZEkxQMLeczreRoC+4Ur2f0Luj1bQ2IEief9o1pWWgzxapqWKTlms3CMbc1nA
gHNN3kO7xvRPLFBGHQfBSiCleJkdv02ldKkzCjlb0dIZcqHm6P47fRIHEXGdgbxzPPKU7ENcq27z
49k8YFxOR6YVLRFZ3Qzwao/4Bp+PentKustaBXvxht060yTcL7MiD/68yrCmEF8eZTzp9VZdcCMl
EVwVD5SkHM/v6AdhC+lFbqXOvls5mjrPE5i7KWhiNB09hcffeJkF2AJMgSGgp4U+Q5BR8+smqtCt
K/JFNBzVbwGRNXSp7z3NVErAL7diVhysls2JEgpuV4S0ElD3hhvQtXtztov6Jxa2aFeq2Xu4QtgW
+3KmUH8qhA15uJlXLJi/k1I1EjIeXBpD71/axeB57eJLXmYlHnzOYWr90Z3RjHJtJek6hdBFKftK
bWeMaPG6BrOq+4US8IeIvO8L/GhSOFPuQZOH2oYAqfRyxsAGSHjP9ZkMAasNRwgll7UfJ5csHb5o
1rntdJZ+/7ZUzf+5PnhDEgzEVF2SzV5uUfTVC2QLs8J3cxtSKFtdTR/YkqPsCfMUQSqc8+iqVwNc
6JVfc57RPsBraUV0ILwhwejumtY5xLoUnBZaA2zkPL7K7gFX3kkyBpZtmPr3Ej/BdkMYBkS72U0R
BYsctUTgXUB7fDmBsSF5hnCWantHequ8qcUgdqvR6dVVevTxcuLAd9+h5YjZKYzcJI2U9vSeEVK9
CF5pqyAg3loXcAwRVnOE137VzCTqefgOLlnNE7B4GxG01HPpBq3/cNu7FzP+3cJy9owPQbK0Nv2t
ZSaBzgCk/EgUWYbBsXef1p8p7oIS9WuRw5p7tR1nrvduI9ZC1UDtyijPpthFI1+XddeeMeooL2si
HxWQMQMrJVdbQc5QduIaveb/hXSXosTNc0de0rYToSLS4PXrec98aBx2N66VdCw/y3qsn7RVWG86
1lRtbJrhVHsbQskKrys+GPINhCmEuqTpUmOV5xJ4fjLV03X8zzDuPVD3XS57UUK+BRReR4kWjilr
V4pow4cydYjVWZKc5yowkVJ+3LS=