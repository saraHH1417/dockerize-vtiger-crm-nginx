<?php //ICB0 56:0 71:1302                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwtGkfiuTX/SjHmlkCX0e+Atxviz5Wej5fp8WZUZlbHOUIBECCeNaMY+5EpzpJajLXvym/6M
cGiTUhXwR2CPnBIijar46S7F9c8k3sNo2P84oBLVMK2OCvW7s+ViplDc5j3r7ExneqKYfHhxRIot
OcwCBewx0otCFlHLzhpoRBySnB4RUvs1wmfRwt8Ne1+U+oSQ76y0lfYFVk6c9pwbgjWGKYFhY6Ck
PgUIh99AKXBEDJgt+zT29N/+6duiUGIfGH5CjJF5iQlb29nsgcVWpTjWwSWzqIzB8kR+4CBD3qXU
b7wjRYZiGgiJ72KO22m6kOwIVH5HWK4/+IymGYHy5x4tnZ9mSfr2PWbAK/DTOfNHfQY608C0Y02A
09O0cm2O08y0Ym2C09e0dm2M00KtFYQHImByIjlxjZk1kvpmGKvGXsSq6u65RvblTZDy4RYIOagk
NxeeVeNo426o2ap6AkyQ43bAPuLVQ1prjMFDlkak6bW1S2x95h2zJilV4eEuMf4LowGhY25mWYsB
ILoA2ZjD/c7cQescfFwr7Qly9eSGrCJrokUMcBgZpnJ+4FUUpDFQPJvz+K2RuXBk8m7464J+0OAq
lp0uyGof0fshFUBXxp4L0wK5j20LuU3mN/9q67FXvStB51cbWABrY3RYjycaNzYNSyogLzQU2luB
5FS4vcLiDYh2xC8IuHubeqsRWDqv5x/V6VUIrbfXLXDAbC5OjIChYFk/tu63JYKlECAPaWdb78Oi
ZYv0wUw6IcrLL5LIL6amRGDjqN8ujGCo8d1UGSzBbl8fn2WB8KlT/1Ga60bEY1Iyrks7/6NStUV7
KDf99pcsIFy/lzuAcMEnDtbEakeCWXp6jCxJPWGrEPyBSTrCaCf3t32Ws+EYqgR8V9TAlxpB7Ic0
ViFzeORV2QU5w1zRrcuU9giOWvY/DLdkSi56THLZDoluD9MmVI4i1bquZGaoOe3Na1qKRUXq/C4/
hBLL66Ryz7idY58+TVcoGiQ3FMg6znjbpTpdJkst3QAnyP1yKLpONMBm59S/QasFHm0VJWcer8zN
yJDikGmR53ruA8aYtHKIHOiPTaxlXCP4G93xC02j9SWORC9Wf5uKeTAN6wLgFjQ6u7Cpnu00MEYn
QXikhv+i4j191bryijVrq4Rk5CPVHDAj/zJ4Ukc8WOBcxE6giXFC7Fane4faV0E2xYmthAnXGioD
bnFL7HDDiwatLm+ZdSlxO7ja4cEDWZvld2d7r5rS2yEAITcIdCWAL+3/vi6Kj4L0kJQjdWmBof73
MpuDtdjZVEcAZtJjXtkDX5zyG1XK5ZfQK9w46Cvqal98vp6Chm6+iICWyUChG7REOBfNca+Cbge0
c1Ol+RR0PgEaizPFZvPyAOBXnJ9kSlzirnVltMl5cYbmGlzCug4/a8DdO9d+aV0rdmDLJC65wRZa
XJtNWH3fQRD0ZafiSewxt2zJZ/VcpdgCFR1OqsaIwtNbDGvqsU5Sh3JoKosGwUnQ0YaIKKLTWYBp
RUbR1Dzp8PgCTEaKU8/lpku1miiA3a1gqctDH+1C0mgIjZ0Dmt7lMdpr0ezlmMfHzLx+Iax9q5E0
qqMxRdAY8GyrlBIIpm3cuT6BeXg8sYjNwilFMweQZG8CU2p0RQJl/Hcos1H3BlPSs47Y5j2DepdI
ZNGbIV4TVUrAB2Q29JIovB4mjvhB+ODNCqT+uilR0NnWfju3LHSeYVw422kRrQp21oS4/rJLR79Y
5vP6A2DntOmgn5o+WBXxCidMDrUdA7h6GVeG6gg2swrT5xQPbws9jGldq1kT6e6esbOSyr17eUHJ
CkF0YC+8kpvvdZwwBXrTGzNQuxsh7B7HZstBPn/4k9ESfcFwmOSWXuCYl9cdt3z1Tsk/USCHsetf
Mdy5wha4jfs9P54QSuMhi/fbHGp8IJj3m+EgPo6NzHNiDmDUUcee496m3pOfeL8pFYxpUxI4lKuj
7xBt+1rSZ6ULjOz8i/6WSOEM/JYs98p1cU9x0Ndmzv6IvSV1pH30O/Xl0Wr1lIDjAi8/y83yozPg
bOl/qMQ95f3/gKHuQOxaj0LRGFmiEoYGbfXthd1HppUuLAeobd8G5Vr3gw1kOjmhP5XS5TqnvFeo
VKRy2rjpgk3+Yx/dH484ePgQKI8JnoGt2yK7cOQcm8wuYwm4nq6WeZJ40Ln7zSE23oJ90awE0CW2
GHhwYe/rb4vqrXC1VdcCZbig3A8f+W4m6QAV9nru0O2bNjZQ4Z5QCOjLatxcY/KLxM4kZgh6Y08L
0pvL2hbIoSUh=
HR+cPr/J4UtF9kh2vco4pWUpzWsrSERxJHAFZEqxaqJAEDxZlQbR6xHqW4ihhfHQeDoBJZKBohB3
0wMMHFfVEo1+lwz7MiWNi9FwBPx3W6183F/SQCszuvFgVLb0g/vELYKYO3tZjJQXBoEiTzrAhy9V
E1FYgKlyOpT6ol4NJuLyRJN48ZVmba9j4P1oyCraH7tK9lpkRMEfvP8mSDviZH+8gqA/Qt7XpOIO
aOQkpURaEue58nxt8eDx3PjUo5W6AcSm7mlmRF4ktsWMh8DKqTc/HPR1ItPGvmAYfOiBcubJDPio
wn2vutHxT8wM+J4vB50spJlsdwvUK1rM3hL8D/uscEVN7LJHv0gXnoMKfLM3MbVhYQvGQv1G4+5a
qE3uwZcJwaC0v8J9EZtQCYNZ2N/B5kdsCbftLr7keAjpm2dq1i16k4lwyUWPUhs1LYIgdXZCISgI
tOX1XAVj9Ox0XIZdOgtM6H6iBAjn0Ko2ZNDEKmf6or7A1vQc9V9JcYFqQv6tJSS1yg7KevhDUfYi
Tb58X0gwDx69VuJrRc8UP6f9Ci8aq5jPFkPs1BYMbIOjh2zFWnKOSE0Ruwz8d/Z3yk6iLZjY8jWt
lijST+0m8J7CHXy1QUrksiwMgZtIb7plskORd2X0r4GXM44s+Gj2NljNsYOshe7E9QqbJLzAE9nL
E2eNeqrBSCt4kjrOgWIq6ID/1rurN6+5i7+vEFkh6XqpYRdNp3Vkq69X3yLBzAzJCV6fboD1YXyK
dKF2fdvGbVCAOIzJXDE4cLMuZ8kBnmjxQ6UKlELigBogoDMz3vQtZ6wkLEeAUubHMMzcTF8ZV4Gg
kOT/6D8DxGvM2PSwpYd/E4I97N/fOD2timyDnIWf9BdCKeJiUI617ble3S4txdZcW/Bqet1UvKgL
Xga+ZT9S7Xw/glLXPhJDhTaJfp2gY/bD4ClKOreTQXwRb4gWsiUhczeM5BoK0smeLXCvF/vmP4A1
9xYsJyUr4xxfLT3vFd0pO2Ix6yZHszDk9nqD43Qer44xizsvAkpP9qQoTOKwCn2YYrn+M2zR4lyE
ISk5mxlhXtt5WRpROPP87DFLFnGuTrSuUE4FWwxQo62HMboWJ1qOnW==