<?php //ICB0 56:0 71:f59                                                      ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz1ktR1ajYM70Tn8asvbHgCM5XNszUjCLvB8O2muaMEge1GlTEGJbaELaTq7xkiMuBaclMsr
0X3QR1xGmHVob8qGkhbbPxYXH5JuxwyqH9oVXdlbqP2w+ZJNi2zAETo3BwzmxV66tmtmScCOthtm
4DnkSjgsqU9YGCujnP7W826fqMIsO9eKwo22aLXeIvWYbtWLW3tULD8jwYP+TSiprtOou7BkJW1r
ktgdBQtzrIuKiJqEs2odPkSJHMK0TL9q43EtEgm7CQil9bWgMBCKm7Y1viWzqIzB8kR+4CBD3qXU
b7xORsK59U+W6WtcSHC6kOwIN/+TmwymvXtBZ1MBTCDRxDANd7CUyf7SM19QD8A5rv2nSABTro8J
05a+MyN0K5F0dY2Vza/gqZH9242OUgVgFq6VVtOaE9srlEWZRXpxEKLHYhJ0uC9TKl/zaTnssoeI
NEUrJ5FrDuwaB77MSjYhau4C58Yh0uf/ImR9JE4Zvy/BU42QmUvKpJQq7XKdm/xHDxynSyKM5q9Y
vyoGMlum6MEXUjrLJLTuaHtDCyNRESfl1xNw9i9is29yCI2Qd0CGc6c5X0YW7J5gECiSulkQPRW4
MINBHlsdL4y8TZ/qZdVpK8T2n1ivaXZ4SuGHMjU/qlwpjRSXFkBo7RegCJVSYQqM/uLj+voivSWA
q7jSPvpnb/sCLtWad3uARghCoS8S/An/ROj2w0tgK7J40VN9AKpGBtFwElv5urGaUz1vKdGZg/BG
CeRPN/OXazjF2SV63vDnFYYJX8W5RUY9VxT2aob5obafr+kYZWGnAjzIYNzZKZ54InfPXG7MsR7y
EywZOY69fLrpkKrTaKCYrOT5b7TBJxdEHQJsSLQqV7F8o+wqGgcCxS4n8LQ56RA9UBz0QS2IOl59
qhG1MPS5WmQDmYpSo1dz7Fi+rE3vJ+5/62UFAHdxqOXx8ge4b9FBWEN2EtoZTS8ElQZ/FhbvYAhw
T1bj3R+C+AWJp4rAzGCod1ErAWGNCWHMV6HunY6Gp38uA4ElJWzH+nFJ1m64lYjyZhuTpSbmkcFE
88hVszJxSyKnKJA8N0resLUf/nICkE6xn1n17N3hZQEA9DcnWo9tS7g/w3zmOUu7Nqv+bED749nL
6W6PXduSCFQaCNUka98mhpDKP76HlrqW/1YOgxwUedEmGMB8XEb0wgMJKXxRXdCWE4ssrce3IrCm
y8iaG4NcXwom5nvf/9ArvYhOM8rPIeKww1L8AXZkZq4lORHPqE/1XKnRlZ60bb1l/elEOdtwFx7b
ZDoLKAon1pvugojbXLHsdek0s68TGYdoKLBL5GwNyMNtJYMz6anvM1cc032rkjTbMeoxr7sZOW===
HR+cPob48X0Xb9OdJFgtCux/SIEtGbrX3d1d4F90H8Ax/4a1/xdDytzwDsKb4qVJHCS1vHX8Vj9s
JtDn88GExqWtibEapopDexwoffBsqWpOJ05sMbR7Dec7+6Bz5FfuGGvaxI9L1AITXzN578zCr/cp
dWs2j4eulfoC1q9W0PKCUGalZOISMGlBV9Hd3Iz1ebSFh8AF36gLzY/QZj84yNNOgqtVOOD6iZSe
Q9Zlu7zniv3hEV6TN/8C3uY8HsDSRe48DfoQWjZipJslLZBEGh/ZEgW5QqjGuWAYfROBcubJDPio
wn2vutHaR7dBT5EyNd2jlLNsdx1UTHxTYhjVDuw7MTO/GMPgJP7skkuCk9blKcrKy6jfpmILwIpW
SDDRqtoubypnDl6zhCY/hWCaHg/wrX/dxf1xCJBnkjAtcv3jz6tRb8Wgq+iNVe5YoVgFtLypsuXx
C0N0gFfuW84RoVfY0i2baG9Wkc6jE/MI0kp3+bHt5uTUZjKC/XyNCYgXbYxMnCf5FV+78zXYvr0O
/aEnPe3DnyTE/vq0d695i4RWEpXQf8YWr5UNEGJ/czgfytdCfvRryggz8Xj/+2jUrMvN+SbtVlw7
wqafHSjklLwxA7/EIbx0LvsDLWFv/BexLwjFwVHOXJeCJOFDB6MbhySDJk5+A6Xr5U+VWyTjbhTf
AJ6CgnBXVZPr+YxB7MKWVPdilq5d/+32oUoLluy1D+b36dlMyY20oB9ldkXDh52T8N80XLTrz5b0
dgQw0h2FaeCYwFBUeYHk909A6D1E32YtLpgiIxtNBPgnIdFiyCsl8iP8HYLGUrw/7WFtrxtOpoa4
CEGiRiOsaR3cWXOeQN42b15lKX0OzoxDzgMWIGsQkCY1HQsmrfQc