<?php //ICB0 56:0 71:1847                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+hQtC7iZ2NscH99ugA+Cwmhn8mVX000qUG3vhLnayI0rwe6Mxeip2ZOo8ZMqE9g0J01tiuj
nFJEfBaFMJhpvgJkeCrCs5K5b6XESpeERm5oibL+vjg+l6ZrU26bXZ96OO1tEBJ9qrrRK5bw1yc5
ZJbf9VCa23SByE1LFYCFpFKWCbLGil4WkzA4g54svFiz2J6Ja5M7HEWws7IZVpkPfSFW3zgAesQQ
4Tm6rGfq6NhyDzaUNgy/0vQg5LzncusTf6nipzbHhdvDdZl01mO3L/Sb5St8FT4lIoBc/X32pGz8
NfH+8d3/OVEUpgaBBHza1gbuaZskQaddLnD8EfUhtMNUlyQoVE5lR32C7vuuR1zK4zrH3NSKVQFZ
P1CewoxDxOC8VxKNIb9UEiUt+Acvgrr6Q8I3LWTiuLFd20SR1dKfKG+tgp3xXTz0G7IsJbrQWBeN
LHIqFGh8AllCuUvy8W7Le04RDND0CG2tJEiEmf8Pb36kJU3SXqGLOg3qNCsV/Kf9kA3TTZVg/uk9
TcoX5IcYZXQVGUXxpDDjIAwyfz2Lk4ivdQiIKFcKD/AYVCU2616pvokbXdv3kmFgJWzsvjzYdXqv
QC/9Mj2UD5c/XFLNnQpNAQNz/F5AwTQel8463B3lmYgIydFgyfAa6v5sR5lJ//JD/oBeP//VuMvY
LNxWqtp8fVU4lVI3zJW9SotmEUL6YYlaO80ocwmYc9xnIXN/asIaHNnMlXpOEKt9wBdLoEg8OS7F
HghBTFx7mL2d83TLy49au8Z8xcM7BDSnlxbn1/KlrvaHuyRQIURdnA17+SrJRjM0ZP5rIO4Qv2PF
/RioHjZuNHarhcXz/FCFPhqZM+m3pzpw7dn2ZEgZRDbCJe2jw+vOKC6L0ezRAadpofzs7Kyan5Ek
uH0GlyDtmSjtHtXFV81uhLpXNFPjtJGvB4N8OhS7uSzy78f8JTJ5u/MmrFkwtfQKhRX2mRT7zGGZ
xh9P5QMRGgALCxllkoo9xJgrsrCIxE0//mCRjSzPFh9dxFxRhjwHJHyXjoaHotcoIDHy/inAayLI
6QoDKXtFFTSKY6Iwq4DW6t81U+oMoLFQECuOQT5QcYFu/FsrZfWYE5AQRQmUB2xWGREmBXN640YC
q3yhIm8oW1Z5R2Up/2qt8FTFU1Fk7CJWFJNKQtO9JNtbvsBqGClI7DBBHXX4D70rpzxgbtCzOzlQ
lSq3gDIXfP2oen5CFp9x7soz4oju7berc9IdqI1mdbcGXpiPLKOavWT/z7GteN/SbXce4TJLEVCc
G/+S2o1d3HYk4yRuj/o/MPVhjSYb15dt7ZMUgoNMPfMC/YtHzgDpDGCcQQxGAD5vkt4aBK9QOmqW
QJIhuKbFmrDsyeWv4/JRjieHp+CuHBRFqjZYjiz2N5XQMfZdDH/4m6SwTESPyzspnJr4SHoKXRDT
izqBvkcO6nbJsPGJ3+8D5YA57y5Nl63BxsGNfvmxWlHydGAy5h66fbxsrhVT0CLz5YdzwYHnmQCS
szj+vyQImIMLYRlKATxZ9oJlrVtZOYyKlAT4mSjkdAbpudORG8bDCsWFUuHxCY5Dl3TlOTrbj6T0
RxnkRXp99o+/Lo8W2KHqcOMqRClnGYj/xRSNAFykSIx/p4QRTniB7bW8biUyDLYqAt0iHGmR9HUq
kA6p92upFwlCjKuD2KJyzCtdYvUSjqG6lA5JLGgNEV+Lq989jk1Hg44haaChpEZzlfQ9X9HMsoqF
P9sWui65hlCtq5BkoA1xo09YZnbKZmhh2aKJJYKDvRroNs1N9webHnlew6rMoHmqHSROwVPj04Xi
evCL5hoP8kcWO9cvIYOturJP/Iaqax5djoLrNHabKiW5ChVaiecQ2t3EMme4Hv5Xlwm0sua1L4Oo
AsHD70PG26kOsssR9br2PpIZvmrHvQHKSfQ3L/SNH2RA44caaI+8LcKUBveC9aHmlF71gJq5jrOi
XN54C40fgCTtB6oXJsGW8dFlwAloXHwx4N+YH0DsS38XYCsiL2dRepUsOpg7S/nNfEqzySRb8aDu
YiHS/yBwIXXQkFIpuab+IM8mAhLm/e1SG8BByK7P/ImrGE57wg2M4kBRYg/TPUqH2YkTHMQz2vCm
o4+Xs9A+UfBdTAoVrLwbWmrECWql703r/tpuA77aDT3THw0GaWtAgdniRQzWyD8moLGp1OUC4l0T
1J2TnAFjUqG3dmj7nKFKFvbGkwmq9hq5pC4+iTnPl041k7xmDXjaO8fuugSJMzjltQZQQaUWuD3G
No5RLhslc9ZKAwJRQozRQKivUvFSrTIA0n1Jyp+r/3iGshxgU5mlBa4B46o5OzoDasklb/sVU54K
FH4/+oaGl/jKqvcra7HMmCwKjuv5fRGlIoQnkX+VEpSE7BJH2QERIsaVGBr0hBUN/aTaLKfq1nRa
awgI4h6kKY7BnLcsA6Oo/5j/S+gqwBG+By6xxQVVnmCERhgYAANNbcDnfKno9CkYhKaWAuBdyNRS
Li3iX7JAuPEVLKRt6TLnazjOkAIwIA++KW43Dtm9sQ1/JEsVXOUrQelh6R/6EM743k2L+BxagMs5
R6ru+PO8szUdmniXl69kdjkDeazBkOzbFgJe4hBnad4q5VWlnEfSa4sZeyt10WEy2OppsSbJftid
TyZz2oqp89ZcLzrXciXJ3+Ix3JGx9CEgRgPlf5Z2AUiD4jr4TuSKwPiGndSRCQ4IUV3Thw3Kd8a5
TILM2Bp3pTNiOw5rHog0eMf0BG3jBb5q7gqu2GY+Az8+Zxys0u+xLb9AloePAAs12CoaGwgVXCf2
sI+XwlrHOTNogemKL56I0DJgVOFLGpMUqORQtTcL9gb0daoFMhuQ9HvebORUZZdmyiYwpZXsXI5A
9zcPu5PKCKEQc5mxCb7e7AbirPtRegp+3p8ZVg2c9qS/ZQwkkIXeWvPrzpVPGd+txyq503usNTfU
4eF8T41KDx87R+pFXpb6C9Ortq0RkdOaBL/9dhlhfXicj1afbaxLkdZPdtFvJZwu5eKUcPTCB9VJ
c8YD9mp7JpJ3eNiVb9On70DNeZBpYOeGyFTs2Oje83lRCCKkXyumfVh0hm8h3PXGklJboHwjd1py
qBgBtblnXBekJVd7yjs0lGVIYryhFfMOuyCYBH7bM2B1d20FSsjVaPNPH04UalALrZ3Fw7AjyHP8
Ut54tN/msorzpG22Ma5rc8Vu3WTMvhUYEusBYPNjw9oDTUcF9IodpQznyyEX8RKinvgQHSU6zUvv
pqKma5rz9+EiBopi+N0O+sAt2noSuqwZUP1GPwxEuw7KZzehvlklrWrIyBzvu6Gcp3fGWAsopVnd
gvKL8XrXGEZB+RuzRT1qQq8PWWgrCCk9MwtiUHyPile0bH6uaO4R89U9FzhmztKnqr9taDdrEcdT
jSBBl13/YadFjnAraFajrgiespj/wxflQhLPAPjNQIHAB5M3VLeKyF4AB6gPg6POSUcq1Zx4eiH6
ouiOoNm+yhZhoRlf1+lPz8lvPwzEqvboe7R6et9n6GKeKHRV9TnGIg8cN2bYKyYNG+4ch2fXRWqi
IZSpgVtcESV3pzG+KTI2vPJuALQ2ImkFFuQ3tdQ6vCvAGw5wqnVj=
HR+cPy8pQsKz1r1BI8l+HkxpJjrikxMShm0Ml+wvBEsdaO5PsTw9Z3NAFkuqeuCzr3GWSyTr/2u+
Fwk5mNyTEQOsulGiNNFbltZFxWlJ0Qx9wmY3OSSlIJVG/U5qHkWYfluaG63AyogFfa3WRds5hGvk
pymfPd0cu/KpcZgBOmMDBViSoN/+HKvGTBn+0DehTjV0ot3wYXUvVEoanC3jDl2kujDSxXicZCv2
H/82IkGm6wOzpp0KYHBCyCuIwEChiTaeKXPmxdBcywCHTo99dihKUvKQ0r3b0gAbX0kRYLCrcpBh
4BdZT8Dryn9PFPZPxLYr3lOVj5u0/pdMNdSPmOUYIZrCMFTK4idV/o97JB5X3S+JZNXX0Q2iPJ4X
5WbQhbf41kMd9nqtdwmQo672YuR1cn3TmDnBtu1pTV7BLVia1BqDYiDjY/95nRQolPHXloDyGtI3
QfzjzB14AbG99CtX/wSUSiC20SqXJnF5YQtcfEaeVs9mx46F1m4wk+VuSf8rYUhwO3EtCo76+hv1
L+Ki04ePdjhVtX/OjrjOcxju8mYsw4cqHVh21s4vfwGLCvsW0I2U+rRNoWu6a+8CyTiG+0ytABBm
qeV94R0TeqRLxLTC4wqjhslvDiRgdD2FBrWZHh5P/ypSlwvCOpfbnPzl4oVb00uT9M7Qb5KCJ/4w
dLDprZZ3d1gyQrnV8KwV64vt9OXO0+ZohuZel/4cW908uDgLrfDu7zMMdvcYMviSqIdgeC3fuoo7
ymOTqdspVu2C2tm/ZyV2Y0idpcs91u3Zz6njlGz22+s90DcNLch5ZfgbS4NhmPG4YfgG1gf88VuH
O9iIYCN32bqiKMxI8sOLlxv3Rj74ZoKxTCNQE3r7ZnEeBhGtNVbJ/7XNZ7avalELoNc273fGOeJa
bK5iJZLyLonI17Peqyfw6X/ItRzxxXVfuhvQIMVKoQG8f42XznOZ5nw1upuLRNAhh0gqnEUSlCzF
bTk0PZgGHDXcdlG+3kbuaqjJgMY+5fsqV1tqCF+pdz3XxJMuxaTW0Pt8agAK6LX63J1YQildDPuf
xEFze4vvziXY36xbfEcY86a7p33vl3dC4zqt8N4qsdFMTcWH9QiMSqXsZTeFDMaF3wkXzoHUV7Rz
vheZ2KWvNSMZeepg2CXbZp+cfZAvwZSKQ+ms/ILC9XNGCM+NYibxVQQQIsLjmGF8R3KY7JhM9AQb
PHlQ/+vpDYtl05mSlE9tT13RpvASM8U/i+IlwLibZqUAw+Oi2HREMrISfLgI0+Rb01ZEq3gSxhqS
cS3Cq4ajEGwcX35WPQa3q/OSPMyg0le/bUmIEilhuNkwKVZG11KrGLNCVJGb0dUbLUhHKXZiy3qW
AsGmDgAVrkFC8TYxUpfaQqgFeqZlVk7M4nC2rNxRgRJ/91Id/UOW0Jy4MpM/yP5twm==