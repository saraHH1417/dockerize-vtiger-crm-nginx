<?php //ICB0 56:0 71:21e7                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+3365Bwdk5bymIDSG0QTCW9XQetlYvYzhJ8SJec4TGkvF2EcPQqPV30w4v8XnuJ5A9p3QjT
WQnowLwIVuQTWtxeCkblBzsexUrJ1RBm54xDeh6r4pdCpxw9we4PgzVdVPiSQAlsZK+91Tf7cX+2
/IyKZwscscfskqOSSeOsCijFz5ClfmrTzxQfI+Te2nT97usMxI72FU7nlPeiR7m7441TtjjVuyVR
0Tx34G6Je8zHpmaCuLzZSgtSCUgxLwGsU86UlK2bAxwh8z2WLTW2KfaSLyWzqIzB8kR+4CBD3qXU
b7wzSGvIU0yhawt5QtC6gNYIVidypZAadjy2rvKY+4oAMt90H7tDUHVEBRiY/oM/YsQd0XUf7whI
jkrrsia8ELjTNoWq4OV7TFaDpyDcbaKbzj2O/PD8/P8k8ScCoflRd4j5IyNo1w3Vy1/rLhIzhRtS
tiNYxKo6tyJEuJk6Zv3azAFeWVyl0EVJ4LT56gJyk7jFNdZJUhWYPtJK42X4gDrdO8iI2tmxIB6z
yb8U54lXI8WpSeJSrRTSvPRgHTs1Za25Q33pkUKFZFJDr6XepNwsgjxGwYQxTzx+HUgUwHmrLnGh
davQryIz1zpJlA6JR523DF6bV//LUjWFNF01fj9C9IVuhV6ouV/DsDbCyEgydTCBQ5vO/stcKFgV
HL+XL9Fb0/ebTkx85fqEU0cXlBcjCl7S69YzIkJStwTxsjq4crQJgo+7DTh272NUE6bbQWh0oBg4
lVEFYm/BEMyhMzs5jaZIUtsRT2x6UNeRXJKnLE3wyKcf7cyayxovYluJ6HTbPNCHsrCma25KdxJz
e9yZvrj9rNVlD1FAfIwSWJzJcafHeR+CWWB2GpBV2kKCmhZBU3+dGLtgt1zPj7WVWK3UX5bvBSyo
7qTGaVtiH7xAUCqKyOL6zGzUCHwXSz4FeznzEqjrzQ54IHmqcKHB3eOloBQvPtBiPqJmIl8jg3cQ
9+LjMkLiSud5QhgmTbTiAVI1VuKREpF/qUmPxOm+FouuVAgZBt+k3ZSbYNQyixsjWSHCNBEqrsh7
NTbopcDlN3j/vi4hmDD6AEnNKHE4l5mYEEdIQ6JsXUO3mkAZ4MnXhOw7kv2gchQRFf1ezXpTM915
UhGa9iLFwUSWHMvSiFrn3gfQWiQ0meE22RIfoEInJy/52dZio4t1v4HMlNr5BCaOIvyD9vP+LuiO
1jQMWMzkglU2D2EdPxbIuio7T+v5QG592yNdUO7rElFYBKRgI2zgtY+3st9xgxliPQipP1ZYFQ6d
c+FZ/vdDs5BKaCqNZI9bSnCnjveQ4EaBM+pXMDUbxxb7C0FyR3qWxUwoJyjrwWUcehhy2Hmb/jet
mH7Bc6+Y4lTHLY5hXvG4AxSDdXj+2MslYSenuXGGbSluJ+kR9s98nU/z1B4YCXmaWQQqwI/WB6PQ
8SGItDAy5YsHOeAxbt/w45sZbbryLzMauvn8T96ErETaJHA85ntvpTGYdveohUMgUArnbJZOe16S
8Kq01TAAaQ/T7xAyvywI1Y6OqRmMJM+Pub2eMUjw0I1byr5AM5l9JTsrukSKLMTjZnRwVf5qPGQq
iQf9L4H5JnVDREen7kTvaPSgriBsO21wutT4Da39RHUh7a3X+hYra62SfssdNibyAI7fyCf2dGOK
giE/jx1omOPjIod/T7qlr/tk2bzNavpt1lau/+yshOQF+bLdG4HS3Lu5cDtlWur/cTodhNB5z3EL
ssvLDbYCrYl6hI71PG7uYqubQS0q3VCIHcWslo4IzLF7xWRJlCqRhXjqNWuQtPYyUucVoH4nyaUe
kNsw0BgKpX7Euouq+3OEnla5HediYlCi7V2uNHkGEoqEvNacGarM5wErpVCviP2twpwTK6s+Jdak
4hbeLRsSjYw+9xi1uRvqtlZClB4FfIk0V6YacSLIpDCPDSn2TPjyMuxxmwJ51eODFgIqVZ/AA1nV
gLTvx5DIBXlHEwuxfC7CYS5I1gKkc7qJIBD73pDYAE8bFgu8MjLjsPd6sciRoDareI/3esx0aoEW
JMMlu0wlE5MGpTBz7tIs+6iSSydBtq9XSrb84V72ZCl51g7GEr4L3Qw4k2xUJCc0ionj0uZGggrM
mZR4Du3NsfBkiPig46BbBkU1/jqt/VAzJ0nurvtY9/emYMwBqQ9EzQTcHILa7QPxA287C1ozaD2B
NudClPQUr1pOoQljnA68ULG66OlHzS+0B5SjrSukZgGhH0BMgf/MSLqmCqeDjuFCV5uQi9Y5nqhy
nEw37UyAvl863MXy5hyDPtM4Xj5yOdqrKS9j/gLvB3FwJThkgNUwlfIp8j1rDUJBIaUE0ncu8303
roNnfUsdwTlVDUjtfyaUeE/hZzp8w0+/TWZDeA8c6Qz5MI7dtSLMOFPMXQawEpGXld7IrgVtuTxA
CosthN/EcBrNCxEP/qDx3fSMFl1HogUBFjWloqwJiwGMRo3UfnlrrR5q1ST+yzsDnY8pASFK86mh
/mAFcf1FR2Pca/qK1w6ItlX/5qF5YNQ7Qcvyk3+CQpdjutPY7oaX46dZt+zgwIA9YFTdAXQIT+lH
WT2P3EqxdAJY/XLt37t1/p9soQNfh+/5GFjrYKmBX1lFBd/ucTDiJpvfY2tIQDYINVVNlX6V2HkW
O8UTbUjyjvWvQqWU4OIJaovTwzy5eLCMvBNRFn6xva8j5FwlRKz7nfQm9spjUxWu/tPQG17YtK6k
+VUb2uyKCgshuDmAWbbLD3djAaTamAAG/MyWj2VhGv+MPZ05R/gwLQS7fCfvVy8HlvCbmu+7+JOf
b218p9TR9cbCittavQuQjxfk/MYRD9fue2a8buJ3fFRfPfmxQoJ6+i0USDnMazahlZGMIpZWJ9tm
vQwCNyShW4QKubgbM0/7EfyqvHoOI/fJ3ZSwK8CaFUaMTAr78/jupeEzUGDiDDeSqw+5YCoMyReJ
sYs0ui3PDbVtwMyC0HyOTUprgFTomNAppdNovVhaPelr+l3oc3y7twhZxBxJVDSmz/au1r5RqPGl
/54aaoP/yXMtiav9vivMC0A084+/UjIuT9GvXWjyAMicv4CIkmQAIkSTuIax8Pnc6fPxjvL6FKKx
sbn9RUOQLWaibpHysLPAlQrD5JxXa9pV+ISXK4PHxo9Ind5iRROgiFkyvcsq6F86P7vnL5ui8k7f
YoXWH41OnZeP6xwHJN/JLn7WDYU3om8qxH40GG6zbRC3eyGc7mJuRNeSuvMnRGXKjLQ1t4e/7USF
vvSuUfiBXX9ET9GIBwOmLXMqn/qt21GEYLKD5mlbENKAKsXjRjwgUbIMbB8ht4Bawy0iXv4ek92P
FeYMY7ogIXVxIceIlTxo1P8BY2xFbbBYS/pf+0jFYNHEX9R2/rqsoY55TI3dFP1xPtRwkXZf9tOX
BFxO6PDwY3xLY5ViJjkuJubmtlOUWOo3M1wZpOmjeipG/2Yy1/rCfKJAhChAD/SUTZvPDooKVbu4
soqMxTUURnVOgfeDt1rgJWmCcdBggc3wsVs8ZX6T1j4O7yWELKzblAYbxVIk4R9xy8tKMyaB6I1b
AwSksqWhDALPASsruU6coC4VCK9URBDI6uUARR2TKrywQloqOZqwz7Nathho/nbzGOn6GnCDGflY
Lby9uPaTkkGTShgo+RE9uzxMe/h8U0zHAKDwCyRUbeWjHTwDszvBfJ61t3ljx4h3Gk93IM8omRVW
XjEGzJIEPbKZacczImqpFlrUuHD7XM6emB2lIsyWHMPlQu6n3i8IpigFfCuD/w1Cs0i7Dgm145N3
ub++5XeKjYStgBka2ALXwa4kV4btji8A7R/ye1jOCHpVGNpgowp5mT9xsQuue9Pj4h0pe0PSDRVz
2VDa29nSMIPDXs8SvEFc2NMiIKWJC4ogdZbyzIDMXo4ttAb2Xs5rRt2WjH5H4HH5pncYQ7kleNJ7
SgqLStpKGhmY8Yio+CODAZF+GYfOEf4YQ/e6aQ44q/gBvaqL79OuE3Q92pHIxjp9/jOfBlRGq9M6
/+VekzC/MzHfrWzaFcNlofczy2bRa3wTtLWLVYDYhRwPLDJSlu6cDpRwas5UVNtssuzaaySf2hLP
tWaW4QKKgzDlI2Hz6r4x649t9Byr52OA4WTkUTAg9Rr1SnBWrF2C9vgpA9LUrrHOQ0VtI5sJc4o0
Bd4EbUgP9+OrF+kDbZgWbLOiEL2KLI34/Pea7rA0Wv/NeUXcRarAKTtkulYnFVEERyN7vnVisgEe
otlh39dPa8poGrr/hqCRPXCBerw8i6Q2PHk779gZd7tfwbz+IoD2/bzGuDboYUpWZqqNQlWY0AQj
3tke/kyZ+nmMODoaU8MiUflIbyVc30OzhOelTpYXo4qd/cQ8EcjW6uvcoLzidqZq+dr/tNtEWWHL
W8L2AkVeHXSvkE9EvniebJaT+olhI19f9dn2NSXASlSJ7oI8SUpv104smh9h+08BOlzKKvJh2lEy
Ub8ojtV1z9/m/t6XU6jQA0P5h0xrq9WOwLcsoLCmVlFzQ826oAV4pTgdt5p36nFqX6cuq3HuzNT5
WVudb4Mk+y7SR3OdI2jcyN7BGbVbvOYVgvtJbjGt0glb1DCOcNNiwt++PyeLTg9Jo1dzn15jT+UH
UCOvZ1LPcDo3+W80/rOaxpea4tlCQOF5Vic0RYeVo/E9+Fd0EO6ojFmlkLZNJeYzp4zw3KhNpYUv
smr+f6qDvYh7j6B7TN27lSAyfX0gUO6VRny3KeR3XllinUyEdoZJxSvD/eXFr98Be2i6QLLmZDE7
wjezCgiRE3EsQrKqThwyJEV77YzloP4YGyWeSMKQk8160VsMuq8OzrX4oyARtfCBO3TJuWe0lsuD
AGlog78N8tln8oU0PeAzlMUVdH2dAZkNJBZa76th9483GcsHqrjINzlOBLxMezJXcd0mdXARvZy7
r+6885IyAWkWRhdBXJxAnhrx+r7DFHHeXHFX791kUUThJvyOX3U1z3DhpwI8ihi06lBkfipjvx+b
KbxmausGgtfGJcKhcWclZtd9WhIYMxrlaThqQLi4SwpMRAZCXHVxIPI71/GP2gBRqw+y/O+31pNk
cD39j8tny1osizodzdN5yGxlELr4e6xq6GCotcZNyoWfV9OaZnbKMek9oOBYKdhCoYkVAtZ/eBrP
oaziCF8NV4T33npdn9N4keNqf2HUWqirS2/CeBtOvsE5cpHhciRRGJW5h6H0hIeviiU5QT/14fNH
ww1NnMSShnWb7KQEMnuJfiwCLzkpBWSg6cMJsZPGI/hGHct3qNbe69cAUJtbfTXt74gg8eoA02pQ
hNnmfU7n7BV35n2rBTyrAQiaWvDoTqDae2I0GKA8GJCFzM1UXBp5sMGe/ShioiO9hApIFxC5rfQ7
DcMtNAoAC/NKtomVL/6pIGBpg/Ulz7tDyM3apd4r2oqABEDFcy6gOJIC22xYdF5iDv2lJtkSiGwz
HKzQnh3YD1hFEshtH6VhqsJtecp+rvQb0mBx1uEGMXzJgYGaK6V1dRkikhz2g3b0HSj0zKlPQSoJ
OMhQ5dkfclKJ3hv6QVMxE8SZxRG4gbFeaqXh3Ku3ZKCLDG6jI0A9IDoBVG6/z1yd/QBZKFEJ2VzS
BkkQxK9fD/4qkjM3Ss+Tqb3HPoyRhqRYW4nkZkh35UxHd5aN1kGuUlV0sZVm63eNwikVmpc/XsJp
iZ7b2nd4nTdsDJiNdOsBMhYx3WrLq/IqQK3GGiPWBCpUZNf5UU1tm+w+ujXrRPjd/KbE6Dxqp4Um
MqwK52hQxZOOtoOTTSnXq9GOcsZpI9HrYIs4+wer2QOFsR/U59sCQi/8SqpfNDTOLIQBFQ57csf4
pD5cI+Ru3FOXECCwYViJRrxkE/w5lgOg/ykjeBEV2DVvGybDS3BKNr/PUUg4OEhnKVva6QJvCa1g
RmdcQ4JPnVKVWR1f844b6TfwlihtXXvMTH/xJRuIwMCgnSt4wiYqTN8PGC6bYKviAK+XvHHgfzpv
GcMByAHet+Sb2/VKRTPK50CzG9PHymEYpsEkvluFZqCcfFyhUbCi=
HR+cPnR6zk4v5ilMj7nZmjQVVFQ1sfubpiWq3/6kE2iYSZTFn0G65r5IDWn0p5BFBGw8vxBCraDG
ELDKQKEWzUdUSNjXaBs9HTMuK8xxWWBQnCz9sR7h60IsSZUF7i2pIFAAuyosG5xHOeb0dkBjLsQW
5A1hENi41bbbOW4DDY9ZlVtYfuBnsYSSudmWbVWC/rqL4tsQmFQBv0NNCmKQo7QWZfQAB2hxMa5D
X3YrYhrUyTIEQcVo6YgzkvloFKB1G7hBlMe26qoA4eCMvGgfkzsgu214er5GxWAYfQmBcubJDPio
wn2vutHESGDjj1s/xDdcGeJs7xPU20Z2e4M+9x405uYQSlOh3bdsbH6S0YhpuB/a4seA9ffzKD3o
aHqn2FheXSgKz4Vwhb3O8B7DGAIrAndAWnIvKbVNg2UB39s6cFc/XsTuoK+0nTIn7izQ1xjMR8mN
RLDnQzhclSEWAVlsndoKJ/+0eg/2XeT/JAY0x1sFZ9AnQN/nr74rMGBAPZk/Xis92oAFqsPhYAU6
FvADJ5CeXpVnY1d6AOuTdhhd8DIRuNWnijOAnTDlRbV9EZVyg3yAMXB0dr/hA6zMihKTm1Gr4paC
HTDobTaSEuxH4q55m93/6azQ+a1ZkY2E7Uj13jVWVUb3L2j9b6Y2KVa6Lu/AWjYYhtZR6k93UonR
G9oS1mKEsn71qlalACtoaBZ/H8oH+cHO6AC4j1Pldmp+9YuJTkmtI1IJB1eEmBaGj60pTWCd9z67
1xfse23t1Nw6OPAqwTIvzoIBMHfyDvAdwrFf464k4ErxQlwuq3do1Zh2P0I96CoWQTaAAvWc2i0Y
BmbbXaQumOEpFOFTnunfJRxzbcGEkOOZUGO9gpQD7RD3xr/MdXj4c08T2NHxgAhezscZG1p2Q8Tw
++Ac/oOAvA7RDvSQMIHEiNzwLoGZDRHL5baUzq10s6B02Jw8pUpjLBG72Gq8YiHIrwjsgtoDrPzv
V+XTH6xmF/HE4mmd14jftqlQ0ABaXQii9ljJ96mGJjdrVXDVoscJYmhutS5EkOmT6ExYnnH1INio
RWavjb+5iGdtHso2XHpJwS4Y+K2pHFebimPhB1+gUX1jKSIfpcD/l+14BLhWuABCoke0mpuAq+kR
SYYNrE1cuFtYQW0trHaMa7yzLpYTPzN/Sww4fXWaRiPKinjushg/L+gCCivBO2n3tp+RQNcFUkpS
Ah3HUkqMRIvO86/Nt8wpqMCTj7OnMzz3XudMNDxAqjEWYQ+bDLHoFSoDG1K6wjp7wYWxcxPh+OaI
g0yZbk0RRmFif+aALRGfmHUXHe7mNWOq1kWxQ4ZCqXJQwdtNYtQao0Y2DfzlUsEy/C/qADL1gFI8
Q25PM/+D7Eaz0ZSPEczDjMI/4Khu8QH7Jt6vC/ReHbqph+VblLL5Cra2ZGeA7AY7S/L+4DSJ9b1P
1UcmOmrevARpBkhm6e5P94sEXUUiFGnldiMNKY90W0eKey/1XhLkq0TiE0g9uLwOo9bSJU71MDEt
YNbslcQ4qfREDIbqiabBlld+eCS1/dwYqACro+u5/1g184WwFYGItBJlPB1wMbVQxE6zt0uoCi7i
XymJUZuYORJoK0/QBLW1L24biWcIB1SIzd4T50NThSOIexfDJBR4XstE/VwOOKfcXNklxNkGFaLM
YNUNxCVDkvAGM4L8qKgYJWICc1VILFCMxbCwHMRskpaCz07zXh7y5Dj8LNhKnDjRs6xtDu76nEMi
JYogo4kZpMld/QoXogNQEkEAOI09DmJXGwlZnY19EeVm4xuCNgJk6EJGr53XQFB686gvjHmWJoWI
2Rtn/0cdM/uuI/sX5KjxdZ3tGPp8ahE3A0Z5enhZz1/pgoTCMX0L8YCbFVYi/RFQUshMQs3azdfI
V+Jt3tdLXlgO5RfN2GAw8MRFYqptL2AnVXnP7vPz914Z8cjhLbXOwewbLcNUeYzzGbcD50LB5eaa
k+eMkh/aKB7KAMQm4hCZkuvbjXfFd1TFMvAO+/XNTCg1Wkh3kMsjDQcrxE58mdYDrWMCudyAJ5U6
dlsESu8Rgm1AntYCgNqBrjKCDh49QXzg3p5izghDiP+x5LTx/RR9WvtjgC4A55hAP725bF6nsehb
eQy18X5mXilM2B1l4/XDEcCJ00fhR/2D1hIhVw2v2G==