<?php //ICB0 56:0 71:1ff1                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/Omkmvrg1yXSFOkBLu8RA0f65zJCbvUO+DIXCw89nyEEKYX144l8RmXqsfAoZwQDXYhHLIP
XPvXn7uAsweTeSLHuJdIa5Vo9aoz0gg11YODGxwjuRrsWRfDCLOukGpWI4H9EbTTHrGTtkRjGA9r
srIATFhS+aeQas/hX/Qpo0/gEuiPSQU3Q7/KXVD59NeVsks69pE/fBQqXbthryc+1Du96BX/wGQZ
pFj7HM2qusC99m7YPzqLEozGAEKfpwTcyYi3x06PL0KDi362acyVI0r/kKF8FT4lIoBc/X32pGz8
NfH+BcZ4H3MfDeUcZYza1gbuaWt/dMbiKiIrBbQfylWkLNNiTHxebvQ6w9caLi0ZDCT2dg3NCeGQ
qfELENlx+EKvoBI9BKcnXAg30iCWFMiAFXe4HYqeZocwaN2Pad0w38NuTXYBqGETg+bgB2vO/dTK
jZHOr8LOo4MvVBM3EYtSNBbIgOoP5J/wcaCtkSc8zkBSzZOFbzGZ44LiIzsDU40FcQkDs7dSf9gx
kaavpjzrUMwVkTXIrmgmraN6Xzh05X+5BBEw/S1m4bC4YiG72OmXB9ZPTQ9kPM1A5YvpZnZ16+WM
wJJp1HCP68dvraEcbZLReDoVXj2CRv7gbgG6eKOFCRup0XqA1CEhDzx3GtZ8NEAP7hmxea8XtoBC
TnC0qttYYhG6k60AqPUPmRc7LNtTczyPxQTyVnCcU0tD89LUu6H3AqTfKfm/K3iqs0QC4CiwA/7D
G/k1tVrcbjzX+ZfiszKFyZe9W0w4hlf7MoWvzcSQn/laI8E2GvFUOxo4pdbtkfxH7xFs65OzjFBW
JgUVkymk3UHXGtR7iq8nMxtYgb5ts0H9sYWC5xfVDvdhiVdcIeGqNWJQKBUgoTj7hPNCDV3jsNYX
HO3TbCCR33E2yfvv54BR78kj1HAu2Legi4fS2+GcceWVeXAIkBPUq2grD7Rqnl9eaoMrxyzOVTwC
QhRTlStcm9/VcOXyIXQ/J7KTrnIVmXL1alQHuJJzx9wqgLY2KbauykQgkaJIbMjgSubqzstugI1E
36rXZ53asEYm/gTsqZFmTPWUBCo2mrWg+zXTK5MINy0AeXq9WLNHRb91+60Xozx1TAAdQIGDOJc8
NmOWgxKMKnYKwLne7OEJj928XK8L7yDpU8s4bBMZwi2x4+BW6PgST4zdiG5qVrCai8AJBKDI4vbs
WS4420Bc0zMWIbU6X3ik5NtubHPtBIg3BzCXhr7ntFJPMtMjpux954qKWmMw4JkH9o9G90KojE60
Gn5rwxWeZI/WHcxClGrCfn3u8vbhOO47AN1pBY9bds0pL2Due56DXM6zy+QWhOsw9tp7dw6mJnaa
tqswa4SglGv6aTQqIkjCu+4rojXaxWNCB4lyd1o7jsTfVphbxJH2lhGQFR/9f2CIXrrur5IbS/vj
pcaGq7x4MLyECBaRvl6bjb0Lgcb3G7T2iD30Bh0jhkvbms30A0V3RjPTSqm4o+HtqO+0CpxGW5/V
0Zhngx5RSNTrkNLm/utrNKeQYfOKkX2CkViUiN/21GtsCdZLMVUEGBPGh46T9d5EIr+8p0zy32tH
8cBUWOS7jQluCyY1bmNrpnmNywGInL7iViXU/XqOJIgaZcI6T5o6TRIMBioY70BMhgy2cuQ7dxH/
UFNh1tT3LDVBcwHYDTW3BPxDphANJj2O12HILG6pPsCWGCaq9F+Aul/mikuarNyNmVbsfO9m2miK
pF8wAX1uWQMY1gNcsOAUKCN0dCgq0fIx/mCO53cYYHLj+YbYzimv9h/vBr3qobnXpp7y975LOAs6
AI0djibth/OGv52lOuBdtpgQKua3X4i+kWBnUNmeAz3ZMFhxXu8NssrbY7lwTAWejWZ5aqXbsxCE
K2s7qKSN+ajzYHfjfo84CKRUceIIo2GDfqGWf8k2Bbf17xfEdL4ZwdNQaqt8P9FLOIn/1FnSuerA
CeHfvmDKBqTerLe3CfKThtvjMIoUzeuTSby+Wm78Xiy5ukF/H3LOLp7leCcHRV3Nr86ErPhlW37z
dQOh6g6e/aTmmU1GonQiLjSIDa7h4zqUiKtvLeIgOGqahFrKg7dW6zWjlfTu2hX+0URldCmQf+Kz
rG0EVuPgi+cMKNEjPr4jEFBhdgV/QWOFHTO9zvZhGlNzK9Ah6ksrjqrgi/RrUGsw6RQIAqKAB7iq
h8gsx79LeH769gTHxR0e3z1zpRsWOYeVw8alkC1UrxAniK17SeA1bjyHBNgqDVxV0Pcn3MOa2UBz
N+LWiz1X3qkhDpex34+xtAQkJmZwE/K7fXZcr62xq8wGnKOzLlDv2pI5YO87j9fO8sAXWjeFBnAR
19arhE+UpVfDrpWB2LtgeXi9pjuiGbsQUewTdMsZRrvsfUAS2TnPzneV+2+YXkmWvtg4tVfjl7qD
w0lVWd3pX5nI8KlwVpLncPgQ9PTMMYYg5s9WinQw2DU0GSG1zb5fxYf+WZz7zpY/eI1SrfGGCuZG
dj10ZcjENNqe3KOI1evIXJEGA/L0d1N0nEzlNc02TPJIyrHs/p6cHLR5ZXmHvCQsrUd+EUfpNdd3
Q5onWoxfrjUddbftiEz9vUBHRiN8uDFgcX5dzv60K6WQz2x00FRWXIz0OETjneGS0XwcRaql91ii
XPy4H+WT4JYdHU4l5dl/UZ8KB2RYrwIrZsBEI61gTriF5Li1UOIaPcfM6fOUrkNnAp3kYRR5odUx
1U3Sy6sYrILFuAraSHi1qxdRT41QWaa76FO0g7a8JdrZoganFsYKO3ex/cj/QxJ+qhBBx4nLt73j
CE1d1jTJpziSXqJvL5EVoP0j+qxRN+VI947wbAOEcRiMRaFlf476eUO6sZYeJUAuHmgEAEkOXD/I
XyXVQAJUhTd3VsBJV1mXwbJjsUF+YIR/o7pUbsAB8XsBZsaMJg2W3wJ+lHUwZf+dlk0YwGgpVNvQ
cI+/R9bb8tXHeX21ZTD0nvF9gkzpbPJFKknqN6IYhlPaJBukPBjpxei2XT9guCGpFLRbyoKmupup
T2FbNHj14S9OlVbJ+euH4YHBlP2JwL+vShukq9CY4GJ+kdQZ6FFkPo9eomlXNqE+hqi+YrTsQgsu
BsRACSO5RuNu3RhlyOC+06C7a1IeZmB9DBErpEFkcTbL9Fo3ZMabKCpnsJKEgZ+RU2chtNp7cMIt
0sJkwwsMDOabxUJTD8MeL6io76qGVOha1tLEcsliivVcpkG3mwtNMwy9SzR9RVYMbL69qvb5VNpJ
bKrDMR5qvvPW3WYiUWEeGTeNumGdPB0MMutrhG+qkd4ILa/P9LEDFwyfytCbTYQUOZ41jARVggBt
n4w0r9O1+gdFv80IGHBHQvZy9JqApgW3+C68sG+sqg5UNu/wOaK/j7TwezB1sQTOH4wx67sqZxG1
t0CY9hzL3iL6kWadStS00zQHJJuAc19o0qPR/eM91nYmIUHceNrAvjiPpi0MlEjPv9ohOVztMLRi
EvAOcpW49CxCoXNhkGM40n0OAl2DACBKhsz7PXrcQwngOSIYUqgDR8YO1XcB8vXVU9WDEEvU/1AU
A89Z7FOk+WhXKqgV+y2kHZRMwgem3yhXxdieg0viZg9jvDqS+ksA5i3uwLYGEhdohO0fyOd+A3rR
r4ukKL2fwNApSHTszjSscFITidRipcHTV3Z2nYSnAgm4bQe6KRcOXZLEbKvrMwd8MaVmSFqAnRUS
27MbyoSLKKs1WjsKThVwY1iSC6qQU1+GGCLJ/pTQeuQFBdw4isu0FuC/sJwxKdO0uD8kIhuDm/Dl
RlnnXrlXFOckPm9vyDiDPOYzbqHkcvIsGyrPaAZq1xataUr2duz/5h6zQVec+YqkeGGRyh9H2c6+
0XG5OFqMEUa/o/OCs+lkpdz7eCtzfwEqQN/9f7CuH3A3Eh4D/CF6l1mzRM+Z82obzkKYRecdRVwA
TdUrOEwPToaK2DnwdbaN17TwLOlGAUPSWA5G28TwvPsKT7LkhosGZhtjBYrei5INd8fOaN3hbCrN
SgOQe7Q1naJU8F0q/PY+kHRPaJFGPVeMpIuABU1+3NhEfSnx1FGRiBNQtC8XhwTwPgdlTDHqkXth
Q2qYzenK8WRC6iGbcxfSzStajTUXuXUhhgUQhFcnAn/njMoMdL1/IEM8SOadWxBpk+IDl5C+WJi9
Wk7YhXPF2j9rPzjjZySjT+vpliX0Eib/zygr9WprBuRPfEQlegiEjrPSbpTM6O2UeFDYAB2XxPyI
2hQf58t1EwH005jCGf9dWZPlOu7f0gKG3wZsPbMsd6TA6yrCZQ8RP6FpvEOSXmVDUsTuTGeKJ39P
ORizu8PwZ72LNs24kYCOdnt356IDYEz9+lO9eY416hvLZHyIE9iw/2L6qkA0+VgbGEov3kqoS/E7
80ZGjk8KDpGv/ByH5siKmgmcjhXkJO+M9gmjxEAM5oUPTH2baeDaphbbf/goSVT3VZCOkZBt32+1
V1TOAG7WDRQo8RPHVcZsoY+W6AodJeB6FbZvPgE/pIy9RpkgukjuEAY6RF2iULdImfPZ9GrZtqUs
WyWatF11ZBeWaX+Sh+dUgt/pS8dxyCLcD5FSbYllnOVbjz8X+P8oghccazCoDyDb1IaEwAfx6y7A
tl0Ar27gBMjECYzXAVXtCjB9zBghZ0EHdQUljLm9+OfiGahnIPb/GH+JHGB9Q0DhZFW6UDwo7cIx
EcmSS2DCQQ6Jt8v4XDJ22gCO0bx/Rmpba+GH75y9i64o+UtFDDPsRacSPCRK/x/dsPH0HgwhfJJX
AnG1mLzI0IIyB8ypPAXcPugCiHkdH7eIpXF0WqK8e54iY1TU28qYPssrBW4JUMKgk/wJhJr5vbNl
W/bJyxmQElHvQha2T0vYldaviEjW071oZsMBY23HPw/zv/eMLJawV/63Qp1TwBgqFG0lV/Nk8bGe
3Qbl9pyVGhbkE1nOdHKCEErxQI24szLQA/ArRLJK/ZY3i9bE7famyWXJE/9KnXBtLq5imfCln900
TVZZldnVDYYLkE3YpUUCvX2SnFPmh+50BfBb5juhmGHZbEQHaZ6y44te6lKxZSQurQOT+hxX/7Oo
VjlQLCZE/NhveCXaeIaZah/DtwcKdeiegink2LQYpVBC2ordMBBHaf6fhCHBGTTN49aAX/57yGfd
9Qa5eEIKIUb4wpuejRNYV6xRaaGzGx+ptoFnYsExqUXZlgVHsDhYNlhGrpN1fCF6JzhdtDy+7Bgq
+BWucWTNbzz1z3k84AyOw9jJsqQ4m8S7M2074LXmEGUTJWYxfIhJh33I0xXoyny0fSghrgILTt+k
WaOsODDHyCYgACZYgkokm9RyB4orsqrisVdE155i/iM618KLKqBsc0s81JS4h45jv/p3QX18Ke2K
GdPk5nnMKjpMV2u2V/RedsAvSFqcWTIBulgyw7N87ihqScC+6+5m3FcFhkqF+ryQggM6e1UXURfO
9QfJPpP5+g7VdSDWytwovbknzjYNb7bYXYP4+gyv3BU0uGsuW+RCKWTwUV1AqQRfr5B4Mpq65EUw
Dp5xgc+eJ98==
HR+cPusdLgRqSAk9yHx3XHTlOnFPa4Qojtp3ujILSaI8WvG9/+L9D+tE02GVOCGS/O6KgS3KZrA/
bYqBoUMKHcM8pRlZemeomavGcTaBCm75hkw/OZr+bDwinsOzdiYBeOIJ1QAAGBZ353doDE8oZm+P
VU0NREY0Beoj1iADJZld23Y64WmudO3Oky8wQjKYeoiZf4I/fUH+Avz6u0a1QhnaiMW3OIc8UvWz
7eX8SwAEjPR58vt+dkKgOXuoA2I7L2HsvOZvbkGGM+obSKyWAoS+4OSw7grGumAYfROBcubJDPio
wn2vutJQRgpxk4ht6MJAUP/sdxLUEfhMDW8dOhvYyxYwe7LX4sfYNsB/AtATPVsThi4K7N227lIT
hRFt0eycQTAjujoYToFbsJE+CmXtgVF89qza0A3w/yLzCWXnazqFpST9nFok0YwFb8i0PH3p0KYH
gD/SpCW9bbHQqREjVX97Xns/9ZGtxKm8XLM2sTZsRkoahoY9RbIXxxdl1q2ZNoDjc4qVlwAW9+Wp
lHZWA2MrccPXDdGNusPZqjaDkTv+CzRBqQxRIiWuoVlPdZ2VT0NLjnrHlZ11mVvAHxYViJNx/wz+
u2Y1YKSuO87aNodgz9sC6c3YncCUYHHvLrlYsLofUt2AGmmX/b5rwwtnZmwgkoZPQMZXPP/E2GDF
cmyQ/rT5VcVG0hneDCE6BEachDaSa+U3iaVVugbiPWnYlpGAUeUMDZJELaVcvGM6vXL6M72wtkdf
YSlBCHfRf+P+rKlNAkQjDK0HymFsBBXnQwpv7TT/TxfUfMcZTmUakr0fTsqmrdqmVG4R7UODqAJ7
KQFHOkPTlXu76IBmKl+MBjwYlduWserDyg8CVpHQ5IEAHV/0bf7iLazsk0qZf4b7A+MTyy85g0l1
54gUtpA+SMyPVKOhAuQ/dBWrvbA4r8bKWzurC9aSDJS416gsZV6PdqqhywzabACmWPvAiU/+taoz
PVpOk4xCfDLtllaMcd+TXcYMpdl2pjdz99w2j83GPbnt5zU0XwsZ2Gel+mYs1rBz8Qzbzmg9pHha
pfCPIPBhLgiT41YIKboyvOiWvJFHvoZ6aeIbgaKjbJcfeg9SFi2C8Bl3omfMzqNog9v7zPIez3VJ
L8dVosDt05m8aA72nzI6kCK12+eKKvkP0IzXtK0NMNbYce2fnbsS2ry2oL+VaWzIyatrER6HXMpK
LfSWw03peKW8e7N37F2Gq32dtCgf+3JultYJ2TA5h2oqtuJ4gJ/Az/AWS/Tbeneuw8edRbDptt1D
Izde9ewbhlAj3Murg3Beg8yD0J7IGkevIWQxxefl91mJN98ZGZZ8Yk9F7l+BNOoVE1xpjHj6UrZC
8h+scFRx2dGuW4q3RrjLXoZIiACWJkh1jOnx2dpUSZaQFVy/PPsFiUbr+G/GU+zJ1stVTehrScZh
A5q1/VMtOhmY6JcCFKuMdnKe+sySLz2g5RDbgb03C6JxFmodzyZuW5POER2oKE+CZseQetEhcOU7
ZMULg/IbDsde6N3IfZRNUdimJRYMzXWUFPBVPMimvNWComfdVzEf4iXJS/f4i+d82UefJqYhfo3t
t24OVXQobzacOkwPI89trlUw2xl9Tr24VUtWUSrms5ThN5dEA6N2O7p4hhW8Iq1lEM+k5np2DOe9
8jVfcdRcr83cD+LSUw4crk9qZJOP6RLmuddklcCotBkxTk+PJoxw8zPj0+PuQEIV6ybEXn9wIy+x
yS1wag4KdJs2BiBPQk1MLIdn/3a2hQMuXkarE2PxCoWdWqhR0i7E+UOiQrVLaEIU1dXPIlrjXC7E
1iSFwnS5hGuB8Fj9YId00K7R6gpVmTttgd6eHrCaxT2PAydLjk97elC=