<?php //ICB0 56:0 71:15df                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoWs0voObVVJ5VYMltBI1Lm8Si1J1SfPhR38sQzNZwhFoQ5wPUtf7C1qCI3TIExcrYnAtmuV
oUUVCIMNovn+pD3gxAcOXw0Wy85Wyv022Z7k10SZEY7Rr8YsBiKjUwbfK2fMT/3zr842JDrUIKGG
dcH98JBT3dcWZbqCbY2qslGzum2EZ9MhvXfnDEjesKp8AUguY8RYGjX+Xq+C7gyo33FuLoOXhgsN
z6+qsnJ550yNWxUkHNUAxOE43L6fJG75BUikxNsGv6to9CEDTx10YwTwhSWzqIzB8kR+4CBD3qXU
b7wfSLiFjucg3wCdmw06COEI5W6ebemmChUNmu1U1hM7i2udISuAZkdbjf9qCoYDA93livLYaH+e
o65GD54pOwadKg80EIzUi3vsa02709u0WG2Q09q0Xm2609K0aW2909i0cm2509O0X02208C0am2C
09q0X02308a0RxF3bDhSG9u9NvlqQZKueU93/xiSZ4TJ3l5ewoQuwP2O4kObKisS2lSoOix2Ur2g
cyRCQceaMwtAmVNWr6PUKNQuscpnwLJtQXE1VB9y8mMiVfa1LuYOJpDlT6osPlFA3cu4IdyJ27iv
j2QjCubAJtNLLFMy6MMZnKwnkf4td6U6/aDyC3lICzCm7fDhs6RiAQ+ymI/yw9pFIedMQKk43eJg
rXMST7+L71Sljr9gAEQgm4Z+uoQtzuXc/6Yv0+TywHOTlI9sdurb25p+7ztoCKo0nnMe8hk7/HRF
RUYuzyow68Tg+EXtnOjFH25kvFnnVDtel000yYZnzbh6m3UlkNErQ2LSWZW4Oo3nAlP+7EO6UCTI
YrdYK4U/PYK4TBB424A2iRrhTztkCm5y8iSx1t+7UYc4/ezb4I2KI78MrxVou2d4PFNRx82vZpdw
KJZjT0V0acGdnv4UkHorYbLZhuXbpbNx7arxCi9M5Ed1XjuF9aGxRjaY15/H5uoJqdWVM/oridi6
XFezLwj/X6JYiFcqjA5NQzaWZs5M86ubF+PIGMU76W5RvuvUXck1GggpQRQPRZxN9u8TAJO/6lnk
fNoEyjbLw9X0iKBPln/Tt5MEm4UNYVAdTq9Ddnd6B0Bhf4PUs1FFX+Y+g5eNC5wb/2Gb23D97a0F
wB5m/dZgeB26DzTZWegabObibpKwEO8ZKIUVc3Sohc8oI2lxqK6xlUPHGU1F8Upi7AkMwnVOeEP/
iPtqzfQ0g0ZlVntWUcmP3qt2prBZhwyiV1qvdiO7AInxNhzsBtr4WWF7tjneVFGByOfBvcpPYpLG
edOuT8/2k8znczSmCDP+et4LeD97v875iOu7Kf6PGpJGJBoFcljUOR7LIxxfq0MXXS0AFGEm0XbT
khoEp7RosMDVRpJYwnKwlSxN/cbtUrMQ84m2qenn/r8kOdYO0AXeoo2P/RHbPYfmULPeUtTnycnn
gKNVcu4JBVdN9s4ogXaOfCVMP9dzBSmjb2zda6fu6dhRA5Z+0P9+MboapzTkJ3WKAjehQb3FzTUw
nAFhJeo7DxHRkpHTUCkWbLxhY8rtITBnaEjzNtDnEKNwDKocOdQKKD5y8y/tN4mMwYxE67uYuwZh
/uOCgLyACicHC821Xq51mb9S93IuY6craH62CzDWdQ0mkfvqLAe/xl6E5NW1TirRzVn5TpKWcPR7
aS46l24v4Lw3t0f92P9aQvq0vMFxcYZi6ZM+Fi24gtIPVqaIxc/mVxeb4W+ho5Bt47w/byhl5V1I
4sCESwOQGySdumCw6AScnkI377fCBGJYfjlJjgeJq0hWePeVLnA6zpAoEZfgS7bymn8EeA/v0rj1
8BS6K48b/SyY9nAf14IWiZrCczcHJBXifBnBONKX8tPWB2DHv881hPgs8gF367QynVkzOqvNIS18
t9524y38jxFZ5yaiovDohJsigR44adw56V+W/wwwexlyx1AebnbzaDEbqonWzpF45KYgQuqP60BW
3dj1pBouZyMigX8v9uo69d375Ftz+hxaeI8I1zB6kxI27fh8fWcTqZvOBIKbNWh6K16W6hBB2Nel
yiPO7HTo6qQnn0ls3jqH3H1yBZj7Lf7pWyx/y+ivT7SPTJkRSR9MZ4fiaLNdT6EwiXARxsrfzUkC
78d02l0/YfJhiQnuUPhDkPtP/v6laDtLLTiNkNon3xR/mrynUGF+jAUU9j3SDXIPkgKbZS8McuQH
Q1JaPtM/aiVKe0xnV+sYOA5IXEw5G6fRWI9ORfj0enhXQoEKtd9ztwgDo4MIfEXFKrrhuRXwhCjo
f642KbmjwQkrTr1Kqv1XxXq/YR5yBxJ3jB13CTEwPT667U99kphNEiX0NKnIaTL/JCBKpzNvvQMp
+FNJAQ4B7rqXR6/aJkHSpX1j/hLz9hC2Pg2dsQ4A4K9ZL8jLzNzaRBN5tAqKtJhWh0Cu82H/FKwG
PhfOl4HHicdNWejPMYJHIapl1FxPgRQ/ge3awMt5ku6SKbqmh8goyOYYo37HBxWQsgXeLkNTImBq
o5wN5Pn1fV8Tnf5q/OEWUj5CtyxS88Kh8lMeaUHP5GLgx/WfUUKFtrwkXvt35va/4XSR1DuEfgqh
5VQo//3jxQ51UqGR0C1eFPBVAOoFaqC9EmE5w+GIP4nxri4leAGkqevvGp0QkBA0opkpuw6y1enB
KTmi87kW8OZFsa3Ug/FzXJeKRsGqnNcCK8AYXWqhzxUaXHo0gJGN9hlVUfI2pjr2HAVcwQ3zHrhH
NmIrT8JAlZeYspCX0k7J4XjsMquPOX3u3j8AKS9q+oj4yWfYXblPEfyfLnDchNuv2ENwyr76EiA+
GSY8QuoFGBbwMdlU9bxDlyIlE6XohRkSYkw0n4ojycu25w9AIDN/gLV/5elI9Mh4dlLzNgu34TJl
r08Y0vv66Clz8Cbe5E3GsJ/AE2EC6m/jrQdCl60zn+0zr6OVEvX+kzyVgoReX889p0UVqR+/EV76
UojfiBeMmPVJUfD2yylaef3D7mX/OcTVcphPxdWl5mAcO+AtU0===
HR+cPynMKpekeASzH+x66KyQiTQPAHZ6IA40gFSWeJxtBlg2geiHOQRGSfmM7TxJDB+hVobORUaN
9CKhYIp6GchIXL0eM/S4iAAB45ChNcZ7lMhE/xOu0VO0ZJfemFWun1Lz0TQF7G2B1d9sr0Du0srp
HAx5J7BkqmR8n0p+D+NXhSbLYO33LCj5igui9Q6de0YjiSxJ1mQhD39fAX7TWs2tRRuj1nNCyvai
M2mZBWgTP8wuomrz66gW2faIddjuQiK8vD7riE/kmkjCCSG0MbSHzJhyOGyXKF82egMC2vk9KpMR
CkiGkUDqAcnGlOG2Y5ns8iTizX+rNdx/vd6i0RXzL9Pq1XAWwF26TtXwlNA9AcXh+YfcNTnvVUgR
xDxe31K4KbyMp6uiOORlMvQRtyt12RKIczPdhdxOE9+nmTCOu/fngNct7rzxiSvjSSIPUKpF73eY
HHfn+hNqdlI1+rWChChQQHLYd2ZPmleZSL0YXF7sfxdD3s1eyGIjCAGGKRSPZuvRTVnbcYy3BPEr
0z+vMxUq9eq9Dpv9PSBlV87uEiGm2sShBB3h1WNoRj17o9fDL/DK6giBfdMhTKJWr0FNuTP9w8eH
Kz18DGZ1hUAW2sNfxZRXdOGUAKVRXBve+DPEW+/a0oO2Hg9zJ9VtCGgTRFQ8B89Az2N5H9dADkmu
hXZ34U1s67lzjW68Lk/kokPbspO3SfXmbzaXj8NhkUs66Ary8vc0hX5Zz1U+axbji3+S5YoKsJyx
eSaXq2YTmynkyx/VaNWl8eyOYC7tHF7n+BmEL5BXgySubeuA61GiAPXssAO0/hPhr4XQdkqcK298
WBQ8ZpG/Zb4er9YmHBJGSUA8ZpYRCfq+pBw1o49qST2q7iI40aiUppdSO9AZhk4QgEUlbwLbAXp4
zrYPP4gPx5bDBRajYo5bHb7gOSdetc0BTpu5dr2MdTs+qq3ihZyTQAfIm1VhDmLs077cWTIsAg4j
bPsWRbkc3zWEMYVPedeREqvPsJ+6OH57h2fGN7451J28xiVOXQ0w+Tsb2zCwSQOeaAuCkCuZz0Rf
ffc6cSsX9+QKP3lKy7WTRkIkG4nYHUQ1fGhPQb3u+oQdJ2OGFgkBHJg29hhevJMqN4Jzdm6XYHtA
TLv1lFSeSM8tAA5gyTBiKMEzKF41IyJDDZ39pl2erB0WVa5Xo1mnsfpW4JAw4Jj73ywPvin4BajZ
6Ih/0uyc9AdcG4b6rNHCTrkZFOQZPFavK6q6aNHqw1zNUDmn8LeZz03AvtZxMWFOhWf9qNTZzZ1i
tPEUJv0Pn+fTkN+RX4Y6mm4MYwD5DozjW/IpxBG2ZA9A2hyLXqCT4FfeCqBmBnlod8XcgTVyOBdp
3NlK6maddmJm0cV8MnhfGNcVZm9yA0WC2rbcXT828NAlea3/znRzGJRwu/pIjZQM8Ym=