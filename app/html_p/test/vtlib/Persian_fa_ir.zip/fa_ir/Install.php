<?php //ICB0 56:0 71:3418                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzwRL9OgGAtPGqx1jRcatqpyKFJxWKvCv+YMgmjkUfXtsvFL6iLNvS5EScx4Xee9xw+qnZJq
zh1HH7cpkCWn6ndIGv/OMCGLG3ia1zwRilrrmvF2dTY6G5XoIYCa2AAU5iKaO2ShZf6VRGHRHRiP
HyABlT1MN/OoONT7QmwJvOyoaUpeBtcb4SuSBHYeqKe9iG5n5CVLNzxWADa8mxGsPBBmKGpQoRHR
SjN8nC4nYlDCc3730L7WQMPnXaDITXnIruVi/Da6KVDTGGe6gbjuCmUF9/t8FT4lIoBc/X32pGz8
NfH+Qt52KezeQbUeM3Pw1haKb2x/UTVfsVNZd9456Iw35Ym1dce57e2dXvNbzrDqsvZWK+2HPEUY
nK1BBhzrwfBCyBkcrdkRoznXQwk3BMTjnJ6eqwihCdPLpBFTZk64aCuDM8YiOBNfzlffNAeIMIWt
7QFNrXcZOM5Nn8T1okxPdS8lxdu6JZyUWOsjmw7mggPM32YzSOniFrl5xNZghJWqd167W+/8moQh
cz7OseDx0tMsvdPorDXO4OnvhDyvlEOFNSuOm1xmC4BtZWY5nOfPR+/bRUxTPn689fsazn47N2IO
3oDzq7c0nw5WcmZRgLpl2hLKEkgXQwIBYYIeul2Yjd1W8egY8Ix4s3Z15Nh59/qLJ4pNeIXKzTmP
K9zLM/7weaNr5K6ax2hW9wFycSlIaahGIICvh5sk8dI57jaYFf6xG01vq041Yi2Ri4Lz1OQyMT0r
Ze4fhF9KJMObI5wVZEvab/poSqioG5JWmIAEPEsdj7AGhHSeKRD8Mmg5RyyMvAhJFxVr36IHmVIu
UHA6RKRYtv4gdzkkoxkx5ChK7eptBmdgvIFinF7D5HXkrprmrMpbqBb/YK7AtTlDMCamjS+oHVdQ
2M4/XUk7Bp3iXOMB0T4YuAdJKSkBkGHUQHffHsbz9RxsCZ63oPNtuKcDlWEI73IPhZPSr764Qo4Q
NX0KStzDfXw5sAwPl9P/31ZiMOOgPCOp+NatNeJ7raCn6s04PmF6kNdNe5B/hTM2xz8urp293WlL
GolblZTyeQzZXZNsQ1xZHSwvgQ+OhiTAZ1RABUPOVWejpWA6EU0uWdZuO2mzsGzForBqkXnyu0jh
4UwbSRuC32IN8XEWNLVaocbfCZ9kstftdSqiOlabuGY3Cpr03VB/HRN7XckznRC/jMyUPXWn6HSf
o2d2+gKbKf0WmjhTH6JRok9vQEaj2HPqM+w9Gzm4B6uFjdAPXyY2S0wJ/rhdljsxb39TVQThzpKl
b2p5sAV7cnzfc3YY3mKol99f9sdVzrRUT6EiTWxaY6e89334Y2ObLqrc8G2Dt88fLi/z4jDOzXFo
SLd/zJG2hvjM1mI0MGpN6dL1456TzPR6QXdR7NPqHhlCyrisLMSxZpeHTk58CkFyBcltOFhEAxFq
BU1h5royhWAwhGPHi4Mu73U+A75JAK9SPfsyjRkTGoAIGKZG5OVpO8AnEQyiFLjsFuLH19B2jWPp
LIZi9biLN0rfdSaT0yQddyJT96E8IY6myro7fTbBuyVb0yb/AiiMWLG11p3k5a7dW1y1f37OSISH
XWsjPsiDGufAmkk4P6MIshZH/QZ50YM6SByGMKSxp/lTgg1lkTl3/oFKMjUj11M5AzLEdqegQ2Wu
1g9wotUtcVH28cYtkffPpx4wvfuqc4w+InBLmI/1M/zfyOjm73YAiTAvI1ClHzUuD9VtXUiYP941
W5wwhPekhrbsbTm1a+UBZ25Ax/dYC1cbhLXYLWhIqE4jgOwNLeW84lQaCWtzpXv7h6MGKIHuzsTh
ocaZgB1A4oI4amWerC8Wm0YcNlpNHMrSTQUs7KUiXn3qTm6eo18BFcTRJSFG1zEWU+wdsiBzILye
O7Me6xaQoxfa4vuRBdt0YY2JAFHwNteX2513FqPJnbVXRfD8TRO6N18YWfOt4xH8BNRD6M8TyvHO
1L34/XoFrc6MiXB8q8/1yC8tezdRq80D2UZGodn4xBQdJq6n9IyBc8JZZMnEctZJvbMddLb2LkjP
/zGU/yQGNRM3Dz7U8s5hGVIpwg+gVZ95/OpnJ+nI/hO0CeEDb2neFm0940Tga2lsZUWeGa4U/bwP
1fo/2Kba8Pzb2jHIivMlD/UWQImqXC32XaZ+vjFKc34UqqbYcJ3GSGPdPyJbyihuQwbGwDMDq2MT
yJlotQbN0H/xsxjmQNKajDEmDN/poJ8QRx456vv/Otmv06CkKEs1FRkhvjV/OjYanHPt+BhDq5+c
Ezkg6PvDvVqnZCkiqLjSylu7CC9+jv8e1E4TEYHrFzq4yDRyIsdKDgA4Q5o2PY5szm6eiCBZRHkM
eCR7fHh/QakhsXkPi4hPmJu8lVHnYfYvPO9vcOQMncWuhb0UT/WHWCbz9UseSNt34yJ/UWP6buL2
9axXB8nWLsLNJkoVKa3UaLcOyYYYnnig3KY4SXLn43k8cn/6gdptm4dnUKrp+wWo8IyRTASQw9n0
kJ5CwwPphVO9+Rhit/3729KSnWViYuF83Rkz4L+kWDvM3tSxKBX3BgMOo1y+nNz5h1reEd2n9F3C
rjuVohGDOxU0G/mAadsQ6wgWPy2nF+oz2EKRybo8SGn2LjtubGE3p+eW/bJbQspxATT2IQcqAzYw
u19Hv+sj5LgFr7FUm9TEuPFVo0yILDUDnfXkupl+aLhBbIW1ncUpl4nHUxDF/W/vFRpeYdM+J7Yl
XYR6Ti54Dl/EIs6605l5t4MkJWaIdCDvR/F32OBeM4tDl8Xy64EfYkF6XI4DKrgCeNvk5nwzUtn4
bpj+pn3KsuaZnh2JBMlyfI4BKsK1MjZHevwRjuSoL8HN+UbexDXv3OZk+JDXUwqUdu1GFbt69CYb
g07nFSJ+PyH+BbhcR9mChrh2rIL4pqcQyxm57owWy0LKlSSON4tCAcqHl/8wsiEVMMB1haYFx8oA
AAdBy/M9jg24dC8P1VDoXIPkMFTnq6cxajVLM5YNQkI7s78V3sbMXZuYkB+6zV+RjFe0Vig9fj/j
+rHuelga16XMb0z2fbYSBKsQNwBtAoQ9iWCc6A9eTjty00PBR2rIoft4Gk+5RccLrOCxgzlO/mug
UIIeDuh0leibQyhUJWxXY2aM/Jat8uWR1egEuYSnK7jENFpcygUejo/IvOLLWHrYTDDIl5dowOKI
EUFL9xJZL2Q+z8NS+F8/1K1ZsOeMEwYlZDuZDa0bUuia80PqoPeBCqU0j341kP5X1K2It70535xE
B0uX6HrBmAJbL6NkSsX7AB+mrOBiEGBQXyl5h3TNQK0u90a7uaLrllTuIpf8j3V54gcWAmJ3NG60
XPHeEs4Z9HudX7R6dKq/u3YguS0V+Apkq5FImUjqGQ5PrgVU90dHE2g+SVnhzPNJcAcv/BDM1SVl
3HjwgaQTYDDC39rsQVdz+cPtaa6aLaO88/7hvwNB4uI6sNxs2MTrt+d7srssZDBQ/NMbddJ3LyrZ
saoPG/MJ4wXSCI95FtH0ghysYyP5SgCdzawTVK0T0oApREgZX3z/jXMt7kzR3wSnqg4sASGm5JIV
dV9LCq1VIQIWfGaL6FX92F2e8UfVk+qHn17Ilxw3B1kjafLIpccv+B/yij1RQNxX3EYwmg3Mj436
8vY+2KHhXVefuTanQL7zwc+btKK/xYtBSH2uIdcO+a8MDRFVIWJWUbvP2S/Lt/8hC6rdP2i8Qcii
2mqqSQm6VslQtot5/JgnbSuzliryrYnCIyca7avcOGz0a77NmS528xc1a08AEj2zyNZ2fExiPa14
KM2PqTZ2YaKP4OQeptbDlXij6kythSMVJ1DJoV39o3cvxjohTWlHpVa4NjYlHzJlRGtkLgOibLD7
5RcaL4ThXd8GldIA5kAO4bk13gJUk2ky7s136Psy4vUB8RtiLxXK04dm/PvBy1vqOi9LpUMeOfXl
iZ8ZgS7kgNmhQEc21lHhQL7OaTodbYjoxqvJ0bidGzvylpii125/87B2AxVJeP9PUgbMQ+IkZjjg
Riipcn+cG3O7UVuMwmBtwTwRXNyong0zztf+39hLGai6WtSsdCrdy6Ckm3lZxcKXu9ulkMnbSYDn
5v6OnXWvwePFZnYKtcqBXs/B3N98/bVZu8dQZo9pPWaj9WRNYBCx/7EUGA1FTPvVYrtw9ssO32Qa
d8co/+oqJcryEwd43cjgGzoRLvYcbbMR6QR0IUhOaxjctbzdYQy6CiuMeYgRZUl7PWzCy2hMCHKJ
jRmJDQO7/nPxLeefwcTDHUmrTfEP8PYIohcQX1/wT8T9IO3jN9KhfWnv/EzVmqDQJPGTdpXGr49N
tzgeOzXsX2zQJiaZGrIH8cTR/oG1R1RAS+oE1JCnCqvmlW7RlNjMTkumZgDXzK51rX7ss53jV1KD
4QgK2MX/ob1gKDJj8fMTEELcyTb/OgxXnoOk9NouXsZLA8pfjue2qrR/1QEhB0Oui9mPlZb9n/aN
rKHcO57/XLfQJ6BVHpQ+qfntC/gbWP4+Hen+44hn4WubgdNcDvZAwcdrrrou/ZjWJA8KT7yUYsag
3DkZQcltAhhlhVD5c052buqu5ogy0T8nAn1Irv7D5NqbRiOS6qNg7OLiqlYd19ACRHGHFHEJdZaD
DvisYPvVIXxYL+qLEwGBYnAt7zvJZcQxpWeMNbQPRXcKqBPDG1abzBG20VP8DqoE0LcfpEBFKvf7
lutuQWpd9tZVXewtBtuiZvQbzKDpegnE2DpwKr3vTFXOll+x7/f0zvJc0B7Xoiox5av0YZKUVTHJ
62t5s9wRlNPk3dcTfyeZyVVA9wyad94nHmde52+eYBta9/+q9n4iMLV1FNlhhcCaR8gooMuYBFTD
CqYhz6D4CVOuX3Qks5X1KDqjXer4mG8QR4ugHhqBAfizkHkzilcZHo5fYiKQM3WCaMppLYzc1xQQ
MvyXmTi/hk/DflQtdY690Lv1UustSUDCoaXOxzTSwdtmWekvhaAQAeRAxcAWWCly8h015hE30t9t
IIci3tJrN0i6+n3XvrfHhdA84bAqcvQZZcYwRYbvGmkLBq4jVU5kEhr+pp6yTpNpCrcQqDlWsA85
5dAPxGCdbDDpzTAh2MQDOs4X3lCBOYbfCYy1x/vl1ZZBlmUJLQ8guY6lGNDPqKFfW2PkE1dJTeaL
saa9l8Tg/zodR2HE2tGHl9YvkEwu+BM5rgl2TpvBS3tJ+PgIT1sQn428J9EI0kAdD0GvnGwPkGkv
E6a7B07fqYAD/u9cmJ14yW75Bnp3znny3aCh/TLosnFfb5jr2Hllgsln/GTKW4eDSeS4yg910unV
Pf0WvtrT+njF3y0LjjILPDnpcURvB+z4MPQXviQbW0Mj4iLLRUtF4fvonUP2/yYs4sHB0M03j/2G
oDuvf8ppnY0qkUdaeSdVV7VI7wutpK+2j4u1UCkeYOvipB95RdtX3ncmtId0ilxmtaWAiUpJ/FLO
cFbcwByr5UsMXbLlk3BVaggLOIW789v6dl7ALS8BkPbtZXV/9b9wvgIfKqkJKozejB4gJ/SKJm9u
iIiatsKovDUnIQimyWgaG3K+jucU6p1SKk1+LLSJLat6XyBVVZ7WRn78v9z5v++QMQoiI2F6m7Pn
vc6wUux/VdM17Hnnj7otXk0pN/qCCa9BXdkJq3znZWVYsYxTooH73ITfz4nCFkGWiu0lOK+JshLh
BTG6zn0WHHoNkoVNTYVIQ0AH+bSChGcBLK86kBPutcPZMFAxZjiSnWBqIePonaQMNw6goRBbddLZ
zQ/NDrHd71Eep6uzIzaomP3JEk7cBONBS+m9RgJUK18TPqsfHKeMAbULvL0ZdZJXlI8eCRvguZtd
w4fFIKaGN2KfK4tg9Q9f5Uga3S+3UdjN0hMVz30FlGL+FkGjNrflGa71eK4Td64dsVSaZv1muSXE
Y/LN8MuT5MOGMA85soNla7DY5m/RJMCPifVfkoYRQorc3oIvnvZA/BxvClkYvdsJH40IiQ7F3lk7
wUxcqAg9V0lRsKfDcnmiNzpNO++17978uLdQ3GNM5b8YeK4ay148pL/KmO5H+BXOHzvESpgVur0r
RBQCPHqIWNte3cIK8pxI7bwQMKIvqxRO3+Q32bzeDypx9qhw/uC0D1hs6gMcfZYW4Q7ctUveJAIC
ykjuB+YhZ7OayafIqGU/ZEBAjQrZOXLZXIuxBflaNZcB9W5Mrl9CXXErIs7y0kwoW/2BCKou2KP3
3EICuuMAL8vaAEnZq3JIk+NQIR8YZMkUtLb8oB7cAf3o6mgP5Z/2N+Jmz11qFLwQLyHrEwGxUS4k
xOVYgoVk5SEXm21legaGRxZ4oBaK7fD/J/10BNhN7J5zxFdYetmB5MlmiKARk1XErJXmBQM4ybUA
mKAlZ3zHQ5KuoV+KcOS7bt4nl+QChykSENfXIJBDhqM4ehLACz6B3vpUNxBPOmjQGlEWPEF6ADvS
lCZJTBVrzYLRemnyuJ/Bdap92YJzzxPAgSw/409Ug6rEY11v464HwWWiqFwaGCt9IT1v5WQ7aJ55
3tngnlZE9+vqupHHFRKnwIp/dO+aUQQeXBL5JK/V8mrKTkK6ZlVCIy/lMM7NkG9/19PbcIoRBqsH
7Xt+mO6R+6fZ1//Pbf0pBtvxgLY1xzv8A2d+nL9v5c1IsUC4LAPXPRCoNlTllWcxk7L7vdpqQV3z
lgNobYlV++QR8c06CHLWQAvv9vIv9kMDlvC0Qp5bPljxBs+Gsh3eySg6mZrenhOfpXNRqQgFlbx1
MkCAGnbw4+O5OFv2oLI8STKIGBOrKR5Wc3+GB3IbAggR8fysIEIpqe52DJdLA0ECanPb1734E+zs
kXaDZpVnjyMou9Z+VJNqiXc71J9E+7tpjGKN8AA8Ln8+HH+qSprzwRSwS2gsP1vgLCyM/NEKP8Gj
ljrTEz0iN6WVKA4eFaGpvE1tEc64Z2JWl1zRBqsM/lFXo/IHIxGbmbuQ6WCG9btkpgg+EnfMUi3U
CqO6wEk6PXTaIwRrdI9Yt0nAcQgehXghg6zJO37nMlgAxrCNgLQd04R1EqPZtK/+qsabjgU+KBCS
UZTF79FuNuj5JjG0gN3EozO9Ox/Ufug3jWaK8xMouuZ8Ccyde3Fk31ecJqPOMM3DDQx5XNBPs0Z2
2eM8mfkBDlHGLmAosY6XZJtt88o8JkCnTtbg6NL/6qIXU7EeC/w6Y/zYTyFm4xkNt666Ih2ZNEDY
WyQpRvl0Xi/8tOmHVgBUZtAl2cbb9D4JorMXr1JaFI9YB0/RIkSvhIyoOtsriJZ9LHZHfKo+Hd8t
O8M1GThsvAst1WFnrftHRafLgO0pKc6IMjXHymsc5IUPtDDUbSnIUp4puF1Z0PWMGhP4WvTGtksI
XJG5aet2kxn+YKA7DWRE1qzH6L0iN+exHTQIRa45eU03YKA7KVj3U8hpnV4CDcC93xzZK+Tt60Xq
igzr80FqV0y3Lqn++cbkVcHt5/NybfYx839eGNwQKn5phhcSgCk4k2xsSlkwn5P5iFoolKStwWnz
a3f7mJwLZL7Bz+ZFDO/SDr6ztTe+PIaWeRBlwOXhO+7C5DGTXKy1ntlO5CUMgOG/Fcv3Ua+Jsz2y
G2dsx5aC/X3SIs3+GSa2gThgHuOdarCXnWAwNQhbxTuTh5pLC77McvHACk9amm9wGfMr7fAtrsb7
cteWmffL2AeB0yTlURZmwWcrkmR/Ldk2Y7Fp6BJlT1MnTQqUZvCPPWQ+xiLuJj7PY4KLjrgPo6YH
seHcveTARh4AvIUt162BLS/5fGvO3o2LmlhZzpc0ZoySAMvnN1yhLulE4iCN01uLcGttG2ipPcJ6
zKstiGbtSROJl25iXV6f5d5SdCf6GSNDR+pHiNdrrECpc9022N7xVA3gRYKa63SgzU9C9lasGgIb
JMvh1iORk1WADPFx5wTw0H3hWmTTa7hJvwTyESRZ0AWH+7k8h/XSSSN+JeyUYoR9/EwpYT2zTJiw
srNEr1MlFVOMdWB2xe98jlVcJUOjYrDDcmNo8HqD3YbcXDXzEvlhoL2mZ06v38BO/7lHMTUqQdnX
N31eHxF2mBkb+r6ai7l3ZO5isLhZkHyvZGrsNyE90GI7AgAIXgCaOZkVQB0azKltzpsmAISdVp0G
kfO07iC2kQMWWPmfbNFILObIqD0gCtvLmnj8bZY0NcjMhI/DjkWhObbhfsIo66Jh/C3oEEeJDD0k
eJjptZHRe61+Yw8pSGyGq6LzI9UqYprrTe9R7wyUfIoXEwHvogXsIDCnym353v79Jk2yFxpYpsrq
+PsaKAip178TkowJGtRwW9NCiZPJEUCPseX4kbYHJgQ/W18V0wcc7hTuuEETE2DRafkIghoqcur4
Dj42bLNOfPWEt2BNfYunQfU/gXrkto7H7vmfdazxijncuLh3jNzn9JRmVHRskfhl6qq3Tg6QmiFU
CSRQGMU44AwTyrRyRDDuyRXER8JKEK6GxUpeS79xYcp2yB0e2M9CS6nMnT2EYm41UxN+Z66ngOLj
NBzaykV5AUzadUR/1KbHTnyVpj8eTA6bv+5HFdue8+BKDpZVifQxWGm1ngTi6NWpI8FAZ/XZYclQ
m8pDewnalQv2KqfKt+S7Vzce61l3QOTzGzzsdg/m0sGXVgkl0cIi9ctEjnVtomnpwIlAD1IfWaVR
rjwroufqpE/gFmsUOWQGb2fYb7PzwHTFf9e1xaupGmv02YDfOAhHuosCYVkR/hXCqHKs+jaC1IZu
zI8WHawA4zN+nn4TfGSgG5gl/mYgD5n6X41UcUVjnNZ4l7vJGsub9Do2zRUHsw3fxTF0YOPcgmg+
fNkHfZ8TI+prSKrLtSA49X+/p0ohATlstW+5XSGB1HwA4ITg7pMI6uG/T2njOWP+TFed/cUn9zk4
UXMxg3vfZ7CvpxeKLGuEI1tffYPG92jvpVT8UJMLqfGJ1oNLLvcSn1Y+gRLNEdBlRlemzuiV/+R1
z9lRucUU3FH9oDqzmEBOEII6c+9LiUR7WHLsdy7Th6zD9DFFgAvvBBSq2QIGRlx/uS7jPuoPhNKz
pdhieMf0zkB9HAbtyHkKr6N9yOoobhV6VCHaWLeBuZEfMK7aCschyDc5YY7tA5NTSkplaj42ywRA
QVwiYvK9MfmnqbL3VzKPEmsfpLyAZnYUksaWsJ6TuXhCClumk9bIlcdx4Ct54FyVvLq+utbewaae
8Pa67n33Tr0O4am5wbEt9WMlOA7++Y8Sp5h/6GRShe2TlQo9Vhf7FxHc82/Q4hCaoLL1Wq9vA/Nh
3RGwhFJnYObDR6m5uGQYv3S5bjdQbzV+vzHUDGwV/rVDjcWIt/l9ra74HvS9Od2sJx09ykYx+CGe
Id0TNckweKtNlIALWompPXqd0Q+X9Nysv/rL6+ImswnffepRr2J2bv8R40siMyBQws4CasVAu1tn
CpYi0VQy/T5RRAqVp6OYytS+/biFiYkmZLRB2ricYSSJspU75aBXToCvJbBkF+mbx61GXKlPrMh/
8pTlUlDTxPeE8LXIPCIvg7aiEh9hsZamQ56ZACL2mcVDMYNobbVYt6T7+bmgdEWkFRZU7tJ9yEmX
FjRcFGwTAstsumpykOAy+9aOBZL9h56VXzrTIy4XhCSmZ1oEkrulGwguZTetoA+AGm2XMBsZq911
j4JEbh3q/BLSYLqO3ByjHElL2wtCn8wgtsR/nWUrmUHsLFg66h4+Dehx0vfCHE5ctUT6r4CQ028v
0ycKkUESzYRRUKQtqzIJ6w/10D6MJewESCcfvJONcwSTTnIEsrrSbG2BmnrZE9wV4RqRd7XRa9e4
kvILcMbOnIN+GOLLeC0pNzPmXCEWosWFlCHYElhN45x3BerkV50QaksIsFEdDEF9jkKlo4sS3Dlm
hEeA2lmsHwhOXX5GLpl8HySfC0MnjMZFouj2Q3QXrrBMzjM2TtU1mJ71sP9szgw3KKKDugs5PqE9
P89Okmu4/5x48s6guLhqBrjppDphlgDoN6odRXSHZjJ3EfdgAjHykU+NG3Sdot90Q1hhkEuSMV+t
KlV7VfYnWBmwz0GLKnCwLrHwaPQC6kT30E97LgV5PlGKRd+YxN4gEzsiEvTCU5ONpvgeFf0cMnxd
hCAMu4oQbrLdxxV3wUTO/lZpmlNzjqOmCB4i5zeUtJWF4jtySFHzTLsf55pSBpNvs6/0idzxJyaU
VL68fr8qLH6l5MqGPgH+eUG5DYI3lbCeYmMxMtxI6Jvsh90ZoONB0p2MkmPqjRqQbfeczsxD+/XA
76Lk1RhKZTB9GdR2Ozx06aq7uvuPmgb700p/X/F8YemZIwqNgJCkpQxHc7erKJjIcars/qONIFEW
GQ62QRA7vVUmuHp21dLqaqbi9OgS7D34gCTFodhJf191rMzJ1a4R6z+sijkPFMOGdx6WFshpnlxc
GkL9MAszbmrL241M1QJ0ctEltD3q1x4JPsEvdPHs1iMEsVXhH98vyfm3ziIbjjdKtY/WpagoOO7N
8HHpicIG74gLWn/1mFOcHaW8Jc+959N/eZvwHS2CgAOIoyZhdi+vK9iEYvJjZYFqvQ3Vf6XnggWF
S0vUxPl1T+CTea7UXUwjLkjWiDEuppjd8daq6+WEYGgbwARZVCOO9dxnaZS4BiB2l+Oj1VpBrASr
jE+tOm//CDW==
HR+cP+YZizBPY0Zbr1OcyRga7mIvEoCOIQFfVkMFJUJYwUjOlJ3A3Ibj/EIi8+Pfmf27bXqnXwku
IQQunpAMOSr9eC/PWU0hX//EvfwOXoH5+vKkFiw6l3tdEJvFVGfojOHld08DpABsM05d0jxB58jQ
hqVHTkY58bpSX50sEqjTiYLpJF5NYnTaJToN2ds5RUbe7mgFofb3MrXIkupj5NWU/BMa/v01DWwf
iCF6AUC0Oq7g+o51oqx08wKJenUJoKrcw42fGFd9tpVbvR7of/8gZIqBzKDGumAYfRmBcubJDPio
wn2vutGDTVAH/DbcXQZemag6dGzc45r7e+jO+BlUGogUz5DyVxU1OPLAV3NOw4cfIouoZzrhHS22
aoaMnmntEL37WcyDdeuQilQjxqI2JDHSSvItClGKUQJv3J0ZPb6SBmk7wMrkJX4QknJz88SIDM0n
DvMGoJ6X4IpNPdjLdFnzJmuElbivBg9ZCzIDmvEJJlTWAJS+p2za7UkseNCaMvxUHtZbr2mLRQht
GgzaZ/vBO2MXll7gyGcBu16L+YU+yiKxsIQv7PJOJNvWIhtEKDZwghK+0EhscCYUQgbC6ZZ5eDe+
B1jvkJj6q6zfWhDiRyfqs0Wo5znJKsSKWI3wsNuQc50byB+C0rRXKVjQILcjql2M4xUw/kqA/nwe
Csbzgx+nRrJ74ib2KlJR05h++rJyh+HFwDib5luTHyGYi6xqK3YXnp2m5xB1LRTO1TgrYZ+FpACT
MMuJyy86Iy9zlpTynCak8vAV4AjlzUf3fHI1cgcIIIlMnV3ECacOzbQjTjgRMf8O3h16QCY6Mtpm
1gHKUVaIz92fO2Y/wFmfipaV3P2f5aIfv2gWqOE8jLmUGatG8RFgQRl9igPO5AJAPhzKTQjKBWCO
j1nloYsuXWR3iDJjtXqjYkHw9otJp4ie+JvhAfNK4G3xXFk73e84iHVNN/WL056T+7qv6LIdSn4z
V7yPj5d/wP6y0wfwqnSo71bqjxkvOrFpwqcsGpu3EEc6cxUS+V+z13gmgMtx9t9thq55yUFy0zQG
nKj8tZ7NyqvLheQz7ShWsqNRRxi2ZObb2LNq5JKtUrNWVYrO9lQ3vj66enb3RXRYI05BuNB75lXX
qQUYxrnjodFh/jE+fhsz6U2ofifQ5ic+XQnjTSTxDNyWzVzNxRU2E5/oTNiwhnsNq5z3i77UbN9D
Nuf7LAphFITEed7obi2e80YAUVE1Pthumr++JkDdnrYAmYldAJw99qj8bHdUXeae6fwMvpWqelaC
6ZCA5FibHjyqlfrtOc0QaV9hbky/K4unWRUFQl3AO1t2tukPdm8lEpGsz3BnexAtf79DebH/M2er
P//VFdwClqI1EWU6boWrHWOshdgRXPj5ar/MNQUCExA5FUNEwqosfvFYBScJ4i7GTvAAFXs/Ek9/
6CFb1eKBQH+hh4v4oTQ3fA3OnGSewwOUU85onSAhyqb0PK3AklG6MGCokXudStq1Qoh/FWPQVPg5
Ti70y/wpkGE9bzZ20dPVsURoPMoUZC1a9CyEb+oFzt8rCxpCGHyYg1dpMNF4LeKkwVrT0IySPUSV
An3ZH2SreLb3w3esyMbQnHrrmVWn+xGi50PsXKL5GIujSSW3kUuUQh/fAUttq4qqTvS1rGsSbMGj
6B3IHuKXHEPBzgnCO9KhjRB0meGNKyAcWfIwRmHJA91OiNgQTNr4x+4MO60C9KagTlHFlUpV05UF
fwBdnOpOh0wWG7Qlwa6JSH7MNgWbUaHHt/4K7KcVYpu/m1XQJdLzd4ZstkHUZjY6r+PbQt3M/ZYP
Kkah91lU8s350zhWQ9vxPxR++EYDC0aljZKu2tV5lz/VmGP/0pFxQv99igXvvn2sAvUEt25gp/iZ
X8xDIQ1D+Y8BhjAdYp7WstMvct59CM41b4dWshF/CAu02qFCYk6uSnpLhMDsHigICb8HpouwqR9H
f2iPsE1/BjYtq8PZUl00pPwR1f3zakvgyNZjns+Dvp41DjcoJG1jS4vx8njovBDw5vIceKjW4jsr
HROfBJJ/4mg/qkqIoGW9ocscE9OlW3OokHXMQeOMcQNOhakLRjotGl1p887Z2SNqfoksw0cEAVu8
Jq4xSx/PMTKW6GN2AkFruXbbqr5Q50LB/K7H51WpRNEaLmJcLCc4PocZ2dVo89VrURUdNtept476
DxujE6PTpCFZZtRRvINETzdwQuwm4UPlye23MpjXl1jlRLmo14iRSgUoyKo5uvxtf6hPqZtmHgaa
1y00/JSnrhHr5Y5seBrAynYnOLOuxJV6wrn7LMwF+1kKAY8PQvC68GYD3UKUy05UGh1YOo2BHnSv
7Rm2SVOX302fzEqHB4m1yMG1owB6Jfjejrtyw3010ZizHFzTGR36ugzyrLsMq5kjvrHCKb07LgIE
j2LdvmcrJmbTym31YaMsVBWq3rBACnQoeHAOcRvxup23oJOHdPdcneglvj+EfimFWADDtM8GPYQY
xB8r4KN1JSuqECNJOZXXuLqYQlh60hmfk3N0UWNY0c0cUvZ9+moUPXwqTPU3L2r/gzv6ZIDBxZZ8
uZCuf3JfmrGOPUfAq6MkgFr9C4pnAV1rCiLYmUYhrLjH8h3IXQD4sbGW/N4Gx3AOGe8Yj7MISxFq
RoXICgsiic6pMR+omU5Myc0o/Xw65lgO4lS1VJSrJHrBpefKOYV+iHlC3IZvhyxUkL53sMXJ2AL4
n0Nqt5DUHrOsmgwUlZwYBY1mQ0ZZ8Z7dPtv0uym0A/5dPgY7lYsD0bssonxMm5IHsoEPZTljG+qL
7Dr5YPj6/v5alzV1g9prCKZq0nyddfvCIMhJ3z0rRmA5xZ76c7Yx6uRrPiNxuda/0RttBMmT72Y2
T8Y+dvtl9mU8WbBF1VSLzV4mA9p1ynWOG8e0rew8PfSa+FtJYdBWn6wCsq5jNO9f5fivWPK1dBVO
93uRxpc4kaCc+KNbpOLuubOY9tQArgrl61AjbfOhjtwFzBSfrEoMckR/wIUmU8Jd57b3Ji1f2rg6
7VJ2vmscXXegn0r+m7cHL63hreUjOlN3sOVXIPBWqivOI1AWUgWl049mJU6gd1/dbyURiYIKI1el
uNgEvCuNNGyJ4LwwXOzhqA/5IOT80vhC//J9G42DD7qH6Aj+o414t+ly/VL5kbJWWMQm2pWvspKk
oQNLozKG68ZecxQ9QAUl1pzeqxm0X8xnnolz95trt9GNjoW3vVMcDuB9CW98l9A5QJ3ZDS+AQhtQ
Fz6KNDIvmOkEgsc4sZ6EIu97WCstMFv9lEFnbhV7nS8QGEEOLqpJinkfZ5pcNm==