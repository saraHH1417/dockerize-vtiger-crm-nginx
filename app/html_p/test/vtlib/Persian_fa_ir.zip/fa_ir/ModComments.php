<?php //ICB0 56:0 71:12a0                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+2o5dWh4Ej/Gdw3MoxGMlaKKvjQ3PHFLDEc3ge+C1ZYl5g42efeRXBNCmvCZLjWZH+UgOOo
Oq08ozwdr15XoWWKRxQ5+krkDF4osU+ZsVApZI9907/K2F+FDVDtInGAazTqz8H6n7d+kJ3j/X4q
8d/EFuIADu8LrfebfU2vLEA+1LDJGLPAvsw+qekQ/D7OlA/rlUfmSgP7j0dLFMZOwk8BwuJji/1J
jOetZN0hG/Dk4Ng5pzuYksCICRGuaeY3MV0EWMadhNYJ9zmehIINGyoV4auTo3tHBqiYvluGmiqF
I5wKVkbmMge946D+1WFPB0QvZf9sicYZgAWJC55MJQg7ndyBu9DbXmD2T2wGtCsOfHUTLAha6Nj2
yzfC9xIb20JEpiSPbo545tkLONRQDDM0n+k/BZafGIaeHdE5Ni8hWID4O1f+e58R4XUUf1a+b2/+
1PzJpqesPXmB8tA5Qh1WY4ME+jCpi0tgN8Qa+HXkVKMxdzzvPsertKtUdpZpWdiB5PTcZbkrpcVH
J0Zk39yQGm5nozLkXUvut4q/v8lNYUwTNNTlpGsM37S+i1jB9YCt9tGjNwe9QKXj9/KYbQibrjFi
KGyAJm/J3I/K2LNCBVDcck3/woT8qCr2Ok3oErZ+WFbbaxsittUN70GDqxydX5DQw7K3tGcPRLF/
cJGHA5VT5S9j30K1t4ljEGYOSh77qbvGSvWqVbUuwv+xUuLNB91uH2gvNUMg/I+Ve/KmpiUvPpbk
v1tVyhsZxcvgr/aebSeDrIGY7AhcySxHbbA/khotcS4e9vLDTZJjsbOcozRSFln9vhYSWY10TFt/
r7XWYRqtHqUgmSmIjZxC3nM46pT06zkR4rfvBa2XCYhHUdyY04eagJc6CRuJnX4Oyeahq/oWbOst
xAZoBltaADi4f16eboj/iZWAaSgsDmDNxWXh8ffk0pT7JfI6bTqWWCNzs7mCDLRDLUkcQ4yU/0ea
44zUfiYP3j8ORG1LRYnM200zZWe77dXs7mNaNfZQGBk7HWVzDqMb7AEsKpBUgwUF3PYCfzw4W5wK
IpSQAhUhvWzFjs1m3+jY5rYYq0bt5AuR6o8U1n+0w+4S/kjfOMaIPm6FJd01WA6TN6oB5s0phIbR
1dD4kUfLd32OgmmZX4qcQSYHIDN+4Ltgoi1Zbo8x45nZJuhpeWCki1ZYMIEluvgYEOVecD2QaUFE
2hOKVo3t9YXWxvwlUMQ0QG38iqpT0Q+K8PvALi7vCfuFnGf5tmy0RiMSSGxCwddMcrs27HtBpUwQ
HanaCt0kT8B0IixfjSTHFXEtULjXSzrylT28f3eDfl4ziQZm8uRD1rZifXf1dlftLCLIQwrZSL/5
AOv4/yC/giUBBztN2SpLM2kpuKxRAY+y3Ox6YJvjO1mhC8P+SpU9g8mu1AohsDIdfmlZryhaNA7i
BEycmPl25D/svqnO0wWhRjxrt45PRxsCRyHBAh6g7jIjiKcTFJ/5xgqvGZc8ayvQOpNnY/IEi5AF
UmEuC8ORTGushBjUVoPkBeMqoCWzS0wy1nL9BUy7UI9PGbvAsS5wgZRV7lcQQSnEuV1rnd90y+fE
xaQJ52j4SGsW0D8IrzZyB0/q/USJFMqiDjPsPCMzucmNWbuS8+xNv1yx02yroXQIBbrwnqieeCQw
+z1WNWkkTnkXk+waZ427fEbBRUeGOlqEQ03Yk0sN2mt/i2mTe0JO6XSzIJ1xlQfN7nmRzVNeR2/7
z4KLlHlF2Ndg8m3rcV2k/BMxGdCm5Bx5UbYQ7SqElbaZ62xjb/tC2zcN9vTbq3rzCOLTaKgZYKM5
WE46T18CQqaV3jFLawS6FGiLLL2IMnCXm1ZtZM1DUa6l1tAH2sDlhaF908SAOc8E02xVJjUYJ0qm
feSjXWx4mcsjN1YE8qvKZPCCRoKkZzhvu7AK85cGTejz+CLN41hfcGo/ZX5vkCEAyxJfsPfKcV1l
sEkG5k7Vbxb+FODPMW/WOjdp5y/aRKfFJ68rLZ/EUJ9E1IN6/Sx11E2SKPEVpJ1SAG9T0oYWaMzD
96rkD63mlpW9efyuh0vfOUEzd07Cj0XgVP00PWHHJlwckUxljjn4MaQ1LZ2BQM3NQ7n4LPDd09Js
smKGDhs8VjnKMTzlZHPav4f+9zsQqEfn6vzyRW8LaRTC8ydqrbbUNhUfGbUgqv2BpG===
HR+cPw4YiQc3y0cEAfqaYZI4B7RQEhloBrC9rUcv0r11JCN+usk9zBptFcM7teHsHfzWI2CuSVx6
NEZZRxbJy+cvQQsGsL0W0o+W0pKcFcSKcqK1aJ3hIGvvRBI3devHRmje+3Cp1SnOo9ERK56lJ9gV
sHMdqHPqH2/dMN76oAOrcUca376sTFm5r9ALThQMEqc+QCj0S4GKK+kCjs5BdPBWCylWgz9RIdxd
pU75ph4b8yoWEvvgk7RbN7+iw8TgTIV3qwnrGZSVSkq82S4ndbA46/Ex3r3O0gAbkGkRYLCrcpBh
4BdZT9vnPvDThmZ92AaDtOQT46PT7+FK5bxHQnVAKbj0j1z+6GNYo5nb7GGLseZzXF3ySdkTa1as
w4T0St6JkFDfny5l3EW+tItz1x4ZWw6f664jOMUkemrk5UII6Iu4Kw+gXFcNEMecLTZGdan4cGWi
SXLehc6l87zf1ENc44r3l4sNhB6OOg1a08ajRu0WaMbYge7P5papdC9c12kWg5TPkzppYcFardvs
WVjuJK+mr9uz9wSCwIhu5afUzovDWAAXGn6RWKKIIglJiMoFXLb8qY1DIeCPOvocOoantXqXNwBZ
Jupv7ZNlzEfUqEtu48fVmyE5jxzfiVl/Ne4BkdGdGTzyaCBWaBVceLeZ2qQXo3+2aig+ERpo83fo
E3d/XSRPkYix8HVU4qkOeCC6dlmRchKuEr8AUb3CUf/mecgZ30oPVtuce5sj5BYOZ7lFW1LgPEOn
yCTejKQW3VQrGWQ4srDqzEoD/8Fp7XeSbQKxSooQr7rOLVNiN1JSSXdli8GPWyb77iOR08M0qyln
nHNMFSdWK7o1HyOQ7Yu1mGQN0u6XCMSt4J828tTf+QWTFOxn2Y5gaAUsU5mWZkMAS+U/qgtSUP6o
ijDDIYtBGdobDqYvl/nTEwGExIQDl9/VRtKRUFxJzJVBWGKoyGfh52Ap+oz5l72IyaCHfCJs6LHQ
DP3WkTj1GLgewKu+rHMuRM2LGUXtsS1GrlLbZbUv02cKKGY2q6rm+f/mon95RaVohol0wiW/kPG2
ONX8IQUEozFLSFNoVsQR6BRq5V+GX0==