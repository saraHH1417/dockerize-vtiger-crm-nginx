<?php //ICB0 56:0 71:23d2                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyhwqZg1LYSzB3j76Tn6fRo5UrwfP1weVu/8NFHBnoAZDdy1q0zwHA8OOAFmacyaEXxXGHJW
2/YV/2zc1W7d8muuaXKOmx4+RtFFlBvlWG/bJY6XlEAmzeLQpgv9rh3iWj5OK8c+8as9sIAyOzgb
wGUcZH6fFwWUvPY9mSAEnPC8gYrhAWRzwIOBNbmbNA7q7rQQdrKzDA5NZHGiejjf1sLVMk5FjivC
+b3VRfvdnh4YgCv/4CCYhegkFSzfutARXvPTmtmAjVQFGH9XZzP8jl62FyWzqIzB8kR+4CBD3qXU
b7vGRl8CD05eDZizx5u6COEIAK2aOKI7j8t7CKd2uRW7JZItHQrNqzbImGBWM0xfTdj2Faf7+PYB
iHTOPJNDZdkWfdYaSDsPXrrmXWSOhLaZmF3yYG2109S0Xm2B08G0aG2A08G0cW2T09u0DhB3owOB
ZUVfq2cDyNH8dcUUwJbzN6PRmLlwoNvlD2GJvp8uTmwrgvpdaeUPoTRIq+6p97ovUNpKsa3ZHIxd
vzyqr9Be7l30ZpKibiKoC9YRz+F5qVqUZYXUP+w4oGbFcKuLwLdFwiPnpzoG2aWMaDNdpH4Wz6HV
t9ZhJlMzSR/Pmu57bcwWPMc/P2X90tOqKWZK1Q+GKY3zodPwVx6LSVl1S6RlWtn36hG3XhvQbuU3
X4vjbgyTdfRqfdqM4FdhvXZQhAu+6h1CQXlTDRFADKanZyvaXepI5ApV7w0Nf2xAO5z4tSxjuvzC
v+g/24tmxpyzzNO5yelepjQxQiRVH1k7N8MOVgxZGNeIHT4cfbwVppiEdk47z02b6+8WyVUh9M0G
bnF05qKEXTIt5zGcC9GYXcsKo0OtnBUccLio4SvzCZg17xT3HcjOZE2DQ6HuMOcUCNyOdOa9AjXW
8VZ3RZPcqkw1X41VDKu8dPDI2Cv0flo/n4odfPqI/aczOSFdXvK5Ceb8L3DVwSbhN4bhqYTsZwdb
fyF+MhkI1ZJinI3C1BTv9PVitMdNwSuLYfIcpLm6TCMQ0+uqiocKAYK1hGGPn5qa4otKAFY12iuu
moQ7VGwsw0sI4X8dauISRcQFQ3J8KC7mbCBCK+A/qzpxqCtapOvEod1hoOy4Ikdxz+fRqozzLOMC
xw5dQ71d+IzCl248YaqZl1Co/OJj7czdQCsbrxcdRjrBk2zDZtI3gga5Dckm8wzL0RnnyWWN+LQS
lUGS7qYEqaSJjUHGayqW1TlJ6l1PqN40DAyXGeTO16gkhmGLhvIFcNcJjkzkODLgkWRk+LBaP8vn
Nzf0LYG/2lE0gniqJvbwsN5ZW0MyBv2aiDdaPqpgaH3L04/MHBU7icwBdZE2lfSeLB3w2JSneXWo
9Wb9Le4asLarl6lajMHoEFEjAsdlVpaa339O3IHKy+Vy4/GD1FQoflh9B0EaauD1Fa+610CHU+dq
FTQ0cQGDwD6bShE1+1FkdNvOWOovK1Bos/Mlu704iQes0UaPgp1kWTwG/0EBnRYEtmQCyQCQTNUy
aRqunQjdtBT6U8sLn7GRuqskOSMJb1dLgN9j5+HmsP6cG7wSWRVLHHsDs/e6GvFmEbO8lvG07DQp
CPU9EBvPnYHgFNB8Kfpw1axu+tIHukgEps/Ccu/Pc8UTfZSkr2iFR7UpD4K41e62Yfi652w9ZVEX
UgsDZP/uwt/XNWTitOCrRYrWRQhJDQWZs95d2j6/A+xpS23K4znnS8LmVENEJAzzXNNRuNRyTVCK
tgPKh4TfYNg35mq2a4mK4XK2I0AHUhqO2k6xbyNtGDnwfE2VLIUVY3ZMStGbHqgETmOjXNNlruiG
jGV6MB+lvc76h8TSWzjCifVntIjfUuHuMcy4HyIkA/r9J7lhaBhsHkqnmtIqfiVYhIQq6ea/prMp
M5F6zwC+pA4ZXIs8bnSmO56K54N+3dzvn4ak7PjVYGSzFGE37/1XuRhQsgyT/Ypv/nov4oBheHg9
63lN1e5sMKeeLY/vQHY/Eo1+9l+fnU/oYjxXhfz/6FTwGAk5IGETTXutxeoOITYedA8TeJ32sKyt
j7sMFg1HSAKe/hPG/w/Cxw+D00xUL1Rq/YXeLFtihoXOlJZwaEe43KSo3Xe4gw7FNKgQOhvA0IL2
0GUVqEMAwMee+5+J5jwoXUw95kpRu+X1cH6h29hANvcsCrY7fbeoxWawRedOBnDpl5qAtyPYzE0W
ESOSgq7miX2Dzaze3HhDGD093zyPMoiKnjokdKa3YEMQ7NcPXHLoHfEsNt0NYrGWoh+Yr5pMZKHs
2Ff99i0xPT8kfJqgNJXtZ3RvQwN1G/0AI6/W67mm7GM991WGJ2H6GD3n1rDysUEMEs7bScuHShWf
j6ZJPNOAjrl0LvA0UtaRXY3PlBO1VefI7+hEQ9WebtFkrzpfylh+fO7g3eaGUNQmj9Ww/HFcbTxH
FqreuZ0/n2BuJq3B8e+ik60q5/+ON31EB7UF6imVbWHiwvaVAbKA8druPOXZCbhhY34XDVeUNzdQ
zr4FctsaNnP1OXs/fr/XFaVFpZu37TAlW+lyNMKlZJIL6SLag7bOmfV4FnLTQ2f2bLurIqZlavY6
YU+IcF9yHpU3yHlMxXGHiLQF7PFXLPAN51hI9hfRw6ToV8jJLERbYdv2UGmcnZAmZGr/sYjpvJ9I
4xavwQ6KLpRTi5bDvuWFx8+IfohZY2Ad5ND9w5g8mNMCpEA+q7eUb/1o655J3s6kyOLuEakA166T
l2ou6rc+L4IJuDGXUaxwZMRxnp3bEa8104dwmrVKHlHkRTeT8ah/LQ2wDJVcPwyYM4nwaWjQpzRW
yfGn51JFpf/xbKDOkzeJ4+Srn5+yRK9/LZjpQX5GZHOoiVXusfdvgXXsA/w20LWDeJ8PWQ1yVOYo
fh/idnzO79jhvEIFsWkPikD5v8ba7+M2bqzfEcUE5xbG+N/0lZgpMuqkw97+4wAJVlbKY3k7xs5o
TnNoXk/TEY6q9vqKGAkllMwqGvFgclAT1tTOeIqmrKhLxr1srnmkIzZpMIGZPWYG2qbGTR/TLtBE
yKcgJgr2nEx/NOK6ujj4XcINZ/OxEnu8Vd2PoCU+TqkbFz/0+tRRp6FoJ59ZkYSqvjpxPI8HXryG
APElw3f6kMegUSKYyloVl1HetHzU8bnTMm6Z4l/O4A8GoSXqenhgjxAxoFlUwlwQ1s06YKhIP285
2bSPhc0Yeeihss0QNHU4TWSQt8EzqIwEttrGePkUWn0wE+jA1ofth7ybiHV7Wx6i5yG/fgNMHT0n
GkVpUDquIsBr8joGfLzEtzV+D+78bbB5/kR11BHGYJ3Jcbn/egtPIWPFbg6S3Qu9LgQfgIeuGIsk
A+0qw/ztVHXmfxitr5p02ozZ3ecmhGW5VQ/ttEgSISd7/tH8vNbJ07q6tiwbdSetkrs9mUTwkTJx
oCeX8UT1mjSLQZGpAji8pvq3vGGA4Pwk/Qt9Cy1zCAsXiFD2qVnqWoiQYbS5fbQpxjrRa7SQ14O/
3Y8LYWJL1IklflF+szPJdsi/3E1HpqoWbZWzz1iSv9yEKUFkU0yGK6v9DeJ1LE3C//ybbKAaZc9c
dcVmsnggznqvYpvlrspJtsKTl8BN5uhv0QPyaSXTYyWMRaNoMjSZMiZZazopCwUDSTM6vx6Q8NpZ
2WQKZuR6ZNpCoP543f8vtYbpLO0Fx4yEErMBmbQRPegSMFX6vMv9gwD/W9HLKMOLJJK3sISmjGTi
kW8mBO6FJl83XW0XrMr3WEy2PQUVZTRgSzS4W0jVEYJwxPGpmxzIBNGSxQF8zw79MQ8Agjm7RjWN
Gq9+P4MXdDLezw00UOcv6MdXozoPDZBk3fzi/sNebaSakra1WvaOMvzGerEu1Bm6Qri4mDkb2cIz
gba0nfT25OwIXj32ZxjEFKUh4YxVtykg0lHkodILV32yl5VELXpAf5yclrfmFROluzOt9cVTZz6r
iq13PgZpRp+ELE5RaPDZ/TdUSlwWNl7X79VFitGua4OneY6DqN4WCkgRfLG8HX27wnxyC3KE8ow7
hlf5jo95xUmNzwnHbCWaInP0Pd/Z6Bu0gYokyDMRONzTTik2ffgXVn7rs7bkRHqXvP9SiUmFC6AB
rhDXe/5f1U049Ta8lEEgFZsV7ISvfFLzExMYqLXOv7gDwztTx1UEp6kmIqg4OJjEYzKVxf9H8Fth
//KHrYn9u/U5D4PbLVXe/xAw+9UzvNmYoCFy+E5EKE4zmfbkBalSEfQzBNQvIH0c8QE2DSlJo3qr
cHrmxnpOqOXqhuMK9mxlswtcouApPt8BqC7PGjHMdHsG3wcyNdqdXJ/E7DdkwEn8Im/XKFyd7jYE
fxWi1O6Pzr2nRYKATRAjtCOo+RqPgQfgczIaz7XJPR+cez20p7rviGTX2ltCPnKkpZNNr9z8ThrR
ZUa2fdzQkIJVfjwxgfeUlui+nFCSnOl00Yy+LfUA2ACrnbvkg6HMCPFLGT2KBp5/IlW4tBYD2ojM
xj40pRyjmhGkY2M44dnCLcbIBWNBbeVdUiji0k7ivXxaFvML9mRaBpktXCzvDJxmYJLZkSUjRt2V
ra1hjPQwFvg59bndmA3nR38ZWm3g03RWXsbYHJjERxOhj+xoK0qZ5NahcJaOoIS5oR1Z/mgtw1jI
7fhqmkUg1p/LPE50SdhqpvOYDk4mUWh2HgyOks9zdUX+/dBa1c2JMwxfaxJz9agHgCuigCZSYTeX
d8W9rktk7Zh0+za8ajxNjeXFGXChszdJpJH/8vFLYzLD/1m1VLCQIhCvekAW2nvSkOta6jd3zDTZ
DHoAoDP1lBM18YUwWX+r7bRd/568V5b0gCJXYKJyFLgQwFRxJFWXhnPf2FhbnR9PKDJ5QhRQwccI
Df64/Jh2pJ8mu5wN/yfA5b/82rPkFJzalfGoM/JT2Dbw8vJGhkUMwH2tmc9dSEV60ME1nFnuFw0I
z7RPJa2krw460tvn8H5yGN7GuGk5qfgKDrwEIT/gIxC9HXMULeLgw3VMswfATKVfgDlACp26j7su
AC0dLYS5L3+UAg6fxYVyIo2MKmPHMBxu059xLP2XrwHPTpdKG6ANe/6K+Kk+i5a4FwPB0XEs9Pag
IPodIRhDsuSUiTz/rZLvE0f8zBclLYI8RDbhDhadillDrIkXZr54mcGHidikXXPmFfyHN6g4qfj5
q4UWj6iA1GUYZ9e3K34e9eUzRPzML9KhIAu8QtxnVHjE1kX36CY4UuP6HPq5WgwJd8nX5cwW2EjT
oOeGYvz7HaJrJN5LnY/Kwqry3pvrnN1zr/OcL+GkXrIrN1y8qO1AQSxF3nPDAc452B3uoXozC007
yOeNQ15o3guraX5ldqmjf5goyN9BWnl/eC63d2BnMofbtrEg3DQXSb60jIpKVSWVsD2YNzCTKECv
mVcSCYEl2CNKWlENinFEvhqFjUTBsV+3Lx5Kh0OIC8Kby77hOJT1nS+ETVOEzAT19PmGZwaI5O5n
rsX1TW1yf96LJ5au+X9rzYvh+bUbc9uJ+EOinrdUAWGHPxjuhZQhsZ35uYBgS3HtOBjB3a+upgNE
2FJI2P1uY7994xx3OwJkU9Q9eu0Nr+l6wkrsOpyE2OwSGw1FNigUwOve6aXA/UWex8mtNJbbaAIB
kLBrnv0kMOtAoC5sQk0QQ0uWAVW4KSBMBOCLXXZZ/oWG+o8IuQSTrSwJArpC5hX9tGg5zHsik+bA
fTIQBbki1KnhWVArbfXH3Dnn2CcM5my4q6d+C1cqyBtVoLTXab9E+MQz2nJ4lv6U14DAFT5TVmwf
Md3cqyziZn6FcGVodMbjkjM8JOGg+/V4YC42Ed/aP6pD2fW/t1OCuWAn1VKC/mky7d+JqNvyg1dh
VkfZNhRCnBGWLtPKHD0aN4KqsmaGIKBA+JcU4skB4yWjY5zyXKhylp6NMLwJFbRw7LuimzQmLBLV
thO3qtd180l/d7jR0gR7A26hyD+8VHJUEpPI0QNC4Q0YN3RWI0QZSbOFG5ZYk7gt4HpY5XDKeThH
qezO99wbEmzUP3N/q33dxfIdqSuCEulW+hyi4c9vEX27qwAdoD1irBlSmupGNQ9Ne5MapsBeAdUe
wz+fOaQ1x2a8lvO9VAxso/s7WM9bu4mKqtlG+VAxwykTy0mZszdb5cmj2FdSr+R2wTgdcNbO/IZL
78dg92lMhLptFgQ2DEgtqfXAREYYH9oVSVZv0/N2+T/PhrZ0T7SpoJrBl+ajQM3rAPHuJnG+d0j+
T2QXQlWPQNH27EUZeH997l90zl/NS6zFYcpfi0CplnIO2cWKCL7vAiP5IMnRn8/qRLqSBUDyCkK8
d8wTw/qug9XbTXAGb9gC93bOj8VDnAIsDfadwJGo8ATcwmPgQOcGkQRh2SXSb1eni2kxXz5ZzAer
I1Zb0zwHV6zdpoBLQP32LGXtAQncNA3524KkFfQ2eLGU6D35yCnq1keqBEc4XjEvyM/0hgweieEk
vGhvDPHUPN6Dns7Cp5o1kSwYIYttjS9T4w5O0bNAv95Q2BJ/n0xZEeeEmTUjKRlnvbd4yOitDQo9
3+TO=
HR+cPv92JHMCbRLQEVZODiVQV2LZTJ2p1oMZd+13Ljbhy2o9Z2JGPAzq9E7IVhl/r4ZlKEouLC24
52nVh1fb6H9MiA2pyPmIv2e1PbIRGcg0bWdmRvZmBcxbHFQ8EB0G1l9rxxbpvrouoCjwtDF2Sndh
uZ4l+BQdPoswPndmkvkL0atJVEcyf2JqAMznrjsezZ+q9X83WHoezaRAWnBd5Ot+SktemNQJ9UQR
0LvHXmptxAGjisC3ki8OHgK8COQhQUhZsCuq3V4pdQBkNlS2GvzX25HBD+1GvWAYfRyBcubJDPio
wn2vutHNTTtXJNtF5tqyAQ267H5cPUlKinr1g6ksRV4bJpYU0ENgOp4qJxicP1hCGtMZBiutguXM
rI5Vl2lN6Oqz7ATCmkk1isKeR1969D9Fso7So85FLyXo5dQEw4eeLPkphm0Jx0TOYCj3RJh8q5ly
ZvACKLnPxGfkuf/eJH/tuNSh4vxpw8AxxHY7wQt0E2UoJG+G/u0xxrR/0BpJo0TasvUfHUUPAqq4
rt01arU1UckKy5bdnO4+xRUYgc/RH282t+11/CtHwciSL3sEitc4+SU/2C3GfLo9HvZ4DlhZYf4l
vs49JeZ6GBqBdIORpxVUiXGO7oJIIIRR1RDxQTwsXVuU4x4nh01dq/EqDoj2tzmLrVKLO5PZGGEZ
RzfDPoF06UMpKdSYSv2KfHLswx/XTFYWeAjlZVQruovlWHOZY18NN3YdchrN94qwSX1tFbCMm0PH
1fdpM9ysWxjzAw1DEDHO85y6GkZu9LkcQkXYvSQqwlWLFY9Paqg4Z8BxsCtbYA06AsDR4EgTf3+H
itkoLUUkN0VSTqZNK9n6LvP9OwjfQl3w+osIQA2wsmf2k/ARI6xWHB/9lszNnImOjTlYvJ1xmErD
aXS+Jto8C/h+EJ3o97Cirz/v0fQyh+HcNgmaX7i8GPhNZ4mkwvuhcN93noqTXns/t9apv+FkJHNa
cb+To0TBOAvi25rb+LRjdLjcebiifFaBH3OwGAL8DsHUvcVkpt/QqzwPrLC4Ngqt47ueGsc89qtG
YkbZZqyOLCbS6oP+aZz98LjRaR5s6oSdeHr+gKKMjJQp5JGgaAaSs2YQ6crU0bKlwQNVMNvuHglX
1nqp9TMQJr6GjNjtSOIZ9Y+93s3ss2GGXr3W5CchVUZVI5HXVAT8v74SoRqMh1PPyCLOPXNhiUMy
wkMPgkq/78PS2aCgFWQHsbeKTmMElo95GNSpAUi/yEBBvzhUi/3sx0OLagE+X2c/Z0czTrnYlXFf
sJYQzb2Pzk1mo8ZT8VG/4DUmXYfdYkSo48TzEHBxL5bRuL+6ImfJYDEI3c4R+Ayu7Xkkk9LYL5hd
c+v4T+T0Qf8leey2KzyPJV/Cka4dCnnc6kEMVhxPyyAtUsoVqZu757okvT5lGJsMxf18HgsQd8U9
R1cehYJRtia9f08tM+kvUwjoROFaJ+ozZpqY8xhgdfEouWLsxy9SPxBt5DVoIlN9lD1FYg7y6DAs
mF5+n32oDHTbR/INKC5f17s4AvPZRzVKQ1CpIrrAcFGMEw4x+rKaywIRzGtGwSD6JzZJme9RocJw
bimr4cNCMISxs+mmS4AW0vSDydF8NL6NHEtfdF7xmvKx78n8qbQOtRQPiHgLalgziiWVymAGNnIg
foc0tFDDP4rv38s5LTn2SyrUgE9nEI7gCw/8g//lj/kr/sjq4wC6iE/CQPzIoKzl2oTlaYd2RlwV
kp22Fdj0ZuzNROuJvoJwRYwOGOqh8fYKhDli1I91h4iKTt/m4jQNptTQhG80C/B1/Ap5SzFlyEtM
X251e0KVC/43Ov6Fj6zgcHLTSYrHILPLuTkoCvyqGC5DnmBd4OoX9da9x054MF7e2iokQ36pcfFK
KGsKEQVUSC1pvLwLk07FBFJCYnRAtHL6qUnr2Jdx8k/uUW403Vz/qCwBCq/+Znutfn4v1fs3zTTe
Ttqr0iVEi0rDOIO5lq7ZLPK+QvA293NdRVg25oV7aPgtQhBQLrquL5l4qhqUItaZmSxASQAkKPNo
mrRKk4QladOXYihui4DWwJ0LuWq798n3TeHnReraD2oXoUjZSG2IVTcBTlRjvnNIRCFBy9bVSK9i
INclQbKmY2cN22fDQoo3qe09VgAzfzVY