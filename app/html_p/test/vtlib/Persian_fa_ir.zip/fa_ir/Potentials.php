<?php //ICB0 56:0 71:2553                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrxFO3JQWLd/bjCDzHUqXHPn4C937ld80vp8ZUEJ3sKWfZ8pqTpujF5gV/XHRTHXDcPBi1cV
DTSXJ7T06qvZfKV8S8aoRcbeUYFyDssHTmIZfmuwHcuscRSnP6hp0rrJqHNSIDKIP8Z/fwg8qqKs
EJse7CDTAtToNEb84/aREDHio5or5WCVgm70y1XINyVXazSYuKZH/F8HuDr4hlN6Mbzz3za1TXx9
0wYEHrcMyrT62pDcHcgEAYEjL1sGy9xEKPSC5ELt/17JMExM+9p82Kl1CCWzqIzB8kR+4CBD3qXU
b7xWQoknkl09akjUYW46IG+JRlz6ZJG89GS1RvQ8Oeme1OT6UMPb0hdP1cm7BbneJz8k8rDTLwzl
K6hXrXbNCKH6994PZPimzs70D0+QqIjyplfkSPWRUK6/V8kFXMfo3CXS3dLYIE2gfHNpN8OUT7Dh
kEAS86W8SKlirQPLROX2lNkXJGWVTN85it7R8O7MeP3rYK7MUuWhubaZApDeVoONrrgamhL9pCQK
X91X/Y9+al1pXK8v/IGYuc3pLXTzY/8dqVhTQiJmDg8rR+PaYTPP26Wpme7+13daf57QGmkD5xdj
v76Ene0TnjXTaD0YZg7CuhBpqDxsiGipeqpwc2jmgIoJ6ejFa/rz5SBRlHCaokvf/y9W9mVdRkKY
pMRjoPz2Mx6Qipyzt9nVdXM++rsnexwqtKk8BlWOZdCP3tJOv9MZC4xb2vrY0w4vleXkSR2Qak0R
1kEyJJqeFV0u3wULkc2nI5tUWPPkn/iooNC6wNwiM5blqrbpdwhwlBpUrVJl4kHmlIydztdr1KJM
c2HqJY6GJDfzHT0Rt5DO9Ykfg5xSQchF/Q/w1D2nizeujPLQPEqTAospq3+p77XARrp8X6v9zSo/
fJdKEZZ0Z1lc/4wxIJUZfmKv5yzwNK1kcbQhFLHVgcWnsdv5fMqmxu5UCvuWbbNhjxMso6yqyYHm
C7WJOvfLHY2n6PEk73ZhyIiF97+QdJLId1coB+/znTczssKKqHNUR+YwNZgaq7vvB9FxBoH4o7nC
CTNjQ3fioIUmdyjTpUbQOHlOrJxYTwHPO8MeLi9MOaln+1w9O5XIqLEOZ1uRXRAOwvUV0Xb+lFP2
z/fgmvsf04zNfKtcLKwPPlnFSmD7yLAelmZQgt4gL5c9yR0vr24h6OePHRKK/bw9ha074APRb6lQ
JBvNDPzM3n9IG+qtq81RS9wsytKAe2lnS+kFPrrHy+eEf/yLoFcZY2PePxD4qATQN6bg8vEP6Db/
EjP4UW4s2xodgekFz2q4q/Z76uRr7r2q58bCHh9Wx83KXWIdOoEU5hgh+UtiPb1xgDk2TkObBNjP
4E3ieRPD2W3sJOXfWkiVkbFKNrM09klRpqH1mLuF1tT973N2/0XErc2ZVaFoA1sF2Ss360CaHAah
Ur7J4ie6YKZSG4ujzVXFGDT8bKB236RSXoqsD6oEFHCGjrfRKmSm3z/aQLWp/oMoT9LdXqbvvJiJ
n/RkA63/6MAD/5Y3Mr/mplCW90j5I993Q60gYWMRWLh2haca1541E1EgqdUXjJLJT9t6NrRbuGcj
4JSh4h2SyYMpjZ5aeJqXcLE+T5+blI5hPU7HxVQf9pcngvSlqaqkdX9L5NRBB5eAiAJluiLP6aIr
mhNiH8AxrK4uDf09Ua5Zb4KD3it2tRdK0zkRwz5//seBT3VOPkXJACpcTjYdU3gNDVuoy3NIFd+8
EHAI1khV0h06iGFK5arscKm5UmMGQt7NbPKsni2x87+I0nQAd5dq4cJkOSX4hi8mvqAXfA0fmn2z
ttGggbZ/1+xt7sSYCo/ajgRtljWfsYXkwDo9QB6Lfat+n2rSNtsIOw9E/T1xCgc5tnvLrg3T26TU
oG7/MIP5F/CwSSpJ2CI92ffSC3hfJdRMR9OhS95x6pTiBy2whzAVHIsC36kRuxCgdJinHxzKApih
1nra6cLdycH8wvhb9CwXs/AvgX8h17SQlSF16Cmv6TSG1qOTZ3+kTEIxQMWowEtCxUBvGJEUw1Y2
Z0ekwRnEij56u2HTLQSQTX76d3iDIsxBPz0xdglpvwP2nNo+AA+fAr1J+k6qzKLnwugb83WLc/Is
7kurSz52ZmOmeiwnI9j+ZG+Ue3WBU0waZc8xZI+0Y7+cjnw6r7eFlik0LM64qzUH9fDn+83l39Ti
BIgcDXFTXixCG5UvWwv0N5ySJf55fJOMsVtjKqZE35FgV56mvzczpE5PelPTZyxDSanCW2owzmcR
CPBHbgSsj5bbdBO2ptnFQsCPaBnW5uc0poaDLrrpI3UKjpghNWk0gep1w+LVzNWorVDVS5K28uv0
nnYLyod1BGdMyAxUDC64CyNnDKnhl4cB6ihknDyJMGryOlis1BbvC/NzwRjzLb56niu1xl3yuss4
xwGFIOpIFz2PjiMdYmADJ6iGzwHJg5I69z6qrx4F98tRsd6Z6CL6xPkSGRzHhTK5dlsfqqkfqt/b
c0mvKSeG2B67hf/AAQx5ldq2w2O8REhusKLI0S4JWWkcaP4vzdq/DoyRD8JS+eYulRPxNQXdrwjC
XqezKC5Lb28fFOJmi8fRPoeMWsNRPXSSzC5Y4IDzKVTjN4VVT8+tdh0109W3hsGdkhRZ/OI2AqKY
gT9xBIIcmHag3loR5mFpl2t6iiaFndZQBChOgIeXMUhe8McEsZ+ewxzTISwnbEGxQ5amtTtKrsV0
0PbUNsrx2GV5bViprysimPgxwLZ8D/bORmA9mX1YUj2rq0x+NiOKcPCOvq9zDhvU/xrEBSHp6RCm
0KHjqtpQVXSY6vBYpfuPKjK+J4y72XF9oMvhwu69IhU9WVbad+6n9sYi2ZgC7NXljWEF+bycAAi3
dNM4AhpFQ9j5DwBuYqNNydEEszfH9T23cmfHYzyYeqqERGJXpJMWOurznkp5EastCxrjNG8Dythz
XxKY/C4UfMGDfiZqg3xaCfu6ay0nEqj+X1UwgCGn/wn24hURS+W+p33LIwbR9AZpLUvA7efCYUUq
a/9I9nsJIdoF5SClA7gJiLRREDLBquGZuUYQUWim/1ppa6iXxLxrbF2Ycbt/HvSqLj+xMSDSWMtw
WSEmQsVbGV9rBqVd9WXCgt2bEycX0gIOjE3TIphN/udapoZWJ+LAnGDU/Mww+3hMRLHJP/tKpq1H
z9hPGqPpSpf4pgcRtJVq2JqVnU6jA5Z4TQhYHH864yitPqixWpiMKelTjpixvQlHX0xclQbeNXC4
R6dAOzLN4iMVDn34bK0fiCtaJnqdfyJN8IaiPt7SYuKutDD6W/JKCpG5y+1qrEAmKPA1WdJzKqTy
avuSPtBXv0UclSKjB7/cDy7fyUsmKxeLpXRaEyUR3/7nsEsa6iVyV817heSkWQIHjeSBR1xTKkvk
NpB9/l4gMsFUirOeiYVwO/yfwmsvFcDgTgz9OSWQGtFl1d2W7R7pYiutMSaEGQLvaqGAIdq7LBgc
j9XBp0CHnpGzi/10Rb9jxf/WZ27idMSQEJAQb+P4EBvHgPJud3M2CeBrFSYBuyS9ZLS2kaokbbo7
J6ERV7MuE6B42MInoLkd0Rsly7xkvyhnK16fTYtc/h/3sH9KDDWl4f316lQtR8w73y3mZTzmMhtx
Xipf4QxekKi3Sx57DPtK89wcW1MXf2/3NAmVhudxu6dUBjxGRN56NS5eSINDB+rKRopv7xs/47of
6U94NvAb9OxBSjsN/hkf/pbOo19XPc9bLSbHwc/CiScO5VvEhd2yJCcWbOWC8/H/1cSfLPfc+e8Q
hZGQLgvBUR7K6jli65I5UtKr2awlSEnoZAaUsz128OuI4iXbZgqUkoPHK0l9XB1mpGH1IZuuf2Md
xz5hyUjMhi/aNo/DLf5/a6JPqEjpc9oknEiFHLRTlvW3EddgHUT8bNEzFi7nAOknDsPvsfsuaXVk
jePIJqlteZsJuXmuPyxa8Nd1CgzEzOmMzplrRFGeVkWo+RGcduflcRzMlSst9Ya39qB1qsflr+kc
VdF1mVXjveS5rcmqMXNLS9hOxW9xT0+17t55c1eJ54psgqz76EtQ6YrVfmpk3g2ZWn5odQjS8pBp
eatE6sfkOVhvPyCcP3Epk0g7QmN/bK7hDKW6OOrgC+gmGLXjgkb+rlLkNWZWYeXKtGrSLrunsSIn
WJF5HyG7KdXdrzD/Zx4EYdpdqk4FOtuP7HlmjtkMvEsX4PPz9GLb1GxHGqQhRI7398AtCs7fbeRO
J+I9N5BkCHhXQoArAkux7enfWaYOhgVANBrz6e28YaPODSyevutxBbNRmEz+RRJJ10Ntt4xjlG4d
7mSh9vJk8wKI/+QwaIHaRKANHdyrenEpvGVYJ4Ul9T5BOTKTbHSclcLh2Dd1Df57KZAWJBXQolgY
b2SEwauDr8Z9z7itW0d6Aknr85BgHKGVKFWVcPypRklO7JGG2MWETrHSIC5Kx7reB/zRlLk1ryZj
tZGv4qGz7Kg83K5wfMH4OmUCu2c0EeXFk4VaYaV7I8jgoPWIlYpBDpU41nHP4spIU/yEXG2zKX8P
pXEZm9Zfca+xmJAsl9UdzEXkHWkh7+L0lgskNtymTkpK3mFuO/hhmC7B3doUK8v47GS4X/1FTf6T
JGUD4ffWvUHwjzWnvmQ0pKEbMJ3AaRpE9CvLhwRyjqw22R6i1KDla9Vz+BESoCIzNxrVrJuESYJ8
973GZW7KtYOw8fwAaW7k7zY477D35Ue/JxDT+y74dg96tvpFeaINVUUcor3FWdCP1zK308RlUoeh
Mt8K6WV2dd4vZgvE/IB42b6S7N5hYAFd7Re4hs8c5nL1IYHf628d6OKIMIShD4M7y5u3+9KS/nZ8
25i7ArapKWyhlsT+vmWeQ3LZk/QPUcJgtsQDi2lKnu+sw2bcVJw3sPdZNvO68OW2ymFzLGrKAgAR
TrgdaD8bSwFdaTEm47aMoN53MEDDWScuZrMbLWhe0pB083Y3clvgwHI4B/EB3cPmw0btRtoweEYi
6xKndzHRl+OjrywxHdpXzp5HzXO9jdQDraEGglOfxPbO/q0Ho/bkY1XOoUXwzZrS2QgLGmmooMqm
9ntweCRm6A3zfH4/GOUGqrb6se3rcwhsqoykTYjgcNNGmQe3W49hibhVPWLZi8QjBWK0BdjHBqOI
qlrEdt0TujxzgX690BuganRuXazI3AmE9iAzuLwBzzjB69BCUqM5usa3ZvwUcLiiNEZllO9PLyNB
sEYN22BWTbsuMsgy+ASroP94syS28v5HEnZXqlCN8B/+7rzQkS6tMt5k8fSXdp6MbwERqJgPlKMR
n1CAzh92gm3q8jKKzDYwMfu9JjbiaJOQAJLWTIpvh5G4xqNhs2TuGZNySkAYx8DeTzGI2mTpnLax
td1BAM4urAVzRS297XOeCLDokWQokUs+FXNCAjhbpBWxOxA/MMMlPoc9X9gRO6zCuP9cZWPWEaLz
hIB6E5G63EqlfEikp7w7aC0ihd45Qq6I33ebBoxC8U8w7U/G5OYH9q6QsrE9MnGR2fHO0bWCzt+m
KKkq9CyTDOrB6ORMla4CBmfxsZhQwKyl3R9JnyXAYvmFXjpHb+Xisq1VkpGi31pRhPKiwaRhxDyZ
qi2svTqX8uKIDhhlU0VARTHW7ldY7MegAA/0H0iurnEvJ/j+4vtkkiMwZjOLAgB9FQoTsZj3itdC
zAkjbSWeTbluoNrU/P0Hhcz2c24IMYBE8riZZZ8JBssLYAy3XConirELgaU0erLEs2qOumObBqRs
mHjmBx8GIzsJo2ERcQuxN0T1u9NNpPKmLkfRxq2DX+YZJreREZAA46PZtlPhNFjnWLyGaYVNR9W7
QWFE/QI5iuM9HRa0E3aozrM3Ru/mVP8h2tUMwahYDxnbsNee6MRCUDC5jtFjgK3BXZ8fPRCfqyyA
NI7K6sCAvG7C0BLhW3fqnWcQJz/9AIXh3O1yW2kzUC3tVOy2+EpB6dJJHTMl9xRyQWwCtGhlLhFy
TkpmoUIZQ8gmLYO7cjCPjB+OvfHW9s8LaWZNJLp/wCqbH3LMTv+gOEXWTR8QpPirVJ+azOHREuBn
lyd3EhtgR28T8/vm5spCNxkqa3SCntlZ5g+io/e5tAw5S/WHWq1NzlH+bfp6b+ijGFXqdq94m08b
WVQ+p+gA1zGcXaPX2714r81P0ACPfP4W5Y3dzD7j6Saslt8SZz4q+lcHh4N/1L6pIK8ZNRtUXuU6
F+iYS0L6yk6+EzMAXl2nhgM94JSlK7HSIgl53ab8LfDYmQgyHRGtRhKc4HhWV6oNa23sBa7YbCnF
juotUBLo/OiYYDbVjTvbtkiIcKk52GxJ5GJM2kXr9Ti+L7xZlYyx26LAtxmO5SjiYhN+tsjee6v3
HVeMSdon0xvRqqP//kYOMlx/DwbEI+o+zQLl4O6LLOOivNpHBIuUjVn65RADI9eLTaRX4noINgaZ
S5N0/hTSQb2dXAuNHyxX6lYeWcglp7PdUymssK3tvHAnT3TOcHmMt88G4FqwsUkNgcLqQA1oTrSl
J9LDVDzqVcjh9CC3k1TEP/y1KR1d5Hz9Foh7LuQ2cD/XoOrVRHiiQ2Lwo5pumf+OiVPE3XVukZd8
DNO/QK6hwPUej1KLG9b0Wiwr4VfiFsA5eijOHHCfCikFmqYNNwJLm3LK/Y5LrUY8wjvlVKziGH4e
gYE8UfucSH3+Nd2dGfDC49x3DLehTSCtJR8HSSy5rlJa7JRrSjwRFn0ZUbzTrXyIxIC4M+pSHnFh
Nz7V3A5r6zY5WitEwS5BLIG9r/i8mb6Tnyih3+voBcYq0Qasqgf+AM6cCRSVa2BhX+qujrSAYP07
HqRxi+BRBz8QtaIEynTkv3OCoAcbRj9VMRjEpD20RNtKkAPgsxW/Pr2OiRXJ1rYCu4/jP9EmXu2r
30===
HR+cPvGTQHvb+55I0ARyFTd2W5o2CAZhZeO2SSq7mCIa0CEewFeezx9fwbwL3rX3VCRnpIASS+bJ
3eCKqp4nT1pKazbq6lHFVojvsf2WTkU8Yka8ODbpPDlRk+4GKiFR2MfBUXHXxmS8XZa/nPG9NFKu
j/INADqv/7150xyT62ABXl9Ry08AQyhAJqBIYBBLY4JTdkKFSltoSZUzmxhgkSRkA1i/DWej0rA2
ukGJpbb7KzoW/+pGpPYVgdTf2qHhtFqdRAEMBsthjOHVKUJM3hV01iw5BYipKCm2egMO2vk9KpMR
CkiGkUDqRtHvdkfr6nNMzpIpXfqGPZR/dUQruQPNbAREMQUPHT2NeuL9XTK5swtMv34LodJKPXxK
+VqhZz8/zPAhGmY9NGFgiyRWZUADqx7J1f3eznm/jzwmpg/1DIyYjBasuCW4aDewwK0SxbKokhdp
9YlGmjSUy31GKUIPv6uHunG9ng8+7xiHIPKTNN7TItyQOoMKMzJ75OYd6Ap9G5r5ac+7TxRsIGMO
pFFXzGPcbFCP6WBktvV1kDpO9QX1rr0R8MCSjDFDYvK0iDlSC6pIbjf/dyHwb3FP++lt5CY5l4SB
H4ggIK1Ov941IaxZWWZ0rg8bOVzmL73sv6L58EgQb0kkYAHO3nINK9POpDh/JH47x4qPQlzXiE2E
0675LfdJ0Et67zBB57f85PDxnmKlUGVpoDR7+F2d1z1dh5qplv3Z9YME/b5s47MD1XeFoL93ItTa
+nYnbzo7ikCW9o152FBD8ubES14w4C2G0bNLOB2kgeHrbpC1zPTsOCy+Pmp4XFCkmCej4B55l/zP
oyFwbwFriDznYQqs4bsq2BUizRFRXBLaz9Ymk1TJgeiqxM2FDwX+w1h/1VrEl5mnVOYbpY70O75k
Ke5pWGvfdM0RMMXgFLFZdkVL5j4WM+4VEbWuQTSMxD947e3+QQDcSeWTYJcPomR5QwaNvoybOsPn
Gj+MxVVdV8wLWkmbChQgYURvrm+4/mjW/oDvG1ZUAelLcepI52gM+UnImslzyij688bN4Wqon7P8
60qijzK2rsPxwleu8V0se3fIaQACFwlo7CNXcwGgWTuDrvcFz/EaByadLOWLbXvhMyxkHrqKRMxZ
yfbguXf/+rA3WG4iXQkjMVqBn7PGAtKrSiohvBZBWp/Id3HPLFP57iCxtVZt0NVw2XsvwqS5ZTFE
Meu34ArJ2paa1XDPW01dtCAaXbPiz77SrRP5mBx8w9AwIuta77wzyQOfYzsq5vn/2vW3RNc5Oo+e
J6prAwfsErs6wfndFMnuyg8HguT2XJCnuZkAateXe05nb4QLEZwOKpLz1VJfT6FmjchCA7R/sHL5
ykEN3cuJPjonvkKrvuO1J0sReLGlClBxDZIBB8CV6WEfunx1VkFr1o3AfDqkTtdkabBa4UI7/MLi
TOZTt1H8HF7bmeNsQmAMWHH8sUnuJ8ge8pYdas8WNu7ckSir+PEi97tE7jjrjTPUQFe5m6991yal
85E9yddxhr4ZXqUIh5KwLzIH1EKZtFi+1b/zHqdvX3zdq7qT3UJJB8H2bVol2d8vlcqR7mPKGCoX
zMF6zylDazlpB2eNRuKRCgipvpF2kROLldIgPnWT8aIAEqCSvQS+7tpmTMptKXGabU/1l6N4k0Tc
3Rtr2kVdIzPWhuNmk0hRRPYqEQM6x7blM/isfR+OvI+IFOz9yqfiBACvrMhb2Mt7eUu7rizBz+F0
hWSgrHG1QEoyxjHR7fgtfJ0La3Ttw2BElJvlpcOOtZuBo0ax/ud6juvDoMvknY1qCjO73mOUOI4z
M770y7uNnJupYSJrcvlmr8bn+95d4H630SDrb/TO5P2sXHQlbVFGdvOO9DtquN7iXgz45+8kExG2
NF4mO9t7vxKcnCyenO90gIrsrl0J5TC5cFYqVaDDFaVKt1/yR9zyBpvjQoM+G/9tZIHZpIcMXs2F
6F+l6fw3Z9qhcyYoQNtsFR6Cy39nPXSVWxXxLOts0GHtCUYw9oV0YJeumoXn92cmhfkr0WCCcdKe
syADfexSzXb3CVhHp11I9nJ62ffELifATJxoVhkmfGUyahK/MpShtVapDNIdu33OirXpaJ8qZI+E
yTvNVo2lwh8ZriHi2ID7IFNULn8G5I7efuTQ6AAzTByxrKc3w83msty1Mj++N4zBSyNomkjHX95H
oFj85loMfmrDDHpJEj4Yf8B63B2eoAIUh93Lk+Wp3FZKmJGQjgNy9wC5iLErHXrVb5QNTFmkyCqR
bPtb8ZbRNQN4TeXvTOb76O3Qn17n6nGQjI7q4fhPHhEqbfLHISRUKX5vxZk+TX/vqOW7HoEUv7HT
eG8om7zIXS05/IMJoQL+P3iPoKNvzDgjZtXJGGnKb3uS0tqc+0P++8a43qHchf8apFoZuqvVi2RP
cg46tB/46Cxo