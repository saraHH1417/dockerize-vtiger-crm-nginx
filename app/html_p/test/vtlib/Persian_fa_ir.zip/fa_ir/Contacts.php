<?php //ICB0 56:0 71:2251                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoTzVo3AqKC8uxtg0tXNc4d+J8EkMpSl1CidGcPQGKiH7wxkv+a5E3Q2jxmbzdvSb2S3gL+L
BOkQAvQWdYQ0kJ6bew0vMT4hdHH7PuGmEcabGFkUoY9ZyUgxQBjMv5l9KPmtQcwmkVgf2fm6vpif
ry67st7beKGFVAqDplhyM3f3mGthQeaRE58gdNu9g18UobQEpxapBY3nOfFO8mpSz2rmYK++JYUH
Ro++wmIHD4g46+O7MTlTuOuFmaqlHb8h6AAocblzJp4HcWf8bdueHqfXu0l8FT4lIoBc/X32pGz8
NfH+M6XvpdGRSBFbi1Yj1gbuaZ7/Qe9zgvoxFL6qhSlvatUuhiBlhsfQD4vf7+lNUQJfO9nA6o3b
MJunOK9ujpj8roKU5DkZVVPHTVg0xnaffA2Y5RfDTqLi2eLbokr8X455tTYaCnhvGNYFAXieaOiu
J8kw8Ru1nGmS7uh3zPfA+DMK9xM35euouW0c6+qYnYOonp6kf2ESt8KzNJrqJCjyeXwM/vs6McCd
r3d6VHMZk1/a3eBNd8btlwI+JAS1EKirAO1hAKNCki9k2lp6fcvNBizKxQQO0qXkNDYvvjMeDVD1
nuo7y6XiAWWZJAxRmFClGgEw2dtfcF9/LXQc8NKdElfNAjEp4n6uo1s6wptbPvX9VPdtar3e6eiD
wqDfKSxqX4iU1JFjNeq+afAjHqnIesNNMB+49bs7mGubmorw0S4JwqY6+yDozE4DzOTsVTOfC4Tn
MALnSaOS0rZqYYaxLytbdEkCyyg1QnVTkiTGkw4cpIjx6pbMZTgW/quWNOJ4K0GOIMOctS7do0Rb
bg1xV5utXs784WgVIqztKgKpWTQfozwszLIL/qeWYJcTR0vbV6crmoVxewuE+HjxJcixPefH8JKs
iPry5UmvAPH9QjS6D/6VjGYDi1LusSgi0V69qAi+dJ+tyMG82I8txu1oHNqkivc7JaVha/0Xqhab
AJ7miWNAqu+0xQr/NfIHUSmqHJGKaryS/oidgIQW9Q1yZ0i0ogTRQ3EOwfZZxgPubY+1OoTwuV3G
T0/D5hpqJeNgiDNPWHl3IYNPU8kckuNANC7y5gVyxTC/CfjRd2Rg/G4vMJKkQ/ajuqEACA6Nf2C0
OJJ17FcfHYeNhqKB8cUxZHvY9Qe/ur9kEMonFJ+n9hfXSEnXogTSS+4fDRpgM8tGy+Ltxvoz4lH0
iUTk/9bxAHcsmj6M0Kcvy2cWPulqwK52PhdNEr5hqgwixGDo+6AICOYPT2z0y+qC9x2R0GU19weM
bRWVJoOSqb/Ns3FVurIGElJ5qUg9pgWwcZ3BEMSpZuPX9OvcHiqXnvuof/SVcbC5FgORu0R/aJ9y
mHd/jDVOKqVL9AQRQGG8jEZq/7uhM+IuX8Z979BASqMYy1hwQtfM+tXNSpNqBEAp9Co32iLiNKo5
ZvW2WifvdvVVxxSqkT93hvO9gPROdg+2jtMEpC1gRG+xy59ycd7U3YmjtEkuiYeHEM6Vzgxsp/Hy
QLLCZbntd8Tuide8XyCYV4wPwiwmlYG6USBfTVchZp25AZOg58M9URIJBbeWQdjuVVxEfYKfx6mE
nt08DF7Yk+cxGtCO/aCSEiRJWeDFN8iZms/i6GhNLxdFh3D+NGBPXh2FjTx/wWv7pM0518ZHzTr9
I7XQ25HjI4w8UXYLDbfxft8kbyU/aTzjHHBdHjqfBoGu1r4CcWdHalCcobo5t01w+1UQeR0pX7l1
xGsJ2QH/8diSYKqMmqdOUSLv36nGLpetpB+rPtqMM25ofbBRTfRyV888nOM50hlZOqDLyZP2SP8c
K1e7Mc36gPgO58Q5SZHlecFKxel8HVgMghuCK7L6wvn4rJRldaPW220EowIfqHgThhE0JUj3YuA0
gHigc+WqjzPKIu4u8jsj0ctTQCGvgWXl6o0ueDrKP2/mE6ARNp6Kak640chJcymuHYZ0KPQ5sFc2
O/T9ArdmeX0Cxt0QDQnG9KQufpCsxfz/my5+m7dh5VqwaebvAylQI7LJnmxKMjWPE2FF2SP+eWX/
pkU2WyL5vaBdyB10sxxlBbBCIaRcGzKUa5qYtSd1LW+2JdHyY87g3HsoI3TCHOiHZ3sVrd6ye4O/
kR+ji293W7/Q/C3jIvE7NlTglseFv53Awvn9nttpidoqw5XyETxWP+X36dFMvrjlQQPgg/9MkJqJ
1QIsvOx25gY1RWj2gn4EDUGHhoyokCUGMogLEeQnG5FQ/9qUmE2coyDS/bkiD0F9A9b36Mi1dMiu
uFih1k5wsyrLFj7LuDi26QHIe5nS2k32/4udJAuKxGSzYjQY5K3FCiXkc5O1V+/F/TRrn9DX3yQd
JsJG7H2UR5iwXNfp6E6GWTv7u1RGg5IKGUXf3lnFBebE9bYXnMd/ux4svlzJ3N3V74iITgFDMoqN
EHo2AVIbNu51SrYrIO5nkO1FebGoZq+pxgL0XDKvmvDGYZ0ddT91641rxlh9uulmAG32lKhH10mH
StLW5CknF/AtTLO6eZ6eo6cqXn2N2kovJMHLaG0kW6weOzE74XcHJ55JjzKM9xmblplVXf3wfGzR
pR0fsR5WEJB5K2966koH/D4UnYF8nefoGYQu1XDiK/rhpMHCuvHI0Hi0VN/LdYA9tsH+T1s1DHLa
lbRmzVVNHc7Bvm7jvsON4tmFN2j/BocDumZzowiD+GZD669e9IxcAKqlxkfvGWXqA/ZjSossNZtn
ZxRrZrJxYdqEDCKYF/G+XPjY78To0C8JFSWgHRnlQWZbSS2PDC7U24qoYJdihlNPHhUTpCUEI9hA
dHmKVDD0AelMyPDCYn2wUbD7rssJ8dQ7H2gxI2iQLUzRTw0jPMdrYlk5ujpQXdrDKkIfy7mer0kv
pL7lRdWIPf3icp3UsXaf7aYijWVM8qwkjPVzyyebvgRFkhAffvL/plzoBtye8ngCJwlZ1X4Xr3IF
2wM3dt5bDPOvPHwMLFn0qCTNW/L1c6ttgL9ku1P8cL+2DILEmPGx4JOWLBsDh7F1ObyVXoJWvB91
HOB+35/70lVgNkNPdSJgsBLiftjlxaRjFwkw06Wj+PsAohJiUqAHPYO28ES/XYw3fCq1Hy8jCvLb
X50JPD8hJFTI+V67mippcEQGaiNtsQp3PcDSPTBFMK7pJMK4mtAXRGRg4dblj70fW661e5JljEFg
7rAyMDztWp/9DNBWndWW0o7RZhpDxClAnmzUhKLbahipWuHGgTXBcTikHOrynceJ+X2Tx50pgO1M
8QFcq3hhBcyHd/fxU4X+Oh0lpyeUvqw6QYUVYgtL2AGUoQmbyKBRvbBksv3Z0If00OF73ZOg9e1k
ag+lYSBvNoC3iRIUo46lnsPwxUQRN/liz24U1J+ocgfAHmNgCRC+y7Ce+DaHj33mZcVXYNNw+T5a
gr1U8MOvDIkWYrUVjoTPFSis9nps2VQM8aUGbxYyXQH9RlB1vkYvovzOjeas/Uh2EQlL+iILE/mz
0HyBb5mQsXCJ15F5duYWC/vKtaCwCH99s6yj/49heWKYl1eIrZN0tiPCrUuv+SaK6FE+kjVT/eLc
r4eGqT3hH3Wecn7q7MWs+F7gVXvD+m6QY7N6h+Bw05P9xCD0LxwieVAcmqeAyPF3PqvkoGxXvNwp
SlM9giKRPUjNvtA5DnLZQ9IQA4vCAn9lxQvX1IGRayGRn1n/zDJtr+huOlzT/adOT8QHR4UWdhc2
dvHe1mdRfoVd8lUmEQZuy93zeQRoa3EVqy93VwQL9qNpH1IbXs3cd8eY2C/sPBlh417sOWNkrU/n
8O8pUjQiA2FW1tARiYDM/SDlKztJQEcMrKhVIUqtMIHR7VRuQO6N46ntQk/PagmYLzIUmvPARkq7
0HqxjPuRw+ntCZRRBXTsv3aT7NCPUr5rZT4qRvNJicyaulAUBG5Qm0KivJl080zuPwzvJDDD+S48
l+WztqrItrSXyiCgvK/nhUuTvq8GUkSINR8j5+blrzsXVsjVizzTLfH6vwxkzmTe8XRmNxHp88YI
gCpS5ziJTS342UVrxASuSOSqObZIkrILSzjZkAADBrqhv3v3uJDcJ2gHC/ZN5Lt2cc1e3HbM7Avx
rozzBoJTjEs8WWmKuBDnT8fd1e7N33+ErfF6ptcAWX4qMscTYpd2wvaVYKvyEqxnvPWgM77gc0Gq
9mka7vY27fikg6KXP2praWVBhVtQ64j4j+MFgj7sR/1/yX01LZvR2l8TdUTNTeGldWEbnyFyEjxI
rAXsBxky3iKP7HAK5NDg+cZ4ZTOE5UjMDNd1Ze1pwVimPZQGxG82nSHV6hVudJigDC+RnouH3yyM
lsT5hUnm79qjlrPEWj/vJy20zYzh0R4ea0UOjhO5bdGKhbuUkN1n3t/K3Q7IM9xORKGtoivmXYZv
OKRnQXUXnPEXHpYyi715GkHMACnHNCsN/mK3HxQ5Q/+AVqOj/sCIVG9ns/JOq+xMBvbxPa2iCRDQ
DUgi4Y0r2JuZ5p6f5ATtnyDkWGTYeoPzW79QFOdnf+FYtfjd6BaS77qDxePNk7NS/zSx4ZQUWMQO
Ofw6lkokQ48b6FJHQQOeb2AKVaNIczVUmQh2bkiP0QXTP0qBTgYkv5hc67j7TMkhsRi1i2RbRAt7
qM2QRKw17U0EJWxbmHPqOPkyKhwiSslCs6oK1EbDbvmmOHUQShEDQpdCgG+pprPRYtlw7XohQAWk
lf9tsJ1Pm2hyZP7PDbK/doUVRKhUDwUGoUZjwfRoKG8VS2UfQSGnMGwdLK7Bf31y2mm5rlPHuMQX
mDeZKtUOo84l0s/xUlmsgjTv5lyzmKJvgJ5XyfFFiDSUzMUsXQpM5Atb7lzFhIf/HJAN2BwTw3a7
PmLsFre/Ny4ieIMq/XyNplfXgeqivdvuSNix/TaHQTh2zUnXZLTRD1r8vy2MgFQVRIQCf1hlpz3U
rYYbYePt0NIPdjZwrmsfprPPtYLpt7jVIkOTA6GZYjUTZoBM/roGWACihfdT2vWlxHM+MB9gwbc9
l7mTnw5HU411OGAiUqkXgiXvv6dsQRw5EawyGe0Z/sjSmUNf9E5Ev2iSOHQDIReKRQXznhhtohG+
mdO0dOQHhlJC6Gyq06k9shbYmBeT46RloIiUrF2LJUkyEs2YpyqGevXHjTxQT8P0HFdHlvLpVTsV
F/SJY6SQ5AE4ouLMCimgKwbg4j+68VjSVZlsTQFMQYflOmDfPnQKN5ZluNkPbKI+7ai1Mqc7kEOg
ABOkAW0JmNF9P5GHA325OC/u9G4gquwEQLLtyMZ9SY/N+0nkomzB78mNYkDGgy+u/W16UdgFxjlU
Wd4N31sCTEpA9YGpoWljZVGlBPSCuzmILhLtbA8GoxQA/zCOiZcijtxQKZLAp6eQuesCTNCpFWWp
B2jowKbThKR2YTSxuzACV5FnPO5I/JhyJ3h9duWWnoiFERBHPlfR/a2YCxXz+9+F5LLJ14Fs2oP7
8GLwucRsfChcU05gu2llNAXktWSz8hlL6/NmirkE7L7JMnH3mPlg0gcbY51Gesm+225t9A2soiWY
MMc4KjI7w2jYeVCVL/v1eeOTXFurtVh0IyiHdfh4zTkLtXPe1R1ZU0dDAhU6ynEdzbwkB5oC/2Pv
RqGNg5KIkvkZ4h7CZMmCBxxEk5BDO2WlVLx2ZjJadRsqBh+BeNKQ17VFJNil1Y/tx0t7hmrKG5XU
aQJ/UXi2alznxNkfMDvGrvl+SSFgad822EzjihJ0nZ1ebcJK6LB8qxLhsrHfBwT5JGkjqu5Y4q27
6wfcq50LweRCKKQO5D6q3csVQtIs0BAoiqpXhamMRuK8q/nOu5VI6XjpmtjzxYUUD5bn2JkN4Tgb
VbiKWNeNL/cBrvsd7zU79qahCiQfuXdsUyUww4D33AoHPPOQMd4pnZHJ1tg5ln8SGWeswTxeCYhI
WW/JaleL6ZeFiI76ptxLeLB9kicrX79J+ICDZIT5q89OztvVB4+WpMLvCa/prn5sAUVPiU3fLV/u
cvfoGZlMkSPTfiYVc3vVAhCJedQ7p4VlRalQfJkp76f/W+gAtwsGPmsAcFlCniPPXEh6+U9+G7YF
RyAYo6wXGVQRJ4sjCjMHxvSJekVXxJe+31mzFjojBwkCRVEB/cauzmQxTbZ+yyIDv5OD2tMaf0E5
CLy==
HR+cPsvTjbT6lWgOR+GZT2L7t48lBaQLDIxeAS5RAsepvTLQ1fusbGl7Pa8arPsMDq/04dOYpmcZ
8LGfX74cEQpcaogzif9LDxrN1fm5Sefmex2xMuI6LzgcowpqNyE/5Njkm8e86EZbx0HDJaCo8QM2
3OmIvcbO9zjTGvD5Hi2UY1Vl0OkJ44E7KMo5yK4PdjwmzeLKhJcqSEgrVU3NRz5M/UFsk6bd7obO
lVJraxjL5AkntpkSAKtFmr6nKM3Gw9RNgpWJYmF3yul/LQkvCci8MG8gTPPG/GAYfQKBcubJDPio
wn2vutJgRUfJqg3zQqbF3hc67RjUJ3W/KJ2ku5FWIzSKOZdB3jVdYB21CZ2WmbGm5M+qvLiKqXdg
eLDVE9WtNhGOVeTuu31MdZkr0r9178msLCPk9SjzQJPKLO45aus003r16oC6fF7jC6HICovTYDZv
VXqdNoKHYGEUegXSdkmVf/KDIowfmRwl1XLrOjpf6tyMCoSKfMzN1GPpwYFFSsgwBIMF+vMAcUJa
zizdrbXN88Ze8GFAzotcPpLYTjCGz8qG9+GjpKBxqo8c2wAyUNAJaL1ye4lcbZsvccXILZz6xije
EGKs+rHjiWQIVIs23CD1HJav9mjnig3EkxW9L84pFUwft6c0YIKA5StnfWv5XctGmvaRBm5qOh0/
pCL1GmgId1MctXKAFREZ9E3xEs0toHNuyfUzIPqXhnynRv9DYA8C1vH188o2gUVcxScGMQqL6edD
8I8ibRRIBlQH1gArsnazxmVpmMeuqOcbUcX1g32WxUjiG0F2PEY+b2frbG1oX374+7OG2hPs5JPO
33ySkEuWSWLXrirMSJiasKBxp7HviqcwrAa19F4YD66R8R0tbHAYRV6ehMHIzXMxLhcU342cn3Sl
DjMVg/MfYf3sgEbEj9FmJaoff2RMm+fYULLptJwvfyIHo4MX7vOrmXodn3vieUjrTAFxm2KMlRee
uYnnzNy/VpGddy0zndRwh2llnw1fbT8l1kUIg8dban7/8+BG+aLUnxmCfK9xtL892nIY3eJBY5Fc
+r83YBg/MY3YVK2kYvk82psLNLogbX7EKd7kiu/DjeD/qbFv8817zjZkaPgt0G9Vpq1C8bY3TlTE
5Qqevi+sUE+vT0EPQC8J/yqZZJjn2hb4yoMQQ+Raj71mFtpyJLT3i9I8mFvyt6MG94QrA5q88Q4C
OslBkeUI30rQ999OSXyl42Zzl6pkC6UjSntkYKvGXyiBq/Y54KTAjnRRJSdHNz4LhIKdqpENHsa/
u3Omdf3XRzkResd+q290bPoPeVCANLMpQVTfLUT/Ktq1EclcplrheBfUt8wvlMpwXk5o0vPSxUIL
DqOgC10CfU2eejGG1P66mv+ca98Ya6P/Him+m7RCZoY3GuyAMxN/VswdChsQuaqLlP8YkVkHQ17s
5025OMFu9EovAdbgXqdb1x5euMgdZj89jMuFLOcbKz0FkdLxu2YV6raiE33glBCwaUwdyUVO3xNj
vIJcGOIz+P3ht9aTH1zev6c+9LmrvAhAmUhMQOkPDsiuyEVk6tKv+rIDm+qNNLVRhF8ZgR4P5+3n
DBhflhX6QEr02YMiZt5iNDCOy6cSG+VPJpLQymBRgA+B7tr1yyD+VqkejQyDojkBQBQeM4Z0ewxU
353BGsRmgIHA///zC6aPAahHjwlipWBowgYSnS8B15Z0BuCnCM6cdYZxXIH3fQ4BSxYCm5DtUh1T
4ZysPFOZ5xGRZ9p2uR/jJpFnkJ1uFXr2/DyeE2RP4Z0a8GfXp+ujyRQ/oSIx8tMzSgTPM4Jj8i4Q
9lwHUwMjrKWmIuNcpKtLKWkqvnRfSHJ11aZrwMEwJeUW1ueVf2ju7NOt9BiTJJ7EJD5WWWl7C9ml
l8Sp0DQqAPW9NOqI2Hooa42tWcdkx3a+E3PDYNJn3C8oWspbsuhAMxfhKsKd