<?php //ICB0 56:0 71:2bec                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwgMANWgHP9/GqcyMzydribv39tFPVLBgSTSFVgb/9kcypvlrSOnUWtqSoZkMdsRbr/U7OZ5
apXdpnwXfFk12Im1YbM8BCDeogU0UaB9h+ibBMq9IkjMdSKE87pl7Gu9KcilOz2nmNC8aNfgxLur
+DVgnUatKkcVQrtzBnAoZBiW8jI6T2NRSx4TKD0ZrE4MvseSv8KDzMv1irtQceWakoHpX7wQ4n/u
5zOGML+qpoC84XAFfkKgttxVIs2FmHVoAKTGiTNAw08aAu5IIXjQSqe3KnF8FT4lIoBc/X32pGz8
NfH+AMtiHXx298/R2GCG1cdtasCfL6ieSI0ARneoC/RnlakGCKRIeAuSqH2kg6+lnyZWzxBgfjIu
alLDNcI3UnhL+DloI47ECHsgKdtg/iDCbOznBxeRGkKdrdY65jGcsIgbYG9zvWE6PuUG4kmCUa2Y
9xDQEpYVgKtTD5IEjtehcUB8gzeFQcaAwCmYjzu7XSoZ6PmntTxt4rvnNkv52IlkSW082DdvlIbe
sfU0qv3scPrQ9YieC+JWg+gP+U6DovGR25fh7vWLM/RZLqjA3wNA0jQFKCC3qLS0ZwQR/0vG5qH9
azq2q6+oqEv2GCD8lyfPxCLxcRympMEigGQZ7eoEd8jH1W4LHa+NlguZuaQFyBlBy1Al2hih0C6d
CUsCV1ndlG3+kcWCfbOfcCTJOz25Xc6Ol4rBPdAJ7UFpLF8LysN1i6CLTb4K60fBG8H3YxPFuYN9
w/K45wg68Z5h5jWq/vaYkYi3yoyNyZ4DgNUB+Ff+acM4uR8ZUJaS3rJepsWCfUChDdnBVyhZS2qn
uvyUo6y3akge36JKARn64VSvBEao1VouMqldeoLI3Vj4bgNTYn/gyzqZA2KVQOAAmfW897c8J8cO
hbRbdoo8RYA7qi4+YejbGxbpRurwwoLpmEdSMu0SiwZ9nOyFYEhR0DQLMtvaA7fjsasPdp718aiQ
f6ZMSBa6EOO34Bi2Cz628wCFPvfKCVsVRLz3/+s3Ge3C0Cod/4QW1JDYKZ50T3S5Es9VtrsD3PPW
MPF+38clvuDJochxVwlg+LEEucwoXLD2KTrN3Yun8RCxCrz02F+VIXoJKgHBbf5E/m007/2pXVqE
BPkFOxLxxnwx3IPoxXxffxdEew3p2JsBiiGesO06rky5daqlL/xoAaOSbgg0Q15TqXcRBjQwBBak
Mak7Nc1eUZ2u0jD8GvtS09/rV6IdR5KXvne2G9SMSGlf4aTfJuH/s0mKCXVL/JJ2kul+oGkUeMrh
pm1d1uXAMBfD8OYavNm4L4IOSs8xNyu+yeNS/yLpFfSg+IVV81BvmcRIhfQlaL3WZWS6PtAfo7mv
IFmQe1Qp38kB0bNBvvZuE+Zpc0LQQQErRejDNRMI0iCgNSO6CKzzouQ0PksbHVwcxiCUzPQUH1Tz
dD8nRnc6lRQJtyXIur+prquiomfWsd8XKAMLLuf0DZ7P0UnGY7seNQFmBKbK7mX1o+/QPt5/rZBk
SMqfDPq3ZeHzHU6QkyO6PbSJ1FfTd78cj63S1W6gDGUzcpL30glPA8OxMH+a0Kz1QdgNfz9Buvsq
gP54JrLxQF3XeStFV9gbC6U5tUe6PyxqWMTo588TzstgnEx8LsVCcMgPH3SFKn+sC7Yt9WdLgHXI
h5a1SDc1EK+VgUb+mTZPQrPUgHqcv9s2zUwZflHrI1xDFHLBdqB5UKCvBlC0313mIUJj0dxYSkgT
htpftGQrhKooXL9ptR4BMFkswbRHlBElx5tV6eAHgeMRWqckE/WRLGCmWnSnNdAHn2efRBCjPt8d
98j8RszpFWGWO1zqCIm720EaQiCmPa8gfjhZw28HwFW/GyYDPZOKw7G7MjF6iBYTilePHzmEKp/N
dBoAZimZGnu0LoFzn44B6ZCpdipiGZr7pm2XnMxYlIVrvAczjQ0KpjGbcrT1cHeS3vz1AT0El5NY
LFTcVef6mx+zgkEpT88v/zkTkvG0EwuQ/zVj6Vk2pr6x/IZpxuPfh3jGiXOpI98tMY2VpFq3q27J
hkeYEb4Fgv9Q/nmckp0MZD0YKzQH9ZcAzZLBdU4uv8eizF9TN75kn5qar31GveqPtn/Rn9YXOKFz
GbGzBAdFQDy4DfFxMnWo9iqC/7pgzA0gddvhZnpfteHIJ9MrxXiNI3kJbbVbdOUxvOAunmb89rv8
Kc+vJq9TDfYXkLh9W5A4xUiV0aKAea9Tbm6ssBbrqLzdKkXphNym+S0+RBVfolRE5WuT8Hr+ccWb
WSeoAR7+EydVMbRtZixwscZDJ0dqtlKGEHtnXQEq0YdCaMCB5V5YCwVR6x+vqT+drrfZnmuwmKyg
WFw9aCBtzsf6EEtMDMNSInvZi+3DdMZBZKe0mdgih5aHviDuhHZ3AgXBqd6DVadXFccNA4MyQAxX
WXOjYxvcubgfbguzDFpvUIza3+UmdXdiRTDBhw1RO1HMMI7oxE/OAdXDQNklREcgNM3MHj3x47Je
qyK/4Or6hODuA38lgIii2Xw/alrYyjH4Emv+kY7l8Lf4Hdc+hd7krVOOERj6xrWOTKhS1hx0ZxRn
0Cf5GUTsZmz/oTBk76llZlT9k7aKlJdEeCo/2C6aKr5lI//7CwFRWAArR5k2oNjiYQW7SrTcDMSo
WRGToN3Wc1XOEvNobF+N7MXxX0+12/QqEAJw6N7C1y96dOXdiVZpGydsrV6WpkRR30u4BBPyCpA+
vzHh0ZxD5vC4X3hM59dl/gJXvJ4mAl0hLO1Yr26Joata2uEZbCcVw89cOeWaWvVAWNwtqWQmnWuc
68S91ZFcRvxf+UdnliVF+s4Mg/OYw4U3UslVoBW/zBhV8Y2/Zvbjzwn3oLUOfbC2fdMYA9mPynH3
MePcMH4r9wBDNespm0w4e2Yhf01bATRdeHbBrHwmaQCbdxp3nGCFQgocMwX3paKx9flpAioKh5Pb
UJMCXYpIuwzvogNb/DDUDcQYWvy0Q08VRf4MWa2d4HVbwyVsj5nEWaCMAiTnv+1bLzh5bmEzgqQi
vlKx0Vch2g6LB85IWFmUHivMK6SQFOdKt3V7yE6OxarxXZTPsd9JQTYC6tbj/yyWhsIpJc28muuB
e5M9EWvW9Yw4V0WjSJHaWbl7T4efBKUGzcj1Uh2rcSAu9fCDPPl3OJRY2MozLqpQ8lU16dOSUUHX
MIFB4lswigI7PlHdQVHTb4MbhSzgiIQaNSwPz0z5e+acbInM5g3iCqopLNPO6fniqG70bwtI1EZc
shzjdPNcwVHxrwytGbOaRkxOBZY1G7eI8CS8bXjrUPABySWD5szlRaGBBQAiiaW81TX5Hq/lFQIE
rQmbsy6hu6p0fh37q/v3qIcRsvl1dJO6XKTkPx1THSqPp3asXmImDaw2tsuX2h0PXmlosPYNeaPa
yKGb6JPAtMRdIn/2hoJum5Zibfo52nAg1C+MJFJsu3cVjDXMRFiGFc5+QZg/s0+dwrbDyKFwTP5i
zU/xw8QiVvoPOflzC6yMQcOdMfnzBCHLVZ7rAIiUASN9BvGfkiggxY2hvygB71XMr6BDltSTfFOF
LALeunVVpWVhKiNTedpcZJY03wTuQ7faH6wpXERKroE5jUiT+b6zWdppUSPeV8H5ebmnwRtnlJcB
+HdCXAW3XAS5vf7KiwKHUABoVBZeMnrQAFoMpqe0paaTPVlqgWP112FUy0VlMxzo6z9pYYDmH/8r
nviOOnSWCwcSM+pGkp8iTTV23ztQ77qorYUO6tSI6/SFd73T8wn+dFFXWWtnCnN9J//azpemgGs2
K08tT18U4DWcHJAFoZQp8TEWUm7kw5gYi1VM+WbaS/cO9hAVdewEJkc+vEmGYvGF7pCMRS7gi2oH
BiSGUdcFVp7yCs6nyhGTAk7bxSIUKcdxAZxecHA6NgDY1bf1rIUzPawkZXKs9YTASH9vJ/vcXJOq
8TWROd5VHqek4wO0tXFpqt4GuD7VgJaAXqsTrRr4ZNwudHJRCPtn0ihi4CTW3OHZdUGqMKmBjawI
h2AfIApEkZWplcEEgQl3lQXO1igHpLQ6TFtoHxq6zwp/EezQ4Ck7J3SV/MumRdLlcmu1/E6bz6fU
Yw1TKUhXA/QXWyK20um7G4dDYIfdiA6PC1PfpKy/T55doPDGphG2uMgCcCH2ajWx075B64ZHhN88
cdnTkgcDb194+VIHxSoZ4fB0xGWMMwmsr3SYU4IwmTzdWyaP9GQSXmPmaVui+BCzgjeKNfnHZGH2
Mpq6D9gamgMO+kH1sNzeKp1b2OM+5Vhj1UlbXbIulsjVtRWBi530t9+cynH4pmAM3b9zWXQUiEco
MgIoA86lchbB5O/ME6aaUJkw9GtV34r5+FH4Xne1JjOiS7ZiBeimKHci9DFSCKFjxY33HMkASbLs
Rb/7exCdN4/ZzJeayq/YQ5+fegyA02XRYKgqWwoe04zrkjghL4AGVkSE68gRJqRoyJIytJfGHlPl
32kJCBXnWEVKmHzf0H9DM23uO+x5sWqDivcA9Uj+tgudY2/tTvMW9yp471kiB50NaYLgqYacwnIk
NEwsWVghSgrBeDR4DdUfvbTuD5wQU2+kbn++xJ2NbYjvhLBbL20lViYdJaklRPZD5WvGQGKZ3pr2
jH7rv4S7abhmfEG+ieq1Gq18rv1na4pQgs5eNlkt1P/T1yrOAkMlgmpnFb4U2p47EW1ZMAzCjS6w
TjBNrXpyXsFBngVy0PZ5S+AH/lv4PHg3ZHGYbZOS3An8xh5V033lB+GTfNokTvCs0wbQ7HkC0DaW
Qiafas7nOUK00kfPX5D1thTQc1tzf8DKWY0lT6Bdmaxr/eKRInj5I5FbPyvREpNh4+IQ+9K0YaqW
qac+P75tX9+48tNaldqYy9W8OXgrn5mXtZVAOVmTQgOat7VGk0qgz8EvdawoP8WI/wrzoaRqQ+sf
nS89wRsLioFssGp1TvG879p9FzNTVhuKj1LfkHJEX+yjIKjm5KjwItidNt/LgwIUBTOBKvdmPmrO
KqOPO+JFFL9C6nND1X8GJUc498OZ6mlYsgWlpC+yaCDIdgzg6k5r/Wu2AzWHOqWNV243QAxTz3PG
YttI8xv8KtJMKrv01COmF+O+N71oz985eXOtQRxCujjCo0wwFmaCaYSzwfSAmyVxYZvXezjOslQ6
UNH0/n1l9U4pSOYmFWCFIgfJUqdGmqt5l5Pa31Cojz7IAZYropkMBwfK6V6h5z57duaC258Cj61o
yW2SzyDIjPLFvN5HZ/knpMtLcu9AHLJeZ0ohS4AwYF0L3HFRKk7/0YnL7+qkAWb/vUg8/sqn7rIQ
D+pxjimrO5P0g/+L7N1kTh4m7AMCwXcFkDMRV+B7tJKPnayj/imKVG4lS6lMOoR9/2LYa79Bs0XO
30PWucG/CEqUdE+HHBpO6mWqW2X/nVRnR69uc/uNEjWS4lwICPUixuJXSdTPjA7c/qIwz0lLD6U8
93Z2Spz5pnSdVhnv0qjT+RsZmg3z/VC2B9Ji+F9NFq7/RKY7JBHae1+h6TyS0ZKVMUwevB24eEMq
cZgd3HrE/kWDdtfQAHnG3iFmsn1wqCFwjg4TvrXuZN1knVdr5y1NGqd6BGNYkJNQywxofCK1S3Ru
pQrsCNVv4yrveJE/8ISwySOCLIWwpKGBn4nfVeNa2tK111oGvp/jddGUvXoO64Lvt3+roeeao2Aj
5fkwXW9+7npq//D0qQr/wYb+5asoK8wVxsXfuVcKxMZNBHH34ZHDWxxOo1rKlqHXQ7xn5vDQnO0p
VeCJJl9qLpEjZMOwrka2Avlf8ux+51PZ5gDrubpcwwPxb99pqhXcbqJIpSh8FQMzvaEGYaT8GDD6
9ByQ6KQl/K8Q4UFJIXDZhYQmKOxjrZBynkJ0kVe4Yvq7r1KxH/Xm9XdJbbLI+0Gt4k5YtXDntugm
zv3MY68mj5DtVGSfzAQvRTSPcODPk1lXvv8zzZNw+uXuc8ZZ/tCoRWaqNGwBahu4OFRWfJEUEF0L
V7g82l7Uq75M7OPF5VFauNHpukNZlUx+pDGoI1EtWEwYYK7Vw1/YXJRbhZXitjO2ChShCzF6ONCY
+TCBlJiCJ8MGouQqfjGp7L7T9IrbM2K/fpqFLzXTHkoZfITyJ6LZXVhekAuEJ83Z89zRtUEpPK2m
PqdOjIvAGMAVWoB4ZyRkaINFisPO1v9FiBGhicwzgytPuAfwdzMqghv6/N5inPg3qArxr/NT5pGe
ne8WKVwHKOkUeVghgvPgvESXkAT3rj+ocqVDh/S4+0msJop6Zi4RVK33FQZaxhKjpqdda0uF1SNB
nzch8bWBXkVqSITjbw3lws772fxQZNhJjwrV2sZ4YX/bHqqPGjaLWwVN0sUFLgbWRAJeZOlIKBhy
M+rwCT0SurkmTxLR4rXCfIJaEoId8WlhLfg2SLzHtwIfRRG3wERqKrOUmjufkL5Ct4ZIOuSH5ojR
JNgerwKzHrG9L2w0OqtdAOo2XOkV6bfmdSSemcOjuiGFn2DPhhrt3ihMZgR5Kf0b8j07FnlerH9d
uMdZ7DsZnONHDHp/UoSrXjmGRvS8y1RTB6xnmXDhzEejhfqCH3/nnmNDMcNdPZvW9pQUwLClKBHu
dNFwCLW5JSzPybpXpDip8bCQscwfveLMOTpWBMoHuoF4ysuSAVa1VOBgHX4uvOAGpcC49xWi6K65
qjySU09q+84GYmC/7u40thJeeKS6njnSJ9yhQfX8yzdNRpt0KQ3OezolGaFny/HnnPk5kWpI4qRb
ZI+2YHr1LV/dopTs9oD8JAA0jg4k70ohgk+Y2h63g/sReR2XQsmhiwarWtTzafxMVnPA0VYaz7pk
ECCENp8BOD9Mjv2bjTeXd/pimpPmQo5CHTXc2ARL11etI2x/IYKREWbOxm9NlGUbi5gQrWhheWIi
NybYffXJkBp6kVsRWKGAP3/JZKKevg7cYabqeL1ojdtrCIAygVTj87RrPlaeFegI3mGfLZf3vsiq
F+avbpFgHygnbgO9o6V8+BEonCjsvnVhpNAxypj2Vd7Pqbt6JmVJtuVQIHklPLEMg5cXBZWE/JKn
DDxQJ0nCw7NEO2WIBKQ9wcA0GGPNejjq1qFoHKwQOu+Ml44jtlGitm7IcSXTUByS+KqePtcnLPPl
FoK7Pk9UdHqOdVi2qaNHJDtNXyq0rUwJn7sb/MZOI2LpT59RmrqgvjFfr2HT68kVmr0rcbqHdd1q
cokhZeg73WdItc/E68mdQiCk8bs9vwRwCzHVpOQeC07+WQd56yyvDxSD7dQrv91lnKOCw/6EM2fV
fs2wh0gT9speNKuZSzQJN7LDjrfN/VljXePMwItYY6gD6c4MQzlCdCXCnhBR1yxgkMgl9tG4GjBA
7UnkYm+dN6AXceDSTHwjWQ7T7D0fFnqFpHLJ4BBXU1jY6xZALK6A+XCpYFJ1g/PaPBE4IQwVds8W
6zWL1KQKk3kdlY5eGoZ5t+iYM/y8eJR8HJkucQ6aFmuiFmD0azT+GvxRbr2ArreMUwD+OvDnufT+
EccrX8EbxRUiCK//rh0UPuBT1PhEQG8TT5epPqXH5ewyfayLycrGm4U/8JkY2MbyqhMU8aS4DdJj
2m7/ej5GjebXMMfhaMJg9GClC56rHud3gAZlYBMhnZSj+g6IlT0OcEPwDRAaTs1CJmx2I77+6aRz
EYG8YV2hzQ20HhUcKgw7MuY6fRwyQWJWA7v1o+7qd2nosyzggG/L3sFGYuYIRSMPWd5rJvvSesg9
FOqXwGgS66QjmpxEsoRkv1xDfCkB7kbENL8/8rl2nF9N1rGWpumqvHrlgJbxpoNWnmVeN0I+iLRJ
7KCAwIg2TqEoeaGcihOELh6/MInNZTBrEtQPVhSkBwoYwivM1uUOnrNbtEUYP3shLmTNKx4IEwhk
8fONkkw+l5f+ONxRE5Tmgb8vy49y+ac4x33WvoT0RKhGVskU2fGbP8hXcrMSyPUjuEt0qa7ZFa6T
WExDWxEx830g0Z9/IhmIDznJwgcKXd5lbFyrRQxBoVZZhtvxAkAaSsSM5vpOGeAiQuqS9h3JsrqJ
LyfwDmpJvWtIy9teDW7xwLlri/e2siFTXD/YM66TgjQtGlYorHA+RNEak74xWTc5Aj/rmE9zU6l8
SEHzRYobhjJqSqnpdm0zyhe6DXnZ/FlHuUYu8wEPwJZtpDlPx2KEOJ2BNoLIZ+5VnolDJUOAU6nz
AjUnrgxphSBNDj9oqN8LrCvyLLqjcoaMf6X3NZ4PR+6NOhRk5Vo2/e0S30cowIiQ/XyO4duaMRtw
WOOnE0EtyViGr98NNIn8rjk8mIwuRq3pEUsR+mHjH1vIdBrjLGx/jDhPoqFSuOTI/H4/wKiHVn15
WGOrwPUvZb//4QXZIKnQQz5DlA78FI89tJLS+TBlZjzPWO3/jkxhqdjRwXOLh54tcGsvXgZ/O6jy
Nbq1f0LPWEeRDD9ZZuJNJ4JXrGdmqGqqyV4BNV1ABxCN0h2WfNpX63gfxHiFbBRo1XeFfLa3MtmR
SpwTucvu+OzZj3JruKovMZUlbub/Y5fIGgXop5kx7bdcxET2AiS8G0dsIiresASIyDfai1JxrDe==
HR+cPsfcIAnziR232DtTZmVr5L1eaHrMyUEUEz0iymUpb0Bb0Q5+GabT6KAIUq0tvB/ZjDoXUfTD
4Fw8nxebghnZpiUiPfwTq/R+JrFIn39K3aIEimvFUI8usDn06pqQvlJd+VQnFNCIdFvE0GKup/2c
6oDKv4nE2RYcdDaQ5n1Eq+aHufZYM6HfV2DOIA27ZBHmLsmcfSv5vbcKEyUYtl16hsoj04n7wlOM
B/maB73JKNZXY3l0h3QtZbZus11sHWCmi+wgdF308smouC4Aq0ndjeUV8OQInW5GzmAYfR4BcubJ
DPiown2vutJhStu4Vsop1qUzG++6dGvcAVzdU5SEGX/Sk29YAnHLRaWt34i2qVaFgYi2h5fPcYQJ
6uJFI/apjrfSrwUCWdJs1RS6KQAlrVa45qmwIyRUH07yLhxgBQM/4r4t3ZNi5Yg7kSQh0xCFlm2G
de41Hoe/UNp670mH9Xh3LL9Py4mLIo8nUMYd1rqJcO1XtlvPMK/O/m1c7BrTVCcnb/cWk5p9mTFw
hlnoxkMWFl2cwutVJ12ahD9oEz/h2s2NFoGd2+qWjjwOpTkc7ai/BI4GUtu0lg2bgpfo9t5KzZwl
NfTUBpxAIF6T0ZRZFktbfSvjlVGCLH0rK4hoGjpzUPd/K7YD7F0KmovfpAm+fN4GNaU4zn8EGoL8
tbkvtktKq1+YoZHcWnYzc1lKRu92VCNR3G52P55MvtJ1SUl2ltCMYv4mDDoVI/6ynYuPhbZgejac
Xu9KBEsEQiYEsr2v0UaBefLKfq6+bTYrZC+E2AewenDMvyiB0YFP60ytp2tfXOcGn9zC9Imkaui/
D0qDkrGCzfEs4CCz0ERqyUhoFPvQaNc7r0nOLRg6KYXWim98/oGYmpcGxEvGUdwinONn+lIpXbF/
PCpGy46JJA1p9mYHKseifuhDSQt9C7OVxmsfXecDNGhNqaXS5aAcb92MBeXg/zRFbDAmK8RBjJHc
jEE+oo5vgpcpdpQEf2sEnuiPjVG2fbzZ5JwGs0y1VYkQl1NZgK2T7oMtccyX16jh/9M8NyfPWEjX
/E7ubN7oKlFwMyp/EFGSmsRL8DukrsBegqMeA7v2QaCXdztId2R22aPObtw0s5wsU9BGMqnEyC/5
4rDgYxGbaqcDAHoTOh+DYasDvmOXzVhRlrso1k7z+WitAzHk6gn5KhRn8UHgOybPwKxl9ENZjMOm
UT2rw7sDAKp5JU+mNnggtejW8sHVNavsMtLsgFnyFd6nFqyYedyrkNDyFGy1Avoff7Y+gilb9Y4U
20UeLmEan1kQQkKtIUtQQ+XIYASjsTkqJPZ/2gsu3jzU9igZzRO8Rs91bahSs1SlQ09yYwfoPD1h
HYm/etabKFzckwUiXcT320ZiHrzemERr5L9Gi+c5oYupUv2ianViWiDVhE3iMYQ3WlQcf/lyuJih
wRy9hiRjRfmvtoQVaCKosXKlNYTeHMgJPd9sHf9aI2BtXV+EuXI8Fsl6GboZwFpKxJgrl6vy2eGX
+dXejgel7sGQ7f5UhooKh4vCK17lDDypdbidxHqV/5qpK5elE3ruCYC3ztlxRHVFDgu3U0YvMkbS
MoGM+1hJu/pRPN03r4IA9cAdtiFryuAKPoGRJBTQp/Hx0JRYImw0YOP7KQxTDblED2OZC1/kcrAQ
BT0RuPtNW4PqEWZLH9ODtUrhXtcqqJ+ONqWbBQRyMEPCPiza/quDFyMRee6nALtvv7LNfzpgG3yW
TsQa+GladzmFluqRTs5ELRT/uscvbGU0QhYvfSrVQTkYgqtGRC1OZ6IPIHLi94StLXaw4VhWRfvF
CD+1kNpuSKSNcwRkxraZkXhhH7nwx+2qrGSG2Nsh9w9BuiJrhITN3u4YDn+pz3PorY6RKabTb5Vx
1TLj8WwsZRVO/uXFOVzhYuuksjcXaExp4lvP4Dw5gY2qeJP8jAoO51w5m8m3p5fWp+6M1AzXrH7m
H9eGLFYmLVBp4yQlrZf/F/xvkLmubwFqjpKmZQPYYc8rwUYeDVJ8cMfwuS8xTatfNwdsXkks3XaZ
kILkr2Ah2bGvXcLgD9ZQXIiFqGy1OzuhkoXVnANrNdeQUsKiRsLloLCD4fexl14G5kci04kc7+Yt
DFc7oqRJcxkSb0irnUnlDNGdYCgP5qdaX6cT7A5sNev88fhEUZuYb+ARo/s6FWrfB2had3uFRR1f
3OloX0sveIYuSI29ve/I0PsPZ4NVt4eo7Ac9pcjEozaJkipkMKuawZtlnWDhg2D6rPkTubznHp2f
jdrfl1Hwi2Cte4UWE4O+53l8z1U6UmM2wEYDsNC9mLOtr8GEVdcoIOSZ98N/M0HK7dKmTLEx5fgJ
hirDaZkqqznqhsiQ4xYchMdwL7LLcWV4IgLcJ6H9m/yBe4bmmSptMoq1vw9vJ4G4QKCouT4UrYbD
tpzYOHMd7omITf1X+jXLOrsdFHbGi3YCm0W6OGERkdv9aVeI7EeD75OXjmkFgVRofGtxhqqra+xr
rKy0tu+2RtecI2qQrWUjoHCit3jWrQWtethsu40dmfb9RZElhhNnM6+KYphNAvfBvfxm70Xoije+
7n05Cw3tE45N