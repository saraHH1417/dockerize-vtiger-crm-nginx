<?php //ICB0 56:0 71:1baf                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtfCPHeV6rvUbeVmETqFNOgpIhwM17TvexR8/4cbBhGNkkEZtlOT1vwzC22spJRTJ9Ed4ozy
ntSj5jfM10DEnXTBZRMKetWt8JxVUL2Fz1ghntEVq28Ntp3ZlVYkM69sZhgS/jktO7fJCqHDnc4B
Wb5RB/3nneWsmOTE4ErNcjiYt8JQ7L/yB1jB4cQM6kbqBxOn2ZhdOX4q/BDpktR4kzXoQlQ+Wm4P
vmamKzguTDCRPm9pAgbDeQIGlAZ0n7EJxgI1j3CYSGMlgUOnkio0fPcHFyWzqIzB8kR+4CBD3qXU
b7xGRerWoJ2ft3bs85q6QVUJF/+MlmQ98MzFSmZ1K3imT1/JkSdU9GbizJhmPs+eT3diw/PWd4Ep
QhNYqk0lQBn5WivDsEqo1eLjbK6rkHTmjKDuwinrLjVXxwOJO/Akn3dk7tQz1xiSwYwIAUsasbTq
A4ZYmp7Z9HqQl8bHfiDb53tnECigQlbHXaerv4vwZdLe1q9fQxjwKV39xHW7Ai07BCtZ0MOJP474
ldIFqkYXOXHMXqr+rG6YDtvJiv6LTefYExmksssVhScf3hkowO54Ksiq4hmMsNLkXxgRp0C3Inkm
IeY+G4siBpX75pYzA1uPzLcvd+fn5mGiRh1h/hzodxSRbeb9FPuMDjtcFTXze/bf/qIPlw0RZ0xR
gMj4pLtf0ZRrfQNhD/FhSwZjxU947IX3h/YIopTQ2jModGN4pU8Dg2YPv+VMOZ5gcbsJMiSPVlQo
m9YwW4TM/BBIyPZ//jzneOy4GIuXwPaIv2MPcRDo476oT5+m9QpKeu+C/7qCDzTR4Hrocr3cT83d
THwCO+vejJuktVr3V7q+H6ZcYOycR8KkP8VneHcJXndbGzxED/st4YFGHfg9OuMSqQ9hewsQikWK
Yc4rUBXv2T/5RNb0PwqwnmjUouQzPBGGOmCvJTU0o+x5u5zeGhqXrV3nW2LHqXP86OPxu2+SLPU2
pof86fX/XRzLn8X9ZKYeaJaP963/ImWuPt9lzyvo5qHhYUP2w3ZGSGc49N3wjzaxOkR0WxY0r0+7
FkPOq0wOEMChBfYwobNzvSNgVpg/gaA/ILUAy0fTH3ae4YdbnECArfT8Fm9RNza9C8f4zDFeLH9l
w0MutOF2sJw11VMSPnmRvRaVRajWmawMHFmnI41uBz/58+suhLVLYjd9ilPibhMqmOPZ6KRIhY1Y
oW1gttFDY15HH4irvjc8Ldoxny9L95lU3h91p9hWVdVzmHB7NxLRnBiEZ5AB8kNxeUrZqu9k0pfM
3PzUKtrx2iMfg11Lr648wRbo35WN7/ivIlxtTtUrsxNMuYhXGfcGszP/OH9tglfOOqNiUWvDCKb/
4moas3wSI2Vv2lV4G9KqDXU53YYsGD6jZkHOnHdwIJWtXSCs6ObxtS1jzksP74MbnsM3Vr3WQhNv
S35g2h+3MpMvkaTT+cMUkEPlYM1G5YQikKK4BiOzhXcoOTvI2C+vImJP/G+yaRXJespf15qqIWcb
rmSkL3v/MWUWl9PRm5DEb9rQmoEKOc4nu9drgKUNBvM2Gu81JZi24PIHEjID8vnmONFB2j3JqlLo
O9+tvoztKFgQk3GNEb/glowbsYaHdOF8pc+1joeaPNToYk/LNrt0VLeEyBwTuEvbbzKNfWtnECdV
AhtlyaPIYXUIolRb8cGO7CUKqNih8hSZLc+BoSGDCEq+EEFpYhGoOD4J9w/dsZ9ga1FM6+2deHKu
k0HPlNsIiQGH7Xlu2175hdtL8PFQt0+0z/OTMhoYlwyzb66ggdt7Vrl9A5EE2jk7Cb9upfecWtOd
g4f5ImdKXAWbGhPBTL07iC60CA/+eg2Ivd9WcyOxiRCaJyO3z3LbOUnGJWjVCEG96mOt/Fg6p+ZR
w8okGQCgiJ2cPZQ43MKO3zg4SqEb/hUfnSB0Kn1v0Up2d31uPn3lsk8S2DwVE/ucASc0E3T9tWZe
vRiVPH6EB+G7g+YGyLlv21yP6NCxgJLSnXgBtRQvkvk5A7DsS+kKVkt6a97ZFkgUndf+cQN5omx/
BzUsjZHaM3zzensDuQvijF+P07KTclzjvES0cFhYNcNU2kPTHwQZJYIqX+inXfE+fyQmKul+2ZhJ
UpazEUssl09e7MFUgXC0vPc8WHbQk24iABny8WnHUm95radADWBtKOqmcsn4ApxBdyk/NQ/O2aQa
7SrtKKv4igWlgPvUKKO6qEO4OJ013UEvylVOWuoBK25CiJVN45b5N9tJbViULXkfRkTYvyIald6f
g/MK6DyJGVAcHgk6b4G4ix/0DJASs8+L13UcvH8J/hlLlZeZ0nBuhaDroTHNB6PisiekIYNWsLkY
OIvduwY4Ka6pxe+DS61gobjFOP2GBLSMo7IlHF+QDol5wr3kxbYo+PVqf0b3mPNnLTO8ZjBzizJB
6i36K6woqWWaoQ8tuS5YUkHgXOryezWeh4FMPHd6X98aTtadRe6UBUf+D37+QZFVNas9ajhqr7l3
4DwNIWm3bNEZI1w8ygtN4iPhMMlzwhnbnel4oi6UawgIzxW2uGqXZCpFd8FqDblFtoqEwKhqVz01
ID9sAbQK5KNHqtbWO+igx/5oOioeEcG08ykgFxdLCQPibOkAZnxPhV08PM5lhUWHYN9irR7Q267Y
6jj9WiSSUokqcq5C0VZKJtO3OekD3X6pisQmjhNw7keEcloTKcWQO56L4cBCco1/eSdYdbT9bwPM
nInCo8uEwzS7VhpNpylXZ4rs7DzQBd9rnY2vgTIs+vAsmiTuZlPj8BGG7KNQuc0P5pW0lC76RPnH
JGQUBl8X064lMvn+0vbyEP0j7kCQIOgg8QK7j0urINhY7VAR1Y0ga8K/bWLVHHNwTx0ron0s04pS
DWIlBUdHyPET8tYIb00MbAlahF0JLd9j3frohMzM2PebO7REJBe7Dtd0wDtNn4r8F/NmSp3sl9ro
aUBphDyusIa4QlTwlZZHDQTeh19CHv53SfAubjelESQw+iWPnG+Wk8vKNAMYKn3qwYwHBcZdNkkh
tCbmj+zabqu2h9+/2SA83m/BbtLOMmBXMHgYS4W8msdcja9/W8Q5uWiVS/JcufdAEzbjluTRzg1L
ypbKbQyIPZZ3Sr7c7zv0dDkudXV9b/0Aw6SJ3Ufsrf/A9FyC221r8UPkBIh1mbISvn6JgE2ye2gc
pupDXiJzhHO9Lb1gA/BFRaw5aTqCaC255XAdCeJJWRHNYt7K8ya3rAXBQbW07w5O/R6/1brr2Pxo
NJzUuc5fnqK/mwsz3tGrEiW5Fn6FuOXccaGXmK9T8uPMaG8dRsSLdRAgAqhbNnR6c+hOok5f4TvI
koNzBejqmu6MZHnZx/wVtFSCtNoSX83K4U1sWGehR5rjlkg98peOB9l284I6fxv52lg83Nvvbr9Q
FJcSi/zX2/zbE6oVfgtyeCTcywnKjnmJnR9DclXguNFA4zaGcmSW0G4ngMVcLid9kVTwzGw9iYuv
/pE4TOpbM1YfTQDQSj5+lRgTZ9UsjpFmQhuPW9zbv6s2BgY4QByCiJrKwBOmW3kmuiRQ0lPWSeo7
bJy0jehfoHaeBoWsvHHj1mjPzEbmn3zjPVDBmFw26DgjwbOqwA6gqEkc1BKVsO8J7ZFYLOsQMXHv
S9K1cgYEDK4le/FCLqsr75U+C8mN+PbSqX4fnm5YbA0v5uUNpCAfq1T7FyFyjdV/m/S7wfSuyxGO
wEQvX5aUu3TP6Fih2M+GhJClU1vLhc4kbQzpZ/IqmeaaELHo5kdAWbiXhk3Veo3ZLgt9p2UUnj6o
vIgILKj/FO+cL09G+O1x+moOEtRE+B99XlZ/n645Q96WCtwUimtzigY7rGt7FJJJepCOaI10flpY
c/0Uir+Df0nTMaQ82ll3ewyb9zd80mq7wHGDxDD9pih6Be3jlvwLhNI4OYh7K+FbzWTIdm+RHdl4
BOopnKHdpXnX2WswPSxk/tiqe8j57YO+AiYdW/UjxhPr5fwmWU0X9DFKq2ON6rpRcJ7uw8sJFG+v
oAQV59uYVq6UZSjAuy47k59Qo8DUvSnJihchGB+w4iTPTFe5ZusZROhPlSzAciANLb2fC9cpD3e3
GBMzGBnFOYuO7GCEBNDOsXLcB2ScqKAGlok/tgIg/qH9KVADfxH/AWpw/HvKAuV3zAZCsSeQZQoH
I0jmM/NniuAgfwc2zXlhrVOilBZyKZJuMjHjqhl1AHef0rqTcSCar17EcwNQR9a3Ji/300jGT4g2
j01JDKbYbRrBc7FE5oeJ+2AO+bza43ZbwPVB/i9O8szBqE3J8lWZg1RNhCfjv3cOix37JrzHcmwM
KYOWkUTKlLy6AE51UWJCpAQa/xVqaK+mR1QvM5BBuwGCEM6uUvrgdEYFdip+6SiRGx5b+a2i5DtI
e3Yy18Trgh9c9XWZ43jTSImxc8w789txvDROf1X8HBXkxeSi0QzgfW/RqqwsBu25M08BChbb52Ha
=
HR+cPuk2zZ8eLyi5HJjZ4RBSZnVkZDYXLx8pqj+vBIGF08tvB1edBz6om99CwrtAGxnslO1DmA7l
dxVfXYatP5t3xkAAtyYNv2H9YXlGOpCG6gZHnljWPICGrMAhDifTH4mw29izSnyEG6x8jhG5AKvO
VStG2NxT6XyzDtgMQ5eixXkElgnFbOQy8b0j87V66VcJABL9ACo37m276IJvB5/uVgw8HjKW12KL
ZIijbzWFnlizGK+D9vB1iMVTu9FYP2uwz4+CsR5jDZS0Gsy2K0nLir8wtr3J0gAbk0kRYLCrcpBh
4BdZT25fWHq+2F4/s+ZYvOQT56OtovC1eXta9hJQFiXcK6uLdDbq7tJYsoqgLLUs7tvjc7XHqXAx
6wUqbXW00vVEDQ/4YUJ44yjvilHzd9h7OwsElsCxbvCUmZhg/8CGLNz+nR1f/2rknmY+SbeVn8EG
BoKP4mnHd+u3Y4d/CkoapTXMX+f+7AGsO2g6fyU07dnT1hTy8Aae2IARVD5K3Sl2YiyxIvTSOHVC
VK2Qqcs9hQZOZVEdRZxXZo7MzHg0iCOLRkcf+u3WgtvXa0u0Gb0s6fbflwuZKdy1mbQIPGMEbybP
C/oUWJuQSLPSTUKG5rCqd5HmAGYoDBfBQDzj3F2xDFbRHijcs8ffXXyrgeqimq6QB8EmWLx/sJkl
6v4sk5bBG8R3fD9DoQgKpJ9zfMRZHOhEQ7W6UYnxv5BwCUZnH0s1VrD766AgHtKZ92HMcmuvUTs1
E08/e9pkPEu/vpaR2/At/mTZLJJp66OIKgFv0nn7iBZAOQszdEAUtLhuLBdjfOY39XP1q5tW9Rwb
YMZfa9BeBpGJZyqS3FDdmnDc9Hz3SAyBib0FvdkVNTxEXKiImJDRR8lpBlICd+pCC8II1Ldoi4lm
6WBx67ca6C1prBfUkLwLfIbKASwnLU2c45qwUj3KRvfTALUmqaLf3a+Rkj7wTQrv/2+8za3EziH7
ZsDB7heEwXuWqnSFq7kJkdFtKRGZytFfRV+G6vFgi8xfWjcHOD3//HRv37tkUpHxiwMmFdx5zkx+
FSnRYMQzXhdfoaRWc14sWpZJhbwTv4sj3G/vUDpNYkxjlihHziMP8o4iMuab56rDAyBjem8Esbn8
aHrmXu3I0uGtq7m/mmacZ3CvJfphrRt3/eoV+n8iRuGlRMXl1Sf+ekQHbnnB4h2Lq8t25EABMXhR
DIDDUkBk0ybQbbn0d3hp2l1V73UrYClLpRFF/OaN22iKJFWxAjf7fzdrNzbJ+fqn0JkLd+AMp5TK
VFX3gDgpEtNQElv2M6OfcmqO7Ld16bHS5M+bJFMcjAKMCx3xngCe78Z8yT6qEUx07lKXr2jztlZp
C2dCzqPhW/UrQQGd7gkrQtYreFF549w4eRRm8iMUDJIhg3vGqBgE5SL5S9SJBteC1g7ai0uMJDT+
2J5u+eU1Br2DbbpctS76+oLC9Vg5RtePeyX3UtO/i4hZu5WsE8Jk8aZZUbp4dZzC5Brt8+Chh3EM
WHupNexNxnIZD5GSqtxIuV2qIury+vmsLSwsH/N3gUxTHMq8jcGzBBCqC19LLPlI7QtjMMudTZXd
RDNRXAb7d4cQqDoQL29MrHDK41eUqch6tdOlTPy1pnACVCGVodsua7w6Q9xbFHoYr9tyImZTC+YM
A7nKDg8mzkD0