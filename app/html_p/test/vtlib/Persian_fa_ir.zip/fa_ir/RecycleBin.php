<?php //ICB0 56:0 71:1685                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzuAxpLNsTCwNiLw5bftjnNOORgIw581ski+4MZnBdzr8IW/cuo/+XP0aikNdyJpu7L2Y/S8
W0Ux/NW7V4LM0O+oPhRqzPY8qJfnpoCCjVtTvLRR8aoT543JTIGOiIY1jzN9mTwF6kJs29xlt2Yp
VVezous01EpmY/5hrOHJp12SEQBu05mMdYsrHxyofWjDMN1lJft/S6bKYkkwY9OxlYD4vRbaPkhW
DN3Yflgs6d+arC0OCnbOpjG6RCNNR11FpyX8/vob3xs+ybLZ86qO3OKJPVrNo3tHBqiYvluGmiqF
I5wKVXHr+D8bN47S/ogAzmOnWv9r/vCW00HMc2ZMZDbGM5+hXe7BQkwLfxmDEYyTR4B/vcWLCicS
tkfaD0g+9ATFs6p4LU8DX0PfHZC0pF+iYNaR8CUjW+szwccSuRFqM7bCncTtuwYHPt8R/C5D4F0q
DQDF3YRbrnEuJsams5tjS68qtTTT3uicm2H/q7lxnk1TMz1z7uCjm1NAgvvjqddGUqtwRCCZJb85
M2hoLkZ9eSgJ6RSOZq+CzzfmXWzwCIGr9Y1eKzzybvhGvA5PVkjd8sYIUq5qYI9mFazXGFPjSDam
R94ehDwopksmTAECe4ZOLLuDhAzoIdbIvqKaNMbuYw9chzleiamllTNfcR8LDcq9bod/qR6AmPcA
J4gKhnff2GUbrYVKPdI9D1A6MVSFJBLCxldhurpsjPTGcfPl0pdLYj4Yb+rkCQUdSRnKJnH1GinA
s4nqy+cN45y79TaC2O4MQiGoiQkyth2r1EgYFQVBx2mnj36yLZDNJUOG+Kf6+6RK5A8pmCS5tbUQ
tOuZ7QQ8TLc8H73DSvTj14MQM+cOUgiz/qaDs+KTcKi7n89S+p8qaVgyLwktLl0IRIZyKUe/r1gl
PA6qergSopJXmEu7LKkBlMWPXV2K+kSn0giZWEE8IEZ7SV3TRM2i3GDuX4BnX/1/kSItTSa/lgB7
1yapqSYw+ZLkfMgSEpxF16s0xN5I3l/7c2rmsQcbdKBIr+Onk5kLxMNJXEFY8ttWVaRev5KgqnVy
00cHrRUVK32uB4dhWGMc1oIe6cjq+s7ZkSvrBGoEU9Tzr+cbUOFrHpyKhPJ2oP3+rAxF8MsAAQha
g+xltjU9HhhW/psTXNpUBH8P8AJnt3OjjBLYU2O8q1yMaOX/3y23+qCa0kcOVqSA32H+u9rqS7Bl
nmxymNUI0VGsG82HD7no2FxSpSwdkvI064NZmHEq//khML8ZxNPGOOVVpdI3s3raPeGtsWiZTQaB
SMkxheynXX69HqVDCSCplxWplzu3wJqjMs3UPiMhPzMuZCW3w0NPUjvSeC1ab/DgmnO2eID49VDh
V20e+ne0ygbiDGMz2QVh4J3YkGG1s8a15XTmyHFxBZOz8pTagV8pt1UjOwB+TXp3zzuBq+empBkt
PF8CybmJTSNWoJs3plKjZvGW3fWYIxI+ihP+mj9w9dO/qM/XpaaNbT335Q7gjJ9KhTTYHPrIrico
u8OT2u8wX1DGdIocwAl+tz5hzjN2SIDiMPxTmIBa3y8cRVYdg4UGsDg3WiPjNUOQab7PvguDxhnS
qxvD9qMNN3ibKVhNVZE4t8Z8fKen/CiH8v/1rSLQOp7awVq4CeVUNHbgFG9M2AxcA25bBadulp20
1ZIIZoLpBpbI/+izA1KBbpMS2SEFIKD395N/4YZYersf1p9Yd36mcDRhyvUKbjavdVCvZfYt+q0X
+IanUrS+fj9PVy5eyxNGV8houGekJ6rYcUmECSdPEaJ60N/bI0ucAx55t+xyvNk63LDMNeTiOcRl
Z45IFd4Ura9ayvC44+yGKWb6Q7h/vDb/usji0TPEjte0dSEtxmC8CNaz03EqRqT6d0X0yp+eGEG3
dlHEH/WZ9jsZusTnvMDmVwRIJ3hoV46r552Wz4UpoUPcm46Ca/2OLSiHlFttkxA87FQkfM5Yl4zS
DDisMLepLhbT/hFiV7GG1n9tDceVpejd9sfiluqXILejM6v7Z8dDIajJswwy5A6NHOrNhuZuGV/O
JYx0Dz3cuD56BkNNO3jhl38KArmz6nHJtTgL8RNGruf5QwsJjv3KWvfi8tReOQsum4XU4v3bCtu2
QcU4psergQ1bse3Ta9nd9/i5AD8BbJYjU0rois6VRERYXw8pvhaHqpP5KcmEX6MsoJXkWOHdaDCM
plqBDlo7WkIjPCBiNh5DwvsxwCe9HSRPjXBviSW3iocB25WT/e6GSRDyiH1FegQD4gEuBIZBuZBn
BCIhhsxRj43zlAU1LA22ENepuUr3XtHdx9t8ACW5SXziQ+aAeNQ0LnKYxzW7SwwIVmvkMXr3nDLO
VKLJHVGFUh/GUlrbjSZYVkh3oy9fehreTEuzE/Uo/qN1jN09j+hG8fnYj45lItpSzVm/nVfn1kli
WjHnP5UcfMU7L2hmMxL7awRR57b2Strf/vWqN12mSG56aIy/mXI+vGdeY6f02+9F3axvDSSC2C/u
L98vWCHPxDdJziCERsoNYS0Ghg1/KfCB5sK625UOYkK4qcS1SrjSk/LzkkXgYaWd6UT0zw5KcxME
9VotL8pWTUCZGs/mWIRfSvlTKjLCxaQgVhc9ittuwgrQDShydEqHaJ/Fku+9gpY3BwQsZw5lw+up
5N4Htn0Dl2kDjpJvGUelut7370gowd7p3RjEUGLWK7cuQCj+ndE/HJ5wHnzszzzufKS6Nlv/v+Jx
KHXuAFyCeYLx8J+oYE/b9vpb9bHFPgJENwnWcbx4RDBJ1d0q3f6fH4LlPYZVCKFRqoutKjUx5NtN
u36uBS2Xz8yRHZ+Hid/gX5Y1hIDzXI39Vj8CE2A7/qLyREJjW3LxKoaSXnOMl4cjBXCV5NS0zy6m
RCxqE2Ewwgdrp0tmsP4UK5nVebNa0mEygXku+tPRz9zxYPX1tivGXNXU2wksjuUlO/WSPNp80eeV
kEuLSiyIObUAIPwHCklGz6qmMJUIGy/CFfOpKg2RfyrLgPVt151No3x9v5bKH3PA1LX8yFcrTlEA
ffBTN5kDASMYX/abl/sHocjVjJNofKRpXla7+JjP31z432LV6uqTGEZseqmJ1OGvLnBZxM9DGxX+
BXU2uwED+nUmJLgNwH4Q6UddWiabN4by5I1IhFo7R/caGWyayb/YPuklNpBRnm===
HR+cPsPt7tS+m+Dujy+ALD6UyeDcnE/VKOToBCMvPBqNJsS1p+6/uDQA0cYzNOhrheK7E4g3j1+N
Dvw6bbgFvYbJCfut9cHlLlg2gDPkUC7B74fsP6UDimFhIOySuAVTHsC2P6fW+jtq6ajaHOs8FgEu
RetFMnn4Pwn6Z1gXd0qNw90DD2r9JX65tYEYbB4xAYd8XEVC69NkdDo/gfrJZGRbUj13FmnQCJcl
agns4KcZPNHEixAusLW5yjTPe13aaTbdZ2Ze3fEN9zChgHTc3MRx3AI7gr380gAbd0kRYLCrcpBh
4BdZT3DlED09xrgz3iMNeeOT4sPW/nW7slniTwxHTZAITzmftqtnlS+dQ/Vyna0XJUepX5WceFIC
cD/XrPxc5v9JNd00Kx1vg/2s3B+QewEeiTRxofMDwKcQN/ylM+pcW7/yEUh0K4rWpgxjq/JGhP+V
Xi8HKtjycwoLEqJhyHz7Wb/0HoehfS5fUkzEksH58f3yUBF0pQeme+kXCTl3lwTwErO/l3J3V6P9
o4RmoyB0nD+6yplcKUBh4xDSnTm3dLWS2v2YZYdAc8BMyV9TB8zOoreIeykZ6UnXAKHz99qqhBli
SIcFA12GD+kX+ycdffkaha2zYA8vBzDwY0uhy4dHLgFP/PwimZjL8/LHeIy94JJmmNM6AVI3/fNg
FjzMYSLHDt7nnj+AafsROszHDHO8dSqOsB5ypnm3Tyk4DX2IaKC8TEE+nHrh0WyrDdyZdHE/20H+
ptC8sxEZahuo+nMAG4M5CL24EdiY1Y9sUgql5BctfqzSMMQNGU1za7PFZKIs2BECjm+J2lHwEety
ZE7NUw+hfb3mJSBUpVcL2KqP7FcD3sLm4u+cK41mO9Tc/qWMdCfnVK6pGOrfMbxQ6n2jsBTedBC0
q+BzXLswoOpJdKXJMep5ROPOaaAeoZeccpTFNwilmMUYWgP+bfXhNdyotDHHX6xEcbfV2oXyZmkC
BIaGDv5syMupXUUmi+7JB6LrcYowht2YQzJCJ+PbXC/8z2V/s5rgLQNhpodkH2SnEPDcyZWlGpFC
2Mzmxad1WtrcnPFCkoZ3ofsr4y6RiO7EgItcunW4HTH62Ep+Qh7nGGG9UdtWBEN7zDwQBcKz0hs6
fhy+ftcIVchsYeaXQX27+/oXyFEWXo3lf9juYfiHMG9+6rTS9tytWOdjCQjB13s1JTHFLKhQJcEl
fp9ULIjwyCAX9BkfmE20S1/rSvnfx1NevWC8ikRlTt4zC+AbIS8Iz1Bg39CdIlA9N5fhh5snTlNn
X9v7X0M98Ci5HPoZ5OemB/zmem2cDDVpIYfaEfoHWww9WM3/uW==