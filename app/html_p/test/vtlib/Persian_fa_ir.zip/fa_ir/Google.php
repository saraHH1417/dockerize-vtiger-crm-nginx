<?php //ICB0 56:0 71:338a                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpMYfFErAnt4C7Onq89ArcZfe/us+hzhECO55nY+0q+XmhfhiJELmGaVJBsLwBSC7idtKlcx
HvdPPmuBlE0bKkaKszmtL9sKLpeUd31MMhUGaizNImrohMDj0WvkhL1ivCJs/BW3RyFjq+rss+pF
j4F9/aAAAOrxH/fnVn8xx2WBJ1j7blHMbcG7YUN8sCl7aD798U1GlZyCzQHGJ9kJ4tsuqjBeO746
8CFWdJZ0dVUfL6z1p18uXq4ipILAWOHbQELEXOQ+e7H8VygUqqzFnn1aF+Z8FT4lIoBc/X32pGz8
NfH+6dFmJ/RNFYg8l2+c1aaFap7M8hvfwfEHt7IKLtsZ3zhejuHqDqf7WD0BoaFho96a7h9yH8n4
ccCaLEgfjCkASrnMqDAA6breiE1uu+LO+PzGrs+0+GFlMhbpXY3zh5Vm27uvWcHaVd9HG5sxGJV1
L3hpRtrIDOnVnQjv1zKH42Vtzglzqol3AmPzyD3HPiiwDo8g6fjhu3++iTGWRnlZ5yrGEizZGrV7
Eph7KqQRPJj0FgYVpqK2An64rmSUzukPE5LxeVBe27m7lvmbtUKON0KuBYTQUiPcIMFF6xNxlVwb
NuNMwnQN497F2IZH1ndhce68PPg8p1/n+hGYZhpWyuJkggsY+XiPEG9A3UmJJfyqOfEOMxEgLIwc
DRmuC9vjYtgG09+J3u9TWbvmIxRgfjQZEjFYjg0ih59/T17px9P2SugV7ws7ibYCUzSRt4MhuNnh
ENkCSdL6tgdI/gemMeZcqmgqVMCfEsW2emDv5zOhqFlRl2jkUQoEFrpEtwfaKf3mYm0HZYg/umtp
USMfcMWdW6FYpqfAWz1m6IdLNxPbNREtkJkvbIO8DiHvBmwDu5wia2Z+HtwBOEpcFZAlaa1dDl1U
2Sh3YPjQJakgUmUXDlWG8yJKucsMPZHjVs4wJqPUCSCgLlgwyM15EQEMSQv35kPvg8jxYAH6Fckq
k7cG2C5YtT8RgJT1MOHYqCsYYy9wWZK7poHLoX7+rPsWWTJHBvqAfjINpIUy9rsB//QKPiBT3V6J
mnCqleVQ56Kz/CKLSHQN90JfDkB8XFlQz54p1IA7s+gz7pjg10Zcncu1lqYj0fgnIOqmpR9Q2xE7
tR2p6k5bl2PfWDt5TJ72/50cME2iFUJ2Aj+VWtBn1QhY79esUoQSGX5uUP6U/aRLY7PCj41C0cau
WjBaWaimkRJ05JcHdArBdg9d1EGb+owANcODBGSad/0qxFdWGFQLOmAWQO/2Gp3w/JrYtlnFoIgE
EPoLt0iKieSg98Lp6BQCTSvIiS9X6ZXk8lMBs7aVtF5P17iU/hMR1ahRo+B4qWSRKGW+8ktjiIgD
85sUznPBItamp6hvf2OOGW4lD9TiZD+w4WF06mEurg8MwkFFdQT5+0gNLajiRCzrnx22W6THv6N0
48XY/q6i0fPjsNvCpEjL+6A7jX4xZp9DbhPWi/OO3w4IOkLXWhORGLuWqcWrczBlidrN1r5ZrA07
CzRlctgZXpiWaenQCgnaYQ5NGTu74bhF0k43JH7t7zGdsjlUlPa8gRd72bHc0LhNrwe5oiyTAkgA
nVLnw63ixasy1kS952ZWl+6QJwJmusK99oN7b5Tr3rD9wsTshtY4OL1tnJqAniZzjzYajMu4DsHk
BCp8L12wJZTusZc4MID1Yq7osK2ReivOK8ewArPKPyFZiYsQGF/o3sRfJ7U6IraOvAVJQvuDP0EY
7oV6X89Amz/GtmXwnXWbTXHmjgRKlATNkLDGdgJd0c7O1iTyBLfn8sQ9DMaujpIZPJfQ8p6Jrn8q
UrfVlO44POgp5HigP5qczgnK2wZCj7LYoKC/t/AKtbvPSXL32otj7D3Wb1BF27vofhKz/JhNZX2J
Lk5b6sqVnVCh/cOfKkOzE9pH2otAKZIQ2wEvliyqD2hvQzwG7w4cTeBPjiuX5dhXX+w8ITZNO4wI
v1PtpIXXamNunhFAK+Ch4a3arROoeumE25x51/i1ClKIXRCJifl/bAwcDOdcqRP19er9OEN2dbvN
6aypEo5eikGg5nSjQ6ZAoqpOQZqETxAyUW6XESMwl41cYbjGvt1chN0eALXp4jJwtH/0mqw0OzIn
Q8WcBBW7Tmg4O2iltbBX4glkXbGBCBQ/zd0Zs/7GNkdDONCXfE97d0axIrwCqcU6RHakNgYvN4ds
m2ya33MieBXTgs7EY5sn8MQFpNnhw/ZXQaAolASx2DXsiT21lvQg1aK9LmnDOxHh+Run3UguS3O/
8quC2g0oik3IPbW7cXAcNKOwswUn2GJoDWz44rwvjCo3NwRuqxVb+IaE2UnbvAsF97//Vj30dXmJ
CvmUyP9/19iruA4WOWWFAC71TsASVQn67gU7og1buum941nlUjZqKJ//PWZ2B/Pu74vwtpSa//En
kgRhwTAVRlErsvdVBr95mPR43T+zlXtv6dLo1mBFiFBqgMNITe81XHTrbYl6DiW6Wl/NcbvB9ayY
Rdv6luMLdBRe5ittTAk2fKjmRON1rAx0y/fi5ThCKDsDZUaTb5L0RApShfjOTI30klrVez1Q5VwT
zNeOIMIedQxv02OGmczEDlksRxBumikE8iAviRoI0ngKouUGLVCbxdgXP2h7L65KyU0JfF+vQRI3
U4HHrc7ATBizUmOrXHdijhwj5jFZejjqrIhzWua5eEtte18sUwrKgqg/jW8ouCLFdETnEKwdRBmz
9WFhLlyTM0oMRslP1uVrt2emzhbAzTR5a4kU/Z15UMslC9H4bdVvfNJsPhNqMxSWKa2verl4TFOG
Nm1ojBnoo5Pf9mIQZjr06PHJ33EMiW9T39hwtavBywiL+VM6i35s8KFrzbkiggT2MagDqTTwB2JL
jfzu5Wm0CqRBtz4EHqsJjl7B6u9CP+BvoKiSIBMlg1jUErA7K7PtjgWGVCPX9JCU0WTuec4GuXYA
ImFlBRFpnfKnVJ0Ul66EEhdlhO6LlvbHmDeSDG2GwmJttun0kmm2Dc6RN1jpM/c8HkAxGho0+ZXj
h/z4HPlKMrllhnwh2nnxgc9eFgMz3jMVRgXsN/kUVCw+uj9Uw+q8IOJclvuCdzjsYL/J8uTagi9p
3oRE9rF6y0hCV+jt/SJq6KjU1PRx7/lFxVNwLPjayl7uf2ZPTB64So6OdqTKj5ZcaBNN24oKgGGT
B8EHluyCJEdFf3QstzCwys1l9ik9aO+42QQmCC8j4TaBxFLGX5r0nKVjUi/5cOPFiu7TzHIlq+tb
h/ZY/LPQO7dH8ughhf8eiiZKF+nLMwxYx6gyOiGlyupdP8pwUr/qYUoI4XsY0UEuOuQ7gMd8d1yp
8ALZg370ZKLgfQacOAysVJ8CgmR6XuULNFKb6kfiFs22v3iYhHaXinwfNDyKTnGPma9NVah+TNXm
+YPdsMYa9bUbXuSl42t+V7yxXGTzSW2s6soTqixFzA8nxWI6Gni1PZIp8zp/MC4L1Yupm7aEq0K8
lHsBozkNs3Q3s27ztplLL5yXQ4h5P5hNT5gg2n0R1Drqb/lY83yYzgAYoPJ3xDhwgHfGL5xWXLt8
AIhLs8811oZhLXJ9+tO0mGmpIPjA8+UX5G9oxAkrx9g7+d16ZGzJToLnzyCq30jGAKxGNfCslg6z
AGYA9dTMEpNkyDfMT2jyX3E2fTrArfZ+2/KGGTK6C54olFC9P4MokJ9sNexZmk5uMf34HIzPj9zM
5lTaqmC2uEdcrrrkUO6IKD1DvjIV35GP5M+8u4kU3Qsr/srUBZRUNY36reNvQGfP9GfO1fqzea6r
FIx3+WSZ76Gp03HCfYYRYjYgvWeUGy0RybGl0/oTEO+Qd/WVibLyN30vX41iFP5odTHaMgeORbEH
L+scU3hhaFpWNFxB4KgVocf2zjxUWmtQ0fN6gsjWr+b9mleFwyiD1rBy9TKnnB4gbr2q/nAm/dln
PA4rqHobjai+HvGYgpVCBkTRzMr+fFNjWkgFVuHMFdKqBwY9MNwi14pWEf2+XZBXXIeqPBfsVwBT
T17KWplHWoqY7A31X/oPtf4zfnUKyAj1GzrjSbTN8zGRVPXFzfEwEG6rGuYx0FYTs1r3vOU6Thnr
hAH/LphhaUtcXaEvlxcwBK96td+Sb4O0AJG0cLTokWW9TxKf/vp92r7fZMTm7+YGGKtv1pUxsmH9
TYf+VupWCj+WDb2/c3/6akW4DaalwSgod01DS+uwK0TFTa9ECjoSiVFoAxJw2dNvxikbcCqdhT+t
qWFFqq0B33QIiEvjIK3v47v3XjxZn1/tZbOexjllKs1BSMwnJp/OShPJB/PG6XmIRnvCHe4QTyVn
vOkE9I5qFHhzX/WoI6XPXcx10ApdZjmROzgfdvOhmyHt9utI1hAnxdo+i6qADmiWZ7fL3PWcD15r
5+A6ycewj4ITt8yoBAUxZ/4vfZUvUukndB1340wXM2oFKipdDykEnkWjm8JLpRm+jXcri67ACcoX
9t58ZF2oLaX6mNItJSdqxWol7KwQWhQFh7B5lc3l9UBptbW/x1KgiCoSa9YyaDt6H+ya1V631ec8
Zt8B6CZQMXooRoP9TaEVAiG3hVVqj8ZbPBZtHixTmXtTAQRSBXpfbMpatJxsPPDV/Vh7QBdNaPUZ
QyZOsKNSD6STVDYVW504UYm/2PfX4I20+aX047XEN0xwAwvy5arjh7H93SoOI38gIH+cVUAlibAe
s2McTEMOB0akjTihsuz2TZgj7rxc/i0DuClX+nG27eV++tMBKoe0EGKAMbaL0UES5ewytvjQyZDr
nTKGndiRm1XJ8dgfGt/eblWQNlZj0819eOmGgzHOuj/y9mTwa341KFyxyBet0h8Ik0AHCYg/x5zh
WEsHBXvpZ7rGT4CSeTyfVuhkplunIxF6nH/GoVeRSp8CaxfokbDwEtQBFVJkvtKFeYR6ul+exhkg
WFnHfRPpYbyRX9WXoZQFWsemSS9/tGviPOXPWUmqHn0AEdItoO7W52YdXY0Al0/DFnU6O8W6qz1l
SmzKznQpuWT2FRmLOpXOjef6EhkEwZXBvGXCUu9bQZlyDD4Unwk3MaJh42XstZRZ4NlyJEyYHr/b
BNUcZRTqBBxoNS3cRlQLb00oDZvedVjVf0GZeOrPW4D+olzz+CnnfNHYerruqkYoR4+gaIiVoLtc
of4AsFekn4Xfhdi4/+6pIgcZvOVOOTRz3AHPccnSDZJfUp/01iz2RBZWaAfHa4dneCzKmUALs96a
wbxQrkBsaWhNjqNaB9+HlMh7m/jls5A8FIUWRco5TuxFrkoyQVg2KdOhsuIzeCX1NrgwMow8CZ7a
ecdDOMyEl3DFhMUp2Mw2bMFTIhXWwcwaEAYTrfRfLhNBloOtEE22AAxpRtm9QE75zxiEHZWzPk7U
nRTodXmrB4yQHZQGXv6JGNiYiKtdSwl5h6fKYQjWXQWQCF4BL20SpawuRQrOPhM82eobBBG2tFoY
rm5HulbxqQWaFovZT3kmcaRQ7Ch7xbLSuY5hZyW3z3WRpt9hxogDQMFMrQp6SuRZ9oNalbNIzbE/
Xs4x1hpvV1voY7iA3N/KJ2hQ+OL94V1IV9WKbpAvePQTsL18ZQTGlqCZtZXfy8EPqMNO7lyoyOVh
HkWHbs7rnSbn8F8Q81Q6cGGgG7/7+RVPquKZYb8qVaW3RQ0nw/Rtj7WqGP3xDPBcoiDUd3ztD0ZB
StzQZ0rTHrVijQdKeimkwcqBbVLATq0bO6oOwCptJgJ4IPzwOV6GhpkfC/tXETF0Qdo9pmZLU7yZ
mJL72nqFC7ItUu/pmuChRP41SN0S5gPeR+8YAeDtJIWcZzBouTSZqDOAYcmmc2a0WpTN0b4dCK56
MPgS2CvJX0QB76NJbTDQ1geeFdXOGo/Gw19BZulaQ9MbrNAISJ7LujaBk89JeIbT+3iSFUB9n2YG
dXt7nxcBeCn5PZkeIAQloigxAI8M9Pv9mhFhgR0ZYu8UqaI4OodK0zgFXgC2n7y2BnPHC6nb57p3
vbW/d5GCg18Z3DGwQ7X3gjvf/2+2XUrkhtEhPSpDJ8D/35Y00Kl+9TFAiHHBzoLqIbQEaK0dkvBH
wvIasu///28t7vRHdJY2BuRgLI11xjIH5qqZZO+eDdehZiSvP+yknfWhmvvC9TjZlbt/RPLj4JC2
Hjps/igjSFo5Yy13H3D4ixxAgZYjTce0AsNHmcJHR8fiKYpRSjdK3yLbJVErdnDJygik96eU77lb
nSzcs6RZ/QAvFXTWbSKoHh1Idtd0Aaj0fedsSgdz+OxkLgWfJQSUU2tk1c9OKYRbXBrmEeyaEPeW
0tSe5irlv7OF6SGTpODZ29Kr12oWCo2BPvCmlHYly1xY1YgI/dB8Ssq7WY6tkaJA6NeBvrCqIskk
Q7SetN6XiIWtUIbapgKkdiSK3f2rPhG7AZYASqPTrGnAZuy38tEY51NxNz9gJojDlhHqduu9Ex1D
uooA+axalG3ybHYezwDpTSPmxOOL6zgZyb5ca95JDUYMHLCndIt9cHRaWj+WqNwhYTFSq65hgLjc
YT9n4fkig3TUmoNtcVExAnnE4Lv7bMvbWM+ThoTNfSdQCWvFKZlYsaUFUOvv12cMi0dLalN9dozC
wDmGHwUjB4Jwu6SlTYn4J0oxh/XhNjhUHEfUkE9pjbyZAGGEZDxQ7Ii5WFTOuWYtT1HEhkl0o3Z/
CoGMXtjf5cjWojW+uexeZ9KEhoxab5CuPE/SIG29SoUGnX4aS4QFo19lDaRbP9U7avHHpF6GG9Gn
V8iJJJgJYrKDeVV7kRioM+Smj02r2QxyryhQRMGAtoj7m1uHLBJzi0kpOhDj/quMFhUdtYobCRlp
DsLKg7zagJxExPOrK+mGKajqJ5iK3VuHpWXkHkjyACuTeT+f9WBxqEvABbjwwaJ/2ULcChjmFY4Z
rinzx1KI3/+//VJ4qmjKBbkAPg197UD64NkQSGyEVNN00Ir0lUaEIPBCGnYujeg8Zm2LiToiEsA8
umzdXzubJem6sc81AkQUuif8ygNbFzfERoheAF4weifDkDjuAAtzZrvwe0/xg+3Eg+ydQUoWtTHQ
KkJuKOCJJVVt7YfFOHz5bC9qlQ7CzuBNRHTotLE26ryfLH5hRuypeBlVCIGwAM0WhgsIjjrAHOQs
eZqNdSFSfLeXImaQ9H1JdfNv15II/AgLSrZzzJu2BmbqIzG0oaFg2qFPJxSAklabqHezTlpUH93Y
M/Ay3u69HapIn4A0EOzueERDvxNYDotTh/mPq6f+bdcU7r4+6jR4P2KZv0p+L7NYsAzq8CJesJg2
tNXQk20+dZ0LUJa2VY9LwF33gDxr+fpnXPBznrIyRg+2uvtakKbbm0O42FRSb0dFpVE40cFTnWD0
BaiGVW/JEztlwNQpov+YZE8Xg9eWCgP/ShZ/i2Muk6sXTHElVzhAjjI8DETG/lON2NBLp5p8aLaj
JjaMtYCikoGa76UxCjp+v7ULNrS1BPS/KsZNTfTkVYdbyJSobITbb+Vj8NdXOIDIlGqM5H83ic7a
z8BuJrnv0QaLkj/6AgMz+EVn6/QVPpRn8dxZPMBb6+a30y/sODv/sXjMvzcKe2FS4uq4R7hwlFXH
OJ9ZPC4pfBd58uoZxMyFK4N/DIe+VwUCZGLAhhT9soEjYK4VfR/miMACFahxS4i5GeNA2my+CXD7
fyiDepMpAbqO30oH5P60pDYDmXt2RimJfU10od+Tx/yxDH8nwjflzlcMztUDzEWH08i20ni5XcsP
61G6BJGRdkhrkXxHOcvp+ywDR3FYDFNF3wpfq+iJ05jpjoGkzUUKgJ++484cZyTYRfFuTo3p5B4g
fqQuTk8coHuCy6c5Re2HM1MYWBMlEQ2yV1VmCwazrbracTYb3hGZOgX7p5u2sA1vTgm9Wi6iLyCG
4JYxm5Qq6Hk+teFZDiGMm+3KXNzRLIz5dtNBBmKZdkkBq/AS9v6vV+xPmKWY2+lWrI0Y2jsxbFUW
fELPdBj/kCMTykn7dQomQj7YUQ5u3n0nyi/eovjtMhuPPDIOQTClZMBJtbVy+sNepL7iXybfDcJX
/PlPSyKWVQLfmJKCsMYCtnQknh3ONgMHvVojkmUrvTJP0OXk97a5ivccQQX3OdkSLK5Wq3QepWcV
6XLCouITzy7BarVe9/sGAwYNv/MhuZIf72YSCZfkhOKdo9V11j8ZxNOeZUzEAqRG66jR/Qy5yei3
prZibJOuSNpi/ietd0QQ4t2lJ0Nj751pfZWDMhGN7uGDIFxOf8g6y/ruum24Gn/byCV8AukBYrL1
4tl3R4YSi7hAqav250ohywTL1oqF6XFGS6CZADwS3gVkNlzsKfTJrlc6Q5Up75jLZmC7FJguITux
vfy1dCCOV3SSiYA87ivz1guj/4fG/2iuiLR9lW9+ZH6M4q1Z87v7TGTvwJ5os83daqnJXCHPmJg7
LtkcyagmYSn+2+Hhvl2wK9d8OPtILByFOE8dmpC7od9fThqYmLDn1akrOIoqfVF267im9/d+Uv54
pttLzrecyV/N4DAPCYc/RhsKwp4vwrjWiVOwPiDJaye2TRkD+kLN264qwIucw/kQnETgApkVzF06
RgeowwrvTiCs0g+WJ+hQ995eKWlNumI10LA81VVV1y07RS06GMyeIhJXy2xnzKuGexrVNo0ztpLY
xjOdREvjbQAedYRYcK2Ck+kqEO5arqs/U7kbXclr+PjuCZf+4MXyJtG5JDeSw+FwZVRFX0Y6ZuHT
nuX+ey0pV8WabQE6y8ULoHrX9rfyC3WQEOVAjq2zM1wgPlhHB6TR7QULIYHr3ghb1rGgva89IhAI
d1InqikKqLxBdXb1xH1MoetZbg7oVPjF0bYHRFAwmTOSpwNEhjZNfnhXIRCpoDNSlh0EZfgpMV49
CYo+qAYX3OW0istM13yilVEI8rkS86lG+By44r9z75NmWRSYH9eaClMJdpyQIQk7X6iG9aRNW/ot
gZl6HO6sj6FetnrrOI2hsvC46SVBLZSgQERcFXY5QQTEB+2jMNW7b+OEREiI6Uodnt1EsckMNdXu
pk3AVUSu+H4jN77ZhV1ZeuGrv33IctgNTqHy9QrPuRCBAQSQKai7ttNdL25vl4QuwBavVXNrecJL
Ogux8BP/+WxkBKmxtQ9BxrAGvW/Qj2DDknMpgRflZ50oFbT36PR0iRiWJhLp9SO0ht5GdylUbYHn
1eeI4jEuH3OiSPXc4wpJmdA3bkgNtb2Gv5DEiwqm4x8AIMwj/uKXpTCq8jOvh5+datFR+aTbyn0F
swE65INMGZiRX39Gq51H4D8hgGhd3Ai5ceHKrlt/ku+kK1uwb0XfwYb8P1HPpPd/Xfv2qaVsJG0E
5z5zTcRm9ZTKQsS9Rxb/k7borB5k8GrPIcDYVSFBzlSrMuh8ZB2IM7fvGvunz751Pk8aJPEUokHf
sBrJm3Zaz4GQgfqCyjH4Q3flCRdaSP5zFIO0K+WnlUeNFSfEUHYcV8Xyqfw55P3Eese/S40D5hMO
ioySbCPBawPWfLd699WlQEPhU9GNOFOaBS0gAOvz6GvYnS0Tzmzqk+59u8rxTXXr0OBUBFqzw7tv
gQGnL9UvDXCS8jvK450revF/J7vWiHGIayFCCEqSTNP8CpFzk2GmwP2BGb3SNIGMaPn4zD3R0nVB
460lVOflZirhbW2XHT4fsJtjicjkg+QakHxQVoBaYtJKDnNoPYEDiah/6QM9orh5uFZkELkjEiUy
ab+fTR0TTslyPl9xeGeijujfYhFWLgAbXDeKhtSr+yOrp7BGOMoamxUovpMBR01Nxa1Uh8a7o1J0
n6bhYxm5kbm+7WyOhzwIxQCCSaPSrEl3R7t9i9nHSpOLGUKvdAsbqI5sPifxKec3W0RUYQRXgrKa
3DhQVXFm/bAAXYQNNmWvssIFmyk9CzFMJJrD6EI+Z4GIvBq13yj8fumNnN340eH1MQbNO/I6mP6f
owXVzfsShKK3PK6c1nQlEaI1u39nzWxbesKJXazqbEeSlmGgi1S9B4woj2Le2LDj7X//7Rl1pAoe
08iKtiRJQZTnSNJhEF+ypFs7NZdfA2j/0SyTzYkWh51iiS70Qrt5JYk/vLxMZQxiN0UlvuvSinNX
5Q9Cz4600newaVHXOagYFu3fyCRvTV7DUry8wU+MhvRsjQ9VhQqtdM5AajSAD8a5ZyMfGmcVr3k2
AGoXv0BRZ2cVjhqFzgjXZweMgemXveWcdD/WBZMirz96UnBqhzL18YkGt6ScufjsEl0E4o1Jt63N
TiJ+5vvO8Ciz4tyjFQ9lVzbYVwTnfAGUPO2fhFAIXnGVbbgnC+vF7P4BYy+84WFTwTlkiL1RLigb
8R4x2dPPAvkBPx0X+/qg5upoxOL3SvIFdHzeNQ25Cvb+3TePiF5Cg/8KL75kJbW9s2plx7KrkKO3
7PXieBtMesNA/c9c0inknIhLNeTLqSr6j2K/ZuQk+4Ltz0zhgvXT7gaJo42IfSXu/HQmHv66/hcP
xsO+rbQHv1/MNxl01hrUpeoh=
HR+cPsBsbr+pNsoGEa82VED6SWooKaoPwsjI8EEvA1Slzur3MOjpAyrNY9d8hZR0xelzC9cj+yr6
Asn0qX2eXZbHACD+9tsEL5L9z4WC2Dz6i1rwLDUog+n8XrT3D89qDAIUacyxVmNn0tUCPOq7kyYY
5f2cUzIMbtZg4RbqWkrJEzJTsrr/5TNcoOCegOXFB8TYdMaP3bcFVkpcofKP4WhxYbgzEf0VTd2K
EDBkHeLdQ4ho9plGOUwYEgvkI1+lD52lhc1+P4zPj5Vy8252TrzxD2Oggb3p0gAbk0kRYLCrcpBh
4BdZT6jiIDbmVyIHu6Ny3OQTkrvi/r2cj6mQUghNKyt1PYchFdNkqWhVO5/8MlM4LL0TdYfh8988
P8q9oUu8rdomCPlBywOeh5JBJTZwwhE0SGEhhMnEs9o29MBiG6U1K4rYgXflnW/uzWAisFAufifq
vV+RPAwu8Mw5SuCL/QvFtJWk4J7jG97sXZE8Tfsao+1rsSm3gQa0zJv3OQgTmqS0QODQd/ke3eFG
gtgz0zKqVVMrggYDeVXbjnmKBuV7y0urz4R4G5k0siUVGT3cQB2trFezPnOX5l6dt++L/4iJO9Zs
AC0qXxhTEhB20yTr/6BSq9HWOTNJBCXv5Utho+5t4VNxqsKcmHvstGFpM0uoqGjG0NB/M+C9RRPt
fEmzU4pm2mDjCgMJ1ZhU42gW7JDkCbtG5RMksjieIb/mE6615Kd+Qiz6oWYjkyod80YiqQO+YgXn
jh1H9S+wcvPKKFJiCj9e3eulojJrIeIYAqRGIZZkiGODklB/o2bt/jNKNHtw35nMwjH1T2fXG2eb
avi2WvVYmtHXqQ1c/DCcxYNumtDX42AGXBxzX0otUsEbs6tK3wZh6N6NUrYuqnN3Wcb17sLBlCit
PeyKoXep8BJuTzM93yhCs57mdRgJU/YqnNLtdqtr2l6l6SuCd2XO+3KgnHdVnRrePLqfdOrb2ET+
auZLQlUF6WIcbdwRdhm0hMGjWW+kAZl30rR/MyRAG34j1SkblmgvansC58+5aXqnxRMWSFtLaBvO
eu0uIwZCXUR0okRWhD/lKneXCCs+D7CerOg90SDb+Y345zzD7LPPhBuFSGZlJlRrrehWAzPnA3g6
roqNY23nPAXvIotzCsfzGuxPMifpuLklj/yc3RF1H3xXvdPMSzxvf6o6KeQDY0ItkyeEhPwHhsTT
9KsiVh//7PX/uxWEpjYdb/pJrTgF8DyxZnbp/zvzuaC6+42Popg1Qii4EhXkWr1fyZTIAq+1GXrv
YmEi3r9fvyUTWM5M2vdjfmGfXCFRuKoOC52Dlz0iukT450TwaY214nSshorsg435kQPCQJav/x3z
HYRzmGoOcBjjQ3DnEB90Te1NXQ4e8bB3UJgOq5hhDOa3EhzX+a+VpZMnKtLT1eDZi00OCq98CJbc
xWHep1dXPoI1Qk/xNd9BaF+fAa5ZVXMuUBcwQiwYnwSWp0SbiOJVsafpPmKd69dyG+qToTaObICz
p5n8ECb19C0pHVCRbqd/4zi5/FzQmAdg8MfJRQhN7U3AKKSXOqoSqGQ0fnIXSF11wA5Qs7+xxW1S
uJW7gOOkCtG+KBFravatBqrepmpB7as/z4jqZyopmAAlXHBXDRh9MTTn5dvsAtmVI9OszkVuu6Az
+2rhn4eBhEIYm83Oj3XW7tD0FVtrBZcvAthXSLAHUhcx+7gsrvtPsW9ZHUtmrQOM/3Xi//dySuwO
T9OO+vgDk5sPZQKgCaAEeVeE8fX4fTuMghy6Owdh+7LX30Okh7GdecLj3k8Vtxuw956yv2JeplcE
Y1mFWWZ6skClsBwf41uzIUCmFPMljRmg1bVKzij7ffwXX14KNW0ZZ7pRl8K8ElnN78I4YmoIs1uH
K0K98USzUOm2dtOV66Ct8KkHfRGfhXZFGL+8V/b8XkXoLqILetIJZAYlAv8LTDjnlIGLTr527xxP
Fs8SAgOYGdKimdx6rBnkuOsuRPev0FL4ccnM7Lc/hQ8lgwxnYyIQlJegnqhSKuO5qwurC1X96Uwk
3sxDkVpyf/4aId/UqyaO4YtM8Ih64pXOmwzTOYghNtMyCjIib5Dx6pC+r+SbHFAmSPXvyn4/kMsl
gRhKotWFdg/4boC2zBUisbn7lrEqYXBzXAXwtcUAjiBs/faGE5y+Y3BzZvydVV94HGTN62QvHOys
Ef0buzbcJAj5Beu/fpj+wmbuKtgAiDuB+KD7MDJC3TEvELjAbS1M0L3b+92XIJukSzUxxsdCDgso
wHuCcyHCY9EMz4hEEEwWwaqdA4FvNXzOthMVtOH2DtR7YLYEDiOYmkLS12dasOfOCdTDGTWnhfvr
lORJGghVymhsLkZ8c9HsC9grVlpW9IxJRvABDnk/jTDrfc6PbntTCzIC4+Z6ZkkTIXNvaElyDrL8
4fh2Nwya0ia2ixuwBM79ccM/eqZqkr3vTsDG086ndQm5aIVGr2rRpVeGrI4oxszlH/0aBVXnhkZl
dCbCZyekKTma+OdbGQ7YPtdeqO4DopL0kkij+lm6I2/jnfVw/F3hmBZH402kdskv9dGc0Lsn1BHl
EBDnCPcbXrZHqhCYCPqOqLLsyYrsDDvzS0prvg+LOKq/C3z6pSTdBe/lEIQJJfLaBrMS6w8kvnZS
ZKMlhsjC9c7304jMZDzX/1B4WHhjz9gt7JgU/MTfIltycLeuB4T3ZQnU67WtzyuiYhoAjb7SeQV7
Kl8JHry3U5hlZXCGcd+1ONcWbYATbFkznWXKGPDMApktjwgiJuE4jRcjuYY/iTHxklhf3ZfDmNlO
CHygzif8/I3VT0yHt9cKE6pdVet8OuzbQt/zMHFIdNIUrRQglV/Tlm==