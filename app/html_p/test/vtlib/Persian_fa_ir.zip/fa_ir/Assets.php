<?php //ICB0 56:0 71:1649                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxkwFzvUAOGHLtMg/RzKuvV1Kzz0Sl/u1kysVrDXlrIQZmViOXVfvuTGHaWm4/KGl1uRMzyf
ZbGDmzXWQuGiKdf4HeSotkyiy5jSM/GoQQpBX968Uedz0qp+T3f3rXogSdt3l9tAU3zqPXEU4lac
xYp0gGy4KwzWgCtAT/pBZO6iH9dB4Z66Gd3MdZkLvQ8xtsRWVqFB0yRllSAJAZWnQt+Dg5pHvsFm
O13NPHSrkfZ9/W27gXuUrcmD27loxVA0on10EjDcBru3wIc+gMf4VlpFL/38FT4lIoBc/X32pGz8
NfH+ANAjjzk7hQWao1Sd1gbuadcF7lPnIwOVnf+Ez+bkX8fEneEveg6+GdccTO+a4wY3RMqSi/ZO
VkgCPxZcJuv005hyGr1ChHwtuIctS8Qpf37MdEwJ46Fot9ilJdNcAY+9psfuLCabiuUmxfHvrSTV
8yCsbgoLxs+fiwhkEOrI1ZdGaxGMj4UW5o2xJpR2+6k6/uClxzAqDtoLhFQGxh88CVcPM45POEH2
pp3ny/tjMQDKl0Nlx02yftbf47+eHg4OluXlbtdsgerxaHC8AnkwCSuSJ7KBJEvIyteN6rWRNjdU
v0dX2/d9/+gK35O2aHajk5jB/2Kokk7nlAUqE5M1YqyLzIwEQWFOkB9hMViKPwFAHZuNZZioHVzC
oWquZoYcOB5dxH6hWla8Axa9Ijb/iqfVcuwDCaKUyxXI6FOESwNVAhm4W62uDiLoUlnBDVa02fjq
IbzC8tl766Iiv/t+WbQDzXCAeIRPYUvu+eVM8ffITt6/1WYP3H4O3FT7BXxCR5iYG3l9o74kstjr
pafaznlXuLfsopLpMzWpRtVbFvGeVdrr7amf5EfLlGcwlZL3DSM4EYswxpMetNk4UuCPzOdNJj4B
XYXFCkjLBW8PukUw5UFx48LWnleaiIFJk+yd6WZ9/sk6qz0T1KQdeYD+pDR1LhcwSuL75yGvfoWR
AhEfK4IVm27V3ShZBtq4+LivOfJkonl9bnj+/vmqR+MZ1BsZwzNCGxbJk8d7DM0PPfMnpN4Yc5Qd
xoSLVNmM65ehqOx3TYUz7C+ioCsq3M9sxmU8jiFMpU+S4Un8uzUgjzsBGVbWu/0iJ7pv6z7rPDGb
vrZKAFcR7aGVL1hmd/8SkUxyTIP5B/L/VCHvpJ3J3Kibo1ejg6wg1nvEpJNNgZ6XadpTRQHV31EQ
LdnSc+6fcPq8Y1OcuuvOGS+mhv4vXQWsvAfYxkD0DAc20NC0RTQjK+17BHLRHP6tYGrMj7Con/t+
Fwz23Oe7b/N9X7k4pDAQpoq0mQyGii/DL0jYENEbj7IpC1MEiuwvYufhmv/6QGJcu5XRKAphy2f9
rS9A7Dn6qfgVcsSM2IsQH1VzYAfi7u3v8n1/+ZslElEDGZQEFQUyYrW5GesK1F9+fGOUBUsbDHJW
E7Ysnp0fyoZ3TSkF/hdixOgK2xLZ9VKPdi6Nv0qu7JhZiCeIT2QKeioVtvBlP7cVJ5RVbGJBi8s9
3DyX1fCccgx2obp5q5K6EqV06wbRaxwmjhlOz+SWzSMYDqN8TiL/WOTTLmh+7PygGJac3OpuAybw
HNOZYyX/TH3ygfmgocXRZ5Ep8bmRy8LF2BOhfx3w8ksxEnt6pbD6xl7JEvIn7TPPk4bNeCnmoE1P
ETYuh2Lff81LvsEpyQ2S3iBwEUOzOIPOq99qtCLmOn514xO0b2Tx6AZSeIJdolGG+eCCLEsnA+C/
NfhI9Tru3MSxIbnR16aLWzo4M5r5mwdkQhArQUm8wHg3CTqE/WquAbXnuVx/u2DqMfphWEbXyTdv
JchHiCAH0/ydvpruT1lwAWUhTXHaun5AR+DqrLz4iORXGLFKXp9MQP8V2crcCAuu+SMoRQLZztHi
tV4YR43ylct8r44OKTPLZh2xWbFQDnaRhv8MZZFGfdnk20QmV9Yr8nkD9aDMBmkibee/BIRTiQa6
DrTGUqWaEk3HXTfI5WUWs9OZA6dykK2MHmfobQeDdrCijp8lCnBKJOQSeYyFUE3+o4DRcEIfP9eQ
SK855cHnKWQG5Za+fpAFbA96jNA7cbHsGzXXvT1kNbZmR3Fzm2KlgGyZOFjY6jrmCEBRtD4KdTy1
SmpX4Esv/H1h6+2nUyXjliKdw8eKj5KH/0mvSI0oNKwHZdEi61tq4nYD4hLrN5owQABopLAzZ+8s
0J+mxul/OSuE2EcoPS6bCabeoyMKlc8/KHp4ALV1cZEbK9cx4exAFzUOd7I+6bB6yu0WZi6Si6f7
+3SmqImH/0OK11dQV3jzKcVZw2XiMov0bUyuRlXZmCWqse3G20M4c4SQyy6bfGrVV5i3ynYO0/fA
TP/KwvEC99DKnYW7NkMdce94XL+xC/b6QSXZH46riWDXFXiEBtJ/3F/fLFSVgCk+kB4CZUDBi6He
0L41BJD4XrzpJBgVlnJ7FkFxBASNkq4jxX8tGhiz0+0r0ytYBjej4YDsTAUMKj31A7+wRwLk9vcT
JyQHmQMwG1axT8mXa8VDivI3ElmBaul1bUpEMPitLqjeKhflkluzNWf6fWh58UiXk5vRzndLOf8U
DaSEp+ax+PNUDN54Z3WCAaZlOfsyt6D61Sce3Kkd0OF04LxfY9AFr09Rie9bztZBaEx8IhIqNjql
0mA872bSmT5e4BQe5CgVxbj3v1Z9035fQNml2T3Tfu21VGc7NAXVEGL8Ce4DjGt9xgT5DzfBJesI
3TJy06BD0TSGQaycdNE1OZ7Lw4U7t6R64lIO25I/e7QQA8DUbAqc54wD9GGopBcT4HmsNpeMV7yo
9BO7VIGgi0j4msE6Q/TXJ0XH4rB+8CyvIy+McU016hGtYjHShxzmGdysXKOSh8ObUwJ08bYEzf2z
EY0BxzSHaGQSJL4gcaI44eJ+FfqXqeGFTSf2ofhG+4317Zk3KlxfqCskjdywHzou11K6A7Q3b1DC
hEoKJ4JU+SXh+gWz+WjCgEHC3/g9ybLBtZ4ZQ+COlgsFy2R7c90bZTV/xmJR7BEq1HcoLxYxmYC+
9JXHwfq+c+juI/jq1yqoEy0CR51hJHqej5ap2jW6QOmMN6h6xwlXnw462n8Mk5BGCTZAJPcbh0Rt
ORi==
HR+cPyuFJD+HwhGG7BVP/1W7uaLFUTriHc5tmEgv/ptqhMl6ZuYZNPaEnZJR1mXtvDUPopQ4daJT
1aEqbPqAui0DLH6NVYClwik2yqFOEB/BSeMpnDg1cob6WvY/HCRTKCHEiiTx6R6VdBD5JkGRkjdz
xTBCneTXM3ao7e/JTIdPjEF4Gz4NAH54H8hIAyw0qPpdh/EBryh5GWB0jL02EE1AcgVucCQ4gnUh
BaevKIyp+QFgkzHSbhSzdA4k0ee5dPOPQerwAuc8NecIfw865vnnpwvKKL3/0gAbkWkRYLCrcpBh
4BdZT4Ps2Wy3GRTAwys8fVQVkLvWs7rmHVDvFPnaBEEjpviCS7Vf/N/2D1cQbJ8IkYhR5bCRz5el
vq7KPYC2fKK+l6mCieZSOMHVcPMoXiDaHbUDscLCbCZOR3Y/6gS3xqTKTcyBUmgK0AJvn9ZlpJZt
8shmlbIcnxuHNQ20cDbZKloW4/AGUExMU9vwwUeLa1p0CV+7/4BP3eQHQY8tJDwCL+q0QAnRZS54
kLOaW41N6XdbQP1q6yr/SSC8eBzGvbfDmahbdClv+2uPw0MwIYBQOkzO619NuUvA4da+bfRv26QX
aryufDXUpkwlmu05S2QTkkcE7jmV8c78akgZ8G/rmSB4YuTBFNWk3YgWv9AZp2RYsL6ZkWQ0I+NS
zvGH3bK2WJySrZlCsUSpyRxGjaZ4q3Wp+xz63bhl5F1MBLzCutCRM+hqrUOVDPsXxsjR4HbGCqw3
lMsl+8OZS+HBEm6USjLXPFRl2xOTOvqbAbTl9hBW6bF/ctv9R2ZoaNosWjLeG3QxmZRFxIE0XWue
lp4OFKUiNerUyPQ6McyKTk6EpbBoan6kOQaSjslSru2ZKnsF6ZrAilc3p6zuXJKreYgAI0Ie6iiQ
Mt3J+cyaJ3dD06SsaetzyFLhesVGo15j26fl59dsYA2ti/hR/rlvhDa9eKaHMmaVwlvnPP6MxYwT
7rGUAOK3GIp++fqD06LYHzKo01MpgDnGeJSlf2xigQiuLqksq+GD4+7m0EaCP290ptpjPBNicOWv
7GV7lkd5SUI2uSgOE349lVWgJ0C/dE3RkV3dC/Ok3UFts0YzX1RVUUdGAYRWs/4qSUT4hHsNLKCG
dcavLKvO4J5mUFiDf+w5ROFfEavZRs1mQqAopw/ZnuMwOcorEH851DyrX0afHs76NwAiVzRrIa3U
R9p/kKrcuQgB8CxnWVwRiTJ67pKwYwS4SPTJ+XJFFSEtjE5TIfs5GggQa5WaQ+6iN7tY9jLhEjPn
j+rq51mnMR4CQf3VXPLuPyuObH4j5jtTcFnq0SE+R7Rbwm==