<?php //ICB0 56:0 71:17ca                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsXFVtNC6qHx+OVgLX81aI8/TVi+xp5uFSO4avz/xgt3FN2UcvBAmSEmSYp+AcmIlxtpOEcM
VOa+UaXHQWQrXvroUo2VX1LLLJsjJkdfDU04o4WWfk68fC6WeYM/tBJ9CnT37Ubkf6V9ECQW0KGk
uOe0kiKmq+9B+LwiNbDLdYvR/PowCy7Cb0SgZpksgAB3yxh50z8OrcD+APLzS4F0kOquFbwMSWw4
HaBpUZPtQwAIqARNbJSQ3Kb9CkW6H4i7/vpOUxdeqDLLYLVtWC0YZMXJgMR8FT4lIoBc/X32pGz8
NfH+2t7TQ9YLnhmzvGqx1hcEaa6HSdxxzhjSynZ07AvIYCGocHnZIhWFovVYcM8V3OqkH2PsV7zE
FKV0PZbQxKmniAg5g9E9WJTtBaQss7QGNLZlomw2KAArauXmmMdSpN5rK561PG1dFaB9sWf/9pGO
BoA5KKmJXltnu/yjQ7IDqPA9pLl7ieqPagI5eNJjWnZA67Bi4UxlvoIgJTcpcy83EVOd+85xSm7+
ay8SQzJebRniaEYUZfvX/Favds/bBJFb6LWsvEMM8hzasGqS1s50GNkMWlTLb39xvcpXcOPXOl47
MxOQAUjyJ7Vy3tcrHv64//ZjzOnp86+Fi3InkFsGFUbbmO7Hpg1BC2zFDr9vBSsFDvQOVc06RY/b
tCdfD8oc459T9AFPbwa9uYrw7Qfvbcb/HkB8Twb3ATqndHVTN1nTnb/bdUiTS8wi8S/+npEQQtbj
oAk9wLBgoLoSbciFD0LkB0YZBB8W76l5EluoFb62jGCEZFGmxlc6TrbYeJN9dG/BXaEqlFlK+6es
ZhZ+7gzf/2V5AqnbQ4w6/AqVGs5mGR+c9+9vdRX8eE+K5YriNnnvSbIyXDIMvK3/SzOl5/Pp+wCR
DJP83Ao8RoiRuy/77LAerPFEWp6g4NxJlOvp3h+t5VSS3QSvwPor6BZT7QQ+SWCHzEW5AFT6X6R5
NsOEyNq/96YqZU2xwLQYnSHeMfZ7zs0k6u68IGrqDkl0jPgKax5bO2Md2IUttlLotnlleOabuvE8
pUD6SEwhnXSzAWKfmbGODQ0wfr6xu9+eV/Omb9IP1Xv+q7rIu/PFzzchhTyEIqkIN/0kNbiwyv/k
U3NkDAQ6XHsfv7HkiuB34lf3HNT/xoztptNH2CFdtn7opgzbY9mdgDLNi+6opOT70G3o47N23r3n
PZfVZhh/drFn1roqEKmmz00o09R82AryI3KjI2OIWO6pP47RkxVq5EmsrBBuSZGA5IuwArJpqtMU
9gbWamoUPCw/qUCMNMk3hJrlMrRWFGRqWijaSSILJsMMeAmiAIcTH9H7M/wxnQWY+ydMuoYafMlg
O9r4VEjW3ad7qdgNJ0Szvoj8fyaLY9PCo/MUvhq/UonCLemwk/jEC0dXeSCDE5h8YuIdGydZiwIV
MINAzn7Wy6nXU5ar4heOVd0jARroX1KbDyCWLBb5rw2ghYM/KydoM2/92bXoh6i1YY1t+OAiLtFr
z9kQBR32aZhebCeRD0ebU4Rm+RJo9kpKg5g1+6eU1iSBTLOrip/z02ZJ9Z08KLjJMpbTvh4K/g35
NQRp7TKZxz0+LvnE0cVnU+K/nfZG5V+5tRDx0RhCatUlhH2HG8dzDGcnlWDpH6oM5GULj403E153
W24/AOaBHHfmlsPTXVPgcif9VlFYDhiRi7sakGijGzLHqqXMrxoztfQe/fH3LHiFHSesBx+PUmpw
01TRocVEOb2y3LBBXlrgXRML67X0HnLsbkteVdDwcZHj5Ay5/9JW+weUjbukHi7RzJj1lcRbIUhl
mk+Bw/4JxWYnj1SQ15D1pzApC0WPFr/UjJ5gCvYn0QBGvRhySyTzij4xUrVfI68xmDzE6FLzTAPZ
NiEYSSpJimeHDDex5cMolrPQlnB1W7LAnMJuRb4PbnrkqViMEk7lL43x9UFlrgUrMtH4Kj5R6exq
lJT6xMWMYkJlW/lEMDxGo3AR0B81p5DyrVa3aRP0S+lhkz9qcflDp1z4Iye13y8pnVYV9uq2CH07
pRKYKtSNtHO1Akjk/CMFRaeJkqwfClLXm4yGUu3hSc85l7AbMETZOdjNsOa5cyuu0369mNjTFrag
kPIcflR6zdfQfimflvDSo2x7r82OzkxMPU4vt7OiWdt9pEY312GhZ2sOLDsvazRYic8UWMvum7n2
dlN+XHKsISQRQut4svwWTIpIB/wxDgwlWYneLpBCAk03MQSgteI6uuWZ/TQvXV3NcMD9HuYfEoIC
TxXMzDxSzOVU80SXmomPeoZokJE1V8MLyQEAoOSawfMN5NM83qTKS19K9aVMIu6jSZuOGyqBJqHq
rah2kSPQVp70ba777WpBEsS1k13Q4lJK/jldrIg3V4blFeXzQV9lCtP9kkl1NhvIW8SKLHHbg17/
BGuz5/jsxdKPmGuLI6GYCVznGDwsnzgouIMizzlYNS3QEiMwPrhqJNvYRbzU06di8P2JY6f5f3Uj
DcfJ9+NsYrsGL8vOHjy9LoXlS6yqxY1cT2S9C4CeuwAOttVNlXQ6YNkLrIoylHcl0hgDwNeUOOLp
e+qoOVcjFPb9ObqCVIMyOiAyY4a5Xci9rzCURynnlt37n7TJZTRX+DBkgKeAOW4woPy4AxGjsc4n
Me95rnM4EZSVUF8BV1Ux1y4+8tC25DmE5RCEGwWg1I+FFW/VIp3qdZzJjCuuztYG2GfIGVCzjUyX
5IHfBrzVpEJ21m686SiWOzhRWzmg4dnTzav/V/GuTnkZiMMLcuwzoqsjg5648BfhhE8uVrsl+//c
IORGUZsLnhthYXewle+ec7oxEUNQHjORtHW7SY1yXbbCFrU0BaK/NoRxufJWlFZ0kJA9NJ19/ZRJ
HINIlJhP2nC+0tdDZ/7SAaYP/MQTgJ853voDMYI9rJeVi04IVCgjAFe2ffOsxBGnupq+Xi5kHZCz
ZdtOLduux/5tYjGvpbRG2Q8hXf5jmHq3CtUuCOJA6B8XRltkIBOz6VfXGL2m0O66O5rsl/JnnEU+
FdMxpqgx5c/7+jtKaHN/1ewyRmKHj59naNp4bqOFzPUgm9tBiA6hrAihab5zdy522ZAiykPChPxV
TQnEpq0PJ9huKSZWU/H5HVKVyHZW+DH0sTnRT913Sg2+5nhJcyZ9mP9/apx21pEPlfsMEbeEIVVf
Ds9w27nanrTOFox1JXZjD6hlCQsbt0nRCfY+orYxME2WjTCOcWjXlsrNbtUvN+vxYjBRDefixn9M
kHyoQ1+j7lM+uH3bAkuNNiJiWU+Il8FO6tEtTAbUUhuA9rMXGRAQcNesrsj10laAMkOhD4Sa1tOk
oyhz6Y/LAizjloCol3eJg9usi76V5XGoAXLoGhoF+Cs++N9S/aF4peukFY+MqhOhdUvjf+lqY5rD
wG3NdFm5qS1tsDICeHjv8AOZWnGhjgDNysXC5gi2uhzA4q8IjxMjnsFz9sTHcv3uYEyces70ltkU
V30==
HR+cPudqtbgsGIETFqnBUMDQ7ogJtAktQ7EdBDQv79HukEJy12qmdTRfFqkWtDI3efDT0jxivLYq
jEtUwk/DpKgjm0rZXgzvO5Wd6rDq/VXujUSJgCEjmzcKa9TsoKDB/ora9nx9h084wg3nqHhzTOg4
jJXejxOkpAP2CFq9oCdI4cgVEBqG7PdKqLrjLh244FJQp9/rMMEee/Gz2HRi2PJKUdFLLxt0GuhM
BSR4LyCaopuHTpKlXG58jIS/tATUgzcAN4OPIjkHDObG614rwxz5Rr051b3a0gAbeWkRYLCrcpBh
4BdZT5nqwpcyBHpXPFTRCeQTkrvs/ojbTgcuHJsoJGyRk9Acm4Pdbt9ANP5ZQiRvxvG8URhjkJ9g
oZ4ul+RWUWn7soWF1purzpNVwccL6hf6SZc+9EW3BXY+Wu/e+OOxctHuBvNGgDo9ppkG6otpa2sf
dmU4kzuQB6h91K62Qa6DVdsfIEMxSQmoco8HEEq6pC5paTSDbwU0X8NMW9N23r74I6RhH3ThDkRo
qt9hYHmfgPFVXDUMQCTgHtB3XA0I6QkGdv5I1TiqwREa+CP88n3HDPDe0lQqCsL+0Z68TRrqiq5M
ZY4PkR9WmThfVh+6DP/7XI/nGrvqpGda8mUEGYKQNYZYZUrJrH3rK7TIhtFcxEfKjmfS3wCtPMCO
9QWmzcy/sixoSwMZ28810cPTVHBXI2VB0GbYzYBBfQ9Z0RS7Mxz2yBX6RYGO84Hs9ZWtzrU8D2Gx
y3PcBFtTv05P/ZSuq09fpi1I9aRtxnuX9S9Hu1sAzK04Y/LeGe0BMPrQvegdscHtR4IYtE8fdCy/
550fh12CvRc9PSs+nC1yYmZpjbVYCExfrFLwkgKrJsAsx2xREqroKZd4+1/c1SzzZ3XfFJB82CAb
jjNkJ4jS8cxPSo1WjjZJpGIT9zoqmVYTOKtgD+HrBl8VlEcJ8NOh4mkHaQq41/KdNehlTg5W/+mR
7UcMe/MX/sRGATJbsqZNt8Czhbaa0BB8Jfct2M3myex4i5C1A6s3XGgPWwO5lyZlu2+rYvXyDv1g
bx3fxvv/GWIQA4+vm6c//X2DOjmNjCjvCRdcHXWSuQa0YMI1JZtLxAIaquxgVF/wcAZiWmCSZnEJ
8YMc0ETAMaqU18o9jccUIfUQpQ/I3zOKf96BT9+xYJAgZMOCwmZYmKdLQ4x66+3XE2hKyN93Ntkh
iSCfCdaRyg5XYn9w7TGA6a/lx9MhJUkDL6k4wi0sQsrJwYPI3p/C4ZtXutR7h4ZLsu+qtlivh0h5
aMk+xs5P8FtZiQv03FYY/096loxCzS6CZR2v4oK2ldzveg3X+qz8+4XfG2o+sBYeyOR+yuIAEGK5
ierq2meSMm5PWPERPY5jb8jsBLN9BJMFUjVHPXAizR33x96MtWjD3Nl7mZwiBlTisJiqddkMUQw7
jXBiHao9zRwAfMQ1