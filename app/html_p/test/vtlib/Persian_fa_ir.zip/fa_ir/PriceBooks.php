<?php //ICB0 56:0 71:12c1                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPx28u6ZpNjbF+aHrIoeOKhNdj3HMV+p4Ifp8ti3Zlml7ZYXGtHHWnFzb1lr14F1EevsYgrlR
v8SHLSttpLkR9AL0sO7eFZUUwW1SFNEVOVwpAop5DM9kXSjdEMvC629ynPMTZwJzp+VYJe6iG/s0
1DRmp11G2Y4ZTvVg55BEuzHLKEquFSzN95sX8oshGdt/CzPpO4yjMd9IxYjRWgcLKDQWd0PVcQI6
8DXcrEPn1A3LEHaOjkFU3uXImugAac6s1YeW72wcYLhWTqxlb3SeJZMUGSWzqIzB8kR+4CBD3qXU
b7w8SD3kfn7Gva1BLbK6kOwIK/z1IF2/AwscXKDL2BOFgMNgGcJqoTAbFkSdKWAmtv3uONpOW7j9
4nkfrPkqqOyC9roYU/PqMiUv+HREiSrgPlLnDUySoB/aHLTiDzwp9TWpdqevZ+kcYhkxySZluKb/
1w90JWIWqY5zA10toRpPonfO/ge45AGW1VV8J13yPs+kLS3sfXQl+khXQyoyMfCb6PuwzQ5HrcIy
xrv8gtNUWs6vJOiI7Gd3eUj7l1gfMNSXz/PG8uk4Hfv0MHALWPQzo1DhjxrzcsWQS6XoLnFNHmtH
gt+KFfc6PrG5JiAKzUvmHN88T2ZTtL9LNpxY503z4ohHnV3xnHhG2YMI8J7eDqCBBP6YAzjzwghs
kxMUDojrgLUo6wt7xo4r0EinpzgP49OJRiqWZ5QmM2ewpC+9q8k0OesJHgPSKQAAwq4vs5Peq+jN
vKukLgRDt2XAvzNxQ78HqD2614aVHzo636cuFuBoyaR1Zs/6jyPzjypXVQsUDzvbGO/nPWsYN6dn
4aTEkNr8W8qr7dd3/0rkPEIFgaz+WnmjMDLt2SeHOvZr7MZfHXo8cV78sCMUBRpT+lFk4AtlDaFb
mDNgDieTV8JWJHU2XKP3q/SXxwXqNPza5149xu+Wwfmnl1hqVAsFj/Vhng3/ifp0Ar9ovf9n14yk
WM853mEx/7ckD+Jje/KHcmZsuH1R4fwcT6IELLUSbv0PwdZcwXdqSWK9P6wxd3rdj6Jg+88Ftiib
Nr0X9P7RPdDDbf/OyS9aOLLR0W4wslVP28VLCkS/o924Wx/4v8T1d32yhImTKwW90lOBnqRdbyYE
oNb7Cu3JmECAloF99EyBjbiOMorIhJWdJhUu2baEjquNc1L52KIOgV/8i1Z36TWKYcozKmTH/eJw
PW75XfjJ0zf6h9E21Zhohzfo0JJTawHNIkV8dIDOz7Omnm/R9Rml+OJDGW8zFuUnskXLDpv9tN+v
qUfi0GN7TfCOMKtFFMsPXdiRB+wnHJNBdyt5scdTcxewYH6Mr5vo0y8e+36d3yTxTXycewNJAS4b
rGU0go+ETZBwKr8WmwV2Tmqzagh1i7wqUeE5Yd8VOwiWy6qg2yC+H2RnDoyELFonyugGodtfvjzP
4MoEpYUWQmoQlQ0ruW1Wa4CzpXUOIsqoUw+HMBJXjK6JVAqCaqHw7eogbuXNtsWdZXw2LIrzqHrd
sG4rExm0PSV27cyAqPgyJK+Z73HZ705rI2ECr/hzSR+Nt8CH1s/KpURCfPRdXUw5ISinZv52cvGZ
NC8q+SoSBJCxxWxN6eynipILxLH4pJP2cGgqDthzujHPuPQX2e18ZL5sFMszksBMFO0gaWOsw50+
FM/s+pDVTMWl1aLtvxGMfohnm7f0ZPsvSWHEc04j2C8wDz3309dZO+VQqiRBQdzj/yQCegv1PvFh
LFnvt3Au8cux2pc7xu+rUzlqASC+esrdpM9EJnZ+jVcgHVccBOKTRmSk6DQqKWa/dsylpgAYKAQH
dPMJ7okIquuGHfkxsbn5fEJ/YfpfoNfv8g+gfi/rQGFsER7CZOb6IB2WXlUZPikiSqC1lqf/+WtF
9KKqB+S/FNr00uE0iIiMuJ+BYey+OObEA7gnXeNp/lFF7XZYACLQLkCf3HlE2hd8gyLw4C7j7AJ5
quYkZNP40Hx19K/NvNtlOeg5FQDNC8vn9WJlDOCXYrZHP1q7IFsKEYUlCZLyTaJZl/Yn2Uwzj3ho
CQLKIahl2yfGIM4260MBnLB7BI1emM7K/2afwcHRkIcuiyMF1c0b2GhtyJijHKsVqKqL/X59NgSH
nE2tVCpfJfO8XZUoer7iBoMrMmW09jPJLrdiXjaJgpqPyxePVoPypAQp3j1RZSGbSgq5Zr50J7QZ
KQkWYWJUfbaHl1YwWxnp7W===
HR+cPnuxhYJW7XCBZOGx1yL5Hd27Kqfnu8QCJCkv0meDG3+kIalNWEcYQ+tNQGvcote05OLDkDeN
qkZBxUxSiuETz/tR+ajnn4YLVWx2/ZI09BhaJ1dogCpaSR/aPPvG3YY/5p08V0ksNFiSyyAlZ+HO
0O27ahAfmNb06Jh75+YStW8n24vFJwEIxpT7zg6wYF0BDNj/Yqb/6yQ98FhvAFwiO7ax9xwkwuEL
Qu7YIB99RfnH2Lx1sdh9kRgBwc6gwxoWwkcbpTXIh8wnBf+ca8Q7fJx8bb3e0gAbhmkRYLCrcpBh
4BdZT01sO+TbKTWbWqARqeOT4cOKCrsc+PMFVmiWcfYZVuTGr99rmTF1oUVfdDQyK6bPB5G3CDq6
4maJZ+c/vCGIhy1R7N+YMPJW4rxxgjYHz/dkCYUp0kYRq37Cy4kGWFos5EDZ7PkwqhGiKhNuCjRO
7NxLOQz+hHXrcd7upWCciQuqWDwB9tdz0U/bK5JZ7yF8x8cJvvEAs6flWAmzJsIh+CopNeJgii1h
aoSE31xffIH1ei5fe+ah88xu2r/0KNAbsa7AKQlw1AsNb0fAkME3aB88HWxvNmtKjGlmQxmUIW6B
kEzZmbASSkqj9RyTsE9NtLRLjG3myF+SIYYnZwySpBBOe8mtfukYiF4/5aoISW72wM0ofyelXtDZ
p3l/zyuuWnbQSjKFt6j+GEMgzbAdB57N9ho/qm+weelp5oBXhmcM0BtYcqF51So0+3vlMfKEJu4U
KNP3qpDRq56qESqNEjWFnvafAB039c5F1LmhSFEiVhMsRdQZmPDU+X0NaxLd8uVrBfnhzeMOdVlU
e0hH95B98yy+IoSzmx6OETPn7Xt4Zgb83MuCi+Qq6t3j9ljXZrwiDrAWrXUv/HGggvVzyNxE9bog
ArUaXA6sZ0PzJkzc5VMulgIh6Te/HbXX/0nrf4n5BSILZW4YTNfbO5aKecY+4ig7ZokM69zk9g5C
WLirnCAr9l57i8hW8L+lYM9RqaSRpPi/QcE86xdZJ26cg9yt74E+UyRv0D8wKwqelIoJKDI0Norn
S18Wy0XbrFsuzHZ/a7i=