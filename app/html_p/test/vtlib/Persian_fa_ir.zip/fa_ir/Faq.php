<?php //ICB0 56:0 71:145a                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPzVzY6YWOd5FpJ0TIqBddmjRJgFrny/+w9N85jYVTv3LFpR6IFeVSZ6Dr1bBsVsYXHqV2DFa
ZibcAW+Ts/ZtUtSXKF7jZJffum+RZvBpjQUWG8R8c2V7XZq3J/EWb8hqhaLqQBIQaafphRLZQyKZ
KX/DaGV00ZEkA54Z7YwF4hqGyKjRjBHoiZgjokX4B8lpZ91ay7IXuTytSm2YGe4gko2mR11wOrri
6K1VLzoHrIGvnOsKrtBDzBhVGmAtX+Xcu/YnsJzlbf6S2mnNg9NvAMDGfiWzqIzB8kR+4CBD3qXU
b7vlSsSCcgRUQtNSdqm6kOwIPdp+mUtLIANofbK1cTPwSjf8jtJyRqdZ4fV4yHatwEGK5igGIE40
QyzW33LQQDZ9geT7ANDyZea84rnMrwnAvA5xhipeFpWHduFZVA7yvcgPFiPSpxTOBMusbiFB47YH
aRV9c0oSKLD62bmGTqkAWSX6zIHo5TWr+5YCCkiJXY5IWhqc+nCv4NYzZm7WLA5OUdaHtm1wu8wQ
SrYCSiXzt9k+7azFFJEeJsNTehxM/TI4SjSLHyTgpaRQEPuTf/dA16Ddy6KwR9OxatE6RicOEZWQ
GlUJ00bnZpajBoVhB83suS4QvNbrpIiDjXUp/+dk/euNa2LpwX+YJrXGDrNeEud14nLWhgwUWA1u
My3bPJ2TwaWM8IcHd8o3gVvttpOCKJ730mpxfW9jYazJ45PyV/Gel986BmICNfKBpp2nisiln8H8
Sccibk/yS96Aem5VSYs2uo+1Q0aKjpqjKclWAmXyiQY7as5iPmkz1R9WF+7nCM0Itq4gHW756DPP
fwVhP93h2JEGZYs0btAxInv3m1KLzQshgqfdbPhk2eQ4DKfd67FV52juR1QmoiZpJqn/Q/q5fu2W
GL3lQFvI83O75vabgJwmXmTbAKs4AV5mE1xBwRKqRCCpIg4MtAHXmHAA97Npqrhc7XvxsLD/qkWf
UKHOaK3Xd7J8SA904O7h0b89uQVZaSEgeMF/uai3HNSY1530oV/RM4nZO1sluJTNT1VVIUJA79VW
g73bDaA1Fd0FKG2Y/HUgKobwwrDYdIJU5kmY+KcAaLiKUdjhzkgZiZcTJU5eb5YAMoJ+UzgXelLO
v9x3ELPjRQGx/b2DTszsCY2scInNEYvVHk8TJdzxnLHbyFQirHHGgQ6jgoao/AA/ts8kc5Njaduf
H/bGQqD+QqTxlBdo1rdAfNQ1oYERAH8kojddgbSg8lHifwNW5XyfX2Y3AoLEnI1t+jYmHXh2iNNd
f+6Cimaawz93NbXzCSkKVFqLCGljWtuMf6IwfVSkb1tCETSOpTN+d8ltvh0+j8gqnCZkCv4ZPdiQ
jdOtXI/dhRl1pEeuOD0z/xBVUfcBjplTSpAxn4DZZVwGJwAvRa4jLBnFl9yMKj0tdV9qG17GdQv7
sf5Str408ujVezCKT/CC4ZC6roLoDEjtxEnziJHkU5b/h7O+fdmAQtAJe32y97t1atdAx6lLVBP6
uiTYh+PbD/c691E390FDYFFU3PioKH5opJryksgFOvBhb/afAP+JHxA5Us8z46WKo/SS3pSguMYn
zF9CoRb6YOxftxEHO1IFK1qPh0GqpmXUHVGmZ8Q5cPklgdZHMtpaJ+zi5K0J28r9eRwGySipZTOO
fWkgFJAD4+8Hn/0sSYlbzEPPgPgn0C+pibcvvoTm/skfVcRSnB9hv9MdbEppUjMQNcrDAdkNNksE
seAKXqn7IaYqWCEdJXIYpb36zIlhnHvykD7/ZfxKqprIQT8U5eRZ5q+oAwUHSlFv1pYC1a/6jZOl
xyA7di/TR4mKUG5qN8/tr+fQG9kVbLkY4ugpoKcT4x8O65yOWoWejKRXawOGB4r55RdSY7hv8OSh
BjYfzIhJHJzbbqNpUuHu/LJd4WZiImT7+ABfhj0WTsG2oRekZQrYX2YLZMlSFaFW7Sge3yjPZ4MK
BRRv/yCZ8Zd/sfl4lfrXsmMJnp6vvnklFhvWhiXNa4kbXKyksOoGbCfuMc6se7fg2LPFQloAC6W6
8pD5HOhqRoQiqhUroX08nshQWrEKNNEY9tm5+Fd34m4sU/Gfdw56G7HjdtJZM/wR3TxvopydwEnm
tMOKPei5YcA0SivnvcByaoS4kOdwY6U5dCBz7eWeUVT4RhUZKvC9nxSIoIvzvau7kdC3UJrH02HM
6vOChFCxMxsEHGs01coJmpsLVuVfv2i85mcv3RiYP471E/9alEGuu8wBJ+J64aGNrTgShs9GvnNO
Q0/IUzRTlpxr9BsVfaclLrTqN/QymyOmi2bkX4oRzLbEZH9TYgBj9TRJpRQF4p5Whl34NGDm0iFM
IPjt5jrW0gptI+40IcR5tG9F6bNcPNpIbMkfwTASpxq6CAQuuLEdKxi9/CDwz6EC6tOCJR81oLum
KjsS81f9aqk/HInlzelfCGTo+5LT7OtfvaM2cvJnYrlo8lTFQdyzak+IM0Z1wXe6yjHb3OwcYcgv
RGu1fi8/hVkTIM4DxPsQord9RSWEr5GwZINv+lBKkmmfpxjor9fs2TziI80Dci+AD6Gqzby02xhS
aLGrh8mrnDe9E2XKZktmeW6C6i02uj4K5bvaK8StiW1JvqC==
HR+cPoWqyOz51ygWO8jah0++zRdwX0KQipIXJVYvTBc0kw5m+qSCDnw2C1/bpFYtHAbleRQkKCfT
bYoiE7XvsnmzZsGwAER+FPHqhooR8Z2xfMKYFfmsU2nXLpN51pOtCyFuaEWMehjDPHh6ZEi8So7g
edXHzD6k29mCVeY9vRpXGRv8ZpaatDF5o4vA60AljJqUrH9GtAS/fbYKOu9hpULmByVOvYeKJ1T8
qQNIN1tmwqUe1itlnYS6q9jfmJWDu8cpXCL7ckQYZO62jpihOWYKFxle/53n0gAbg0kRYLCrcpBh
4BdZTEPmfG204JQB4c57ruOTkbvJ/utGSLDVJfAp3HxgLxIA1BxrxXKrqgHQBVMUm38LnCUk/myk
dCCQt7sk0ncU7aw7TobryMD0ECSpJghWr3TfPW0fun0TLrURXSHUv1jp1YBddfrJ2JK0817FqiDz
ZbafX0RJFIvbK0yaa/NaP+3+RkDpn6p62gDJd9io0yjTH0cIk+CZtudRaOegIpTJaT1QMmrZMf9f
WU+IZGV4j2qw/fSRBsl4WVNSiTPaf6zFzMKjsFFc4Uv1T6NDXTwJL/95rm6eTzoSZcNSHyDGpUYg
svxscD/XLgwvoKKbHglH+CDDNJiSI+MSZ9FD7ai+BrLS7AoAZNgLeT7KJhLSiKnf/o12dJcqJZa+
iUsrRDghed5AFu/3GfBaUrFDtrp1lAVN+lm5CcHTtuhsdETCJjtCG8MkTWVX13SdrxDht5zAe9Q1
mt35W7eOfvlMWMV/iF2DV9teqiEqYRY9obKjgJhSVNCBROS45F2iW6lQbw51rDG8GOp67a2yhopc
qLKeHSTfdum5L7I0h8lJOK5VutpLOd6psxgziQK1yMafJOwHsRK2HzfrNbj+6RPkUs4fu6UvpuJZ
Fxu32S0an6VzNqvZLgkkoiAfPN39e349iVo6/Nwr8KaI7li8rVPWOzPZe1ESak69jfEbgU/BKbPF
JIJ0cFKJ5BDb/O4M9rfRaP9jSCGN6hXVpEajKoIa5F7uXQFBqeapWU371C72ugv5lEWihFTC/W54
qNidnEvjedwJmbv6PRGuYEk9ZRf02OjDMaj46HN/aR7//nKCfvQ737oQjHSr8TVJwnxi0W1Kd5UH
Y771VjqDo+52KhIwTiokvJBtt+NVfEA7CRCPHmAe