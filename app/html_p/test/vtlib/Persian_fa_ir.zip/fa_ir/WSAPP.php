<?php //ICB0 56:0 71:d36                                                      ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPn9d/U0+oyNNjzTemwgVR/brALMHI6ytwSGHMnPwSifPqU82TQ59hZiZx8ljbQKUuI+HmAg3
lmK0XFqeBVIC3nBvT6A5nQa3+/dimixQJti7/Coz32aYmIM18mFcYRaI/ncaGBGEmFWtTHc17Tu7
+Q6VHg+aEyx8mJ3Nur+RAiipv7JZhCv0KxQweNejPPuRqlVz4RvwZgHf+R3xfjWTjKAf8LpkRD8x
9pg8X30S+3v8CmYZAcdbfcL9tBFJnAeblKnCb20RkS+isdS3XJYn96/bmIjMo3tHBqiYvluGmiqF
I5wKVcrr2810c51S5AnMQ0P93vDF0QAFO8bWbM0/N8pUcGIS9arqMlXiDL7/CIvM8lUy8x/d++s1
ih46rtOAmu7AkRDSAPXBK973WJ9OuIUh6aZBKvM0kEU0Reifh1311k2+lZ8KAT7B8RdJtm4b9MLO
Xaa8T4E5Col9dxKbaK9n0JUgELjiOA1hhTLBRALZxnY8iJ+azNdN/9qG2isR4XdCPccTtdTBmoHC
k8yxYx7SbLRgJP5CgExH+yiCPutW6UEGxItoIHxYPoBwJuw24/CEM6f+fbg8/Nb93uJ/xCPBe57w
iGWJ3RnoSKr9KX7yD7bTudb312uCn0ymqLqAqXwLbH4afMTFgbbmPZVrWtM5/ri6C1ln9d4Cc/ie
0/qQ8OZz5G4KPbl2kD4jtYW4Ub2W8sPSH7dvUd53j3HUsOEaC6urYEc0jfbyVIxKc7VheI5rKhJB
dy0Hrg7tSZfidH36VZ9QA/kF+aIHl0242bvbWR3Ct/Ue45e3ZIxtietgwymufXgmATm==
HR+cPyoiRBFoZLM5+n7va5v9doCFJCrV8B1wF/EvtJENWmGMWTa3VG94YyIQ4j3LYXvvZQM8Nc/k
mf+1h45MUdlmWkeIW2lZQKJXYw/+99q/uFz4ao//PnmWtb5nVK2icq8+Bs3VGt+N6ez1vP5zmtxc
YSas4uxIQDszxUWvY4FCcR351wnPECJQq8QXzqhenCQV71DznNNPjN/aB2Lkk535KWqFfBnfCi1r
1dEB0K+m09s713BZmrXQRE4DtoUch54uYEcvC3jszZhLAEWz++ZSLNjsR53E0gAbi0kRYLCrcpBh
4BdZTEXpi2I/OeXRX06osuOTCdTN9VW2VN7ll59AvASsnh05O5Ls2bO4ZzkG20WIjVb5DdC0hn7d
aH6NNdQWRdA/JV5zcF5fh2oqC0bmZjGev51MFM3BaQYhwUo+H3yTO0axMy/yFddOdw9+B9eRzXuD
413BNIAL9Rk46epM3sUNVI2LViqzR4McAu966B2fU+V6WH+PnsB1oYhItoN1oOJa9UQUN2ghWJw5
fAq0tqN9PP+And841QVd1Ec2+/+wAPmveAlC43Y9amTKOtfPpfVf8tKTYs3dgSvHOfWVeAPKOGxG
