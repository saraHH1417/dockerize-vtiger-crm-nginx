<?php //ICB0 56:0 71:1817                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPy3DleiVcGEibWKhgFJfG49TDPuFb3a/rkY9J/rUvod00mMWS2smcAOKVjRBkSUIR69GJWXK
uV3QMNxeq0YEBa+homtqMDrxpKgn6xJ/sO3GZyl9IpC9Q/5Mmfi+TxXH/+iM8/l1ISIVnbvTT1y4
JghpuXBZj2ngZBPSRuT5hTl6uv967kfCX/b+QiMwn9AS+yY+dOl4RrNaMpDv4nxH8sJoqcp33vYj
hNReY5odOJ/2p358qBukcPnMudFb6HsK7lg76xThpn7qoiRVzCEQ47Iikz5Ko3tHBqiYvluGmiqF
I5wKVdzvJQDPuVTey3MhwGQv59Gx/zXK1Al3YJgWxpesPebCdpFQBWuGIlD+7MoLxY39gdUye1Wl
P3eLFh9DoM8wsua4wekvKNWFMzexwztrQ3+OL9zmGKDsT0fBVdKvUG7W6fW7ylJxrBUBq2Zu4VdH
uITP2dPBVPF91lpw1SWZl0YNHA5NRoaJ2h4072vaKAy5DI1Dj3H50BXfwl3V0tivxDTKWfBB2OfI
zQGfh7Kl4J+hbvtwsxSYkFpiB0GiUwgr12ZlH+ssUxDj1V0Jrca9aiGvJTDiIsZswoll3X46XU/J
wD17OagcFaxKTqQUv+xtEYjgOcluEMCRWcNJDMHbVwHnAJZaE1eVpz/tP/CizMsmgKTs2SuobqZD
Ub6AJGGbUHOP9Sp0gpWBvhHWmcInp6moNzijo6ovb3h+CdL9OHw8ynppnRYDE0nkq8ElIa7LtBYi
HAnq+waSLZAEH3LxKCIBItqYqpgaELhN0gKknEXdDumcUks0X9qKVnB2HRBgEE77yiMrdIkiL8Tx
IeWQFRHQfBFLplQ9ujqrioJs78eRb4IKwF/rywABWfoDIJhmMJEwRhyoQWryT6MKuXpzeF28vE5l
bTaD5wmalkWCXGH+6Lrz/SLOCOHpbh/4HqjaA6j5kKEZgeuQTKHbm2CQgv2faloFbVMAsgdC1tum
dVNyGiJoT7W84A3gzM0hppOtCefMkC/mQF+DC29FykGLs/Iq16QdPEcv1XoIOxEXZCvQ1babc3E6
7s9FCALdpezwLYicTrUlhl/pKecgArfeN6HaKBFNL4CBghnnyzRptLWdr6GM1zvFfDmBabWdIvhg
JmHDki1Y4OZqq5J2/mHOQFFYGfdmlO/Sb4wQIOHK12UG0hvVH+9S9JWgXPQ6Vno/37sSW+7Z8ecY
Ut6gZkrHZMXzHGaOI6OR+FYfau7uEXIsw1T1jCgJ1wmEfi92GG/OhQYjPb4EWnjyvM/4ePXBnbIP
nrMFciRunTzvcyXSN0st2NmdIcn808PtwYFauwaJoAT0kj06I/t4yZ4rbvIfBcBup+9VCovk//ua
meTdXeNdwubUpqw4MTLI8G2NYGLBmk6Mn5WrQKO+UwtYX2qEqUjPtp+YkjmF2Ji2w8i15EH6NlI5
tonv39xBxvzvjsyaRssFiyEZM6oDRKRuw4MUKR/AqIVWSexnH3PUSphbrhlw2zTrBGd32vJiwECN
fWUSWNR54ybIuwhhuKWl2Qtp0wU8ZGSxyvJnhat406+/O4dP5blUng2dkZP17Ly1QuwHfYKzZosx
asAgInTZV240uTN7fKc4fw2E3oyMJV6vJELrSEY2EszHuy57GEQdA6R/5t7LEP0tTnsvunnKZWan
CKXq7lLY1VqDMRCRZw9M42IkBsuo/N99n4O8YhpyD777wVo6fqRsauS6d3cqkm6xBUIgjWhLBrxw
B+T8YK6BhETDL8dc/XlK3LZpYJadDuIDOG7U47uYUqCGiYGwHjCgau1inJMJRPHmCfdmT+lZyfW+
kbKpWW0YrWvoTdcc/CfbEmV+OU8ilCMQOP3vXCjEdHW3UwynaxbX9W07UV5SRUe/IBdE8NDEkHKJ
q2ewD+W5/3gd9ynkMf86DMoJRU93i/vSDcUccUywLlTzwgdqLps8thkcx07L/aZM6E8/nOPwSsFK
31sYhKuDyi1ogx9lqOwVHW5b7NIS9DZ6perOK9lbu+lsY+GJ/ssAjJ+fnEn2svTgpQQViWHH+JNP
RssuI8h/3Qa2ciAwVLbOiBlYQ8qEWJ8rNug25fcBNs2GLCZvZ0VhQY8hq/imHckWlSqB47KPKlAg
pY51SQdbtP+ACItH9oWrpP/rX80apWxJY4vscSDbIQv9Knt+YNKh1Tlb2pKTbG+fFcI2lhyzZ+S0
aPXkAInT+ZUYC27sVtxj2kQ+0gR/ii7LI1ZpEvxfl4ktXqL2lw9hUmsrzdlyWE3+2VYSASC2zfYN
nTGtK1ahaxFU9qLVHR9ft7JFUqcAj8wQyp0wKa8qbxPCMy3T6Xh+FRrnVJ7soaxpHlOsol3tgbvv
/0aF70WvISvkwiHXt0J/9+E9g1Mfw3ZKB14FUSmTOWjCHXdZBIvuqaQMG+a0qV/OMvuBJyIOvs3x
vBu63/82sqA22Oj9vuvwIvgiH+bAFMFhzp05ag39KkbELcO9txNj2D9CRCLdf0YC/5AXma9GR+29
4lY+SW6735n+v1OSfeKtUEqiZGn5Ux31wzUyXUbviONuDI4C+MV7Cw0Q7T4ohGwLfCeN7oHGZyW/
4hBdEoFMVzVOuOMvwMRp0aewzScy5zwTIE5sCwQNr0Jn0L1RqnHlfPjbjQTmRFDkJ4qVuM+b85Jg
cSDQEGmP8d1ZLopmDSsPkztWk4OC/SSKvVfUJ7TUazDYyVbxDcQkAPkIbGuMc/EGbHWpH4+IEOnw
uiLSu4T2hcjFpJA75HbZDpYxihoYqb3rEERNfVMi/rI0+uj/2WmxNXHwD43mPiCwzgmxRzrtQUHd
E6aRpGbeLwfuzFIPr8PO1a33IJtAz3b/Tf7Cqpv+JMrRpXMpwT1ogT0IQ3Ne4i4gL71w6qDjM5RI
J6yNx7hIc+H5MNPDbnEycg5TXb5s7Y/n2YDsk3RsUR5Kad1LTnFRQtmmrvaKunv36407P0Zq5tlC
XnSYu4601EkYyCYa6ikYdr1h/zYOmIJy8aGUcNg85MIfm/+X1RAQbqNFtyv8tamrD9x58UEkgoIe
APsBSCS58dujrWaS8s39j7Rd931+vG2PSnXFvbVERLVVt0l7Wk7o1WEACVzlvEB8xEEhP4lYGBML
Grw5li4nJ3tWjVKNt5CRMetORYVnlhMC3o80R9muedel2qDhdj2JdNs5L79t6vzmhbTHrd9HThC/
0vtpw3GnkOik5iC4Nt2VYcBa/zE3AqIDAJCQhcbOIUTeG3RDuujxias8RaWgTiykHYMTDN6irhCN
8STvmxM41WIFYG5Xi9RjkDQqgCCMCO36keu+VkRjvb9WXTKD/x8wV71JHHnAts0p/e102qeeKmd/
6m2p+ZWlVKXn8Zq3o0eg9fCsT7C2NAelU98XkIxt8XF6o33+58qW+YMfqY6LwZVOjhDQbgte3RDg
9BzMcVA1ScMgcO+7bKD/Nshuuc4i2ZB9qBViTfooW6CBbrmin4TQGUcAV/ahM46XSKbUUM5uBaOv
vKq0Q0WhEGFwPWO2P/orB35fRksycCDYaXZOPLiOu+B8Q1rKPBt5YlbtRFfvKJ/a3FjznGBUkZMi
6bW==
HR+cPzOEy/bSwCV+QRPcslOtOKSnU0jo68e3FVjqpBCCdZwsIfpltFtRXvFY0QnWCzd3COlnXkNS
rIL4+4XujZs2xx7OCMfn1VC0sRY8zkh+76h/oVl2PsB/aPLXPyOsGFgRzVurJs0s0IIlQukGZwae
z6j3uILYz9i2d19Te5x+CHOmWhAERVHMwpfabAWAg+ZwHB1cb5u4s9FKwYAfeSSljq1kVWKPJZRp
B72Q34DoaRU01DpGBGi5/W+CHCMfFV0sjgxs0K9rez886yeuoTIqr5qKy05GsGAYfOqBcubJDPio
wn2vutIQTWX+I4Aq+r+1AHI6dH1cTlyL4WVv78nOCPq9tejyeyxCuAm2xf9SGf1JAAG9tZH+Uw0p
Er5gneJEBS/xD1oh8UKBxsV9uu+v8xYZh85qC9xgSQNpH4ywl1rlwg6gb3gVPWdSdxX18h9f9B2d
TmDgB/O4qQQP0ReV7uIG/tyYxagC4CqVxiVuhvo/XzTG//FMEHfPvBx3j4Wj6x/iLgfzD60pHgE7
V9pAe3LliKZ/oymTJ9nxsxmO0SGFC4Q+fGS+xs8eVA5j0GJU7W+JK3y7CaOSnsqYuuJEd/idaMZo
ItgWIDurQh04QgoeIHhECdVZZm7L1wbsUXvsCSsoZwmuazJDn7dJhLPF3Lv+dW6jOU4P/qt/UqbT
iyBHxGFubxEreb2xQdJxcutzzy4taIR78VxR2pbf+cN4LcvRECcbK6PP90nDuVtXWgnmq/aqvjsg
iQE1PubKcph5thTdPtT3E+DqGmZWSOZtWjpaNE+zxrLCKOzCAyVk37XDy4JEAnIZS4MRM7tTA7oI
hRaO0H3EnZBlI4TL5dTS2jcHwnHo3Hju85TJ0tEHxVGiioF+VrrIYSkUn7OUgd9DYqg1zZf0mSD1
J6b8HmqktEci9gFKelDweLm7A0n3CTG08w0lcti49hTipOfTpUyBKp+IfLRvtwAAZXvUSrmF9aPO
SWTjwNFqt/fAqM29ezYG7LG942HiZ160IPl/WiiFU6rZ5NUdyZ3CcmNbKG6r57U7Xlzyjgrz4fwQ
T+4hw1ojg6x6akoHh6K4msOvEeVERbcPNSpAd5uK96lTlPGvxDaqd1hJb7bklxfOzct5veyUFdgC
1linVfZ4U4c+9Iutmj/a+Pr/Iil6OT5a4ugp1rBSicB4LWc+OSEHAIb+TPJD4SQEka9X/cjEx/Uw
VJhE+JgCqiGcVtiZoRNHCOT6QqvPe7fCptMSgVVpTkACyExG8vNXqAbcbRVjE/AGgit/lA2C71cX
CL0oFvf+a07D478NYosUWJzNY0/X5Slpxi4lRSEp95k5+PfGjyWA5hWOlKNqmyaGJ7s9Nl3Z1pGr
g9W1hIDkxUJtOx3yzffOLXUFfmsGARxIwh/o490gEkXoKNeq4w0/p075k/HN/gxe3/4VXs1y0gpZ
eAQaHkG=