<?php //ICB0 56:0 71:dcc                                                      ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxPVTR7heqs7Wk/WaczKipKjSMGElnmO2z9zZzfp3U6RMC6R1beEE640K5ijAnx/bqJ5oN8h
PQJJprZpPruNRhvLaCrC1hi/J8FMAywSlPTeJe2XmcaNZ4wttm0h4G9ENrMNuF4UoKK3TxcubK/a
9aYd6Rc8Wz+AP1xYXORcYkYDc2xvEymx8XvyGakn/7jmUd5blWRI7jti2+1BJA6IfCnjsOtSfpuK
sFblAstmV0wudzZ27Qk9PDHfknMK2e5V3Ee1uN33MwczsxyQGIZmjWuLzo+no3tHBqiYvluGmiqF
I5wKVcnlDW9ghnZ3/E/QAWOnWv8f/zmEXZT5TgJw6oYK5GOR161k7qqIjopji0R7dTZxw97Jp8nT
1hOVPkg1sJVV9lql6FPDuL/JvUHIlita8dBB8oNLk2S5ikXLB1qO01pAWTrIzcjDC55Y0zAXKStT
T5gpFlBa8K4/NLE1alJUuPtYDebgNNs1z5BgpqX36pvutj54qcqpflPrbFYo8W5euOeYSonyVP8o
SmLuvmhhNXWOzXkONrIYMsMHRbBZ6EJoG/ZhvcnG0+t/QA3Piu1AXDfam9sJB9CCmzvZJfP3XokX
8NOVtWkEprzuTVPuPP7uY4Subj4PN6GE6eHx0EpBi9TTEJz4xa/14AkzxBT7uEDghYNR/DSLDyTA
quDcJlX2vnswLoEzVsaXneqGLRbKxsmx82DiS9bPqb6CfxD6JspgJsTnutQlIzKP4m9GxC0O3d5P
naoVekw0I8MI238wTlbUHri64wKOsWYrc8SadFgiJNx4ayb8W7Az2hb4Q2J1uacqQ6xbZj5808I5
5rif66Q/4/xR3cUD1IP125zz+Nziveu4pXyUTmi0IccuoGHJVdLQN8ZgjCn5tMF/PX8DyXPD2ZjT
oO2uI6P8EhhutBwT+PQRDluRdYzPIvpx93F5lR5AFVaIOKqUpKdaGAqaexFcVma==
HR+cPow/ZsK1dNHAh04QHleZyDxBB/m5OMKY7DMvaO6iD+EhAcb1nNd345b1QcOKbqEy51XuMfST
+DYsmwOaUR523t+sc/FDxSMeRq3gxB6Q1vztMhxWNQNEyee0mnK5mmQ+8LNeVjlY4SdPTDRjWjnn
/98qVDOT9BlzWci6nL/RYbmAvga0L/L25x6/kgTJhAmhJyHNC8+brkmOFjnvOe4bi0ZURdGXBNxl
ppXO4dFdiAtDkII8mIMPk6f+5uvDZHubVmkLlRDRc05Dupljl7W6vaxYHL3V0gAbcmkRYLCrcpBh
4BdZTErna0Mg+KJZx1o8h8OT4MPvHA9ZSD8/ouf1ItthnQU0ffis7ytKz2qgXb9lUo4YjSHkq0xb
U/vgrJQZIk/3fVkP4oPowerSq8cPWWYhLsF9TiQlHAnkcPbnkgIZnwDx7JQK29GleI/jsk8DBvW3
NDlDrSZM36xEtxyHXQKcnOsWYzlUm9NFNNFYJ4VmVSvIWnLR/k3SKH2PWeMwalKJMjE77SgdmJGP
94IOLDh2cfaHvxCbYrX7zoaO+vQy+u00EEtgYd2ijWwY7DfN0fjk4h1T29mvnre+oQ0KlUfrquo8
M7qQRaKU1IXBeqgmjtxHVXhJtZYyDvB581K4BjKchKu0newro5Kd2BvqZXjrD77ILUDjQ7qu89na
aMC9y1ttqRJ2qWhetDjGqiNSJluIRnJMZ/KGn5J1NR08dw6Yu0fK5oqAgVivykcz3+idzoMcyg5/
aG==