<?php //ICB0 56:0 71:1dda                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyoSm+ZNIZZFtbXMo+IwJL0hRYHr2BWQU878xKmaD+YXFpv6uo2Cbyh9f8bSYcwP5QJ73Ovs
lbg/g6Ws50WMILmRnFyJl2UUe0AIZqxl2Rgf89rREiANfhCHUcSwMRS1uZJlI/iaSMvpvYPGLiLL
ObN+3G+lVSJaHmeTGnmZYGq7lCCSSrZfbuTql68aqNm2jYZTvweUwLn/UYmIf1oLKWoK0lJ7Lfel
77UDwDr2GI0EmCju/FSoE5Io6cjQySWnRHBz2OkKbhg4qtE8YeD+AjlSniWzqIzB8kR+4CBD3qXU
b7urQoU6vbofzAid4uC6COEIFUb0Td2+trg+WHfEL2+ZXsquBJO+ueJkxz4PZ9Sde/6Bg8VqPdkY
4RXmPEecLFxhR1wlKtbKWwc8HHFVLRAtEWbzRfqsUoiVJFBa5+3yNmhjcsTmlR3sbfrfe8DEQBFM
q5Zahtkot7p5FL3kV56B32O2P+N96sjnyC0E+Dj0EZPZEzpQKlohwCVzX+p39GrscESsb+CtAl0t
9H4SnywKRU0OxhusHN9OHipOx9ki7xn7nbnSbN9KApbfnqcuRcMaC/T1ZGYA9HuzqBo7v8cxzQbv
xCNdDm4dD4zFre1AI5ZQVBsR6Dar5i9x2PqjDXLJzqvt7/G0rwqEbypcuETuhbN/aEX6bqJdpkBW
MtHZwe2zH+f+C3BmZQeX5rChUUx9hbQyrsZZcteGAASqHMoXt9IRxWHUtvNJ6uJOmLWO4gxiLqpK
dprJFUbSVQoOJjA/OQW2w2EUjMybLKR/nFCmnVRFr+rz8NX5dkM98jgmMimhYrU6dI//U/TTXkqa
A3hHW/rYkhH7Qa1ywkoHqVV/kfaqXJcOTAhlfbo6tEo6EK1dWgHid01CPbcYvRqSB1WnzNm0rRs6
DDieYA0FmRDa6eUSII1bnjuG7czNhXa7LEnTWVnIxoybMHlGDMisbI/fhdpNbAnHlqBSV2WEoEz2
Wc+FEenm1INST+5cdTfCRghM3i/JeDZ/vZc9g6/Z2vWbybPizaFanFjfP+rH4LmGD3g8lkHpwgTe
mr+BKYthiy7fY1d3CM6j7tmeT0+RXHipe4iYnYACU8/01tcwgDNfQvEJmDjaUfCnY8FSJgUPSJ5j
LoImSSGuzKlk9c8INUQaH34kA/vZuCwpp9MozNcb/53WqBdSRbMWdQaeE7i4e6/X5NgPlrDrDsy5
xrqRZvkwC2ecTzcjnjKVrIplqdRbnTY1cRaBbRBhn9CxaTrKEjqL4uYDHl9nI6SEhdt8Rl8cC+KT
LAHDlSPIcEOP45xaDrRM/EMTPZCPUfGeoiXj4b2J86/Sb+wmJES+kmntluobRsx366KQR0rRH2zr
8FzcwFpgcEpDeF2kw8vCDbwRTUl9TcjER/5ezI7EtlWDp4xQlgGmvZlWG0lwTaZaChCYvbku/EL3
aD0W35WQbBJGC+N7U8EP0d7vsWO8CQKUCQdSni/Gu/HfjVeCo8CXmO1FblGE8XPUs+J9LBOk4SzV
NiSQ5/CSU+aX0UBVU3/63Cba6foV30Pwoy1xqSlNptS5LlGPYiJ+pEZvqxtwh0KUylA1x1pUrmCB
YUThh1BrZ1g+LCXIHfe/xnP0u6/qFcm8HOj/1l3bDmMNemMubAEpAKhDk3D0rzCPyCU3hd5YryVy
PDHxekz6nir8vDFSU7ThLB/m3IRIi/8pXhW7SvOmhf0e5YpDHTIxDSw6BOF0Yex2bqhmh2OOw03q
mg4WIYZ4kUf8QEr1ImB1BGtwy6CbaCs679A7WVKrFU0wCkewoCjDeP9f4xsdkHnHEVmaDhgf0/U3
qCJwYvG/tPE5CG668QdEgZY42z4xzkhWepVwqEwO2VIzKSiPZa47XxQn3Tyll6AAQ+vu5Ob7b0b+
ZBjBcEhLEiT9Mrw2LoYPh+7vPs/xWzI1zfmJAsWuj33B1f2B0nt5pAdvtJTIsWPDts2U49v2l8EP
2GiJeQUiJpFVHeDQRZAsRrpn9nj8SwrGkzk7/mWOBKNR1CmZWTvI8iMyJ9RPpZAyX+ZYZaoiCco3
4pSTwOE3E63/xwEOUILUs9vfjk5o+RYhxWh9slgTxAM3JpyaruPpXw7ODfRmxWvFNCHv1MBv0KP+
yUetkKrecsOVm5ClEDqDQSQgX3h3rd7VmKAwxmi85eM60SWqEtm+UocvGn/P2IqC6DGbfnKm+b9d
jVvSnBWLjuRnBjHCtJYMet2jBPfOzZZoTpK3w+IjJw84WPb4dd/WrCzkr7KxdrKPT2A4xT7SYlRg
rJAGM3T55OlWyYyIDgfkoZqo6/t0Os5olommjX4wkhNtQ8lAzMoUDiMGSTapdr9KXNjoGSd0GcCG
oBKzk0RKCK59j47o32AX09oWOOdpZVXHMTCU7zXeNqO8+R+HDr67bmujr0wTPYa9iwjuarXq/vJ4
ZaRk3CrYE/EqUFUoZI8b1RBEtz2I1s3+xZkqobooL0zM6U8uwNcFVyA6ilPx6xBUUaLuhnHum4mu
W6V8krcNjr6jrnZlbiuWYW7wzAMeMmN9NguNCTvBlHrJbwCN9fHxeDQucjyCeg8p/e5u5+JSKvP7
KIoMTOBf6/21qBQvmzQhFNusHvU2jtG0DzHcfpXmcNSdJOKiw8gWNB0PFU5OfnaBB76eJTI7ltqi
wOTf/rOxtzQ+WrJI8qH+cff6CL0jB1/My81niul4ODQ4W/bFS4lTDgY1KT/eCZIKKoJC7XQrx4+t
HWR+of6HRSW5BVvbJFulioPp8qLgnI6CslmI2mZNNHGSfAagNLicogunCEeD1ldiSCGiVqPlCGC0
68OA9IDrI9hovub0IOC8k9cQv4eS9uMpMwXuDYv26o259G6odGNYBgx55pN/YPxxOXFj6w3keEDl
zRMEfzJWoQTTsAGR3l760xHAUpum2BjftolgqMiXxhRR0RfvbhcVtS1QoPRL+LoIG3IR3l6rLCs9
/GfKB7peARNu0Aum3tdHkCFr2WoBqWYhoa/nrI5uk0RaYFP6qsJwK8Eth6S/MUl1+XYg4ICVrjlo
cP23HWd44F+hoD6XDzsq8gaQxyYb9Ln9b5YjW+FxGcEDuxhYwD3Ls8WNtt0FWCC48iweu32ofs/o
peJLa1PUKAXhzP2/1chS/hU8wb7nP+FeTAQAUv0qb7Dm0gzEObuzXChkT+NqIEYAm0VykVOihcXg
wHm+j2hGYh/3l7Fk6GlMK3KOdLp0AQMJ2bRVqhQ/dcj/dcdjWEXHf13FvQXPlH/sxBu/nCKmfW78
jJrhG8pn7osqumeEIa04lvKrGzgcObewCH66f0CRoIThdkZjOkuOEE0udaflOf/jgW5RnS0rC+Me
lNVjmS7L0ntORkFn0nVa50QrrlKj4q8Aoy5lo36WmUviqrX+KbmjPCtBklVsqFORBEQGJH3E2c7k
89xhbykB1pUkqh4K0Gq0tQnCwF/QA5JHvDMzf9WSV61dExN/NWZ5Npxy3KTC8udIEypgzsqgVkca
Baw4KkpYFj3QnGjUeL20V+HZUiGAc8FYkpD3t8mrDa26H0S9hGg2AbEsx+bgaQMkTvI8ts2gk+dC
LLEjYKSjR/NNAl2Ja9xL2heUoQc73qX6i44GNVylqRI/LPoELQOXtnJ/mOctAg1dc+kUx2ic8yqB
bF7/MWUxJf5hJQjAlAW60lOYFpKNG8JXD6FJBc3NGiwwltHmN2490CkyoiaZOKjL7sKXjqq54sH7
T0IoAbQp/LEF1strWYu6JvG32d0a2Bfa9x+FENV7OFPNvqi+4fjlxQvUZpcVageih/hvgSmJc6wZ
7jXKsxDOYZxnM0fDKh8dWbcgjGW6oxK/XQdB19cAZ6YjAoFxXwiPZ7ZXLkeQ0DX894Cc5lsIe1mu
gMfhuhP3Cdq9M09HZX8cNYTbGtqgk1eesFVQk6VDFI8BXKLAzDeiIIgpOtL2FGIrSFmjwDewX0LZ
XuAG1RHkeDIY7VVDcpgsOJZunL9aWEBAY8RYps89gXk61ijKaq4KPX+SSZDDIBJI/nLwiqb3q9lw
3A0GBNE+T2wREoPEECs9nTnqkKz0M/13lEQjODT/EGqMxnzIu0JmOhyIDuAltT83deieQptdjFZv
fmMwngsLWcVUAcrvwAilXW2rw6+T2cBoqcOMFnWHMNkwtPLeX7YVmkZ+sMTlmZYOgIdjSfoe5PVh
0rqadiu98ZDhcpSKR9OeRRLMcUNqLwQjv4yrOYosvnHP0wP+2fg47WVxRFIg4MopN2EF8ctCT7+x
dthQNpVQkJ1xg3Vj92Xy6qv13iM2kz9ROKobSd6BETuE7BkLWb8H2r4n//8Lt+CnhZE6f4VQ08lK
FklkCRY6TJ6pYTA64PcQo7Jf4OluSC7BfOu5tEHZdbaOvzQK/OIldAFDs1W8qU7FKkDJlXMjEsT2
dHBxklJBlzQfJ7XyGGURo4clzVHHfDcahd7MFvoV/2rNkeuWV0OGdd1BNoeCuXkPOidRPRSZ2KFu
Xh7l8VzQOUI6vIRd2C8pJy9CunpsZBimTq+xnhne5MHjZKruR5+mnu6rJqSAVjdjp4FH/GAY80w2
EZDuC4aLd0oGRPC1uDqvSV6qP224zqIDNC49aPsLJ0uYmEhpWKyesLg07G8NKnDFl4Qtu0KxspVG
ruYwNMcMwtUUcEeRwkqXf7v9QuCq/B+Dib1nnabprvOpWqoRPd3frPDnskg5VRjzfDlKHkPsMKRq
o9A52+4isQRFEVm3H0orG1iiyK8gEpCq4bPakEkl+R5jVRjLVuZGOIJCPr/cQbfinHEQ3gb3x+eQ
b1WKRQ7bCkxE2tI2jJSB8hOOAG/wrJyIUM+U26r+Oz9H5Z6DhfuEMQGaTokDwLfdNaYm1f/CyUMH
PZzr30qg/nsdQHQgE1370R/1qMq3FG7KMl4zmpykbPL2+TmDNJFdLfwlyK7Kp36Kdg+oROxfgbdq
GCWQZ2Q49jPVodfRBtvR6VbKuISwG4wiXBH3DYiOfUd8T1Y8ZObFROQqByO+kChyEM0gk+EcNLaM
2sHC++zOj0Nm6O4==
HR+cPzZhfIswJnu2Cr8m3leMcg86FzXyGaLMxSTMALGHUAVY72GZwyKY2VysY3dbpPLo7Z50toSS
7CTDHIB3+vXthiDJh1Gc9sgoUfHf1gFNEPVWzllzLz/xI88WpYxYGVWtgj8M/jm6diPNNP4TD0rR
keJAOXZziYx32wfbOzheIMegy99qJ+ziQ8/NoaqrYLDF9vpNYjfoSJE6MfDF+SOs/nUsPiIirdiE
kgzHakH6RS7Ay0wuzAEc8DwvqyMMFY88M7XWcjzCgFcGNWVX9jNODHuJO0fGtGAYfQuBcubJDPio
wn2vutGDSUcFxTkUROkuEqk6dH1cMly8i5XjOvEelGw4U8Ypg88Cjn2QP4nDsy8vvWh+atpipZRq
Nmd/qLx7PNojL2RhBBAohA2jzJv9VnFRDXaktVcAIBE2IynnlUqSYtnx9IywRb/7DxWFc1R5yf2y
52qerEPAd3WL4oocQc5paLYTNkMREgcfBZ9eNDLgCHsItwtpVW/m6dRGhXC4YWzgmQZmIooUgChI
J9aEBa+brEXH+6Qk0vHRACUBJYLFPDnJ7POxUEzSmyquk8A8LPyacrVxyCjDJTwmv1+REGARXvEJ
6qy+ZU/J503PYYtaInSBBZJi5yp9dtQ3i9LY824bwuLrQXmdHAPD2Wy5Evbql5TTdDuExDgiDiHX
eCaWTlz3oAhCsgNE0YK4LDXemED9ua0cebE238Aihua/PnKvuJKZ6CvGGFFUukRCul89awtus0WT
z5PC88edRZS4dP4WEe3h4ihMyu7Ei7gmrrtQHGZJ68WFVZdCjt42AK7LtoTbwZBHfVfpJGqUrkwu
hmOOWVS4uLzo0u/TcxIWXQTmpI5+9ij8Zc6LIR9gJX1tnRchvzSAkYmA+BFMW5FZMnyKAi4321De
lSWVhfVV4Gj3BSYgQ76oCk10RXt4nHzmrPw/I4jNp0K8b35A13v6C+JXMNVW7sxPK/8JqUQ13XLH
GHWkZfKr4WgxFMdoc6wu5gFnzrwjC0dAbJ3/oIqjwljm24L1CLN0xNvgmlBnFpXrZAL/gmTlEp9A
Pkxj5Z73ZjRrcd+NcoJQoUYdGqMX6U2kl8543sADNyypfQlCrJgq4JVYe7gT4gYGag00KXYgof4I
yjJ5iU9VbCOkQq/xbiZOf9l+SnUqOpR01wow/cz71f49csHp5KqtP2tIO3PCnlBMVabRQ41H0Gm4
Zgh+Ec9Xvzents502q61rBCXH27HxhBW5njwNqGAANHo5f64vvNCHuCVKT0DsPLClUt85I3QrbnA
eMkFSGg2q+cmJVOEz73oz+gz27Yk941QevADPAsfd5vYJkkqCC7YnAsPAhpoxmt8SHan6JIbS/+g
K7Spz7hQnyRlrtnE1cZYBnUSmUjQZ/+LjR7mYX02zMXJMC4nlOnS2Uuv9dmjlkHYSCea4JWd4OXs
Ia9H7UTA9HuopYJtKzSTUrpW5lSTgrpiOYz+p5DhoibGJCuxj9Xdv9a08BEIQa5yV7kGT+45cIqK
1wNWyYYZJ18NWrbMCSvFzVxOGfbJBcIp8YUou8YTwjVLqidSjYl/3fgkS1T6bbebh15pDRI0Y7hs
FGd5rDsdnfQ5BmwX1VCsOh1uNyTRGoO8eojp2xiZY5GIPRvsiH5WmKXJgRxILqqJraZLRH3lwUFf
/Ta3FztU3sQtNIgSLoQcyX1wtHf53Tut/qaG3LZ2EzYDphCXKl9JYKUr3/rgmm==