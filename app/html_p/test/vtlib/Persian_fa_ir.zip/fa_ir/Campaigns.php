<?php //ICB0 56:0 71:25a8                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPoeXH/jElxlyP+FIs0KnO3vXUW3ybNxMGgB8GFgembUzHrANXSkWjnBKkKI2JQsEy5v4kqgL
84hSNw/1flLd18U9T1Tny08hUpdi6I5SErdy15fXLXL9icvDtfc13pANRKjEmWKvWuxFuOvlPz9S
gDCUvseBFu212SKBG1jGhPbMyleAsQt3o3CYq6BVyz/j2CRkgNW3Zt+j2ckuaXHaRM2EMsnuzIJP
PdiEZg6yUxGfFKFs4lntt9pNqKXbRY/0hiq+7JR0d5xal1uZwC0/a0BLUSWzqIzB8kR+4CBD3qXU
b7wnRqkJNYrTRjckgha6IG+J1pljkVO72tBQNbwiJBbh4cX1vqvWgRyfEG1hnB1Bh+l9yDai92uT
nNflAl3svl/obzvKVK9ZclFgPC95ceSNAiChqHt+/+j1+p+DuyS8P86OKYCD9MeeLm5/KhPxZoNl
rkQ5LDuUWZvlVmgIx+Zb551jov8Famh4gT8BElwr7T2YVLJPa3q7kKVb2cZCa5c94AASSOLOyYcQ
eSFm+WjMvXsHtqnrePGzKCH++dcFEABwoo22zpTDR6tkxANl6TDOfK/LDrIZnZ+eauEZ5UeaXcX5
IwnFa20+7KMT0aaSsdpT82hlmdA3NTploKucMWPYK2G0QFJrOK6cmgTD33OdYwELcbCJtsXdpDRW
NaGOIxtq8ZgQVXiuQlPVGAb8EnP9kalUkTigt8Z4UA46ZLeJx5i+30ZZ2FZUuBxVzrj3yWoeiW5x
TGXis3ZTMh+1UX2k5ZeOTdEKsidTERcYszFg6Mzu9ewzC2NoF/FDIVixNRKGlLLd/ZdhWWhwq9Mh
C4FKQUvZN8NA7FOxk7D4JHHHdbzyfqBbtDn9D7wTYE9l2pVQcRbBwnJryvDvUkC24bnqT+mzLAUv
ho0EunbFsA6NUYNI7k/OSpjwpHj0AA4AUw+VLefU1QXr4BINvNgHdCu/B60kCFAJ+n8VngBe736o
GMGFxvfsOXG4BwlFH96NlmcWqX6hm3DFmWWxQUYPxgopK21K+aXQwDleYNH+EGTq/jMhsyFiDXPX
91fUGkmMYnQCUW6AGs7+tRmnSG4SYXCo2FxEXRLm0K6GYoh2QPsClNEd7K/cXtU/5ceQ+quMZtO8
ErCiyX7XipD4EZBS2v7x4a/BFwygI8XPnYOk00ezXAotMvtXFeUv2FstIzcKQ2MU9ALHFRcd9lnF
ZxDBESYJxfUYbYFhkVBrvF+4l7ArdeaGpnkEARmvKk5fM9riiZ0jOBR58XByBHcz3+7zWTM7teE5
IyCB6dvoTEAB7G0ra4mFKvjd6heEolH/QcfAXcav61XHNdM2oLhitrANlYB8Y1GfaiqYS4vP7hmS
TIOF/uyBlEzqKnxjeKVgY0yEDqc5pGWDrgAGKGb0PGDMo+OtJbvnfrkJp5P5y8tNDt9E7aa/C7dh
2eLGMnkFD+Pm+Hu8yjxS+dJ2HXFG2uw5hlv5yiskRJLZzNt8r8QP3QVnVoj+2HfK5wcqlZlmAkJJ
x0QKbaoKX/qR1DBLIY1Pkvn0m8L45ho7O7Ne6yIM4VUBBf+dudjI05fpyH1Aclf+dUZEMJrUeukR
nIbk3x+vWNPd9tc/AnbPVp14v062tz1D6QZuK49n00BmWCAZeyoEX4KCiNm54H1i9E3pOXyjlW9c
FMDUDGYg6h/GqfL3OWHmzenvAILheEsaaGZXfORGj7TeDvq5OG10ExlPxCLiItZcxVibqNOz5pB6
r8rG7SbBgLFDysvTrJ+rArmnuD9qjwCziddH8VWIce5xlIva5XccX/8dQw4X5nqlec+7icXbNuEB
rMJDjVs2/+CZLllhvvDW6dvB+wznpgEN6ZsM2ErGMguD5aJIkBMBytJPsIrgQO6Jwd90rIuCmt09
C5hVruavZ/L7aXzwNjf0ibmjtuhlA8fV9DsEP8h7ztc9wwcjd3dxQwoN6Ta3pCF63Rdn1Xnh6jvK
skquIHxD8VqG9UzOQkO9EoggmaYVFw+UeBK/nq8RuJIvRtaRIPGlN3aqHfIpP2+xW+/Ei6XJUSNd
FjWY20pjQnyO3+FjyiY+lAjG1kPRpS/3SFoOUdM8CB+OwYm2p60mY/fVDlMH4vm5NYoLSYhTieBB
1nMwXBOVlY9ih6c/lRU3OLeuhifHB5CB2HbgEl4z3yP97d7Jqh9p4Py2PWmVCPjOIZvpmLSZO4o6
X6sMgUHT+XbgovD7/nLPnQy7kwb5PmqsgSffaF4hL4LcleriThjuR8Xl5RPI2/Sv5bYsLF2b5do2
7v/ZOjwbPEsVVOB5Jr4r+wNmgRssavCMnBZ7o3DINoSnJFmqCCQXWsYqx8JikpAeDBghLFbpsl3Z
oWZHZnj/+LBfW2qYAUCbifmW0oLl4X0+VBp2k4DOJ+miqQfhfLdOZMLY1D3e/WPvReuvUzTeT4sr
CLhu0vmvTxGhuexgNLbkT64YotecL6hZgwN5eYgy3Y+ahsPwNB6kqA6Lo9uBerfzYz75+cHKbYq8
VJ4shEbUCweRwk+FYOq15EjsYlCGjaUs7HjSEFr8ZTTOV8T6lJHB2+I7ASzecRH5DWBMeve5iGMt
KV/QKOy8GSGI7JurX94p91EBC20IaBjE753Qs1Z+wfBqcoHZgB2o22ppOWWBueN4P5a3n2g3qb67
Jq+2B69fONJWdbfHAZ8FcnExUNhc+a4KVOk5lB5srhDqq3T28s7NJRXr9mydFTDNsKVq/EjM3FJq
R/EVHDAdzkLsdXoct1c5OOf1qSQXBKBQnbyp1zMEGm2Y/EirdIjQiAJaXVzxG803PwkSyewKpwSi
moXurW7l+c9oLDKslxzHycUrCvBudv5eG1ESI/0243G177JwjMT+Mz9SEt7kEo91wFLiZ/KDHuS1
r+33l+qcbfo/6BrFZDJyQTTdTxu6zY1ibu6bODaE/Uo8MZXIusPd6QcZJSQykJjY9FCGOC6fgsGb
LNlYEwyo6WDu4rShV5BQsO9vTll9sWm7bfXkIeSM8VFZ+ga4Yv3lZCMOlIJnZOtG3BjM3rSFEfWg
R+NqBPZQ73V4cjig01ghXYjDL6qhgH7ts97qjCNNh60krYrGzmiK7E3X0N9lYl3FQaPPSQWa9EvN
zzBYFil+PV+ItQmZdz/55RuMJnKIS09zrDO5CoYx4d40AsGZIx6jnnW5caC9vvn0ycDQUBScf0CC
XWq1G2KzMH2hSrTNOAzCTRys/dHH/ECdPpVEAkc2y9o2AIW6C+iRKgFjd177pAUJ0imTK/3AICwb
lJxdZ4o7rSN90paOUi+TAn83hCNZjCHWbyo+Lx5jke2w7lnwYYMjnTZC2C6I4vIygnoBwhpX9kV7
uassVt962L3R8SCvsYyZlwtfmXZzeqwGvWwLxTL3SYTcWBrwlxgZMkhyAnF2eC/S1C/125B+TBUl
pK0LC/YzLjJDCjrR7Y8jBo2Sl0ly0s7QtRh/5lTt1m/jYe8//uvlebR4YWqQ0kKuGU+vel5SCYpX
V+XqVlGSjvnLAs8vhKVe3wgMp7wF0NnirCazVlYSksJwu2JE9/41DoNKmeaMY4PFi/9wv7k64lhZ
IfQVQ7vNlAHS/9LeZdeDox/oAjsUq39Ho3GV4qCSLldpjux7YeMG5Jf1LLDIbv4Z3CwVCQvAsgBQ
KnV3L5+vx1IiZFNgA5puWzxgg+LZkty6rQDO5ir+/g+9ZdJRgRnG2pXDjTYCIop7xjJnwloX0F4c
vqpgBN6E3rE3yXC0TUjnBElL3U2AjlOuwlxTiCo0RWPShY44QtmaKV+upsNis2GRbzLRq+4wIhBa
BVZIUFMSEa3/zKby5v+ozzCkHy4dqWCn5MeLEEmER9vs7Vk8OH8WjVe9SCzOo4PoPMH82IeiIgv4
9meLTKzJulhWDNA7qnS5KhRdGXsfx1G/8IwFXw+KvCmXMrd/sxjHf1RoXZ6FK0UIKndHSmdTGNil
4kLdZozjdyeZWtGWVThIgL4a1ha60PJ8JJqLkfCKEGidgVR0hfpVmyEiwsR5YiCv4pEgstKuHE5w
JspcM6qGBROhVqLnabEzxSw8lFmzXXw9Uc7J27bf1rIhF+Y35YAAv/HwdxEGSdOI/a5NgR8elqoJ
I+FTYSH8ezWOoueetggV2gcJBN3ikqdXVNmLg9bmGQu5Y5gELF+B89Kjw1+xlR+oDDnItgpKFuhJ
JKvQKeskpF2gdr/5n9AgqcCIDGUxV7KblaGQpxXFKgKBu93OAjf6lygOTxmmIr34FrMBPxRNtPRd
nq7bW2Rk6+Cqx1PSJswrMOcVqPhuZ9u4WVTzG0397pC95RBeSb81v1vwnH9qlAHZQ9/54IqxH/cV
XYyraoyDa0737I7z7UYgoiz/w8fMmzX8SUO6oojrcHkEugk3X2CR+mbhMDuWby/lS7VMHIxSgpOZ
u/EBIwvxpxN842tL4mRk2SrR2sEDioqTI5UwIpaPdpyAQGK95jSVCGutpe5pRVlUcEptW73QpbeK
Ceu5CsDxZKeq1dRPUsZMhvGPGoni73dkOgOi1hKQTccNuTn1t6TTVRF8seX2LjhVx/bOPcN2ZTex
qzsqlcPKqeFk3Ci6hqXlIZgyGgw0Ygs3Z8oy2AI+fwovWYwLxR2CoWcQcv6ZUyWlU2Fj7Mdgsxx5
45YCRoFoDmBhe4urUlbOUuxFlhLJVakmhSk+I2HuQ4q54TxEO0Z4AwEHmM3w4kf+nnHjlwWkub3L
fpb0NitpKhY53ltATobYU4bYCW9Xi+WheYTKKd2lJfe1GjHs/jWN2rfZmzpCdF8IAOufZDTgklIT
+AyRFs3mxbVoAxC88Vg5SUm7kW+omY2OV9VXxg9RIz59hbdiUOU2LGg6yGZ/OXvEJP6nvmKpfmon
SttyxbieX3gmB5zColFVWGm2irt7QHoPOtGMpJx8PgMErmwJuuFVMWWhe0cKKKviv7KeRqHfrjQv
yTx6lH/hs/lQXXaCQmrp6q2rjlbL+LfwwGf9utBZVMfCSlacqMUVP3NEmvtuPfB74I03BCbhVKS3
Mj4ramXMOSUyDaW3rkumBEQKEtivVKOieqEZdg8mH5iWb4/2XfU1/fRplqnfBlLSU++pmC7fKrj6
lkfuUo4wyA7a22ZTcwCoo+wEmuvoBMv/JpNdlYxvHNfrA1saBIeSbKUqrtiwgLjlBR7HVwXpcHwy
FXt1K344pHYFfg960Iif2l/y9duUVENaWYN5OmfbDuw5iUI7fvJvd/zn5j2abLIQvUP7VopjylUI
kIdozNSO1xpOBTAEy3CEwe/a/SoeB0DSAsjKRWuTb7pLgdD3Emu4OaKmhoixEmvSim7wLCzlypgk
P2Ka6hP3yzPRgB6RKV7Hre4mkeoRa1+bprDrg88cQu5IogPZO/6uHTtZZxC5eFAOoE6hiRZPdJtS
zkgm+O3DzyMdVabmVoZgS39UGQyasYJ5tCTAGeH3wqopKrz8v3f1AR1+hQDW6KEJ4A0SeaMZmpaF
b3cz/x6OEVoCv94+aWM3s4dzV8lKOD2A4u3zqkd/zs0/bIBkZG91DJup70Wq10S4XKcK0WgZAhdw
MsRVsPwNCLr7+Z4NZfZ65BD6xQAsNPkUunArLHw7qdd33/Fq+K0vChGthGg4O/XEtbTBeeHz005+
9A9nV9u4O/nc3MJZnuDUMonMIOrJyJ1dkBhzH5FcP9X5/+WFzJLUYrIBxatlwwlI/RhEcCDbUSKx
tR9GdWKQ8GKMlAx5J963BFMy7fA1GGsPQKYG6CeUSFmF1xbZVF8zsRA+zh7c1uemQrPcTsFEzB82
4ja+HzPxnh22PJ5gWR9XuDeGQV3i9yQteAIZRlzNK+cKtuGtgs4FU3/O4zNpSZxCAquFA/mex06E
ehf318n80Lzo6IzVRd8k0gFookVNPrYczSj1GKyiSBecQVZzn8f0waMGw6yc8ytO8BNI3aZhui/u
Lmt8u+LLd1m4YPNYakKBx/TbhK/uyAHnHWh1f/FRKjy5EJGwlvRbYl5TrcPZJ9pkpbnUY9jvKXCl
WI4+9AGknJjPYI4C5Nx/hAcxPZDM3b/O+DVPgfCtMN4X9+NwQI1RVlJ8+V8d2egT/K7UgUkt4EJX
cbAns9FeJbZ2z/6/hxm6v/JPmfW8IbYvaThGTOgTjYXAi8OS6o9npZbkFq/6R1Hc4BHQPi1HJYT1
ffswBG00q8gh/tqlN4tZRUq4Qv65Ku/djpsiTK4QSNGkKdv+3c4NIn4d4BdA/vBTuStYhbruCDut
Shjc7nUqs+xMoSw2wjZ7jEs+ModmIbTzK8+Ho7zmt/hh4yrmXhHxwDQ8ES6n4kqLee3pCLw9w3TW
m53vIfMAr6CikI4IRIu+Ommlx9RYzSk9A5VgmBcw9DYgf96P2m7a0hzsEnJceuQ0TH5t4pacNW0W
rEEnfjvsx3IsaP6otlwo0Mq7TAAUMck0NID8ZPTDAvVJMDB06byQ8bRYnO3zVn6tbsVLR4FR7ZTB
PqpqiJs67QJBp1FRvJ0q6jFxhqpK496ehnVrxCnD3o1iwe0bcd97sE2e4UbnqVyfW9IG00WWxkKZ
w7dzG/x7qFj1fPnfCxD74mAnxXaKeC+RonbJA4fDywAkTQJ5cPi1V4kL2ifPXIflPlg0WJqQPQvl
sa2jUwi+oP2VFZ6urpe5NNy67noXATEDYjZ4czngTi/UMpigwdBYuN6M2byzhbsJPxhB7AYcsKNB
ShEnIBzR2VPEW9AdXBG3t1YgQ0vogNJDo3LjH0ifdEPnahuMp4b7+bfwBcCaHSr7amf0Nt3BLb5k
MiotXzfEk9GJAkNJqYnX+tqLTAlcUPIsIoMgvYR2LH/yUWkBUNCrBLAui6YB0knHZ/q2lBGEQh9v
hC8J5TCAEtMvbjDTYNGFeftFdvm6T6xfgFh6+CAF/F13kWnVut6rou0MuWzN/etkC0kBtSI1L+yP
wWi/ZZ0DLEkZXSxs08mNTIYp4P2iNXj5K04ETa/mQf0DIhTw7ySuCXrEWOMAOJ1Lvp2URby6tV86
axeKhFMnCuC==
HR+cPru9RlyuBUzIyLYp+zn4Mo68PbqYOtvF3SA68rALDO3df3RHZW6HnnFTvbIj7+8PUW9Hl1fu
8Y+A5PtiHffHQg9fQ7U0VynxBCVDQBxb2xZrBlzvcHc0Cb3RjoL0xkjx6SlpNHRzjHQW7wr1yosK
Nc+oa1YUbGKdocRsC89BkjfklUQxFU4axWYgizWDti96fIOx3xWTkZZ1eEatb1VTS/tkCgnxMvxm
u6l//5K49XTDeLN6CY+bGxLO3kes/o4TsE8fflFeTaYD3Gp7H11LQ/eh1PvG+mAYfQSBcubJDPio
wn2vutJyR+qExblPumQUu7/sdxTUGJFDUzHWMY4kKR4+iKXzNkuMhdUBh/pnIv/6dY95bSrxrPrG
L94WiO34zaqOwDjBVjeTjAo1uqA6y26xpPrz4jbJazS7mDNT7A8hT8XfW0pxWZS9rp4s58P+W1W2
ys4s3zC6ENZkDsUxpPx1GUaQOouhB1sTnyQP7WOThSaFK36kULB5NfXexY7rLLae4dPlOox1hjYF
7vKMc+O+ZK91V9F/lviL1tCbuqNy/Z6NlpwXmNkvDARTpou/4XWZwkA2N3L4+lJzwVMyGjYs4Ine
pUse0MxbDgvdY+UVvczCv3fx+pf0CZQvW8v7b+OmxK0MxosxIkon9jAbjRIHo8t05NU+A7X/bOCn
BpZ3ToPtCcm6j0LcdU+T+691BQHaqZyJg6N3Es3WrEQ9WqwBT3jxr52wGVxaqdZpaP9h4I0SdAXN
vweMdNJkEOX2ZvmuYqfolLud4peIdPgm173p/xi29+lqqdXSvpRU6w+kdGeiNT9B085U76LOTcP5
TfERWHUvvRXrzeOjjH174uTefoAu5Nsn8x+Q6ZPGwjROMZ/NbbFEY4UmbqFVdOrd4F1Vf1yG3MCS
hQ4klHajGx6jxwSRxphKeFlfaXNZ6FLycLSaq2Jgh6ZUBSLmDkjFkm9jjipUwpWWUerts9VthBpY
jdh2luFm7/urUNYvjmeRR3D5AIvLLrzj6QRqn8jAOm17g2l/od2huzBb+X54x9RVRbLOq+2bAyt0
q5G67R/wx+bCRv3rLu7Ygv+/1PGpzRaoDeLP8dHHn/S0YOgMeAKAui4cSitLwbA11iKZvvA8Dl1L
pO9o+pe2RKzJdOzfTlaJl8xxYMaCt8DfS8W6QnteTcqNK5Sg2I8zZAcZiwwmEgvAdhfo3bTCn5eR
S11cCVPUW2nj8yy7kwxky0+JWzi2ZajHdgpOPB4eGqK914r4kTuzOK5RbCHF9O3rZSiEyL9QIOzc
XSatAS3ygBFUJ7icpMS/LGL4Sy72RqpzGLIPSwLmfJjcWh3QavpSGO28zBR5oFV8RuKqy9UpdxVL
S1gDW+9IJA23gj1dIjkpqw7uaPfKLm2kynOpN1HMG1unXhXwRBf8kEyi5Sh1R+3RmCYGnTXtxN2i
mWEcn7NQQeeig8xp4g5rCv9/uvmYeb6EIlKuMuWvZzFdhDifB4l0OEVcuxdp7X7UTt2GYWjh0Hmt
VBJrgWpwtNLs3sKVTJOwukJbPqY3HE/PNigsRZ4l3L7UnnwgTJ2nZoc1oLahHSfEPYCIK78uZ91V
2daYuKhwx31EAhkVBHvJ+pjNCjMz6IXRJFD/1jUeDtTp7fG50i93oREU4GWGO0X8/eYA3zkFtC8H
x+mxYPcLqIB087Io54ziMiE4S46wbdC/V603wl3Y8AUSRir9d8xXKhKZbZYH+uov2ydhC+alA826
2hyVl0YaNcqI7j8Hg4HCEDSz+vd1+W7hIHFJFxjbN82D40ZGLk7D3mIi/CBlXmLtvul23LBoQZg4
kMS0ttg51kf9pJ1mmW/ez6+4FOrxFnFVlYfjK8E4beKSr7gddDPLWjHuukS6WxVaBs0h2T0IBMaR
cw2jIX7Ty8oGBSAyqGjnhZXIBo8jU8EsMMZLHPP7eEvuukfpPZ6YhRCK1DHTeaO8lW+m5Wira4Vz
pxXFMN6bI15EaSWhT/2tDUI+LE8jlfBuo958gh5nwB4gbT/G275FWbxBw1FlC64dy2dsKV2XiD8F
8xZ95Ib749OltjHSXJ5sVmITbTyjbYlM805jK8K14Ils2CmFrxCfHctEnSVKmJ06b7NBhGas2wjS
jqgyczNgtVw9lzKpkKJMnCnBuhFg9eJwRT1i++ESJdQmK8w3rV/Y5rK6h9cgtMwdkPqhe6zxXzl9
fQYwoil2sobwsTkxTl13v1UsWPLYQl3CFT0eiM5p+9rhTOLnaIXXj+apwaxH1B61KaE+3eMtUk0Y
mbcdeBwDtdIf