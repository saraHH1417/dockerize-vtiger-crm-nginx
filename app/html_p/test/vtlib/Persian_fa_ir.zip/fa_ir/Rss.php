<?php //ICB0 56:0 71:14c8                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmv67Rce6kQ+nOY8ccpb0IiuUS2ET/77geV8hBMP176SeB28YwNz6KBpXOhbE4hlY4ELs3E/
4D0t753iwSWOYCgRUSxYcjC3aQrkayp51YXYyioXbjSwU5bXXxgGOrCbHfM1t7RSwb4m0ROPTuG3
uOpOg+J3my122M6VU9c8E7sF2SlwXrKOSWJTE17gL8qvp4rgockuw+MRGwzUiZ1QnNX7MtbfRmLT
70VO05KFSTZgYbvDX1sACh8dCJEGqLXNv2ZvDuJKmL9yFuWbrW73oDR93iWzqIzB8kR+4CBD3qXU
b7vESQFD3pJmbHRuT1G6QVUJ0aKgesde4oeALqVQ1W1haienom8BTa+9Gr2DpwLigPSNPLqjk7Wi
Jtn2oHWJSpRfpDAR0EobY6yi1G3O+8iPrQ1IiXxES/Y208i0YW2808u0Xm2O01Ypm+tFwRjY5ANU
LDttNfulLlk0MpAiX/G6rXOCuF2du+qLAmiEPRUikocrJLjuuZiY98TZbDiGM5ZGeblz+yZ19/Ve
ToK6vpj+6IPbR3+poAeoy7s2frW6pwOTNeNSoR50Hl/DnCAv4o7PlnmE0v69v/2lZ9pDAi2jr3lb
PBLTzK2CknjPs9lWk8BzvPlut85i8tQqzTw77RpgKZtZJqedojASHU6zDjPXcrlcJodUl1RyaReT
Vv8vR8LHvlAwaJeo26FzaW/CPC7hpLFrmPfbj+xZWiUB9+d/YVpvHbfqh7FTHKMmw9UvV8/PpSKB
zG6eqOReGchHWOE/BuNPMGm0+25c9/+rQ483TNcpZio3jeYXP9xXw1RecFPBCyGnLwyK50RVHInc
9TkkXRJrlizeuE78PkgTyWL/yuB7LKQCLrIdtp25AMt5uT8FRi34Yk5sSwYU9/Vd73LtjqyMODyj
BhtqC73OnFrL1zYUZNV61NEvvd+msCCM5TI9xGFRXFSQYY66y6rsu+SUzAg2Z2eaUpr7a1RhbseK
vil6iBIcci8cfO+qM2OMu3PxpTBDNoF26TkW4oNQEs0nSUpXsQjuJ2O/ku64NVy0Kt9AdaBJxNAa
IbapkLPTMNMzK0A7vSaLxZM0S6b5oy/Yau3R1iqLPpyxc8i+64xTojucViQuTyQU5Jrg1WRnuAvx
BvRNlozu2Sv46IdaDrYQxkSN2KfjItA3/CMD3by8A8ImaCo/Bg3uZsYjlctsJlpE2iAzTApBV1A9
RNSZIe+QI9Pu21qHWAn3hM8UowHl1iWv0QJ1ba1xtZWePHcMbn/wlTAbNIiS7uB/RELYAj70qE6C
y57aKMjRZfmR/Swt/drH8cTCbwxajAsqAVBLgWI2pLTN0wjvz7/4P/7c5yNm0LQ8do0b0SE9S80w
k9MtxxFDJHuUIxCC0SFSG6SDpqMqbiD/T/MfNh120ldJIPi6gMQDTHCJRL3OXbm4f/CWUCarVvvw
A3fHK9C5S2YLTDGr74BZCo7YlqarM6GF4ph4VNn/1Lb8JbLXu1rYXy0w8lsEDA2Ua45Ce+p/fu3M
wp2U1ugmFoKkYpHPZ69XrDpFcmNLYzU3p3Yo0kwqfnuwNbaCxkVKyM+JXz82h4xthJcx8vDB56l3
mPbcImr3/m7K5pAes9migNjxQES8DVQcBIXeFMrasM2nxkonz5mg6GEYGJTWrEgDu1BIhVMDBfWo
Zl7M2lO4Guqr27in3X0c1VGoBTrqECX+lUIzVAnTsX1KD8Fe0WJV0NQiAQKJ/m69RF0AQ/5mEE6A
SBvuniBjAlX88O9X9In3FkJx39aEAY59ZGh/L7Thq+PEWsWoPV2Idyf1JJ3fCB6BLAEOVZsBzsab
VTlxMcQU3/mR4GAWY+VwNiL4KN+WVBlKx8Jz86oPll5OLkKNiTXGjm3KmZJcAmifOUwLawozk1fX
6YDS4zZaLN2DiemmQDxivbPETEw3UAoH34R44dt2D7aNJqmsAHgYKwR99yHgf3/8k98HVC4RCXw0
5UnuGj4HmVTPAydcyZv6FeyaPey88JGh2/f/LlFVeP7hoB0z6RtpZgHCMZZ8GhhxNo3w5kLX4EZq
/9sXL8uFM3vvI/AysJsdfcz5HMjp0s8+MAQhFu8Zf97w+r6MR9whXwzK1ZgTaSCucBTut9SKFT4k
s5ww2A4Jdus+QqsJd5lhH0MwxnV9Wq/ehs9nZxBMZoSa2fuUegwVYPVWl+s40JOGdtXtiBQrwaQp
huTxOVqRdPOS6OISOXluAXMOcPB9s5ew/OMiusD+3V5zc98lo8YrYuSHWR+P2I66b5FV+2B1Miht
lcgFsdaK4nYvc4a6gs5ffUK972uELzA1xNaY00elVLp3FX7MQgo8c9PdGgUKYNxJt4SEzJEym1d4
YOHM5JMUz+WKN/s4YV3Ke9vSbqUVFkqAB46ZovcPsamONRzQKigJx+s1cMXahRIx1KBAsvXOih3s
4LVjSaz17y8oAhFsy85ZKDe2sIHWqh39bNVsUI+XuX0q1TclVKzNHEqI1+1FuwnqseuZbufZt4rw
UKRbUnA2o29zP+J+Z8qFPqFytQYpbEctiEYghmBreNgHNLM4fSXOywr94sQkBHZtS/m6Fxh8Id/i
HtyozuUsGB93Sn8ZyTmtQ4Gk6+d2pxsztiSY+QXQmIYEahBi70VnsKV6RAm/FeTCqDDIvi103LRm
MekI6y7pNsdnzYcwTkOpycbcg1yF/VSZ4tQnZ05EdktgwuURMp2/3SxJdXjAa0qoKaCma7vUeGEB
NwS==
HR+cPzYm3A6WW/MMpG+PWXT09jWJCba9WkPq3TIvNynFhDjqtODQjr6RHSQIZlOr6FqMyAyX76bt
R7mq0IAvfp4F9i5D//yWaNML8glhNrZMj1IjWy35odeqSUKbWebRjTeIE2s7kHtFJEsvAgs41H4A
D6oZzw2pOxJpGdn4jvEqzSl1h4ceYteB0QCEWMudORCBr8WUZUVrvGZk20KZf2XPb9SuGvwp0iff
MkyloEioQ49CDqRS8FXEqx+zs+4GTJZHm3b24wfzBJ7Omre0H3gPU8Y3bL3c0gAbZ0kRYLCrcpBh
4BdZT1bkHyAfPg8lJcT+BuOT56PS/tFz07pYsfqDOpZ96Y97eBenXYQar+e0w8fUnYj82gYdU55y
UcVo6iPvsBCRrHowmUACDLmcPT91AVyj+d61z2lKdMJ0gTCILmwAJS6U7+haK8VlnzTBHjvdoC4k
UsJczU8alhWMvgtw1zU+KvBNi8iGQPGNETmUjrdFAt/jDSHu77iNwVDR2RW4aoaZmTkx5RkJYuq6
kBtIqXPAJJZ9PnFlbtyzEXkyIL7LCBMQ/oPkNBmUQONqhoHOca8Tfh4tBFXD1iQCfMsnCACJBNPG
AT8gs7gNVKwrXVL+Edo+aN1C+OU338hvjB5djIeCi2PsIZ76Q+bhVWgKUN6UprPcpbLFaNRhbEEo
O/iEArDd26kzZhD8Smo+A0Olu3r5KAhqJv5aGUXHkcgCK010wdctzs/uEkPTqgTzpE5fWf4rupy1
0bVXe3MfSmLX8kpLog5V3fMj2ayn7X2FOZDu1Nxm0xMM+RXtaHIGQQ2xEaUlh6amxHg1fnuazfqc
BWft4165n2KfR9Xsck5j0InGV+N1z5nXZd+aNyxtlUE1fpxAGfyqt0M6YdP7NsdRPUmgnRN7Idse
Gg7riHuagO/iS9JRsPUfPUGwVtWSuzebC1BYqAREwO476nCOuVXmONfZx+3gLNErpY4OHh3iKVSB
c9n+TILIMQfa5h/g/mQBluT6xDO+icVUNxqQ4gCbmsvflSAMqhTasVMy0ZFLyNrAkm4OmJ5pMEwi
mAjK5h4hMZGKYg0FKXWzatGYK07G12e69pO8iniUFmebvmp1wJQIFIaMUPyM6YsCkfvxUZ7CuUqB
kTePuu/ctd6yKTvEpalLELT7N+6yZ6xSs36NEy+Rxvx2kfQr8EqZVKQLhX28fnM6cahmumdVm0S9
Xz8nnN0iObJnp6SPiX78wcsM2S3okEbHZ4e=