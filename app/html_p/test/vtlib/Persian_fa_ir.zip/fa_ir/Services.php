<?php //ICB0 56:0 71:17b9                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPuWpSrIRbaUS4llcTxSAmfK3x9H80LJRRkoKnrRqWeQFxEf3IXUXNwaqdCc+Hquryd8GVuX9
AkWkht9ajkFiOYnrfuY3YGWHi1LcXZ+LSzCPdAPyrGK8jt9bjYyx3DHHeiQJ/7Yx8+nfpQ2R8uRk
BuIjUGhYLWMlvcDZJHRL5QuUpMGY81AxkY10Pu/DRKchwKx8vxgLJdpaga5mGwxi/zPzK+9LpXcc
kl72vxhdhRepE+V5ccFDJyU4c1cWCzj1XLoHzN+RnHWzUd1xjxwGr5kaBOt8FT4lIoBc/X32pGz8
NfH+PNHexJJijnQTwDRy1aaFanF/+/UMT7bPwHzwrRWE/vTQwSlsAf4bcue1QGx8tED8KNatzzsA
xLOs+X305sWVWnZm4Dax83dJE8AoAzOhJ5YqSUKpbHwic6UF4WeZ71mquqQ3RYFSN2jC82apQcD/
YCTct1E/5R0pR62epfUCH8qH+wqe/rdRndb+zX3ey0ApxabhwixM/WcJET3GbTuJWo/y6TvI0CsZ
H+fsjMeqWFlXARZmIFhSqq68+Ja2ipM7TAM2NDcGjT51hSZG+fD/4ug6ipx9NpNQq4rNg/gr6Ebb
mBYu9cGcvVqSWIcBhU2ParrVanoVrRivxPy5md2T942r8G0EB0mazi8uDWNQDIIO1UVUbu9MSgzY
hVzU4ql+YrdF79XtNSrXXjMJqq6xjjkszqJzC2kX2X837bMSBBUYqjRY/RkJv2Fot0QCi+qL3Bwm
/HhdIKYlaxyBQ8Lw/x/FxMDQhEtB3ZGPpZqDS84xKfxmm/IX6h7u3zCpUhzl1InMkkjCZiui5VOA
3z/ttR+lmkSU0gy/Dj2jYXu+99v5UBlXNm/uzhidwf7NV9p/s/G7RIRILQRQxhBwsr35V9zDqAI5
UCDLWWABriUsL5AY7gO5HWkSIPXf19dHW4jTY58X63QNzPhKmyIVUySSJSPoU0CV1AxO/uo555uN
E4OjWTNjmUSpik6rPULwg8k36phEyfugC9GS2Ci6Rj8n7/JVO1z88FHZqnO81j2zOJA7kcBBljEi
4iH68CBThZ9rGK7wf5GPf8fLM16osKD1sNWPidcFxmhMzGfmwfXm98axD4J7DQ2S+OHyreIUbOvG
3DgeO+VmkHxhh4CwGmoAK4JcdJkHiPeUVUKmT54L01JVP6o5rFjxVejt/9C7dZ6272OY6Sf0pkgb
tRnS5XCnGrnaQg2nN1tWN/j2zS7BnWZuETR+gNc4Y0xZktsF8Tz1Oe8Zok7PDYgSJKte5Ahkkxzk
wFInkedjweJgQ38kTrvwstDt5Lm8wcDgTZ6MRGw9RJHaKsfuBID+OTY+KhaOhmhwVG4njoxu0mFE
Mgg9FGz1cCJGnd7m+9lR9mZg0hTLWUbbaHjYR9dRk48gdkj/mPnR+IXZuTts3UV9ARsU3wfMszMp
F++FuBm7ZRDRgsdF5iQFkOEvU77nJ6P9n4JB0ciqm2K9gEmHHF0Ve4U1hN+SXJRsVVXipz7rQpAS
pEkZ+cdsSaKpMKU0DoC0kmhcusoRUFlh/N7nJtcQ1wUAoQSvHeKKGIC8NP6Uz+DGwjr8oIYU990V
OX6/4M/a1UB4BWwndGrPV2ltlfZGCKeDp2WdGXsC6BteMJAu11KDSU/MBVwcc723KpqBCsNIVLI6
T5atP4OS+j9HoXlHbHp04Pu4LsuAyJY+oLA8JvUmXXwCmsRsh7rJjG9viA35HQHZuvb97Qk5p3Cs
m/CdJMruWdL52gLZ0SURznXSbXgcYlG09ecNHKtlYJaFxJtmVVriLZh+ELTgTRK+ODlaAu9j5m77
/U85NQwEWn+4HJLR2wjARe02CKbEckJCg85xq4+ZhiwkGCArFbNolFOzEqtbJZENz88OVKHvTiXv
MoW6NdQqcQ1HQUIzXtuCLZ0Zc/9sRWZ+xqkGiLfKJY3rtkyfbSEg9RcYn4/noW/e55P7AuQ71kvO
xQD839ALZvtC5K0AeJVZlTIU+oe6mrBJUU9qr9lkv7Xmx6ide0x0BQLqXc+XE7tl/+czuH+7CR2r
XRR87ilQiaklckYoefFLr2wUMVzUpeMMbCcGyOsST2wQx2bNPiDkossUWUfQHfLlHt+vuIhct1rs
NTK29F3D84xsl8O1hAF0layxtnXQo6RSE7lvJ7ag/keCr5XEOQEPzebsQcUCyirlw2oTM786ZXDy
uXTYeOhV8s1afyO53UBao/Yjzgd8S1Sf+Od+1YIvmfj4VhULbcfKdZ2x384Oio9tbvNCWgQzM8Qz
8Eqir3OLXjGV2znH6Iaq7VtUBQaXZhwsvZQZMqYsmKahVSsXSnLArLudG8qbgDyWdhR8LNLL4dcb
lSICtzlg2odjHUYft03rvtBQZkDWpjWRaHRRNIvl5jdUYkT7v7ZCwyTDetRxTyOGSv7SUattlfmF
vC9BmHlGafM7uX8hYz+j74sapX89Za5Ln8mObIKKZaA71aixl3RaYHtNDJ//9W54qChQAsat44Gq
kMLLpZ0PNI/Go80/gA2TKrXOuzJg+hXbetVYj8iDkrmbMQnpee2B90yvvx2gr1n+rKAGRY2BjIqf
6yCI9XU7k4kX4lI99+9oV12WWAqfngQ4CG7tQBD6mBxTZ+we/oZsWCqIPp6TuPRAMQwOK9P8yPIC
9iDINZrhu/AtoCxP6v8diDv8bl9cXm9zV0A4CxErR38wkk5RAAlK1mr/V6DkBmaGHsQXrRU+wu08
A1+UXFI8QhQVMhiupeWa/4lfs373ord/CyrE2BzNNLmWgeKAsTsc+ncPZtProKI+U99W1mA/SRnj
xUP/yLD25mzjfMg3xqi4/oUPLE6DAjerbGfIZKgsTtdDVDA0w3ht5PMIuuPXs+mVnBykvnO2Oios
VU5JVtoQQaA2SL8/B77kdGrK7hPGyvBSediQtA+OkqS9g80uHNTqc2nwaIYIo1Av3+H3TvpAMDte
ikjb87v/dW8jCHQIrdWkSRw+Zl4o8+RvmSuFKCzk5T5eS1MPvIdwzn9FLltOp1yYz/L8z2XBHjJT
xIYUAGExnG758xlHpGLtWq2yNAe5Dnna5B9T+EHHSF3e69a4P+iVX2LkxyzWDVsnO7j+8d+v1WiB
OmONG1Ce+byfg70/biRe6mmWZLA8p9lKgtJflrN0KGUjYxcH+crKO83Cj4DQeskdSiXp8TQNMkH9
bgaNbO2VO5JD5rAWtqa7sCU33fnNzQwZMD7Y90G2kAPOZG0RBs/xpcKsncW6tgHGuZfp9i5OmaO0
AKLEIU2NZYHEWge9VtS0Rr/G2zMSonLKVRanbgMev/mn10Hj8jrDZ17ECxkgrBOWCOs+cBYR+LOM
mf6GutceKnoiPfTexkpDPwE1vYo6dElGPN0ZvorOyvyT+y3gShinC56rGpsalLpnS0ILvJBT0rwU
gPAUx6KKquhH1ZJIRwy4m7n2R7m5YiEXnraF3nKTMXWYObCfsr7EEWAFZRiaeMkQ=
HR+cPnu+GMlv6BfCz8RKI7iNpK3HPfH3g8gWASWUHcEzm2nKhjILtcJ0vvUtRo3teaCVhocHlJPO
QOpZwffEDNCqDlHs6XfBeP0dQhFP6TOpX+kwVhEl3IfALRST8ZRtUnOjaC0RmipPUEYhsGe3lGKx
65tRXDuLYH1fbv0r+A1BuG6PDTdU3wGTho0FlLWQuRAgLBZnx2MDAh+M9LW1r1fNDXdNDCColY9M
2SEhIJgdCejHiERxWaookBDUr5IJmGgCpMb6iWX2S5adXnRwUlx9k5iRJUDGzWAYfPWBcubJDPio
wn2vutJuRS69GGls9dmFUT26dHDc8F/NwmEH/HVkiSQUCl8UMFWCfpWVJCocLR0xBGF7jiPoNxnj
1i4jKOQSjbdYTlgzQoEtvF7A3/ypkK9Y4b+A7TN0yeG5Ts6rFtrJPO6pQ4giazzkFlCkHmp3+w0z
+yCk4P90DjkPuwPMnAOPrG+QxgCVbAUa1gkF511LEZFqH1Y1NhfyNl28dhtJa7dVjLm/y5GO8Shr
nkRsTBK+CceShYBQsXQ7SDfdytsssOXyYNej1CKgrbAK+S+Wvv/W+yfcwHTKFptONFY5TaJmNNtw
FnI2cA5G29k7qrjrNVzuOjhG1ojG8xoBLfUvvtJ+q54np9h7wgDV8uKuFoL3V8KBW2Sk/z0RQcVY
BEGzuzt5dVE5EZwkndxhBW6nJjbQspO9B1KUFOVzflL1aAVAWSaEuO7xlfXWhb1mVF408ylyj21J
sk4+ItMBiH31167OVjkeMd/d1pXwwc4cQA4GcEklrvW4QonE42vpTF0T2/RZDvV5KAGMms3/y/U0
9uyXo6aOeSD08bdwC1N+YQvtchjRsSbzDJ4xlgBvYXhB9WZqzQv+d8B2AaBh86xorlMwEypzP1l9
IH8pNoSifCQxgA6fiQ1T8SCWBDQJszvb4iwM0OgsIRgRtimEcSdpoj5RGKKgyM7HcL6hXCv+IefA
rGgJjROzDwgGAzBUHD7rX+SWjRSw1MCSAi2ngW1+91sxRngmQjikvTpQpDCU1dGoZmnb5uEYQU8v
r49AwUkoCM+aBW/WfzVyn81NxdwrUyoEYUlkgMfxJUHZwF4QyyJXBWGUvuXSVqBjI577GxGNiBH3
eHdrmdu1GKwyGGDFCx41G/N1AX5EK7qUxxpV1kENC1dhR52IWCxaDJszCIClrbvv+DrIXfJzFIci
qr2k797AflKlp+7EhflogelEMOAYTMA3CeozVSXGzJcVfJiOO3EowYVvM+dLroZzfDr0Eoom9IFB
cEWTp1STYA/EhOAbjmh2a/HuWATRNrWrnzqi9svtATWPC0qIEOF12qeGydgBkRVYzTiT8uUwCmqQ
EEJqvgrHZ2M3q/yMeZwMZCe=