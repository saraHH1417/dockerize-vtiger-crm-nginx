<?php //ICB0 56:0 71:1a93                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwwykdE6Anz4BtOlKC32Z9wmiMMngA3ml/C1EycEtLiuGYHHw9ikRkDQFUfGaulIlf/OR94i
1GNVeLjCMQndpyKbY7534lP4mEjAnGjLqDv5t3Y2vohdCtdFFO3xlkFqomnNJ8mj3NHcULYcd7WA
3GXqgcJdGbMjE7yIOrHjvfeSCh1tTWFUeDRkKxxdSFG232X60lqz4ZDakbKndtRycPr8FyOU76Da
/SKUGgCtSTS42dvcKIq4Hraue0NUPz4ccmssewmgAlHfRWE669ByZLlPC5HEo3tHBqiYvluGmiqF
I5wKVcHhOjF3Bed3noKKNWOnWv9b/otM7IcYbbobAwtim048R/t1Ubvm/tZWNHABAP+LbI7KlW5U
xYIUUGni69FchHc54lpkzK4zqSOB0Et45bOEVJgrUSnXeRBGeXq2iL/2OUsZMnPznSpEipqVTAa6
zxVWq/0zejaVKn4W4TNqWczgZrd5Nze2r1j9HsuwSA4e+zUKj14kCoNT+PNdSOgZSL6HYa5p+Fq1
q6jxYnP4IZ6vmJN9478BQtMvUT97B+UDbSV/2uHfw8hqIWcgh/tTQPA0/a+PfegzQN+LiA0TpvN0
JhxnS1qpjGbqtmSVh7B1NI9XqampBjmriySEMszIGeYBxFdUBdhy+QwmMC8NJzsMjJV/JoiKyQOd
ix/bnOnCcxHpH7GNWMc0Ow4ri6u7M0DHAN7ahVXqzsnK8AqIgKymRC9e1f4KnzA0zIZ2rM+7Zq8a
z1sjEju8/ETu8VViKX6K3HSxCa4IxmGs7ML5MQAS6LYBtBy+dUXdJ6HgwX9XogFGGj38GEzA4AL3
4pbwE+RgC8/oID63n2YXzdYQoxJIhB60i2KKbhiR1ol7faDQn0f96lz6PwD+o0GoqxJp60BLX7s2
IQ9DBj/s9RLL6j8+038MtSii7L7v8X+APW1rwYXvswJrmuF/Vr4Qi1fJJ8EY2j8K+Dbl6RwEe5Iy
+qgXChcugPqQy+5+oIC6dy/9Zao8V88LwgisVVkIxg2GRMP5RKJEWhNQwN4Ea3bqAGsDpkHdkinS
ymp5JySSM7DZ80lK4nmrJ1dI4Iq08Kb6B7RgbXyrqgNXxqylk+tjRqT6ydfsfyAxu+ewHsKv4Ghr
AsQGxGc/AksR+F7MNksxyHma3bhVwtxR9P/fZAHIkg3OKP7NG+pPd7KAVFSj06VsDW1qvBTI+s60
0bDJuUGNfp3Q+N28MTvyVGSCRTUAfVOUlPCuSQK27ddK/bPGnmmlwiXHQUYZPSfF92EErx7WzbzF
ZzoGZ4fpgt56CgEPDB0gNmAb1YhyegtOzezxsuIN5D1cgmJokvYJQalJYWg78/B1cRd2A1Xa/nj3
hUf6+CHJDFKkNUrvTIsj11Rd6+FEec+BqS3mP3b6GxST9ITQBhDF30cmqRIi05aAPAD2+grU2PLi
jEqFa8vLtiyoUnpw30BH6iHo5Q8vmeOGpGbWxQXFhAqft1PdAeV9uoNvlP9gE8MRbnpVMo6pIHyJ
6nKp0FUU6MkDw2Ko5rtcoL3nXUTB1vDjlTXvIZEch2qQGt7UifUXf9icximt4IE6jJK91a6wS6yX
/4G0Q57lWBy1RIafJlAPt6ubI3/YDWGXSuhqLdE94wagQz3EC0CpsYYRqrz25KDY2onOrWUZmxpg
L2zwZuBh7Cla4FxCZB8ERroramrkpcpQYrt/g10v3aoxJn0jPA1LipKSbuyUk2oMtdnA9gvDEigL
ZC/KNvwSKoQ3cl37n61F3+C/WLiRGO7FzD6pPZ0SpmpxivGvlGekQdHqPRFvHj+HrdkEYOq90db8
n2U1GIIlCc7/JPjPbg4a+KyPDzpD9fjtDLn+/38VvSmsG6q3OQrlGlm+T0cPNYU+lRSbsXBWds4q
UcQ3TEwvMzGCupcshXJrFQPGdgv1pRIJPYruG8Umu6sDqllE+Y0Mi90qLWIPvr72HUws15gGtmoy
qr/a1SqhlmclSzdMRqiFMAezbDXZD7JRkDfiiUm1is2GJIxugilCu0oomwJhAr3C1ypVS4VuLVzD
BykQjuMzLAQQQf7b0rzaiJ4v8ayeBtJ1UiR15LimGO1WcioydYShWXzFFgn1dINOYSrUGq2yqNaB
B2Fs9rTHVCtmO0aY58NG7gUIj0+/66wjn0jZ0miw2OMIBTWnLTcFXaXu2W9oQa5+0IwdeM4EoPCd
bue46xjKGiDRs69UdNXok1zw28BiZ+XPn4VvkmgXEPCYppELI4RUEgm46jIHsTG/AVU3ae7xQHLf
DLjzNAHIRsMAfPIcp0DE+PaPAvY5Bn7NkvbmWVlOzhdGlTjSWAuFm0Gwen0CGRG4V49m0/KBpEzy
dFgrkMv97mDGAOg2uHAQq7h2iFuk/LX6jq4x/ugEvHyYQgC9cQQ0f6+KjQz8yLSpCfE+mqmBZlK1
MhXUiMieQZ2C3tvPp/A1BKJFxdZFr6zeSTgoGCNUz2UtD6o+vNYX2WafT0RqslQ1muJJzBuFReLy
gMgi2Ya4XKoDhR5PALN+8MWjYm7z4jla9rJhZvsa/KUX5cRC4eff1OxXDxX/oisho2wckN3f7ruT
ifToDDW8NabANdhrPeC6/0gz3KyZMK9gTznhlgjZDX9OTxAeP7gxvwk6b5nWit48LgV6ofVUhe4U
+npTR1iLv1daV03tFLPcX3I6JqR8+BhbdIg/xIRge7nNLDaR7dczHctiAM2vZHFjyxuEtlUcVJR/
b+YhguN5cr7+/dOWgSyf1Pp9np8YjvkWLiL5Q0vAIneEpMddJaqFk2lTLVStqkdN2elydau5LzKL
QYnpblSH9tO0BWdY7UI0TEcc+XZHf85AliodHTtE8e/7jxY9i3xdw0OUeLKtOoI6hBG0WOMSZg6B
8dWg6FxphqkPsTsjabvy/osTEtJHZxbIbgp5K/einnpot1+hQd88ibHrdB1tcfyiNfaNAINkvMFz
Rv3VxNkSk5oNPPaxj8nDx6PoSGwMCh3X03qtJbX5pylcmAqnl344uyHiPEnXl/r76k5mkgoHaLD+
2UeLLUC0rWc59Z85kwitRCrsPUmlZbQFO1y0D/ygZmbbS0zngV5cCd/BOWawRTec/6oaa5Ov3Yhr
JmAq9xMTJpHKJeW03WyKZTTfqWBmQs4SXWbVtR/fa/MsZiZY98iZtIlCmx7kfkYwmewodf91lcE1
kIsnClqE/76nL0Oa0Pr5eeFG0mPUxkd/x5DYjxWBmNquDpMXPQ0+sPQXWRmFw4b8wArLo9c1XsNU
0if4DhAODr+WHmKgHXF2TGPg55F8ebhQng6fgzxsqAzVoqP6M4AK0pxC27Pyzcgig2jQHjj5nfs7
/tPwnMXVgG8lw6hL1Ecaiw5e+IlNPEfUveXIqB8Az4D/IiDiCbBty4ws6q/zkJwJmNTO2lzwwAeZ
/teFgecRl1b5g2cVaC8ZSwViKQpMOf+heHXt/N7s+wy63NCSbWDnteDZcMrVupPB4UPFhurpyqH3
YMXZC+k5LHIU5KWsFHuqCKqIkA7xbchKu9gip1LNviCEMD0iLG1n6rWz4wxwd+5np/4H8qK+Vws6
O0wZqA7jdMhQ0dDq3omfSfXiksi4xi4WUKyupSYYX4OnJ5+eccXLkTSwxMHRD1Qx47s/qab92vUn
ToRtueMXaS709ab6oc9HHTan+0Q40xvbN9tob7P4ZhrZEVkAFdA8VPydlBelaCYrXXOe3u1AtwSU
yX3VXqqbacZo5mm6+8GO+r2hlWhR40y6rzOgGoM0zQdUzPHSq3ZNuPcYW7W3uRL5jUh9vEcq/sn0
YCa5AmwY6QMwZg4mlXaQ6vvyqlnxha5UDr2xMLhsn4g7TdK11JGiurzABN/a9s1vHz9e/zH2y3gE
4M8e5ndcqUvsp7+/wxa8ypcObScaYVSrU1kNiqnwfURLBixx/amL8sFi5pw5daT+3/AhdpSJUC7Y
JlutP13s20j2YzkG6l+kVM1P3Srpb4CkRPcqC8DX0uoTcsrZfVM4hx9EK8j355K0yHV7zAXDYP0z
W9bAsGOL59fFoGiVcfAA75H7xYucD9coCmjR/YQuxEhQSxYkaq//odWp1ES3mgU85DmNu9NFm4D5
6xtxGa0BJJqKVZ/kfNejTy4EOQkRbCNd5BjwNAx32yN2jPuOQ4UBmvdFRAT4JQHsFIqTX7VJi9tv
IAW6nw7qV+B8P00/keQDr9W==
HR+cPxS6a1lhqsXSWhy5E1lWO1jVEuBUBpOT3Dwvju+7rI3kCLgCh447Qj+uFQN6192ZNHTKCZLv
fdhVVWHe9vvODBSwd2hF2u4s6swQAjBA4w9txrLmkzG1ybIgRYVYG/bqDmy6cqgy5i+YCu6rBm2Y
YB2Up1W5o8oEr2/CSPuzoHQTNpYvG/m3oiUX6nYOX7zMdR80PMYgh6US5Qb7S/b7M9DH2kc/8lk4
49SVfnAAb5B+JEObUCjFnzZFFHAXRTEhSSRyCoe5GjkHiMmclUKvBTwEcb300gAbh0kRYLCrcpBh
4BdZT1Hhxw2jXuNS18wOTeQT36P6umoMB/ofHiOIqCEioRFL6gryQb9MhQicX0cPp3uBILxS+JVh
KwwQAKTqViOjFtBPvbtGROQg2c6xMQ9PDFjG/a3k/ki9zU4sW5TAYz4JtaZJDB9C6pvV1b/RC4fv
cGIdf/OK3U0JEhd8eBMnZYwUHKX4KNZj6hkuGZupdSywQc3/EvN7xi4cP7lW3KfuPoDpWqNp3tLd
3sZNc4KaRRDOgyiJcPEW/ncBPImc/beWouTQWfCK5abZBsgF9FbADko7BPvn2h3G5qVmenzQQ5T+
DU6y/mhUOCkSCewL7H0O7Hgm/UM8XfDT6swe0DqZXBQ55mJEzLiozLxLGJgoW8wHurO9TbyCnOfG
UpAATjJ9gevpdqb/3AQS/ZZY2zThzAq2ePyS8jKnTWM/3oXZAdaf0SlxG63dZ7q7RoqN6tq7yGSW
KKHgcVoSZJYL2jMLbVGk8yLSuf6FV0FDQco0WipIsrpEziAIHF3qyTZfQvj1wHpcZMzQoKqnQ9VY
ltrABY3LairmFQ4TBT37QjSf/y2IrETpuyTd/Nq8xr7SgmweNCjbIgAYd+O6n31SQIRCDVATvJBu
04Q3BMQK1eTgoeOnfEGReiI7nUlnUwaoVSQwGFtIi40G634svlQAtT5MWK+3fgFnoR3ocj1D16P/
zCk8G+DfdMq1fhQaxdY23oqFgUR5uIvthSH1bKdQ3XsMKJCxNr2NMwiKcqfdmPwmuYWI0q/UrzAm
OO/C3A1QyoPlDD6Wd1cwwxGNmTT85CzZfQ8U9jsHSs1uCw2kJ7Lau4J/OFv4EQ8ZTi4NinEN7xJo
w0eZI2Ttl38dzAFVXv6GSQoZMKX4CYl2GOdHI0P62mTI6S7NViqZ0C4kqrakyS2cGjOS/qFF6/z7
aISt6Tv6iwe/EAXgnwMnDaGZNRyC3JiV08SzUYHt4v2RunyEXmf9W6OGKYx+EO/e7EgM7BcWVy0M
QqxAx2WzicZlDYK/l+drTEsuGxRJzh3opagg2BxYsxWnDG6GRSGv20rPqtEYS6n6lUjgK1bFXlnW
MGpPPDcqLjRU20yt/vpB+NtWw2l38DQYppbbmCwdEhv6r+IB3IWIl+hYZOZ9QpyFZgRRvEW35CR5
DhFBXenH8brS8vRcYAJ70F391SBw94eGb6p0545zxTBgXBFQ6UtTpEzS0jr/e4KGS85moh+cb7Nx
s+YDUshBkcTzvaUIuu4WGvWGFyN7cxsJ95jNEMrSQNGPlTnzjE6qHPSYPqcAFuEbzOhl7gVMdfqv
0nkEh4U56BBmoJeqroVjWy6KRey0QhLU6vjZ03kbr5L/JPpEw1G7ysppgaq1qyEOM9of29Cw83Ix
iXvJLpu15OTz6+Y/YzcHrcvzHx5Fukcbf4u5w2KBvMnbcHpDQrHga6grMN05C5MqxR18WIkCC8Tp
C799IlVzY/9zjqqhyBJ0Ekv0HYcqI/4eMwKe8mTwzxQonXWHYVIXS5b/7kbc9WwZQtltEzVbVxYq
6Yq7fknY8JMwotErtp18QTua17q3amnKyD5lE5m6RG64XshojtWNqhX67iAdegc0hqRCi+MlHu1y
e30ZtchmLVWsKCO/ZE+Fun+VFOsOiD8bPVJX15N5T9FjXfGMZdGFkZVpo8SomLBrC2ffUhMfO5ho
