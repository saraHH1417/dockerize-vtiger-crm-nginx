<?php //ICB0 56:0 71:103c                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxvHiI3UlmaNr+Ca0zB02LXpNgam8WF5iex8ZzUEon+UbnKKXMVfsXvY88egNGE8E/Rk9odT
30x0uPm5VoqfDtLGLsmJkMhoHWcGHxsk85hDiiceWpfywxZJ6ybpAYnjKv405XFAUYPpVDUx3V0B
Kd6a/iuMrItXvmlkR4W23eMn406KMc/MYZGucNScoN0fxXdwAJNAK7OX6Ej/jVpUNRIo0QOXLPxV
8MjphA9QTRaHrz2u29hdOCClc8o98Our+OcnQz/7oSmqEAYJay7c8rB61CWzqIzB8kR+4CBD3qXU
b7ufQq0pIR4nwX4Jz+O6kHIK70ejYGfYwANINqHAd62UO7smT6EHM/mX7KxtoHD770qaTKU8wdlt
CatEMK28PDCLK2bvbbotmjiBKa0EkqCLBZIXhSHX/AuHiQh9r91xj3wPo4E1M8RovotBk+E5CvSK
VkC6y9pQv4nFu86YtwqnaM0CsI53a4KWLvMHGk0KYNSdPcxqZaj18wXRn5MsYyeP63l6V0rtLJ9o
ybSzNfKjkGjgVeuoXhcOoJYJ9+wMxWXUL9ycThlZu0qgsCd3FkDdV+YTbqj2C/0fuCL3c28HVLyo
afL88NrpWEd1ThlL1VP/hdauyuqRb6rDe3FFU3at3oWHSINqrXsmzl2hRwzrbI4tepiVmE/H5ItD
RxniB8LsKhpEW4XTyhQ6dzhAFa3ms/FkG+qv3uqv5DVuqw0hXES3ymzjM06LEK7HFJFl3FwYQN/N
BDeUmVL+e6a0SabShH+yHi0jzaCdWGQUoUrJKVkkduTaIm5See03wSl4qWmHuyHSfFKzU4adRUHE
1h8AupJaqpjuEu2LEXaa4EpNVyo8PbFqQUkCxPUDKG+HLDupuk6sOFm0vdzpRSbvY5y1h/+2zm5T
D6SFN7Bqa3Bplf1TZvFoOcxEdC9y2xJ2Y3LVgRjhsLgGjldFOjoorUd+2yGc1OSHz+PNz2rhRjz1
bncO5K2Zmmat2UlkUYDo7i8CWOPkf1AMSJFNFPnaEQWg/5YzrDCzXSVOfGPAKFKd7laLdVXurzRG
93z4hWeofGdBT1Wp5sPwEj3ab0aRY7jcVd8VWAx6fOHB8CMYMW+zZtCdWRONS8NGQCLgSejkBWJx
Cz0V7uKOi77Mx4MM3/o/4mFJnR1IgeJUM+jC/y0xaX3ZT1CD11SMaI09bPywytLYpksJpRgsPeHi
qXaLGe585uriu1aZ7tdLDIAhwSczoF3688FSJG72IccbVl6ZH92QpHRd7IDf/i6nfqbIZFNO6lh2
ifvYDSto/kaJnoEEyX8W1XXi6XWXka1rqhteU4adlQEBkysSPrdXL3SAEDLrvEOEmvfors7eJP9N
zXIqA3GWBwUr5mYK28AtBlEOtjI+Xde8JLAZt2OIsw5+DT1eyxkK50unqp+slaCLU4ukwyjuwrkI
WAdlgrkaODSzQAolTbydeQhpVCxvarGBGJ9zEILl7S8j2uueLK8hbg6VN7VyPOaWPrZZEMCLilrZ
ws16dMD0Srph3t2CxmXcdE2VoVqTu2QXrex250mwfjI4L/RHlYgUr5CLadVuFWswQSxjcW===
HR+cPtv3/Ni1biLyhFneM9lm8b1rE+nu2FJVAz59irktEEIIcOpRtTSDHcFFzLndWLCogomCy8nb
FZC75GkmkOAXwaYvJ+VsWUEIT692KHckJLHLCdvCDKcYruyxQ1MikEqw+sB0bjjlULpiCvHR65nu
VCuRpu66jzKjyJWOfRrSca6lKi3nHR6KeFWBCS2isGD+v8DdOPnPvurMZCNgqzZy7MtPAx+oiuXM
iKIhLPv/TNu06K3C4058K4F4J0ASDZABKf9GL7/78xj4EV6dNkNJs8sXN0LGtWAYfRCBcubJDPio
wn2vutI3SkChU1ov2nnmou667J1tFlzZNYk6NG8Gpvbv8lDyJYReWgOKkodTFgTuvcSGDVvvJX2J
4847hBCJYVtY92pSNMYzQ3T68MHrqCBRrByXYWca2wqCbGUgnTNTJzoFAEheD+0XVUpOC1X10l9M
VC2S7fgG/4tYeT9FryFe9jbK+Vh7YQy6d7HXdXXJlohqWe0fst+0m2MJfkz63eNFfX1giWfaAozO
GQiC9KiwEqmVEZ6V+XJyoc4g+k62CmPJAblbGNlrkqgK6CH5neUpWBZWkFyGOTNsXW2y1ecoN3xs
nedSLb0izhPH6nY9OF/DjVGVowp8oQBJUYrT349ai5jeGdhpq/eX0Ap/RMSkg9HghkCewfRmJ6jn
ChwG65WYneT4FMLsk7T7uovldwOrhL5AGX9Od0/R/Uau/cyj6Td22v8vvlRV6Kf5cNjgVX1q+WaB
vPwSLHQNYgqwXBfOrb5+rR/Al2dBDbBH4m1LJvwOYA5/ahzhM+ipbNQVjn9UDBl7VHTPbF5eA4CH
3auSVOGMlAUIlIKVAlY2EKoQWrlS2Wt0HLvfrDCHTPUNT9QpuRnL39TXmnL2iUawFyv/HgUFYvCQ
cvmv59StiBC+8Cj1uITBOZX4+pJCjHJId6giZk8GuR0N8y5zcTKAqLuDLSjDQxtw9avs242WGLwK
8gzoxkNg