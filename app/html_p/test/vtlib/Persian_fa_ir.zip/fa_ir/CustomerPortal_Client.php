<?php //ICB0 56:0 71:1681                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqANeT+kIXeGnrWq/8osjBCvI/lnp7VCtul8R/NJTXYjeLZcVMz1EO01EeG83DoSnvBTwcSp
Lu33g072ZJT5gjHx8YmEK5eoHf/KdD5haua3YlXOGirV5jztvc9kdOY7ZSWAc7rrzGxNHqLujaX/
qNGBlHYODSy/bVHNkA7Ll++N20chW/xHkilr/uLKSbAihRDKgDBSDVMhNhqwM+K0CKa/36h8OTnH
RB1w5CEJ67irwWugQFHddTns+1bO9F84MqiGZCLZWuUtih7l5jdu03NHMCWzqIzB8kR+4CBD3qXU
b7vpSm7DYyf09dss4NK6gNYI8M9F8ZtpVEJXiwfuX8R92gsoaVIiR7MXfwJsH8AZLW/qIuxmqKmv
0eWfC30fa5FCoVhYFx4z17aZBdEkOGklpRp+leHwDkMM2uIF1tnYBjpfwcKL0oSppFpmbh/dfY7D
LSoGOO4759aSaJbY25+am2oI9vAroE0vglSxH7b6gcP+94T41NuNlKPEJyAF6TNIXPGDQlWV+6Ln
sxmjAOynkrD+3A3eDJycTHla+wgLyxA/BIACkoUYBZ64t2XJsnKfUFr8Vy/LaUl55JweAtctfT4u
zYy/kZDvRhztxZVBHjbeOLy9Y9RZhm4jwJFW8YAeimSgRWL+AjvlChA6V+4XcdYKBZO2CK96WPSr
YlLGjDPPKAsonI/IE5V3Hrq2fhImAkxg+Th0X48Y965W5SA+qx3+dZeJMITfW5ovgAmJV+D6+xIa
yOzs/kSpN99oPoAtvgLOY2RdbCW4Kd5ajpAPVakrSiLG31RVpIvzr+ws203Vy0ezo72y7ObZgTfF
46N3RNbamqIk1wj0GeOzONtNyGramjPIY9uL34uXQ5EYr7zYQtSUkRX5kzzMNE07nUxtjBBY1juR
UIEr7h8V/ZCJvdmT6YkjzEFwxbT4EO+bFwFNHl2MHgDNvo1yJd7YieYpF/xXs9I1fSox/cZBg0YQ
QohGJQECsRI6NSI6Gh1hdXnMcGN18UGAwClYAGZ/V/w42DiuE1DPp+8QxJQr27E6waW4rCUn4+9c
gzrYpDXmShLbyEk1yAuotznlOCa0rwMPRN1YsLcdTwoIxWn9vpJiWtjLjFtcU8CkAyotisMNhBBv
8+FF3thpwyog/2VnquOLqy5esTJr3Yj/VHXvPYnyFIMnMGueoeoInxwEM1T6wrkNbdg4QF9WE22N
Bz5omWmB3tgLaEbYWAVQyETJ2wSgdr6zUcz94/UFnhyIFzsPeRAogK6HGHxpNLiD/n5f3vT8J/Hd
rLKov24Om/ivhR5iVwxlA6BdX1CiRGkWNbIQJTezkVlf109JsWsHAN9/P6BjiSJ3bXqvx1q3fBRC
9FyKO7QEZ2h9s3Odm1rmmBJJzoBJ5VQLDBxIlAxfhpF1dLJqArXLJmlov/wxJIGPh8tCjGVH57q9
yoXlGf0B/xTcLtlPcyQM7RkaeKzXmdpFJl/I9clpYv/lV9/ptYls3I1EkGc9bjnA0NItQAIsKYkL
Ucab6eNPI/qq3QdBif1w+1x1QuN6i6ekWSPiFtuKUFhVl2AkbiXhsOElFRXFm/F8UJULudwutWlv
YokZmUuULG+PvPPrkzM0PMBmOyojWstQVVfa65cpOt9TaZPqs0xLttbJwiHJ5AkTOSTQk4vcWFl7
dUpt2bTyzqPphZNjtJLG92IxU4qt3MA/jEDtB/mj/rp1jh+xmJBPrPbYXmoWRjY2P3+hyIXCBYAK
/teAmd3X0RmxtHkr+R3RJhz/lBaeqU1lXf5SrsgOK4GBv06SegnyZBtUpInv5dyaTXck/9REvj/d
t1b+Hb83Yvy+HHHc200rPgLUyFbMHhp5Agk4bmZtjfRYGI0aQw6S5EGk448uaPPgZi17H7n5W9oK
RlDgzZD5Na9ht5d9pvz6Q5zCtuCITnnKlX9GkL4eUGGHovNLZsULr6sGqywsklCwa9eKGRQIxziT
cRWR/4UWQcIEzxdyUrG/7NIuE5QVrfzKBPusqdGvlhoI1ZCL43Da9unYMruffKCvB2cqGNyY980o
dKpa8FmhZfc7NcV9g2vQfozQPvWGvodpqRtpyZ890sQeC0rO9k9HUia4BaScaclMw/Uj0yPcmnhl
ojB2Z8q9bAmCr8Cmu0bf8QsMbttoSUZbGMfTwybnH/4d6UVnaqg2aLlp1r6YGyGK/Shht5Qd0Xro
XTl3Nv+jTMiEPgRJhXiPoobQtIun0nmxb6J8zaNOZ0xFi+NGVwGXq7wXOXpB2EWWJisnJ3e7mZsE
YRoAc4wT3eRp7O36GM4SpqsO9D3enXCHPMCgss1BMHEyjf9X1YTzZNZ067WQPqwXRoU37BqJvJ+q
q1WhZBWQ6bKvVOc9e1kBKCaEHiz48R3uiGdABYP1eKy2EUJ90WIekMR2iOf91oHSCKFbLZAR0Ikj
wwuEbZeC51eHjtziSou9mm2IUFDMonKodus+dltl/oxFmnSZWOkJuFMLbG1zLYuRMG4B+rxgj3dg
kSYNu8foMOALiGJ6AzT27PVhvGN8raJs36WQ1Xf+EKVEII4mKS/FgmNDMjMMzazD2cFS0gouCQTR
ns4vr0NUuxUcK+AD+dY8bVQYDUGclnO6z4SxYaiFk0DlaL/GYxELFjuTKcTGZYoDgXGeAkicU9Lo
01iSecolf7R3S8ePIZK9fq7w8dNFCLoTYaDBXRQwreKIvngPDmSQ6PXwGyYfLDiBlXht4qob9QO7
/nkXZyWDYwaAG1LTdxD2LO0avd21WddcbkQwEEuX9c0ftjqgJaal6F0VxpX4kMVNWg44or3cScjx
TCIG9K2TeZAp7r5HGgVq+aoAfe2cGWfpsamjcky3m48wWfTaYlRuBNv/ex/LxdkfVMVuIt+dkRdx
Hxj2YyBlFpjMD2eZjrCJLpZnmYISG6015Y8qh/28a2Z6LaOg1HDa1N52gZ64hBCny6grcxX5Ce8X
KNCE0pVsV34TZRlBIO3pqCf4Cb1OB3/WSHwHUOcUuaXLXcXEoQvjUV0BQk8IyMezgjVByCM6qo9u
ww8GjuGhEITjVFtK1CUEKNnJGbO/Z02N/taJwGEPg9J0XuqFu59s3bwC5x4nqkH1Bg1ZFr/zlXxO
ZUpFzS0dv6Py7KBXWwnxZj+CqVzxZWLFf7IW9Dy9MORT6P2BeRAxGXhtuG===
HR+cPvijWUMp27hAEfKKnZek2butNo7StcQGyCIv7s0/qLi6pmlt5Gyu78U/JMcoa/r+1mZ+fhKJ
AWISBqxXotOAhU/ww6FSZhGJhGky37at3EjtFUE/Es17DRbhqUXGYXsXSAJpvc1bDqD6UQTMqpVd
jZjPbALgtC0jc4N7G36x3H8q2OMg88G2ptM/tAlGuBVRmSEcJp+npXc9UhAHFvw/zaXEaj7fA6KR
rjggtgSs+1dpblD9g+LqxtVSDorx0da5aqzayUpf4WA8YrZtWuD3nn1lIL3C0gAbeGkRYLCrcpBh
4BdZT1PnXcu1fUAvvQa1iuQTkbvn55wolXM2zOZqtHc8MpRWmXNqscR0aIXa3b79SDvq3Swz1En1
V/JUX2bFEmEDWmH+srF3gA9sx8ckc/uR7ox+B0BMoDdM3QXtAqgmNQ4vhdhZpcM/RDrT9OPuo5KT
x610jzKxxGPuBm7dZxbQdglOXVcRQ+m94GN7fMVi0B4Z/+fM6xVIxt6fMwRzr6+53FCbsbqBrmcS
Wwid4tx71Hu9rr1VeT6HkzD/JGGwbVVfOoCX64iP/OvhX0nj5RfnvWZ+9l+cjncsFwYkkd1vTHt4
ke1XGvEHNB5pGtnr6o7iX8o2ubvo23hiH7hO5gkxa+iUoTwkLFjwWkPoCoYujtnnJtDJEPdRNS4+
CSlVELrd+fsIX/GbBabTltovlpV6lIKGR84rIodcEL5jf2U7JCVi+DqTXlB2iq0W/hXCoNHu/HjE
/PLHK20uypEOq5IpgIHzAmWbm2Az2NPIldYnyn2x+3rITESkDfTqcigPQL6Xmvf9A+45eVbovGDK
pYvdz05mRsljJaZg4X0bxp5RV4TkuuNHZNBAziVWkq8xRZAaeJfDP5il15bC2eT8LABKJJFpC4bg
NjMJbnJOvzvLG+rMYLvRHy9QJQ8fh62gwWv9RrN5QWEqTbHiTw1QffZ9YeOfw3rhybf8lpRysEMu
dX0V0PX2jciEI9H+8yD7zp6k5dxp3ugLBbwluQ31gUztyxrH/uAJR2i4MtWuzt1T4wcLlcJB9Ydd
NkxsyWkK0LUKs+rmaAqv58SZ0lx0pP2ISHgmle4xMiQgmx7OTSVq97kjOAqPBvWY0MykZMzsq1D2
I2dV1odWA6tX+1L0Vbpa8T/XuRaG5mEkzy1Z/ixPy3g3C8/MRhQ4cGgoVXbz1dpzH7/452o/WkO5
zLUS8q6HG/Bo67tvdcoNiHaJe4cRc5Vn4pc/cw09C14tEnCz6cIK5dv/48hwRmDwKW8BDZcuKPG5
Q21U7aR3j0qiRIg0N0s6BauAzpzuTHes92eA1sU6PXSU2HLRQd4Au0mDsngjGeCe2qBYKntXS63V
ACKB2Q/DnILEDq9AcDnEt8rpSrY/Z8JkTuh7HwBWtfGgGKaKEHC4b2ZQX2kj6CyvgaVnSilFRwOP
DbYFV83HCH8Nq4taJuvAqXpp88mOQM0MZHU47fy7l+kQRyi=