<?php //ICB0 56:0 71:1fb4                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvnQGp17zhS7RfpM4zXQivKUjhDb7XHpciW5wmrAs6Eumd+3+s7oUKmajsISIb2UlmlEx/ig
6sy8+QF/MyNa3HC+fadn3wvr/M7nbFViI7k2ABkYvC0coiT8w+XbOfGSu/afQKtWOSQmu3yJOG2E
kJK5lk0SrePC9aCDUT8gwCWIV6xobexhrZc2QQ+Uy6i99DyJQzaGkZ/0EomEQd1YLDLmQnJeu7UJ
0o537ze9w09V+UCx3Y5agV1ydQWQhHTC+Zitzm/uilWjh4RqTRwUC3RKxb38FT4lIoBc/X32pGz8
NfH+k74O9gQL1NTTpw/f1gbuadL5iQj2oA3oB3K62T+EQlmSPa1TSiXqb/R1KK7gSInUL0IDRX/U
KUx81+d4pnjXOAbR/AMZKURSeYGnJZYbZEVu/wZLzM1TbG2V08e0ZW2Q09e0W00wiyFnC6hurWRz
/vK7FKERsbYjgUkDCEZI2lvR2S3kK2GaLFsYcqipdco4FGGFdkt/AhfLMTgg2kq7os7ykjki6+nZ
dO8lNbA/RUSZS5uKU6U8cPdePAG7bEo1TV/ecU2+vjE7X0Oidh0hUNSHfQCuAfVEzB+qOAGHj8+s
X69kyqDIkiZde2Xa/AQs4nIrbjhzrmL4xs7l1Z1QUGxBA2dH/GQacMSqR/W+ARX9OQFas6mOtuIg
UR7gU6cbtyQGiVhnYvBDmqR1mkk5uRXJ7IBiAYEgjLIHBN4EYPj8VZiUP0vl27kkH1U3O2H9f2hh
kLm5L0T42+IZtteB3n4L0IKRjd1s4xTZB6TlaIernMjPNDJ9FKzQp4J+emtco61bfbxoKZtRwgPy
8rqM8co5NyNyRK4t90WaReY4WGwozyvgYTlIIOaOMfu5EaVp6L3blbD0B0p/fBAw8I4ow0W8FoZv
qgF7d7rWf9EPmcXD8tj4cQxTq9aPoqu/rntw2b3NrP9gAlbIDDbc7HD2hv3Ou8swvIIRFNpbw+Zq
c5hkp4g6cQasM6dCW+nyxqHPB8tO3SQ6cIHDTUEVPlGnxrQS4opg5xctVZj9kQTZj3ImCZtaI/Js
SYpihM30wyeoQkdccnR2hTwHWisDiU9MSxegM/4+6ZAF6Yo2C1MOy4z4WiZgrlT6RAknJj4A1Frj
uLvsh0OVfjShNFhzwjLova50dJ3gsO8ETLCC/M/WntWW1N+FGwmUykzuT050NqWokJLaz50xwI91
ZhzluHkKvgUUkNCoT59ZOARS+hICuAOQN+xYAoAlNMw5XRsQMD4fcP9qtmlxubAzLSHPhY1aWOCJ
RrrlgoRszLnUr77pOd9W9dpiSoqZwEwsQyjmQcnKJ9C4jEMoPcF+Xsowq6CmaIDF3qT6Agj+zcKV
MHo2YzVB2qdG7t4UGF4UlnWXvFnJufDQqYRkygaQeWomYu10jot08OK9qK5bPC0i1UYlAxNqR7ZO
5GLCuK2BRkHbxguvH5KE7YmLDgWV7j1tH72bUGXHrw3M0LaTgbUZiS5u95DCpIUCM0DWC064Bt94
eshxqVALrPpuRG5rrw0ipHksumqQvqKhbwEyGFwyuf4v8xa/q6+fcYQ/hhCbhfJNZA+I/z+D66kp
v+C91xixkyY1VlDNTSiGbJy+8c/W9+B5Xa7ZZgc+Ue4/xc1va14xh4g+T2EjKecOCIxsO/ILUooH
zV1dQu5FHe2Re7BugukuSja1LVb0yFinFy9KT72VLFr3GOBMAw2g6mKm6sgy6flJKrjUkFkPCP0o
MIErvK+Pm1CcNfconu+a4MrmCg6gVZSPRwCRGyyljvELNGx/jskVpu+Ai72zBB2yK39go6oKZvoP
DZjyt5+WAGB05BC5Pcl2Ja7IVWHm9K3YvG4EanyqdKrrggl3JNhuo2t/lKoCA6uahWDuAG9MX4hb
qGrALCfvcQRmPMy+TdEbG2CkJWa7yF/6+FnuZPMQ6fYMxK64s9PY3SG2rpOahX6/7DJongEaOBxu
mr15iKsga8s8dOHFDtEzzyn2Vz5QKq7HC9Y4EqVZmRr8kU0pBV+A0hAoiONe6obq0QtkGwuw6G9y
EHklhCnPDc6mE18D0L+vHvrn/wXO99+a5AgbaUUS1RUQH/qzQh1FCKDYE19gWKWGNEEGCNyzQtMK
72MYsQ7Cow59ZrLTrB4/oPWHQ2/Ae+DBXwYXqeZFWExhfNzmXXoqEOYiSqypxLMAP6kagdKLc6tX
nQooO0BquTQBD01f0uzTed0IqhaUp/F8LuyeC3j62zE3odgEYappRYZUQRsc/uCS/WI1d1PxS1fv
kb9fAtV51K4uiZjpDrjpy0bgnSpImN/v2fCSiY8VV7ls2f6rDRBl7seBy4dQVirSwojvhg2ZYdku
aih720fE0yV9OeWvGaW+oPfPAXIlqf5UHwd+UU5OIID1LnwXcO6ge+gkqwLuGmGImHMuJWo499iu
6mJGBIIR50E1XEzGPsUNlnpv2QkWhm2DYGHA8Ps+9EXhSZhlI58LY/LkcsGYLQy5R3188mXaMj58
KDqmsnEe2YcsMujVJu6WbM1pJpgzBol0ZckE08wI3V+ILC9idDzpJrDnPovZlvkb04BqYU+J9byg
7BoGws+4S26OjaSVsJvH7pTZHRp2nc4dZVc6gZAzQUWrdv6RhA8dllRp8RtzgchaQ4k97wujz9yN
BiVgRQVSJkHaOn9A7AMiXN1VkuKH/Nw46f9JkNwgzcKfA0lTl0AjbkxlmXXTThW7knMegvre0KPG
tQnKf6QRUP+vQOxXaaMsexHiMaBer/qBHlzJ0s2vLOR8fpDs+D5ROYoxsfL4jK6U1tZDNQgz72YL
2Pz8pNlF5x2FJoWLyl0IbSYUulVPXC/qSycyACcgJnelSyHdw5JqxeMJ9nuEnIXK+OEuWWs71Cxw
Wngwi7PdeDwp9Weef4yXZZDxHyp40Y8mIg5DRQ8XR1UqnCj5vLWwJfLH5oeQlrd2B+OHwB49iVD2
BiVnenFVI3QMim/OuHdN1S2LLpy9FSZz2NLwJvCT3bTSUNq0HK87mii3YgGsc8W4y+gp8Z01r5zH
k+M2corM7k1yzBM5WCQVcfr/scTlsdZ0yfukQ35BuIC58YQqgKBSOyc8dvIiQJ/cXxg7UGmH/yG8
MPaiYlMiX/RiLmUN8Smm96MFS5nP0JvOhKkKDOmIIPluMIJuyzGWaUaXXH5rgf/Gtn3OZjPBFhKF
hN4Ezt+KXaisIH2Y2VVoEAIqo8GlGR8mSLBS4BZsaymjtRkkiHTpexKq9Lj5RZQSQlVzXTQ4dj14
AHoxo5pFtwwG8/7nGuJROL1e4zT3I4EKllTLE3ROsIhw49jVDUCbuglhfqioJ/7uw0UflwS6a6ua
2Z9W4UPcpGpwf9mhQKN9q3J23MYKy36Mmw6n4prO8XxXN0pZKpHnZvHsCEGTJ1pBvraeeG1bB0cI
y8UYqQdRIJ8Ut95m7WFU11fNEe7cLgr276t/XIzFb87+CcKjIITrx3z9MYyotlYKeKxJy0yoQrzn
FZTgtyAd38tyVQx8VVvIvMJQNP0RGIkmsHotyYHqvZagzLR82aYiSwvoFn/ihvRUp0JqcOo/NYiO
GXpm981sA7Vdylbcu1p1CdF4i+w2giOFqlsEuU/LveWmSEw4LDs9D506AXy9RQBPKWs+P216cMCH
k8VNVX8Givu9M0+SBmpNRygipyMU5PCz1txOlZbyuzkmRAVWeFgbGCfqqbMVsYiMdev7jXY/6CNn
6zl43mc7lixQI8HI8u1i7jPd2XetATIHZEvzoSZyx6maz/tRyTtiFIyfzwwNwZ5Th+21QzDC4V/w
dN89Vc3TyRunMpeljz7R09OVwI2E/XqVebaJUId0rFV0lyrrn4I9kdF3or3h52y4iC7wVWmFGVRr
jonCLc5jykusJRlnRezuo8jEfE36sBM+UqggjVEHIyTsbMvFHRus1+9X6onRxU/Q0GxkSYdDtcfx
8iWTjRqEmM7lOWphXoaFw9T+mZCo3x8ifKGh6RTkOUhuHr6Zgee7wt1eh9gqRVg/wZh4KjORXB/e
r1jnUS/zhMz+f2o+IfuE8Vf7adPP1sP7QlCNyC2Ym689V8YyzS4aiq2H6X6MrAkJ2r/K6YIXGrAN
zY/TadBlmZJw17B7uMcpx8oDpLoMjd4u15Hoxxrzots2u10UJiiCduOXT5sk95Lw5vp+80RFR1U4
+WHzJf7TcxhBEHjOtFCev5F+T729ALO7AsHKgOur/cv3LG9eRIU5orkziZVsN+oYT7C21HLnXUl9
xVf3XyAHwwVdwpEUAVmQHUMk1gGWphWBBQP1O5/yW47XCqB2CzkmOBdWqToSDV6c5Lo7AK4mcKeU
KD0FNhq/nd+x5l2S/8sHLEB8YaZVKzsQW1sFNSe1Vkylmk88PKVjHC1ZYz6n45fdeUcVrbN1V/Sz
N1xYzjrm+43Ijbi9i+i/q1BWCxMzajPZH9s6NGodqk8xEatK3xqtac1r3nGHtYV2/dLDdMfT/PKB
95wf1f6vpWcV5i/L3vHUMCl7oQJ7ezopf4TbgMeEYdBkIKu/C54qc/YbfdAQLjuu8jxHXfGlfCAH
t/GpDNdQE+Uamij+if/UtsHE44ug1qQKPKMxmqtAzhJe7B+JiagHWoCDB732fXlNMEpIIko/63cr
GtgQxt2YrNf8QVFhZd/U+6TP5H79ZRTMgnGStB+apOU93rrriuQUZ6lbqiWVRFoBBpZSLDQsZb7i
ZvumJLNc7KTJe2Xd7uU2B0tPdulqmQ3Jw1amqajRvKbxHtX0cGgklGyTlaZ8g+Xb+1/bM/B91wmg
4FgfdHaN9294/WQJs7Tk4dbhfxUU1MP5EAgTlu806p9hJV+FVrgxW9sPfj4JfNNODSR7Orsov66k
4W3hclNDNOENLNqK/GhPiwSUrYeqPI3G41PPHUAInXq1RV4CS9z5iXVkyEHsnD+IJuZchpypaZk9
icsQ6VC69YYS+I/H5NoLVWU1JVmdjP41g1axIznvFuIg3RQd1FsLTErqk9tRuQ9JW+SGmGWaX9bT
K1dzZgjp35vCf3H/6SiSaNxCIP67W9Cw7lU04sRfNjQVN/QCdSr8wlHhjT4sWB/L2J/2SJPxlGUH
w+/rA1fmf9IczFwivwN8MSNn1Xt0CRxdvA4XqdJanJGX5dxMjLPffhqSHUlC9KfN1djwvGd2FKXP
TMiZXtmtcqNt+WbbH+cK/JKSCUD8TYwUBjfu27dNKVtEoE+RboyGWDmGfeIrMGuSYLD48TjlEzFo
3lkFRLU1AD2mmXpfpUqBYtz/YR+XsbVYslCG1HQVmEcPZJFAhrAgHbFApxfUB8RvJrkGUnKnnM3y
BZ25Y1BnQcPTfRDc6NPM6GfzCIM6Rh6zwdWHli/wZs3/kifPLZIaFIvonsHuhJg6bwSxJZUvtZW9
gKxXZyLz/DFhq0+OO/34+ozQxE3ksxmneO1yKP37G8qFoE8Siri5C0nAN/sndz2TJ0l94rypc/wO
Z6/cHN/POd6FyTFna6WG8g2aYUTL=
HR+cP/SgVD+03KKHBP3f/D8C/OW7dcmiCY137VmWWk10nUS5RgToHg1b0F2rU5WJy3G5J0AD/Z8w
qAvp5/xfcBUtI4G/qiEKXQ5HcBm8dA8wOJ3kZTvVHi+rqpv+OrQp7Cv2DElAKPqUR1V2QUImwhVh
rEKJU/wh23tORKzZImekVTrMqYP7qGjhCD+vZ+RvN6jIm0p7T9PkofCcTI96/CMVd5/Pf0q95XmA
aQP+no9Zy3dR78d9lwYoxkGB07FNJDMd8fMnU9vtSD5O2Wutp+p+Uj2p3vbGomAYfQCBcubJDPio
wn2vutJXSN+P3ODM9QSQXFo67RbU3eRPwlpo/fNHWAxC0bEK1nIYZ5NCuotKx+AksHsl1TI/jXpS
4LNwuW0qiGviVt4HaB1evNDPWIyCGjRGuhNj9n1f5woTUtXkp2l0Ff7egdJIcMECEwxSUXI9wK79
46+5QdDYqiBFZ5jH/f9tPWP4owIRO+O83PmdlkEnH1ioAjbD0zaIH2UgKOxAHdWCsdnPyizJcdO2
Gbl2tZKpbRlDvEUQzYQ3r5Md2XgyJcznyq4dV5Nsb7ebT3cevZr3XIZQox7FmkWwWe0XKw+KLId0
sMThRntHadV1LqzyaJEsgz6wp+JVuVft8wjbSOxMvm3u/43s9047wyYX6ak4zxFB5DpNQZO2/oy8
S6tZVPA6o2BGDI4MZlWoie+qvOgIG8dWg2mbaYE8cj3TWZjwDRpIapqUtVUipYvPBjlibbInHMfu
V6iJ7xWBwPPcLMo+tUTIAs1eVT/M2stMWxGOaXtb+UJx2TcSnEihp73+PlRmknd3+iJ4O/YpVEnd
p5ikAwceMVeW6TUXk52mChAgwMgEp6615BVre+sV73Z6ZbNTSCWDL/W/MWhIlEZZywqeRpcSa/Bo
UumSwWBSfPbBw2qKaIrbpl6liXsPN2KNdOmt9KQH6aXmmDc9dDzZ5oMDwFDjzCdlU0gjBEpPpf95
IXd73OxXKAyNdd2HmYaAXXfFzTs7/RIJ6mCQgVaLKR9GeMgNuAygW73Nko/207/R7+pcT9+3a0yk
XwXM98G/ZonuUcipx9rOo2mMn+0sNbf4wHwZHj+NBcBEpe5bxAeSZi7mPY9yEOzPEYxflE7y2snS
M3hWHERMbou2D1AfJ1EoSBCf6VT9X+xaRkV3Li0uX5L72RkV/nKvchztXdFDH7X3Iq6NBTkMTiJp
HAMqcMM3Upb9N0XUOelGYnzUOj7SfbXXRy/INFSBDlJhXsdAgunJqX2I4hrdyBk4JkuhZJwUjyhN
3pCzauy8JfdPKbYL+Rj/noPaGeskfUUhqfsrehuwXTVB6zAKZQvRVipwd3OW7qit7vM+Y8DEo6Ws
dQ7mifonNmhMst3Zrhm2RVfxd/fSz8u5zdQrWic9pWJExfjsq1CjkjKfpBdwH3RPv8eMBsFmlDR6
L+diM0Qk5xUbaax7/EmWr3TvLtaWIy46hvXL8ZVdDOUgq073M9CSDTy1NwaWuXLclT83OhsFebS2
dRLCXMr6SBfK68NjBqce3Y7hNW4HCzmI3WEsID/1I8MnqDsTzM68b2B2gB2L4NfMI02chOMeRHEq
OSSlntciCoSa3JZtfPJklt5aT0Agct8VaKfALGyW2tKHYqwoO9pf4ijAt5/yvvQj4e58d6LJ5v8p
GwZ7siz3weoAUFRAO21GGuagH+psdwQnmb46PaStVHYtEdnUjl9UJey/TDzHbjjj/KQfXVzp9YU4
TdHiDMzhSSb1FUWpgIeUdkA8H1lyKD5pspiaFaGPAurIba3fXI4dLPRAW5ajp5QzJPImX88R9NVK
mGNN9fxUV7veGNbfaQzAFnNMfgTBCq9zYzv98Cj5JxCVYwXEo0WQSnIbJUR6Udl5NvSnyVHa3qUb
9RkwfMBFO5LAaubudrX2DYW/zlUraw/lmhKfpISLjOCt6TiRN43hKTebppiXZoPGCnPY+BcpXg98
KwBEwwPrIejUTY7sbqK2vxtkCuUeYtbSd0==