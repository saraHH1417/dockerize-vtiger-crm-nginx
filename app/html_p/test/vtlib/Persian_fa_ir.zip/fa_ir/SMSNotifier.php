<?php //ICB0 56:0 71:14bf                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPobAUJdD7a8/+8Ji6f9YCM+uP5ATbPF+KOh8n6/9/TgM01gU6XCMEAhQ4dQoRdXDwzcuuPF4
Lkli/3USD+cRtmG9pEPFsq+m43VEG33mveHwPBFJElNp5OOrbrxNqCMxvefF9mOAlilePkJdMztB
wzkVcct3zE3F+1UfglHp3DkrP17SWlntYpR7ymVrLNSeTb3sUkYmkBVPctEpRz33y+1rDq6uspyR
b83KM/XwrvKUV06C941smSarXAri1g/kjaWfjqKdQdDGCrCgW38gMZAoQiWzqIzB8kR+4CBD3qXU
b7ujU1vBPdMAJmFyEye6kHIK8WxGozxjsZUEgFT+icmzeu8AIl0sXDjKNZ3RRt/rz4afK359fg64
ZWIjd8VvlCRJmyl9fenZoJ0jlkcT29bFlujLhjz5DC8rCcEMCqL8VXA0ojq3TaPOHSIdRyMHzxcK
0od3KM1F80SvYsPgKq29WRZOOLTbISEEWqjUi1tbqZKm3pXwayzX2tggnAoLAJYqkStgVrvrOA7d
JDIGG1urNcDdKGnvkkBq775o6QmsJWN4RpiPx0rVUBcpc0DZ1pNKb/Yq39EV/yOjxlUTpSn69nvr
BPv5r5GJN4kKLKGGmoEs/+Z+v+dg/JyPlSu07+vQHcC+4QoP1/tiNp3hqx8sWZqB/69P/rWKTFEj
TMUewgK0+MXhOKCJGqZPHC11FOYebw1o5cRdrTVE8+NKtupaBrLWPYXRAT1tjVk/iLqFCYae3CvC
cZ6DobFFh8H/NEdavJE5rTB2YPWxdfsfCExXFqTfgR3b0aBTv4Io2hmhH7bFJ3DmdGF7NkpasV3C
viuNY6wkn3elmkl45nSgaQYNc0LhWBc80suUBhuzRFFowqzcg6qIbcFwCxz15GsEc0VsC4MzkeFk
wIxmmJcQYccJ6t7PxH2/xjmaWBorpaNJ6ccbuypQ9M72zqLFfGQn/GV+6IUQrLO6Moj0CHXoQfST
G/FclTekQjItUb8aHKek8MbMFf53BdrqB6kcFkUSB+5MfcHI+STX0NQsffpHp64X9aE1boqfKAKC
VsJFAwkhz6Bs+sCD3cY79FOPmiAQzyWCA7XrZ56w6soN/jykjSMlxeCW1hYga2Wbd6CAZ8BQY8LU
BWxZnfk4CKNU98DW/2oOi4IbenbU25HtBvYTKqUA3PhmQCdTTAYKkq3oAj4VU4GcbOp77k4Y/16V
VTFbhTZGbsltXN21OphrRywWQiO9W3MboSck1OvGb0VKOdEt93yt35puO1OcVLyYcvH7T14t0BRw
o+T3npxtrBH3Vnp3jEY/JEaJc3MysJIvj6XTjzG5HREQj0AU09ONqfPlpLHIpFj5jLRiqyRWV9iX
V2QkmyJSYS7+NU4L276HHys7ljBW42o0Ky43nleEMJsaDRXF09oXPBE2xmxOnz83yACLgHqaRz14
7qJuoPobOmtTdQupLYh8J9/l6QolJqilAs5PvRz3isalqmpdLwA4lqrpummT/t7R4kk3lTP5xOUo
u8ckIIqFpO11JM/c2FqzO1cC9hIT7sptQxN+EZf8wNbUsK5Tg6cMafpP3MFUamnUw2UcfD4rld25
FcEGeJ0xaEAinfGkhb9DcIQEzq/JJtkJZXqBDUjnFxOs46bfPDOKInxblQkGDikb2voCptNJk5Ip
ClBJlOLZZbg+o81LEhDa/IiTUF0+Ws0zbWG4yz9U/tezjYKmE4BSRjaxNRMG/4o6RSaVQewb4QaM
S0zvevUJlLt1TBnn17svnFrncT8Z9v6vrzhFxzLgeJi5uEdUQaLpgCRv7/cWYqw71AFjbjeTNU3G
pDpWlTIpWepD7rETDeggf5kmVZMybyZ/udMuQeYeIV+KCrnFvCh8GE/IjG/aBeStwNTQjpj28AhJ
Wy7apqgFnfjq6GqSSrvpd8d96xmz0NNNpx52AO2dAdY9rOALU1Fw3TIZZs+108iCBEmtH0ELlc1A
2C6QSHS9APz6eVfpLx3pBUBC9Y5oImjIMYUcTFzylja8SKsZnKzHdHG6asdfi/sHWFyrM5vh65k7
NHCvh9vHEGgTnwzy69rpC5huohYOlkS/1XDS3hHgVrWtNiVnmFYVxbDal7XVftet2u09HIgt4grX
bzx0auWcnKdsDRAmWh2uXBm9Pegjf0Q5uHV/0BiIicMPCOPzzaCsSpEFpPpIWtxsc3Uos8ekLcB3
RNLb4QNjTw2E7fZxTVgrKwkNCkbq8rqVZnQ3zQLj6qIEoJclbQRPD+7pTsaIqnKFta/mm1rOca5m
QLnUFxabcVCRxQBnPWbaTuraAy27gOAZYLDh+CwBzcaW5pt/OG+ok8ya51/WLSGFw5GnchyQfagV
lTjrWadk5+pT5RmADzPItklfwBmdedCsZGiahAVWmw3NSJgRTpPCdijkNNbYnvU2kLdZEzQ8NHwA
LDgm2AzpHhEZiXUPK2Gn+rEnk8GhdbsSLEzhu5Xn4hNSSc0TaO1Finz62XAjLy3xO1Nx2n5hP2Zv
m6mGK/ODhsOLj5BmuQurcFmt7CA3q6bdLOoAslfOczKESYMJoQ3oT/p+dcfGM/6UnTs6MxHrnll7
fxOdfRHp2xZ+KprH8oLjVOFCQ1hdvRt8wFF8HSDwAOGHEaYMSDBStv8U54lhmV+PbDHqvQRKeT8o
zyYC15q1pdW+GLDUVbugAJtu0Cg7aD9+MnE34Oe6JUYSXw83U5srf5vAfeDA4kFOjAo7TEm==
HR+cPssgRDDGYLNbNHNvyE3Z2I17VN//nJYNUz0YsTptCYzQKcYtvcicp1MmrMDbepfWbGnLR6HF
RG3LzwN4kSwMJ/4WEMnreaVT8b5WcXKYwrAYiL29CJKKMFtvXagKxiTmuhAwXvPYC4jvkNVv3m3U
S6hCiFWhkMNoVCVhJbrXquL/ZKpAWk9Bk2aoxrdU+XMm/LENZFY61ZdfxIoUr/VQq2xaZF25/Toa
xIutkbfcxAoemyoqpWDWYFcDYf2nQWvypTrf6eBK2JZ9AK0Fmkah8g2WYn1GrmAYfOOBcubJDPio
wn2vutHjUJw0sLLtPMglM0U6dH1cI/z7GiZ89sJlILQOdX8E8ydZjEc3UGatqIBd5hO+bBWSA5vG
CqymlGQSlCuue9tpf/a6Io1l25u3oyAthW+N0chzJ8inMBrQ873n39Cql0x4tsY6trnZV1RSa+ir
HH5rUmTm5c0CGbUL1lUVigKskzlso4rRwpjgkRV1ntge1VrxaaeiWZT8cFdwhrAUksPBKPrKYDxX
XagL5Ha2qKyaui08sbIvDX+6coqW6P4o5euVRZqFxRCl9zw4Nd9DihrZnEgnuPFc26yB4CdGB30X
r7ADAvjfGQD+A7hmoOU3w1Ssm3vzHar2zK66gkyECCejLTJLIIbYdP+M4F7WmDAI0NPI166JAIUI
/sZwiArDr8L1NQDaYZ/gPPTW0whb69lFq2rpPKhpNfOIGZcIb/tNMKUnpBinexozeXz0gXZbWQEp
PZlJN+8suyyxH775udBDu82HsIHLm0rQypr8/XNnmE1XjgrLO6QPKGa1YwaYgURS0cTUPZjFypTC
MIwR2vzKng3m6kYP3qgSwOE5AYo/okEt4kqxhkVBJw1UKpl9RDZqu1s9nBZKZxJ5hUZtI+DVANhM
A7vVJG8OPqwyl3MLXRpPZ9WT7pcXM9LX+bLQeF6wLMs0j79ZlLws9w7Rdd1Kn8v1VcVUYfaLTopa
5U1l56fyfZzTpLcI9+QZNel4sTtd9zcTg5DTkZ1xP1gEl84+ntGZvJMsK4mQoMpZHNlfO+rXDja9
xSKKmsL2mtq9hB8eb8gHflfXM5+8lrlW6S4ZlFhlUTp0/2v2g/BP96RSObJexWqzRJtr9lTYqrgN
mGY+6TjHaufxPrnomn34AOgMyJ9l9uGn9RDPAJRxDqjlV87hVMJ2BVJTgvfWTcNEh1olxijhet5M
ZJyf2S3fjxaH/TnXL5OQpks9A0lWUXCp7HN5uP3T/RDuOJW1hmZpfw1vqfHNiMeUpvEyS7pl+uYm
RcZS6m==