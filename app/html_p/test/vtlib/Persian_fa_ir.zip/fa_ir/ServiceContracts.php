<?php //ICB0 56:0 71:1cc6                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxi+mHr8b3bIPVfKFht/7BxkrnrQ041TVwd81m0SGI8KO6CZ39yzbjT38EsJsblYkbs09lcc
NxPzbO9XBjv6xhrCU/ehOIfLVSRNJR+XBevdNv59SGJWSwg5Gmf4o98Pwj7PspjpjgMBRt9N64SH
9FH+b2UMj5o7BgTh3eS+ufclI/0t/m/hJapbtNNWj7I053Jm+FgPEXZg628xxhCXcR4JGJ4CxME6
KIsmTWzan65C6V9lCxz4aj7W8kNwdeqWB5vLgXU84lnfsKhYr1zTGUmhMSWzqIzB8kR+4CBD3qXU
b7xqQuzUpJdrqCmhm9e6QVUJGgMYqUtjQfSbeK+DBaKb9JCKHUxig7kCIDNpVd1EZStgqZXhJfbd
C/1ctdLNlYSpNbUSuiHW47EGkXF/M0+f9ehf7G3B2LDL8P63q7RbzodqeZaxD2Gho/C6BP2SNHo8
sbyuPMwZHyJIPmghhxCnNu5REnSY/r8pZgzOPlFWPEm1IbPy+8CQgR9FqiArzloKH+bW63V4Qpc8
k2yxOZPKWzbcfsrC8ZE2xLXPqiRMdkuPGpISEnTYJIRZ4w8uoyrdw3bjp8Uo7FKzHJGQUYp8siEE
CCA+E9GIqGSHq2EuFaOLIikAHqOIXJuQgINsjI8jbZJQbPurSCOu8L1g4YgnJTE/bF0Q/zMoUe8M
vlX90rZYPEcTU8zEaZk2HaP9hBDsSLsj2KAwHwS2NrMiVOl+AvcP7XEK85xd79bwa1oX2k5LIf8N
eAkr1jAzZtdTRon0NZvnER1dD3lSt6Bdq3Od6tCSPU2pC4h9xC+TqJbX9mMiHhfOH202Wu37lghI
BegCGNJan/M/zxuHGaxa+CYSLz1MaxLwz+YE+0hy61wzonITvU2UIw9uldXqAX3fS4WryRNFZyMB
hx8OCd4LTvdUof2ea9MNiU6alH9/47vRTJy+u2RmGq1CERPKUy98/awDPyxzyo3bEZ/yruIAJJx/
/pWjA2hOAiMyS3OGrmf7/Ie7v7jcNJx/Pwj/LHm1lECGbb721pEZHXkBMYJxvs8AWiAF5YYrFiFE
h28FUQ2kAPijWYeraBky59+EvRj2xcY76lYfJgPjZQc+3uDogd1JhkHDgfS8ML0EBmN9xw3+T8PB
6hoZdKFTUhjYBUQHopyzGfvvVIjLVO/QPQ5lJNw7DSPIfXz5DAggjE+yFj5a4wTUVJXSFxFJKaDf
1Rxi+CsbkZSCSsHu6haChyJ2kS8OSYBh9D8jTFZJzhKuzbNNU1MlceK4MFxRgvwIDPIXlEqsz0MD
zF+T6yUFgZUJOV8S1N6SXHQL8vukYCuxKyDED/Wo2701cdYbeGmMif/OAiKJOCzFY4OE8/zaXTBa
xrd6kT7s/+TCHPWzXYCp8JreETGMBF4vkMvFsf/n9b98ykmTJJ5uBUnDKogFkCEd1hwT2uClGM2Y
rRn9V1RSdhEsoeHHNepB7XMx3D+dm55o/tNYM4iexL/aN9DUJwHxec5d126ruzVx+d3CegjIqNbO
qjKePYGuif/YUdx5HbzyBeRJok39vMo1staIMnNwBAo9mTF4Lqhs2qgvhBVYIcJk5lBWqIBAEcX7
LVpJlg2mZZ2wZ2KrkfnaFYDsCEFpmiwn2GSiveJd5BeDO+VqNBkgRZVMAG0V25TVupG7o4Cq7/Se
j47cVdqHNePWD6IbyUtlHwDL1RhAHlSLCA70AfPXtvttMeFdDn2PNTtd5LyCmlLdNsnp7gDWa8yk
XOoMYNlEXBz/Qkxj+9Rg5PMY6yurvrtsUhDcxVpWJQBnu8cFLucQUx3GCQOuUE2CcsYtjeiYdx01
rM0B4wzS6YeHQWu7vU0MHbqorwtXj/wdMIGpbZLtW6Utf6N3Jzu5v11FOg3QCWGrT+s3Su8fVote
qbxc3AWFTdcyungERNPqljiFf2/jwxvrDaLlMKSsw8S3ncVEpm6Rk4h59KQWR0S/51tvIf0t3VSt
nNCTB2Dsqzw6yZbaw8lXmm+32byjZ7K6R0EwokgEYFKq6qHDxwrtIsOxR0uTxmYfY461noFoFNnY
8htkfeQo4VOkTgNBn/OiVwwMA8ETPfajBo1Gn4py6FX8Xt74ffzK0szCB8OHW0njPcJzMcRz6Ld2
hY/WKEdEJ2iQ6wmViHD3p7FvqM2RraQtKEmq4boGU6wmkQG9T4DnsOASxpsSdNaiQtBuSUPKUTgP
3BY3bnot2tX5nXmAAhXUb6LwDAtNYpQT8P/Oa3wI9uTFpnU/zdZufdBoxkbBJ46IqJHIGN9e/HAg
ZyKLQpbK1VZgr5O7aMzO78FEf5y1/UZoUQR+s19J0LJy57wnSAgf/fdo6iUqGqQSQjr0MSiQYtbi
zZdcgZhkdqlqr9emQVTj1pSGpnqA2ylEJNjxrf2AMWxsQ4TpLBA0hVuKYHPAf9hM6l25MS77DnrO
Il3tgCCEcS16++0IRfI+YtV/9Q/L5UTJzuT0MvWMxAMS2LUDYbafg75xQynSOTCET1CdVF0tfUTx
VwG6G9KX5kgVIpQBp/n2KejI6PjIwsh33uBR/pHUlR+Ytraf+eXBoTxIthTbfZSvOjqb2oRWLgfm
Z/e7wPfnpGcIZj9sX07+huNYrFRXlTiLrjL8RlFRaqJ30efQKiezD/04ANM/LxDh+sd0qGp2HBwc
Z0YeqXe95bw4mR1QFxq2LatOPzoPZW6LBpL0KbzUgnL1//fzXRY7cVvIfea0sr+Icvn3OFmcYZCA
7dcAe0fsEtb99gipvKtaQPjOuWrLn0yfmSYG9W0D+GlUzRHS5nfqGnwnXGsxJQM9ZZAIOddQexXJ
hipayVkm+bOBba8jbKoDbX38crAFUTTw95+QTuJmK9WXxPRSBxiPXr9QQnh/E4MsZlM712hXlJP9
byhVDNdvv+vE7bYfSDFYY0hz+6HqIqiS5h5QKUIpgRihD1kEUUm6azWUQz7AHBdTELlB0PZrd2Ql
6lyLvxfEPJJokKQ0H4X9mCcRDFdJmVsXEibpLA38Xg24vlX9y/X0iLBxgJKv5VesZV9WBT3/NB8g
wNkBoMyeB4DbSYgsfD9tsIH63G9ltRjVlt5rgweKN0prA+v5hTNn+Nrdy3YPwAt8xbcGVrv44MrI
I6LLL3FVEckGm02Ea5V2Ap4qDEZC9tG5d+kOxzg2SAAKxot8FoBFtZ+VL7uQPCHQjdhcW88rQRT9
jQGONzZVcP+gML+1RUs3VQtO7lu7P5h1rtXRSmN6ivqfTvT121yDBaSIx9qBQRRQv+IiOFGF1Z4h
+pWp8vVPHovktOuF88DOf7vd/wt1vULxOoMLY26WhDw5uOtFS8r3Ems55QImN1FYu/1LT/9zvqvB
Yz0mEVqEPLTtXZjPtTtNz5guRfzyidJEqukr5SPDc5akN0xaq68IKudQOgrKYaFxUU+ySfMCWszL
q9/H+pWUpScY/PV0J7NOSVyxLfJxg86F8klwKdrDlBDEcJDxcuyZFlQAhDVeHkgURGZmxdjtjPiY
MoYdoLe3aPCmvfHKin2bhpSW0+Hrvhe0KxL+j6kR8AwPk4OW1tq62Q/UOjHU04OfuKtSjQwiw3l1
r8iM+RLP5X721zIFTS+pxn6pXqO93X026Unpz9T3y2+8yepORya/f4XLxNVDBksTs8jDyo3Ho/LP
sNUo8QdbuFL5mR38I5dyfVKMaowMg4Jnob1egaIwGCGqGz3eJ3IUTi3O3hz6fE5xkVYyvps2t4WP
Rengy45sLxlTpO5r3xpOJHtS0thfGgkfzZ/UGTeP2n9wH5KcFN3D7uro/gD07xYNM6Z2v8f5X9b0
1mv1dXPE0S7DRFDiQyxQHwAEpwA0XX4UBEZmz5Lw4Rr+JlXbqutTUZEQkCbZ4tOt4oBpD3U7aRrF
Ck45DjxUm2dFnp4u1l6VDzaeZgOdr1EMHiUsCPfrhjW4atlfdSpPccNnDjNWRsA37DiDZm1OZJ7Z
poe33F6ngAw7AFAWh3r2WhIq0VpJeGQyG8PbRLo6jgEwX747QJ0KqbJsK5WORrKAMHRxH2DNyQn2
MyVOysQeGIU/mpxYwzU+X70NXgy0EJYn70+iRx9xfZi96Gm/a0dXpobDgA7A4Mrq7wh+MJ6/OYxe
fDp6PgrwZyioPqj3v/GfG8GScVb6O3GWSI7/4DBu6gF4qBlyTDRolutdeCevn0lhN0nSez23xGOD
6r4AAHYoZmnq8edU77RtWn5phWDjqaiBoCnexprM7QJSL1rujJcPgVTIoOYE9D9qheLazpTJk/n9
1ytevoXbym5/DqUV/xie+257qeCVUWwsB7MuwhsKnynuW0GY0Jdgb+u3meL+wry0LFe3bOLxzaNG
cU3dU+/JdM+jErWFvffkEE9d11L8HcXv7haV4n/6uE7k/J88hi/d0mFxVNiDD9vvO0Bl6l1KyNDN
ABQS1HffMuN+LWGt806dQoWBXMTIlD0sQrf5mCo3/W0n3igtDK3H9C0Kp2/JhUO/Inzqlpsn1Sff
qzRpOaX5prFcZA8DBSRVNFhY8QXwW7Gpw3W6tRqAVj+OE4pQPBdA09xP+QaTTAsjoLfeZKelfaR1
Ln7zTAwUSDISwbRYaoo0zCwc8iFlDzgBQiFH90Ygq50T7B0CDcHTo1mEP8JgAd84Simve9U/jHg6
nmt6VraQfGlFqgNTA9bhi5dlKHbDT7WpBUqfNg8vK3bl5ouJv6uUY3Xi6WlhTduvMYcwjv81Tkqp
+8DbJxBTIBBoTtq3bnQ00BlI8JhRipqSWp8Iq2eIlwro388==
HR+cPulSlDvnEGKHV6Kf/KpBmxdcQXhKhxO0rVcvIqKIXIXUS7DJ/QL0/o6KKd2UPo5jd5oGgkD3
6IjyPwD2lWPlQTcrIaNnJJ3I+1Hgjrvjv221SHPC395pSgd1Rc9bJsyX2GUVDfkzB/V/aiNKCmrz
9LrfXfqhICExYHnISE/BoIaWoHMPYQXBr6NPt1eHIFT3tdqLuWEWVaUCmJPgUZFw5QI7PSioJkBQ
QZbf1cN5tWi3nq2cHunozmGvEey/tH/sbvsVOLNvhzhM656JqYfaklWb9r3G0gAbc0kRYLCrcpBh
4BdZT2XjIU6aDARDtaKYAeOT4MO///RnhgPXUduFN9HfEkaVxagg8v/q3mpL9YbJFW8XLxne62k4
14PtURApO9RIWh729lmdTYXAyS86RGYNTH2x6/AxZRIJ/zxyajPIz2LCBNZg0CHg/ZxClc3UIvA7
s4WdV5RfSO0QJjLM5oUpW8c2P1HROmSLrKenvTUymesb+6IiaxsWupVWwUB93LXvl+M85WqXbhJZ
i2LR5YLfwPOBmsLkKwJFc+9M9CASjM57UgcVTFD5bWL2/0TXZvsHXYYofQJlXO+HOIsn13s9SHWl
CbAF2OlYv4A2f11OFXvMovLx2agu9SqICJj8QAt6fxYILGDcTfHd7AWTONf7eWY7Iq9uCNv+ViSD
jfKwnBDdiBuLWad+hyTgaS9bV5AioutOXba1nc3+AU3NRYuExL19DekGpS4lUNsbEUCogJRWGbpr
PgTksS4TyagO9QKiPHPkFejuPB3CeV6YN89TpBc4UBrwaAT7Ylr5f2TQLhSsoIGLgH+IGDcd6xeI
WZO0Xa04k9gmcJVh960nUYeGdVErEecvkr3PHjM7ZG0mP65xensCFdzj3aGMjjGdxwXPuOPXa7Ss
ZeHnM+mBJXi2nx8m59Ad0UrreS7ujiNjpcl0Qdy6Yqe3/b3ywlVqO3CeYhL7ikf7+OQgehRPUroz
W7djxCkcSwUdtM751k/a1XB2W6nUW3JnKxzHkHxjnrzECykGVTCWiJr54tdiZUGwIgC41EC2UdNt
N5/RAx/GprtpFY6brcqUZ++RuIXSx40+mwJtODGlSBhmq6TmNDKnvsrURdVZbpqFTR7DIGK96BYS
+qMF0e5wrXKSJyAH9ZtLAwDUzF943f44CNj2uHd5YayRr/qNPvgMxUPoEwqX/VzjhLJ2E0Dp60Pn
GrBeLiVnP+6HI1CW6FXX8x7PT04MFu1HTe5+ATmS9hs445QJzIAx89vwS8jrbfCv9ZyR6fuKtcO2
YhEcshP17jCwUD94OzwOOouAh2d4LHZUIfog9EvmlH41/IKi4wXgufi/fYvMFx8W6NIxhMgosDjA
l+Ewd7mRHlAVuWo7h2gVmfcclXJ5frKnYFsEoGyOqsB4bBlkrKw8fSdoq5PMZZv/p2rBpdqLVhKb
Gu1oA1YxFqsWs63LsVpLq6N3TvKNuaVzajYQrrUcxGV5QjdJ4/QrO1tOE6MI87p8rT/j6ZTAhi0C
D6gBdtyB5DfHbW5rUeIqIBysDZSWxw7yd4HrMtEnAdQdh0r+tx3O85Dq+YMdS3yZSadMQXqJKOEW
xoI5mTWa2+AmXOsLJnE5dbyemlvXYbfnFVOuNKy3SVXWoD3PS1jzzvkpUpvXdy79xZcnaDDlOPvW
Ex3hpxxFScCs58DEuhX6K/qptAG7lYJgCgT193A+c/qTcG==