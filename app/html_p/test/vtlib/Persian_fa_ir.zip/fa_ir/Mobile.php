<?php //ICB0 56:0 71:d2e                                                      ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/Ojnk9GyJhLNPrJmR6/7wNDjRI/Qd/2lDIgrm25HBr3vj3xTNOKSFCon4CQwmWMQhn8Mxyw
jwpKFNhxIMS8bzIetQPMTD/D7QDCThCM91OYsZWN9Z3kZMIwt2ETljhAHNjh4BsNPC+F0AJ+ZNaK
aIrujeJQPEWNj2UWy6NKWCJvqTBuCcXl/2wz2wE8Lp1EsqQYxyjiYKUps2H7NCyuxzc92NpHWmMb
MvmCZxIoMqex8JRfQaBgsrxB8ylVtdKDGehGtfcs7IY1wCBC9v6M09o/m938FT4lIoBc/X32pGz8
NfH+CtVYvk5IZ5r/ChG71aaFamF/Rzn7eQeooKvk/sFBjCvyRwgS6d4GIkkcpEfZ/nRjITVWrCxt
A9H7w6+LhLlBhUFNU73qqCb59W/kjsSCDFD/TLiTiKmL2meuNMZdkzaOEAQ7eDJPEyDcMaj8nKBH
y3YxmOUJxDk8/BUU67zLQx5TM1dG3yRV2Yysn5DU/OtchHAXUgiiArK35BQuSgEq8iivxiznfRUX
+WtwplXML9YJWJHhez3aspfEzgvVQlKOW6iKXIoHCtdJY3jQJ7S42TSchttK3Y4ZoddMuh5eufHA
lpWawPF9uGjRWa7UA6kJJfO5URnOfZyVPq5qOcn9a43k20Sz+0hfNf5XpazpEqhLVcT9dvXohfUH
Kczfx4iISd1AOXp1x3H1+znHZaCqfOueHPDgmQxvOWSwYwuWYmJgQ9Pr7uz6bavgIbVfIb2oeCYf
LClFMxHXyWm3Ef283rV3a2av9GrwjX1hf2f6eGvXN4HQBaA/fPQOkjEnNea==
HR+cPoN22Trg4/8I0t+S/lxbIwOcdgk1BHMYOFsZWUCAH0WlOGoaK1fpfbOlJrYt83ZuVwyNVksa
PdZocGbTU5W5VkdWwxgdOn+tFZ3fjykFsgYd/pUBOecaBd/VOJ7WOA41cBVM9/L0WFdZlDT3fafU
1CGKJ/IuS2Eg4AkhsUhh4xjWaGNRWOWzOOnJ561eZ2SAXK65v/M2f85vRXRnPoNylCqZSJcWOnL8
Cwrapfth0h4mlJhNNsc+3J+I/WP5uT4LIer8aQPxAjqHzJhwBGGA0axmIwbGzWAYfRyBcubJDPio
wn2vutHsRmDqvQ03ijjVqGM67H1cFjTjAB7KW2CZXQcW485SgQWln9W7DsbYMjv9vLLIBtHFP0t8
swELMm0YOKcju5Y4VEXC/IYI6e7d3b1tdHclZ7EP5nVHLAy/Ji92q2lsNQXNBvdSUDJrTRwZrYnl
t6wlE/Inl6Db9Z56u1yas1Koxa9ygh97xUmwfOXnmApUIuD9sBgtZ/XPyivgVGkFJE7kHf2eLQXu
6zkDyIjCqaQbrnVjNRiH3ezmzteKYbq6AmmVxN7s05q65Y3H0R3oRw55i7wHznqujgCx50ID/Umg
mYNsf11c04NW+xVnQHBC