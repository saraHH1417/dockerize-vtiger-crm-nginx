<?php //ICB0 56:0 71:19f5                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/ZIiMoXTmf3p1iaJzJCPXsAx3BzM/UzIV6XNDwrA8yvz7sP+Gk/HAQFd4kHhsTxcNBDEFYx
1aZn4Q18bPLvPl33u1EK06pohFMZTMdF1SPzFXW7mbqs2y27PoZBM8XXy+Ck3b410lVKL4Od+wD+
KN1GqbQkxjPsX4SPgMkU2vI/zduPp+K9SI40oMnjUI0qISLFRNy1GPM1bXZQVy8tL/4UAnzbiVvl
tsOzWtPSKKjo/PaoYDM+0ZeDEFcK9ihQUoixvP0sVliivCdDCpLd85SJLF/8FT4lIoBc/X32pGz8
NfH+06yLxx4UNEKTd3LA1Z63abXNOKmgQ0JrnO9P33I7gNA+ZSqSd9ZfbsT06AgJkkyFw7i8nY4X
wkx6xz9oGM0+paD1Ia/Qdy4K7BGVBVN6liw0+O5oSBoFr3jaNcH3HXTZlOlQaNeQNcXQc02K03Mc
fkvV300C9G43IcyhEL4xJfLJk3jF6kzF9E46L5uOREqU0ZH2mmTvzbmcxHwq0K5PICYdodKaBz21
w7VWBSOcFrXjIjSErIGwDTZNGkoD5RN9k5F0kh8Ap28UiY3nRg62WmRuLCOFANIg3qzdLtVBwMSk
2wQZJHscGpTpKFv6rPFivf4HFymQflSg8K+HTc87owpCR8+T+zm4s47pVckfQ/DmATyATrvSxkTX
jvcX8GLYMVSeUkTPcG2yhDucUQ9DnZTIr1jPnDMCmp4682J/ti+iR1ZAnveMzPuuc6vg5mlRccfs
ccjv7aQ7ZHP67eENiPx/CAu/lN29h4ZHtCCnSM9CVhQUKmEYfTfNxHPwn154hDu22gjWmJzAuE8A
xK234JqUAMDwgW2eT+GvO1Jr09xsCLAx7CldnCmjEsT1/B3ugYHvnDNWPq5HSRhik/1TS0lcubcS
q3830Cxq/uQjoBynkwSU7M0sJPykKRAlr0Bvv2imnH2Y0DvMaCm+VBm4mGVIOy5LrJcUaJZAj0LG
sBlh2s1djjk5+xQosn0WwsvmfCcnvicneJaJS/zcTI9CFunfxate175TyLC82b8BZWW06bhBw5HC
PWea1pUWcdUsWLmbv4b01zKtDQrMnONDvI4HnFKPzfQX1doaITjs68eCt0aIpLKElLesMQOmTh5b
UdCwuziGwc/4XMX8rVwQjWCHWjTLTgdGDy6WR+a0PqBvIRh+tatkpUG5JIVU0SEIetHYO9qoXJuG
vZ2C8puNr9kEG5Augy5vkjIn5GUcxguW5EfwG6Q/Uxs1uPxXkhwcENsPc6yxr5YhRAyD5WP+603G
Bu0KPgQ+d/+DXg6bBt54UM5k3UNLVLL+B/4k1C3989alPnxLpUIl1fT3CsBm0KJU+CFpC+6+fAXz
BwvNeS5VlCxLAEdTn1gECAEM0sxZ/OTA7VTGpefzNEdiMQQTZpv1jIr3J5llw0q6dKCXo9JhqDD2
RNYn1WemncQ0a4VVkGBzBg6Vy+U12SJ0UPvb9LRqNvW5YBs3eXGtgMKbJPlnJOmv4f9+9L1ZL1kL
l5spZT8zskxl6mUUfIK67FXj3hIwmMsplbYh+6OBqZOVohFSVp8IIbf8ej5SL/MD34ybUYkDisFt
N5ncdj0Z+SFHL85eBC7aBP3inIULK8XmjY1kzbMmJJ581FTALH6vwBDfejI5aoCDrOsGPUMTFnVe
Fla1bzdG7KWrqqwK9Pq9tiSptZ1pQpB+WU9Q1aztxJHtwM+mp9MyvCN5YokHZHNVoER81kY2BzL2
dGg1njWvsdk3WLuaTVQ57PuCtVnMIktGAsHRJL1lqqQ6Y2yxpVlHDc2igBvcL70Hn2g5nffneAjm
KkckXpLr8GQ6GSkhrc8cpCXEAICT/uuxCsYLRim/OdAD4KlWPWhGn1NZedy3ja9XdDGIOfdRRgXV
g6gDC6WNrjVqWNRTZASL8DzE3+H5sWoZKlRlUGp0vZO+FwyVA0VxXIYFPJa2fIEPp6z3LNtgkH2C
0Xki+9xra9FRUrUGK7mpb44aTnLk5hTrv5HE3lTIjnQZBChU7l/1vX4NPPY9g/1JzSfYsmyqKEOY
0wG4qOzPE0TxyA3rGcIT8i5xZx/OMwn0QtUU4kkIBpJxAKukvERBpzsTjeqdCQDThCBckEFdHZxV
Z50LhTsHC3IlOZIPveEpreA28kcvWisKOTV7Rqr5Y8RVr/xEbKJOOkNmUVpKNI1QFQRjYInPbVGi
gp4JR4lXhO/kpgw0CaskN4W+AefzSPmwNKpuIFIphKEllff2Q8ySsWxyweHBevo7qwPvYwT2TU87
if694UhptDsRQ1H0BJ0dnTQxhnejo+OGrPHN3jwbBUQ8vhbDUW7mWkmnFUiSW4FFxqEspACOsSbJ
Wk6RlRtr2P7KV/fbMrrUYpNJ02ELDzXjKMMm3IzTT/EAzH14GOq1Ttc0pqxa0orf7dgGb8QLGRug
ndxGhLzWNcjOJI0aLMaHteEF3mfEgOalUU2V7Nt1/45KSaq7FtHSSpqgv5/XL85P2l08uTgeQdZ8
HYCHWUZN8NlfaT07f3FVA0a2/nu0yd8BpQXQdoVifBWNny3ZkCV1QKIHA03mfEFHZaIv6xIlG8lN
wXC86M9FM+t5Au/+EobPr7OkYVSWiW7wtJWdCCL4XaQX2z7fSUMPlmMTBRO6Z+QTPjJ6DGZ61S1j
stkYEstR4Jt29TC+mxHHo57Ib4n2x2XRl1Kguu8+VNi5VzwuO8vc3uiUl63mGfZRCqvZQc+zcrCj
4stdeeSm75PUnZlZe4GwVHn+QYm+fH9B81bEQqgSPHzZauRnibtzqnFW/5qFGG4TndE41lWH4Rej
TVMLNrs5mKidzmeblCTEeGGrK9sg75GnsP0RcAFtUzdtDw/7x5n3qIONae5BRg/tAHS0Js2i2ZsR
KmWOhB/+KZ9ipq4rJvrRAf1NyIlGloSw4e1zdJi74crz7BO7Eh6yktNhFM/dU4Ms/Z+oGA3IDdL8
LsIbN7nJvvhuJv5J7i6oZwl7rqBakL406nBgA3t9WbEH5uzmdiVpyuSmYxq20/1bpOBuHK39mYrC
5moNeovK4xoaOQHQRtm7/fQzuL/8PMJ/8l2QnpB8vE6VUeRII6W/AKjar53fgSM5BWOCyywiKYta
/jmdRIO9PFKw+IJ+Iz6cq7P1D5Kcetk1b6tDTlY07ObMm4O12kuD2JeJ48tl6WPv/x9dLosQR3ZH
B39aLBUd1Fbg6iUf3/rbgPfPESOv253vB9YaE2mQFdxnbiZXP08Uq4Go6jRnAYsGzOrWsmWvUKGd
D1N4eecpQydo7G3G/4I6yeIjNL2eqZJ9PdKWCc7tfKqqmFXE0n1ik4Fe157EFu33hMmWT3TuKRzA
ql6qRV0GQCfKoQsfC8Xy5U2tueDEZQa2j2COyQuPy1LVeMgd1mBOX0yfaMTupOKkvkbMVhtDXTQn
md3GcrBZpK8R6bXOU59NWiZ0NXW++w/3Y7Wz568fpzGh0tmwoyPAOHeoXc0qwWeaZ3kz4op1V+3Q
x+H/lTg5a9oQpo/ZEHE4NVHHu+zisiJHlXFW+4F0lB07sxG0Huh+YS6Bu1G372J0lIKNs6VxiGMJ
NsEeCrul3fGthqRM3W5+BSusGe0/wAkAvKwMuFEfiJAnvl5bM97dkD7ZKziZKQePMvDdxBUPxeLg
rSX0QgRb+TIXTfT3wcCooS47wE5U0jdAMAjkhrOp0rIVkZP01lEbOLo4z8RrEvJiGqlUgrwYmA65
rxMSs6O00QQHeAgV5Ix+srxZhtTUT/fMtm40/9yUfVOIazG3u0fdROdxnMh3PCkJ1eubVGLOYP3s
Y3FaP10dZb1g1htfq3yM/tfFevFbX8u+DVcKBwgfJZ2pkcDDi+G2cITrTQCPKbYyrOb14t8jluwl
XfNQ7/ClpD5jbKdMRoNZ6y4j29vjoH/vOKHXEZUuURwdHuDxJ5ZXvvf494xoRNJFPyw95PpIz1gq
E2m8nAh158qBc0nXaGTPMpecLUG1i9AIr4EAr1gXxsAbIRF1YqPTKgn5iJ0hLMcpQmf98CEuG36w
wq0oQdDAtIQo95B/Jpi==
HR+cPs9VoAvukp21TUTTZJ73Ta8YXrlBY+0OyFYvp3XTET5+AYux/b9ZDV99OC60r4a/Rd8t66sy
M9oy3ARBkrlZtySRjEKFD1uNQPnRUGt6LkoHHJB3se7bf1EXdw4YTOPmQfTUwnHp/hCP9IkJeyPA
tUh7JenWlZuRMN3i26vSbMtiCmfWanKnVBCsR+ahFt8zoFgoCSv0pMtRdbBN495RsFzemRfXfpl3
m1oU1hiXGpre6aMOpgx/+K5O89yewlxb9egSg+bZmHNELb5RZiBtvILVPL3B0gAbjmkRYLCrcpBh
4BdZTDjnxg3Q1Ngl0jwRCOOT4MOJuYzkTBLbeVVKCQ3ntXvZ2d73yD3r9tam3XeZNha1pzTIlpSN
c5rOjIbnh4TX2+uPY5buNVJVGwfWk1vYWBW6+U4Yxv+nPt/fTChrtRgENFXHi+sxkcEEsYn//DCk
AwejskSb62nupvd2n8XZjW6iy1oljVfAWzGYs62e3/UhsBHDFflngaK1lumJ7OnWbhgAn98o1dpU
nLxSEjPFpGO7QjkEXnMmLuCaEfzVC526OQqe2icKDV44P4KBXxbZD015g/SFOuWD1Lds4MXPl1Rg
laRnBuvJgw0i1W73aIw4kWMuGBEJMWGScocSvrJ1/GvOoUdm8T7GIsZ8XniAlZIzy3FpSHwkyK2E
oIkTX/27U8KsWOUBNbpezsh9p5g8SApkLKl951/3AIOxpII0ajNRKq/7dPUzw3NLhKPKVpMTNa4L
DQFcMhTJ3SFHNs6KK1NYBbt/f+npSKDHDwTQ3vIdeBfeRr2wnyD1JMGY+fWOLj1OvSWvTE4hbr52
UEIpI6DcXApXDwm8WG2+OiXM/HVLVuiAxd7Cghk0QVycA3Chn2fwEtvvEW8qWaHuudM3ymErGnEf
dkqDK23iAfxCOgjvxH1PwCyxEXOEQo2dY9ikJI/kdpPVSqS4M5yf9AY3OZTdy9v8gNjIGSVU+JeD
CZ4YGf5idMgOrp8bfltDyR0TTWcyZSeYQHFCCVmC+I/fNoy/RozU8VrPrf65ebIrlRd5dGwBGX6A
BBzZurKs/4ZdR8H3OFkNVpcn/hGWg4pQGbIU6O9nYSY6dxhbYNuVfN/D8O4TiKaI5aaBSs/hq3hf
z1s5wULMvKvcfu45+ovRGxOEbFAcUBAKVz95d8+tPXfN2sbxlVujgZeaNTrrSsT/144UXPF2ccws
8XgumQdCW9HAV4E9/MgxMWVSVzVkXuxo62KQrLn2W2Akxm7LrJqtP+NN3RDncDu01bRkYQDAwNWk
MTFhJMuCNNkK8towBdNbALivloKap2QPJRKvg85VwqYBoabijJUeRxtAM9BBCUxrJOJ7OykH2Lu2
jBjaIUBDUV6ud0cfxrByboADQsKrMGN7er0Xr9LL8stsS0t7cQTlGpceqR5F/GGv2K8TIormFMgr
Hn6Cgn7Waa1hJZAVtTRr2+6nG/k4xcDGhaf37xNJlF0wftCH/FVgFofEQ+J84BCQWo4dix4aaD1d
c2qMEtX+VJDZybUKP0XLsKzMKMNKgzMc2rjSGeo6uEVjUCeE42U0A/I+QfGb+/Mspye1m0==