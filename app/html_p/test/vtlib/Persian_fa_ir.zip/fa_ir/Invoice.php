<?php //ICB0 56:0 71:1c69                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpTbEtPOu9zvLQwkLGVIfU+lIwW5TDojyuN8QVATy6co9MvxwQfvZHfy3Yws/TQFnQ3ztI2D
yq2GbDw9QOEzvzRW1OKFxcz6LqZqLKgseL8RBR8CMlxQSo+Dbnkm2kPncde+ZqsVFrP++LGmEXRN
6L5TUDCVtiudH9Og7HjMiZVutQlvD9mteYDlvHneNYIV1cWgkyr05C8VHzvhpJfJpjkX4BzrPYhg
pF84HCD8fPf9019poEXPijIoO1ovRvXV4tHBPp7Hs3cPgr6LnxbEuPj0ySWzqIzB8kR+4CBD3qXU
b7xvS6alTHBsEJ/vTL86COEII1yM8dXHKySMpR8Pvr82+hvFr1Ax4zzWxW0zB9nB7ogDY02H0880
ZW2508W0Wm2E08G01mK+4FaXl8S0bW2E09W0dm2S09O0b02N09e0Ym2A09u0ZG2K09u0XG260880
WW2L08y0aG2O09G0XW2608S0dG2U08u0O8J3AS7f507X74U0DDCXKWo/FxHakTHPLqjiQmTii9o+
9Q5Fomj8jEmTdO0/d4ol53YTDOzijueBKlwxH5YL5r3qXQypk92v7DBlsG15pT7UAQU8Jghh8ech
i+CHjmHnWm/G8XSDGdge1khdlPzq2wwzLaWiXge4a4ox0uZPWxK0AsB6wlQ0U0ykomFYXuzVj0Sp
H8fIR3C8xHGJh99fMX6yid+wUqBz0GlGGbEmf30EXW/S18gT70K237Q5vKpyIoEgHT1vKRe4Hlo6
lidXYnPHHdhRIoUZp6t3kkzm771aXdjKcGDz1zVj05+A1legeo9rVHY4QR2MFodTtiVtyngbuFzj
l64xu6zEBlsbPQSsUTDstVN1H6BElXMNl9U1l3xqsRsG8FDx0PppZfvRNHEbdABmOfNoHrKepzTj
lpW/VBVMQaTWRBaPWlIY0LBnG9jOsmVkPnD4pENhaN44BmU4oDfZ3JTwOKcz5FjjiO9VFYhu3rpb
C+8Wc6ljuj+BKutwrPmHU7CTY2XOKWMgV9GLbLu+EcEYXHcscvFjgE7GRfVnMNIJhCVdmCSkccKb
jiRr6/NTvZend8xS5l+vjy5hNvrQJxszJGhhdJUsgATMTTZYqEUKEtnDUoXmYaNMqcIjlP5DMZTB
DMTobl64vcQhz7eg5i+MNT/woK/rGN6KOrJw2R4nl6QJ7Li3Sx4GMtY1r5QRi3lTWwoVFR4PNtOu
tP/7spO7JZFfxoqREWdwuirE47fXGvTyPBuRcxFlNgpzQqwxqmjwt790xnczS6ko+Bk0NPszywi+
kF6Pn2COCtgoH4Bt/so2TlrXbwuTv+SCOYVqlrLzmDvFVHsUE3UWCJv5wfr/3cCnVnmEHz4BxBuR
SqHAwCBxvaTFynLotMAJjtW+Ok+6TVjmWFvHWWzeDq8jZ+sWbGJuUSai/wvGB0tFHVGdwIR/OHU9
QUdvqxDVhdPT2OZZTHP7Xm0mLNSLYY109STg4s55U5/z6NrFR080HHgSRBhX+JHgn/G/pwvEzOa8
AL5deINjCUvKJMulr5wFfZXku209VwEvAlqd83rhbzUCNiMbcbtTghyvnLxFwHukGA2yyUc7erWR
KDOZeXiHUqkxyt6BKGBApx4cGr92SWtVBZxvHonjsJWbZna5dnXcPx2vweU4WxN/BSpDiUpvZYHD
aUv5+aUbfVe+nNa6Fm5w//FhqHnG64x95PafZGY/uwxOA1DrfQCmRAeFcoj3fngyBg/TUwZ7jIvO
DSNUlZKXZQKlCvs7CWvPM0k4J6/jjFLP7EF9JWCO1AonUMOGQUjkiw/ra+67e3ChpHFaPs86g2vw
zEW6myRFbTfaXeAgRakjMRVPupddniKH3ywDiknFYd8u689vxDu0dIg5V2+QMO2EAcob5ymmCzUm
omwVTNjrN4F/DMlQ1MMjoFjeGYrbRuOTstiV66kr/VDp+uCczcM/4zzX3YKGSZWSneMdq2M4bO8k
34iqRoPI22r6eAyoCGwmH1JOJhJJNegB480u0TV//J20a+5HNQ9elirErYB1eThD3Fx20GhdupxL
8AgqAjvLmjXSlNg4TYfmVtiRktCBfJy0fr9csJEjLYmpGzPZrqSxm7lrpYVQMZTy1UZ3jbeQ96EY
hthJFp1QYwe8hdceAYbvGhhB2MHL5ZevnSzVNa4g3PtyXxVic12FL4VRU1OrcamoIYrN4MtLfQbU
/Y/YiPajBc3uTMTBwyMb+wpObuQjBDiMzkl3Z7wk7NZbqACEee7uM1KFGsRjVwlgXP6hJQRlqsd1
xLNx4kNimq0ragy+ONJdVGVwcM8dKgj8RiFwmTYm23GGv/sJ5RTnVWTUgeI5ZlU2Tzc+0f+gNhcC
Si2gV4lccTIVAorPOftLm6HSE+BVSy97uwTwVkDbzv6xRFhXGafN763ORsZO48ECADuBw5oUvqGQ
VWLr8vpDfEXIhXUdRcsfYkdTZUvV6MwXDnrl/xeDWKiKInYX/B+HwV2umy72PzoToFKKGazrHnnd
i4DgrgwczTByhTrkQFWzzK03PFXyxjdf6nk7TsGqpBlHuyNilrKnFPB5rFutRFPOlvv/QufA2m6O
FsCM3jMjLSAsvScoDkfaD9Zo02tEBDZnCBf8ux0Is6sh6J04LUjrxewOkdlRodm8CUhZGsPbTjBu
2ALIi1qTYlmSZtG8ccilBRUAQ3WNfAuK1CodrKu7PCQqNbOLdLrdy1QQmCiCTSCp8ai2ZE/MNlA3
sW2i7HRqdcJEb/0AbuFgVE4XFGXXYzfgkC2iheQwNlDiI6rum7zbBvywyL/aWlXv/bxKwnG297Zn
q02bSJ2DgzTVKgkz6OFTWI/dw4OtX5XFYJsDuK1At206383PFx8N44hXARmHpWsu7HWTdbKAR7yl
MMmwPIORbBf9M35Tf3uFPwWpCh017IGilnjf3qLkKRtPevM9n0fZvnKG5FfA/JarIbrxW9lkPWHP
bqmjO1mxs6/8l/ECI/wSdLNRFyaXN1OcDc5rZW8fMytxrhnZYQVrAE0dx6w3ckeiB9GSbCD4sgpl
jUNuf3EFg+SZuyOCUFrIzOZMJrEl1QXBGz8IUKq8VuO78Cbl0GHUjvj5+9ofC9T06UWRccExG/rv
QTmxFrCQPHynQfCGOfXa2mqCJoCKkOU+BdfwxxPx7//CEPpb/0FUfRKkqXqjW1h8VuT5qpNeADd/
kW9nlSYxwBeVnjrLtiV/2rx/cEZNSCE5Z47ll8c981ENVhu0H4U5Ao4GgWvI/2ARyh1syY61SHu8
1C39MUnGhw16woCf2mT98gAuHDz9suUNumpOgg4ay+iXKYp3Oape4WfMBaYjd2q/raxL9q3Gl7Rf
2NnWC/j/OlRjRmHWUzaPMnoXPeRAgmNy0y6cA/olxCwvNTXm7ZImfY9nf4UgCL0x3rW0RR4/DKCP
6PdRZWrf3l/GANg0XsBzrX+zqNfHAeQSqcH9SIn3IIbncXzML0FuqCC4R24kEi5+Mtar+6lmxT+c
SQmQ/mpI6bbYn/KI8Bk9lLdtZr/2xI56Iz2p6dIw24+tuCNV3cGCK8WYEdRBjXw2L/kq/sSNz2Hq
aYSuDLL3/0Y4liNDlZdGMB/9d0BZ1BEkvqTUT56+RFx/qM+YN9tDQUrJqZYFKefVfj2sOMhD40CE
jCrJw4qfrEaDYZFDFpJXJkKY7JuOULkTMnBzVrFzOeGdymvY8Ja9oafIi9fsBldeLfIbBGfCqWR0
SC6HskQWp9LOSIAlaCxVck94AwhbRbBAg7ZITAeFqErbfeiDdKsCCjISG3uatNiDO1/9xUyxkuvQ
N+zGEob50uWe/DHKEYZdOE0F67gmIn/gZ+ZcKayDJqV/fRpb3VnW3X/OSo3IN39yWVvkdafry+Rk
8FRt8ieXUQR97FhEf5MbuDpczG6oRPqc2Y1ZusWnvlwyT28Jr8/v82jm+c147+BZ8RnYwTXhxAum
HAh+hcDhjyXYf4m3Kze33aOYf37FEgRO5CXgiGTc5WT6fjLavW+97Ah0T42mpsJcmITpKh9zD7N+
yGZtlD+r+LZFitjrQNO6hSfVKjeQfl9Vb/6Zww+W5//8CuQ5DVKZWWEb9PWgdc6aniGw5L1FFONX
1WmkQI6MX5VssDngbWhpvK5iPo/1XJ48pMm8na+fdoR2PV/EGBvdj/iajbYcDCghc/GLGqRQ5ADW
Awp+G//B+lJZ36/Pkg0dSQ6ZoYK9u6pgV5IppCVgz1NC3ofSpn5PLSqPskBk0VkBxQ45CjmRqU01
awsFtGBL+GJ0FMwt/bLTL9E3l5YlUfqPBsqPq05TRssxAquMWB929ud5qVPgsOG7dN7QZpQnaarP
ORyfQfTX/Kx4zcxOpYbg9p3+tGK/HQt3b4g1U+6ioD5x8B1b7ug3FKAwkYhIXKyOP9spJ/1f360x
ISIv7lq/D7icJxPMud02gO+r1PkHEtAGdoCALQMMFhVPK6Zx0FLq0KNggy3vAP9m24dhFdnpWM6m
6uD/8+mUiEv+5HYS7D4ditaDPIEzOBnijCBumOuIr9OzO/l0Qn2yFRUjC6BXRD2PyY5HWwIJ3xrF
2T+BPtLSNadlFUkQDrZSBWaCkGeEGiNpf0tN6vmC/xhvQ7Myjc0uzRb4WCkV8oStaM+ierMqAQnN
/NjuN6T8WrE5ZNn9WlesRMfNwQ4+C+OB=
HR+cPnwtARCQW9A4amwya0adUjloqrhQaZGRJScvhL8AorUUdQSoJ+3VQY6WZJ4VWaN/qz0xGqXW
DaLIM6SfUGk5Ydcxih5absFiaxMKiBD9IK/62Ij6C11kfLzjUJS98cLAWTOtGOVEC8OL/LGTq1/C
m215DQfe7B8vprPZf2NxdhGiBO1BkNWBidKbOKlDuZ8VapQ4JXle7WZw5Pcz0RWD7fPCNIco0iqF
8/2IAyBFDuvUcJcLMy43JRaFilGu0LB2GOrYAX7qfk5IUpf/bSy7alSfob360gAbY0kRYLCrcpBh
4BdZT0HciT1k3H3P4Pm/ReQT46O8h2+MMnCgrPAA+J8QTYxfcMJlFMSdIpVnqtSwX4T8sOWts9ul
UBXuDRWHkBLfKR63EQidpNS86gnig1AArXgvWTqSOP7k8PqcFSMapDR4NRIP+GLERpHEOKj4Ptkt
ciWlvkXi94pTQxlccah+W0mlVqYtxUlEQaHtbtXz8GNujGZRT6DqDmqltLYUFe0MGGXT/oNcd8D3
L/VZQ0/9TqabkKWtRO1PThTyjOOAwOM8p6zIKchidq3RQ9uGQhB0MCYAioIjwr262N2H8Tjtrpb2
oRIiKYh/xb6HxdI73Hv2NvTVH5xQf5HLla/SIOxD26P1piWb14vObz+Tmsoh15QuKzPkA6OpoxUI
klTkInWk3prtb6S37YzVHLPsSMB6EHoT/DXcJwMfe492RXPvblgoxSznsXogPZ21XhLLoxmB8/TP
HyVVD7RtR9ie4a7xsDa31LwijeYnWCGwQdVffW7Cb59mAfYIgeMrAlvQdmjE33YOXKeLib31/X5j
bLDEHv0pGeLVLg/a4qOFP9xR3zUbppPQg8ee7l80gic8hBUSlqANg05JNX4HymTW0RpGtbM7DSTe
0U5RRRrHe9vCrM0bIPAhnew4lck7WnYM4c4TYPodgS8e2RENPthUcZCCZXoLksKMElDXaJ/+hiZS
iSL3geFc/iCIETeo2E7DfEmVLzAn6mBoekWX4V+WJp6DNVuQBgA53jWFw6ve9ldNJcXdsvsSDuK/
Y0DnYq1GKpMpN37nD8d8usaOnBBVc9B+4nv/v02tkCxRhplegYuj03RPB/pipHj8WryfVn0u+EvW
2fTtDZ5c3PprRYzsbQdsVdogMvJMuzRTlpxDP7gwi1CwT7eFar5SnlXbGBX81hdJqXWtd6IMEa5y
w53pGxjF6/PFtMekLlQpSg2k8rQwBWkihR8Mo0sadeY3BFWudKflOUAjGA4xL72NP12L3a8gXinS
uc+Cam0beCBjl2SBVLjVVwnH7vGZ3wVVLhT2SKvZrWRPSvcoupDEc1VjXF2uCW3dOBB8CPxKgh9f
/t3ya6n4CLbueYtwOxlMDKuRQUcvvZjltrlX7if6uZEqkSR2nanOe2krrZhbTHYaQTcIde58GWVS
rdnPmFyb75tNOvvQ3bVFwotiXFd3ny0I66sMqmPsiP+0g5JdAlU5DqQdUI1gajDy1odzESkIA6sX
nfnbJi+FwVqqHCc+VDcmzgeD5beZzX3xHhn3hWfFnJHHc43o0wjPVjVmGP3PmUoqpQ1JxoW3YG81
GIxCyfKvCbGsc+PLZL2Q4V6NeaNxM6OaM5i5+YAYKbZyOo9klW63sFXRx3s9OKYe74EUxjb2FxZv
KiH+2lpSIkNGWG3fW1CPDQ57Jg09xRzhtB1DFXefijbKSi6BDD4n6nhZV3VSx8pKODx2iQRLOIG6
QsRzUSeBaY8GjHSjQzAaNX3sOm==