<?php //ICB0 56:0 71:226d                                                     ?><?php //009ea
// /*+**********************************************************************************************************
//  * The contents of this file are subject to the vtiger CRM Public License Version 1.0
//  * ("License"); You may not use this file except in compliance with the License
//  * The Original Code is:  vtiger CRM Open Source
//  * The Initial Developer of the Original Code is vtiger.
//  * Portions created by vtiger are Copyright (C) vtiger.
//  * All Rights Reserved.
//  ************************************************************************************************************/
// /************************************************************************************************************
//  * Description:  Defines the Persian (Farsi - �����) language pack for the base application.
// �* ��� ���� ������ - ���� 97/Spring 2018
//  * ���� ���� ����� ���.
// �* ���� � ������ ��� ���� ���� И� ���� � ����� �� ��� ���� ������ ���� � ���� ���� ���� ���� ������ ����.
// �* ����� ��������� ���� ����: 1397/04/10
//  * Contributor: VTFarsi - www.vtfarsi.ir
//  * Language file for Vtiger version 7.*
//  * Author: VTFarsi Team
// *************************************************************************************************************/
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPmARkjdwDnyUyril+e7QVRlyr8Rdno1lNAl8C3WkrvgAxQPjaL8cO93EXjT5VlqB4oIQBDO8
bPCz/Y5x8/lPZkX0ZNzskMJGh4ZZGdWl7yuO8PuB8baszPhLpRQXz7tQH6N9hJ9awG1uVlGqSoUN
c/3bWg6RvPjBI39Gc1/H3GS2Ng7ErajTGzzhK6sCwExYgegSnWVbA3Z3G1wwnEAamrfzMEpks3Le
QnW3fLU3brib+fQDXACBl1WOtLdlYPpTkAu7b/Kf7ztHNZcDT//tf2uCFyWzqIzB8kR+4CBD3qXU
b7xgSxpcFNt53pSjLd06IG+JUVy2sI66oaoYXEQTcgigzXgfddeeUKa2VOCAV2J5Oqlb7Vz43+zx
WIxoPKO2+ej5oyy8K4YuYNbuTp0s6zogxbpQHqTJCGOVJnqAX8V91qNr7hUHn8akq2VoO25ZeuSB
AxrepSVlRZt864zHGbDohygDRa3ysHrEGD5MyrovcPWizLXoiSFSBYIRH6wxk6EZBFI5UEjwJNka
fi9XZWxfdB5vDv9V5KsLGwjAruEmT1Aedw93wdloqCOal6TeaVdr8tT7xE84Rq2/SYfh9ksq1em3
OSPLETIaa6RZeHATniNdjCtCK1AgP0OkgQ8q3lHbjtubzt0vYgS7/nMuCPggk0zLDAUF7YzXb0TW
RB/E9hJkUuOjHwBH0HaTmBqQvV3eMEYmrUsVMpihWxV6512S78/17uYBrlQLD0vdBcGsF/72jhc7
gxMG6Kx5eXaZuGyb5E+eLHCsO5C3ngqaYS2KV8eXqcJ98IBsJSfvqLFU2G5wjhqHdNg2/aJiAJre
pGgr1Iwayy1rA11RSJsRbxmxi0W7mj0pPU6SBQoPZxUi4Jws4uurTsBJyvvrHgf4anpBjOFLxiud
9K5pK7E5EJ1W39bn/mZX2enfUgNl4GxhEhawPVwmlFdCz1iVKuSeudBzy37QZW/jdHTo7h62Tc9U
BHCGqocn1FarwNucZGUGQm4gyKYGSWS0FICVtwlypdNg3ki+bPDUZcSOUzIBT12wxYqWPSNWoXo4
feFW1M6pUs4/GpT6PFAQFYf6Tt/dsY6KzGf/QYyTWbZl3OLxr84U5r+qcjMZDnscERPdQ0CDkDPh
fTQ8IgfJZ64d0dpU7/RG7YZA8yWK1mTtfaKWVTH+qQmchEQExPZH38TWr6LVXLfW0Mg0snvx6h3U
x2nwkHghfhZj5SrqlHCvm2xGG2kIudae3Irw3lIUNZZmbQyANHsgE+Gg8gbTYDDz64nduXQk8lUq
bI4BGXpw5f8GUJM0dhwqROjEQZ+plFyuOxJDjLnsWGK3SraotK/u8RYWw1oXZDDDHWp5fp5n7iyW
5/brxk7OUVzbkdDcD7bZjCqZFUKjB5B4ZkTePzxBQ/oRR5HfYyZ91S7hU86LAhRuLViICq7XkgYy
kyHhRM5OrDzdVYPF69Ap1m91bFAC0VBDZ4W0j8eGvjpBM7yhJzYadIFyU5lVEUqhrC7gcqjGon5a
4qXFRzhN6FQ6R7X1MGl/eehrzWxoBNoc1JEf2zNcN/seApcfVcvJznZmoFLq630RXROxif3x2QH3
BCqc4ow7uF75vRgmhUH0ceffvRXEMjnhT9yHwzaeYGhEUxs9u9Z2gFyeZqbsRVw34mZVe150heum
4rvo3wtlkvFSZDEUPsdwWp0LIPzjri1Qc4PQZueu+NIbPIe//sVmQJXKyVjrpbTOGhL+uhpLbgZi
y293X4gdVmbFzbKQWPHPxtHc363QTTAZKlozn2nyTW0DqC0ltGx17Kiblhh3f+ZPSGtam4atGklO
0Jhdu2eGJu7NcD7R9MrYxiFGg8SqrInL8IhgNGRLepPLI9c4ibxKyKLdwGtGb5RY5KsXOhi5MKxQ
OB4JiN3ugHGSrl1LxLjdE+wckU5eVnHPGHUM8iHnIGI9Ujrj+vg5bmyHoNBTWpYTo5cnjVNACPqh
XN0mlrSCfPvG/viRLCkHykZF/L+FAvy3T5ywRHTwZUt5nuA2Zp+YT0oUhuga1cUfT+lZnALNjdy3
j/ri4E49+Ix/Dq8Lfllu6zNnGtUznbhRuP3vHTVvp7NkXOlzWF1j88snr/fInlqFSS0CC9CnbSA1
jDpv8oK+IHcbjSVacAqOnVJbxokdxaTELR17g3h0C/ifrghdMQ7uDiq0a/I65SEXzvB1xK7aH90R
knV2W/4IZu5OaAxeuG0roFSLiA3NYvXCaiN9lud6KLzOVx2nH3wuxU0NFUulWA+/jF9ZKWTr2Edm
LfAIVt5YjQuGGuKphqv+Zlj45sscNTbF5BOZESadNmUsRus78udcUeHEr0zjyPjnrw2vGAmc5PJE
w9pKO1OkgkpF8WlwoSQQ4ixsmkuMBnLAmfx7m4dU0X28Er/9PCJHH778RcQ8BcMCSSEvHVLXBlWx
SjXHrRDhH4r5Y8Z6ed/xmDPw7T+zPcr9zM5xcGE1YRNQouH0iTKEAgwnVWUkjAHCrf+TsoYwAxSj
O7Yy0lLKPn9VWOxem/aITiBBjnfQ12QdkA7GRmTRn+lE/uScdRHyWFJww/0YfTxYl0lG7FmvB0lw
JBJZFb4AIQwrrQ3ceqhCqjkG5kSGilTbkHm9art2fIFV0F2U5IfGOE/PUqKM6vk2q8vP0yF7lQQ5
ljizoPpkX2blEfss8Z5yNxkFiR8ZgabnxpUu5aLuCsw2ROquVSD/yGQtSdDrzjEHyyZwxDhy7idP
tAaVNglGNhdgwvDa/rh1cATmQ47+DSA5ldXydyl6imuuN/53IOf3cfY2T5UaqObERjOlQ8ciMwW3
4r6rJl834HXtHc8p2WxXJmw27T/O2YkQfvPhSvKtTtOHhKP78yAqqK9JM+riryWT2E07rnAYdeeM
aeliTBEiHZOlNhjpe1cVTpqnfi1KZT7bqhJa/FY8i1LzGBdO2iy79JHiULI2DBvr0NBM7SAZpQHv
DAa/9ci815RxGLuZ9FJIHNigdNGwxB1nDdrW1DgR+STMlcCgTx4QEehgcBX0J4aaj3L8Q2BNujqz
2w8OUXhZkn7yAO4pttVTBKxMRxyJ+pImBvHB9lVYEdkkiIOZ7XFp6GP9BLqBLPkh7V/Hdlztl+3K
xOvGKtmYdwk2GC9xChANJ4saVM+5PklUWezTU5CHYuY+RuaJQsF2JLVefRuvc6SrE+4YLi/ukoKL
FiPxNoHErFkfOTaFftlD71oaJY5KE9yAcjTrUEGRw5GXw86XdwDPrxIVAMe/kvV5KqNgZ5tivUf4
h9jZRTRdP6TKFgkiTlCKA3ddENs4LIntg30w7DNM7bPQ7xfVYgnpzYO7NFxDPeB29JyTYeyf1pz1
W5Jb97+970v8tloo+LH9gD7Ym21GmqVx3V3GY6xsztBQrZtTlT4L9rCkwe0UFJhPyNlAbtlVhI41
KIaft6ZHYT8AsapVV2Yt3VepGIdnZ6FA2IXw/03Tty72paQU/UHBEU/koSxA+fUn5zCvu3iWaPnW
R+wuOBG/ZtBJYPHUrh9Uewdt8cDpdQFPZLApE6gyGu+tnagCq9xyILCIr7GT4HjHhgGmb2cNe5TS
ptZdeGFnmBl98s8rdbarSaLeBfRizBo/STtui9hxSJM5nnq3YTdaEQ3F73j/bZd/6DCK+31NIDaP
CxSGSbDXgNjBynXie+32eTJlCw8LnqCZYrCTIcRFXhA6oHKpgS+bHKRcWuYLZg2qASc0ho5+rZl0
K0HfrtgFPajvHY0heiOhewufEO+byT4xVoqfwHkW2Ke2vZTneYaFlbgwhZ/R97d166iVo5NRvlmR
IcqTkidBW6E5YCJnaSWLvbMm/krvUr7dSgXz9TeAxkpy1AiLsvHqmr1khBDwW2tDPmK8qSfto1j9
AIHLXCt/KVWXXfTkYOFWTLxIcn15j3GPLxFg3KVMjnSVCIb3pli7h4xz4ohdgC+Hhi+tqYQYzjZy
HX05NVoPPg6fXUf10NFrYuYPpPM0o/U2O43lUKAQmqBcAv5K04cj8adpCBW4mm+wJnPDdk6iQbfL
S8+xBgZSnWxNljjtWFWskaiSnR5xLReWG1U8b4+RoUQiXuVCvksRjHO1NISwVSE9n+rRLpWBgqU4
9/OgEJTJMZrCrAaGXpUOfXA3GZByYK+VQUIohYRAYbh/m71DEgsjA+AUVMQBSAkL2sD5aH1LaxoY
NSKcn4ZMihIdFw4X1uUnAESHT4GJNn/FS9Mu2AgGLAD6VkE/Gfvblrgj80VKmSVF5gsaf3NxBDtL
vPVFgwIAV70eHvRXYaNkA5V7RcwtIorrpFgEpA6Ox9JAFbBh7T5ZN371s7QsdvS9GGKvUyDu31N0
scghquWAzwh9q27Eg62ssZZO4vecWFbE2I4pSn1AND1fiDtlSHLRx6o/SPx+BToU2eXTXLQBhlwz
+5BWkW16J4RFTC7yra4vpVXRjcO9JVGgoOEnSoEEpTMb++HhjM+Pzu6gnZypsrfCMNhzAFMcShAU
LjhZ3VzG/ubq7uOplEP+oY2IllLRQRytf/7ADL0m9ELUdcBKgDUUZaDT6c81P7EK49jZ+NVRwttM
Ksw6ujvrQHBqm3PZgUWYMBEVrE5y9y7KJ9YWq1I3vY8/mbCfIAixkB3XMNzm2ENLafuMNVDnmv0r
Azvl+DX0DtIDVt2Iiwry7rr6ijllsC5quj5yc8STS8pkxqtt3lJnBWAP+iJ+MYnC08AVZxaYK+JW
idGnVNV+sEXo8GsPyzksW869KBsZj2W4dZF0TkWzPg6neHAllvpr0PWkyz38eH+KoOAzK00cPNL2
HjxgD3HcZPynx36/x1a31fK7LOQJHjaYdeIUxM/zwF8QGJxrspIJava/ilC7JdFP9seeCmaQAzpW
28H27L5OqSz+8+W/pL+8c+GAYz14+cwzzhIqXy6dc1AekRERXSkh2z4wcl5JlG76TGP+AXEWDlUZ
FL/ZUPqlQ+cJA1KesFI9iS/50VjUraS7U3PzXTF2NRP48Hi4rVosYZhcc8tdVt787NQRtu0YRWfb
vJ9LJnogQ/Y7sODopNc3ywIbAp/yBYLvHoL82UwlPMseW/5OpS9phW/7peAeve5G0zKddHIq2p8E
Jk9mSQeL/UyPCh72QuUb/ZXLuv1lEln+pBXRDbfT7zJ2NO2lbIZbGdE0c3Qge1jHWPb9ef2cWG2V
S01t+icFdLn3YkVo1DSU8LPgP8nErjhXeO3DgpeQ5C6CzPydJH3JhTYcMz1Qp2gbpvt4PKZBnkDk
Ba+1PoerHQj5wV6U1sHXStM9RPp6Uxl//DhNtRN+LsTLeiOSvVSuaA0SOsmkEG8M+vC0SlIhKDMo
3Ri2d2Q77Du/5f47uEwPj8PdPvVJtSJC+g83WKnI50TnmLfdt0o5K5Q64DV/TAI7M7DCQviDbD2m
m1oOxg0vjSo+MiVI66jXhbhyTfHPEWC5QemdYMDL/JscwQfsIMIOPgapeRsaQiv++fcMt6UTNAUb
OCc8vgKtyRoMs44bK45QUlbKxmgohXKgIUWM33v67QXGUfXt+US9UFynFLMRRcvIROxoLzLOuwvr
cnesy/1QV8p8q09Np4WutlArWZ0wncOczLoYGgCM+x0bfBswIcZT3Eh05cbywgTZW3YMwKZ7u/jm
7MQOCEDJjul+CqVa29kc5gr2IAi5PVmYncgUQr3poIJWJXegkB5K/fpcCv38Yp5+56nYvceTaUdR
fJfXYdYr3Q6mYLjGvBXKhFozxqDUL8FgTUg4/l/28MRHsCzoyIML/RU0hwna1SV/1TYFvFYKXD0k
ZSLVbO2ZbGP1DU4THQqGgy4X92C0tXdOQOcaUTZtGGkV8eULz9pllxtJQR1dmXSSvgDrs7AfPqLV
LeMG88rbyB9GNi9BwU5+FGwHozAe/dlzfFOHQiSEmpygmaRWX70rwioEshhYnryEzNMzFawm8Y+K
zTMMa4MgP7aUythlJvVCWurncRWSGRB1+o4qtU1zxl7GpyROVrs2+fscVhW5Z49hvnQRP2RF9mvJ
w478YdwnxJA5Swdix/hDKrOWHHAuDEvsOWDiVkTi7q6xqoHkT0Rj1MUHYp34CMd66i+H3EqpVqJA
zhC2kD7W33zOnRFJMKWE/feJ1zr8FS5bmSGlakf4jttkHaj+WzCR8WSg5NlyYPMoQzGZ+wNSi6Oj
3CwhpjdTtsKRW1W+h/HCkoJ+jBYxxPy==
HR+cP/QwnC1KaZttKG1HuoYW6fIHJWKijlQlj+QvRir8ymrW9Ed75j6lHF4Ow/dLOEG/fk9gzH+5
5dx5b0YuzMtmTs9bpdjjOCHK2Z7dQ1a1FcJsDIhREWCmBMkQjHDCbgxZed8QRtXK7ixjMkV7xAZT
UP3lYVmwiHbESH3ncYLXXjx+vW4Y0ggNV+l63QssqYWOqONWEx1NRUOWS96+wGZfagWgNi6bkEzJ
iwMHDdsPN68rVNIw7zbiR3FYenS3ZyjkQqdm2eVmTSVbFRCgahonN5MdJ53W0gAbY0kRYLCrcpBh
4BdZT2brT0f+zXgIpGMh5lOVk5vN7F3VSkyn24v1FRII5gBP2Tn/YzLhZOBF6t1xBzUN9XJYwwhP
rePze7GzjirmLKVO6PclHgkB8/tnD59spOLgV/kys88EQE/r6XnKCa9vDAHgECCtOr1JTE9zh1k0
aSGU+ajh3AKKmvpOQbr+RQ6tzILzaFZSB/HYfCfLV3hGhu8HwZJjlI2IaHKeby1Wuf15A3rz2NFI
hphH/4hT+ta60gmZZi/+Ff9RaprLdz70hI9cqir91uuZBN8eHjFfxe6jtwqDZTYXVXHsTjNf4VTz
+ogq00f+JCZOAJTDODtDiRlFYJcQoLBfohvW/P+zJa3WuGxofwelh7Tf2zqFnvz4WbDr8qB/9bvC
8pGjkfxuC4mCaGXyPTU7FMn8ynE6i0aci3hk7ssgvSNZZ3uQ0e/u0YAwRzBwuwWOCFjw0bzvgHbu
OSFiLM8B/yz9GIBUB5sC3q8oYj0l58a4BFXq5QDMiLYnq494kMAKn0m4IYV+sQ7YVN1UI1vBfdMT
Y4NeSJYeZ/F1M5M0HcTjHqbw9bOsB7yWtltfCaPwurpQhkK7U5c0iqY2g5fVGvSn78EYg+JQvQYQ
+dTZ/EqrgQLlrGkFIk0qiSc/oMUe3MJe5JrZ9wYYjW2W4ULUi6SF5XsL6QxKzOX9JQPkQzXsrZGD
vnKeTvAZqzwNRp6yjw2VQFMXO1DVY/cKDwkpDK3j31jrkzYW9aR6vHRF12lIRCIppzgShsnBgUcg
CmfYpOKFOKSFZjAYfb7SsXkb6MiOlDfGITfWmo6TJYRrwgqdl7104uOO5FV3OHFhX86oKXZ+8wcm
z+1sSWR7LfrFSjqpvabGb87XzIzVmaeCXEHhwTGJTXebLWB73IBUxIqqmqTkE7RtMHFHr73SYwYl
/pcgnAB08BoehtQGZSlin89T5sluIJiu2jsNs0jJP+LLAhUMLc9CFJcKRfGswXL5+Rd8p2bqiYdq
+wBv+jIG++/pdsAoXJRgOW/quBhV+b+YRkgA9CU2asGsqdW712Ul3AEVvN0Cwfr94vpMp8ea6ZDN
/td2MjqICOfP9DU1HLMPQTJoZZqdjUPwsy/NfelEjTI42tYPnLKpeynptQn782AyAAQ9x85o+zrT
ZCgDgGOTZJCD4jDj1P5AogxCTmZqy880M4tNwOAkQKzbW2aAxmyPY+Tviwrb1RlU8H3prjZ2ZKR0
98ixQapw5KG10KLnUMzKeFr4pY+06kjLVEYm4YYKIPm6n8enoa3vdpVSi8jLldepi9SFlrG+comp
8B+3wkLS7/Lk97QexfWQV9TlA7SuNlnOxi657xJ8PgolNwkXC2a97cPWDbW7ltj3zvEcrxhFZ1rY
9PZtK7WHs3KMaR52Tw4zEPbn4FKq87Mw3/aWd0XutgOnB9N6tEsJGMIfzw+P/k6B29914+2lk/qL
TlUsTC7NYVXwRaW/+/kh0as9/xXZHCNxhOWV88tW9A5ml4tlLbWLEcjbS6H2QUUXyXRjKXKm+eIr
DaG9wgwxRifkPNIrVY6nVsKcJcygmpORY8UjV8Aw2BkGvsYdY8D/Xf8mY9z9smu51mC7y0WpHd8V
JNBVrUNfWKvHXumC+juCfxqgREZjtGOScCXvrYFQ5HDF91URd64z4BRdvA73415z1petx0zP7qXW
S5tNPC1Yj+1yUNBDHlYGR4Q9qbnLjkAeg9liYY4oTE6HrIZJuaK9hGNszO+emquOTYUkWkQPuEgZ
htNoK4iSRFhwb2hgcHInboN7eaftVWpCOA98FZQmqQ/jyNXB6I9e6+9izHwdskg7Cuang40Jt2mN
qeU/5qbHEeCSvv3M/ca7Kl02n8EHnNQn/Atl2m==