<?php
/* ********************************************************************************
 * The content of this file is subject to the VTFarsi.ir Modules License("License");
 * You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is VTFarsi.ir
 * Portions created by VTFarsi.ir. are Copyright(C) VTFarsi Team
 * All Rights Reserved.
 * ****************************************************************************** */
$languageStrings = array(
    'RoomsMessages' => 'پیام های تالار گفتگو',
    'LBL_MODULE_MANAGER' => 'مدیریت ماژول',
    'LBL_FOLDERS_AND_FILES' => 'فولدرها و فایل ها',
    'LBL_QUERIES_STATEMENT' => 'کوئری ها',
    'LBL_UNINSTALL' => 'حذف',

);
$jsLanguageStrings = array(
    
);
