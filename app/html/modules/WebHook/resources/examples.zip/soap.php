<?php
$Vtiger_Utils_Log = true;
include_once 'includes/Loader.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/runtime/EntryPoint.php';
include_once 'include/Webservices/Create.php';
include_once 'include/utils/utils.php';
if (file_exists("modules/ParsVT/V2/Webservices/Create.php"))
    include_once "modules/ParsVT/V2/Webservices/Create.php";


// ایجاد رکورد تستی جهت استفاده در وب هوک
$current_user = Users::getActiveAdminUser();
$moduleName = 'Contacts';
$element['firstname'] = 'پارس';
$element['lastname'] = 'ویتایگر';
$element['email'] = 'parsvtiger@gmail.com';
$element['phone'] = '09138086200';
$element['assigned_user_id'] = vtws_getWebserviceEntityId('Users', $current_user->id);
if (function_exists('vtws_parsvt_create'))
    $entity = vtws_parsvt_create($moduleName, $element, $current_user);
else
    $entity = vtws_create($moduleName, $element, $current_user);


echo '<pre>';
echo 'گرفتن لیست متدهای یک آدرس wsdl ';
echo '<br />';
$var = WebHook_API_Helper::checkSoapURL('http://www.dneonline.com/calculator.asmx?wsdl','1.2');
print_r($var);
echo '<br />';
echo '<br />';

echo 'گرفتن پارامترهای متد یک آدرس wsdl ';
echo '<br />';
echo 'نام متد Add  ';
echo '<br />';
$var = WebHook_API_Helper::getSoapFunctionParams('http://www.dneonline.com/calculator.asmx?wsdl','Add', '1.1');
print_r($var);


echo 'فراخوانی متد یک آدرس wsdl ';
echo '<br />';
echo 'نام متد Add جهت جمع دو عدد';
echo '<br />';

//بدنه درخواست
$requestParams = array(
    'url' => 'http://www.dneonline.com/calculator.asmx?wsdl',
    'method' => 'post',
    'type' => 'soap',
    'authentication' => 'NO',
    'username' => false,
    'password' => false,
    'timeout' => 30,
    'function' => 'Add',
    'soap_version' => 'Auto', //Auto - 1.2 - 1.1 - 1.0
);
// بدنه در خواست براساس فیلدهای وب سرویس
// این بدنه از متد getSoapFunctionParams نیز قابل خواندن است
$bodyParameters = array(
    'intA' => 5,
    'intB' => 6,
);

//در صورتی که پارامتری برای این موضوع نداریم مقدار را به صورت یک آرایه خالی ارسال می کنیم
$headerParameters = array(
    //'requestkey' =>    'hello world'  // پارامترهای مورد نیاز در هدر در صورت نیاز
);
// wsid میتواند خالی باشد و تنها زمانی که می خواهیم با یک رکورد مرتبط شود آن را به صورت شناسه وب سرویس رکورد وارد می کنیم
//update_mapping جهت بروزرسانی پاسخ دریافتی در وب سرویس در رکورد مرتبط استفاده می شود
$record = array(
    'wsid' =>  vtws_getWebserviceEntityId($moduleName, $entity['id']),
    'update_mapping' => array(
        array(
            'fieldname' => 'description', // نام فیلد در ماژول فرصت فروش
            'value' => '[AddResult]'  // پاسخی که باید در فیلد توضیحات ذخیره شود
    )
    ),
);

$var = WebHook_API_Helper::sendRequest($requestParams, $bodyParameters, $headerParameters, $record);
print_r($var);