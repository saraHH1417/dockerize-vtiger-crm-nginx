<?php
$Vtiger_Utils_Log = true;
include_once 'includes/Loader.php';
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/runtime/EntryPoint.php';
include_once 'include/Webservices/Create.php';
include_once 'include/utils/utils.php';
if (file_exists("modules/ParsVT/V2/Webservices/Create.php"))
    include_once "modules/ParsVT/V2/Webservices/Create.php";

// ایجاد رکورد تستی جهت استفاده در وب هوک
$current_user = Users::getActiveAdminUser();
$moduleName = 'Contacts';
$element['firstname'] = 'پارس';
$element['lastname'] = 'ویتایگر';
$element['email'] = 'parsvtiger@gmail.com';
$element['phone'] = '09138086200';
$element['assigned_user_id'] = vtws_getWebserviceEntityId('Users', $current_user->id);
if (function_exists('vtws_parsvt_create'))
    $entity = vtws_parsvt_create($moduleName, $element, $current_user);
else
    $entity = vtws_create($moduleName, $element, $current_user);

echo '<pre>';
echo 'فراخوانی متد rest ';
echo '<br />';
$requestParams = array(
    'url' => 'https://reqres.in/api/users',
    'method' => 'get',
    'type' => 'form',
    'authentication' => 'NO',
    'username' => false,
    'password' => false,
    'token' => false,
    'ssl' => false,
    'timeout' => 30,
);
$bodyParameters = array(
    'page' => 1,
);
$headerParameters = array(
	//'requestkey' =>    'hello world'
);
$record = array(
    'wsid' =>  $entity['id'],
    'update_mapping' => array(
        array(
            'fieldname' => 'firstname',
            'value' => '[data][0][first_name]'
        ),
        array(
            'fieldname' => 'lastname',
            'value' => '[data][0][last_name]'
        ),
    ),
);

$var = WebHook_API_Helper::sendRequest($requestParams, $bodyParameters, $headerParameters, $record);
print_r($var);